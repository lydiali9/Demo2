import Vue from 'vue';
import Router from 'vue-router';
import Login from '@/components/main/Login';
import Register from '@/components/main/Register';
import Home from '@/components/main/Home';
import RetrievePwd from '@/components/main/RetrievePwd';

import Index from '@/components/home/index';
import Promote from '@/components/promote/promote';
import Create from '@/components/promote/create';
import Advert from '@/components/promote/advert';
import AdEdit from '@/components/promote/adEdit';
import Material from '@/components/tool/material';
import Application from '@/components/tool/application';
import Package from '@/components/tool/package';
import Report from '@/components/report/report';
import ProgramEffect from '@/components/report/programEffect';
import AdEffect from '@/components/report/adEffect';
import UserInfo from '@/components/account/userInfo';
import Financial from '@/components/financial/financial';

Vue.use(Router)

export default new Router({
    routes: [
        {
            path: '/',
            component: Login
        },
        {
            path: '/login',
            component: Login
        },
        {
            path: '/register',
            component: Register
        },
        {
            path: '/retrievePwd',
            component: RetrievePwd
        },
        {
            path: '/home',
            component: Home,
            children: [
                {
                    path: '/index',
                    component: Index,
                },
                {
                    path: '/promote',
                    component: Promote,
                },
                {
                    path: '/create',
                    name: 'create',
                    component: Create
                },
                {
                    path: '/advert',
                    component: Advert
                },
                {
                    path: '/adEdit',
                    name: 'adEdit',
                    component: AdEdit
                },
                {
                    path: '/material',
                    component: Material
                },
                {
                    path: '/application',
                    component: Application
                },
                {
                    path: '/package',
                    component: Package
                },
                {
                    path: '/report',
                    component: Report
                },
                {
                    path: '/programEffect',
                    component: ProgramEffect
                },
                {
                    path: '/AdEffect',
                    component: AdEffect
                },
                {
                    path: '/userInfo',
                    component: UserInfo
                },
                {
                    path: '/financial',
                    component: Financial
                }
            ]
        }
    ]
})