import Vue from 'vue'
import Vuex from 'vuex'
import user from './modules/user'

Vue.use(Vuex)

const baseUrl = process.env.SERVER_URL;

export default new Vuex.Store({
    modules: {
        user,
    },
    state: {
        // login
        login: baseUrl + 'login',
        logout: baseUrl + 'logout',
        getCode: baseUrl + 'email/verificationCode/send',
        findPwd: baseUrl + 'email/findPwd/send',
        register: baseUrl + 'register',
        getUserInfo: baseUrl + 'userInfo',
        resetPwd: baseUrl + 'resetPwd',

        // promote
        create: baseUrl + 'promotion',
        edit: baseUrl + 'promotion',
        getPromote: baseUrl + 'promotion',
        getPromotebyId: baseUrl + 'promotion/id',
        changeStatus: baseUrl + 'promotion/status',
        queryPromote: baseUrl + 'promotion/list',
        
        getAdver: baseUrl + 'ad',
        createAd: baseUrl + 'ad',
        editAd: baseUrl + 'ad',
        getAdvertById: baseUrl + 'ad/id',
        getApplist: baseUrl + 'app/list',
        changeAdStatus: baseUrl + 'ad/status',
        queryAd: baseUrl + 'ad/list',

        imgUpload: baseUrl + 'image/upload',

        // home
        account: baseUrl + 'account',
        getAdReportDaily: baseUrl + 'adReportDaily',
        getAdReportHourly: baseUrl + 'adReportHourly',
        auditFail: baseUrl + 'ad/auditFail',

        // tool
        getPackage: baseUrl + 'orientation',
        createPackage: baseUrl + 'orientation',
        delPackage: baseUrl + 'orientation',
        editPackage: baseUrl + 'orientation',
        getPackagelist: baseUrl + 'orientation/list',
        getOrientationById: baseUrl + 'orientation/id',

        getApplication: baseUrl + 'app',
        fileUpload: baseUrl + 'app/upload',
        createApp: baseUrl + 'app',
        editApp: baseUrl + 'app',
        delApp: baseUrl + 'app',

        getImages: baseUrl + 'image',
        createMaterial: baseUrl + 'image',

        // account
        getAccountFlow: baseUrl + 'accountFlowReport'
    },

})
