const user = {
    state: {
        menus: []
    },

    mutations: {
        handleMenus: (state, data) => {
            state.menus = data;
            localStorage.setItem("menu_list", JSON.stringify(data));
        }
    }
}

export default user
