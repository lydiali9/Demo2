<template>
    <div class="application-container">
        <el-row class="selection">
            <el-form :inline="true" :model="formInline" ref="formInline" class="demo-form-inline">
                <el-form-item label="创建时间" prop="createTime">
                    <div class="grid-content bg-create time">
                        <el-date-picker :clearable="false" size="middle" v-model="formInline.createTime" type="daterange" align="right"unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerCreateTime" @change="handleCreateTime">
                        </el-date-picker>
                    </div>
                </el-form-item>

                <el-form-item prop="appType">
                    <el-select v-model="formInline.appType" filterable placeholder="请选择应用类型" @change="search">
                        <el-option v-for="item in appTypeListFirst" :key="item.value" :label="item.label" :value="item.value">
                                </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item prop="name">
                    <div class="grid-content bg-create word">
                        <el-input placeholder="应用名称模糊查询" v-model="formInline.name" class="input-with-select" @keyup.enter.native="search" clearable>
                            <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
                        </el-input>
                    </div>
                </el-form-item>

                <el-form-item>
                    <div class="grid-content bg-create word">
                        <el-button class="dsp-botton" @click="handleEdit(-1)" align="middle">新建应用</el-button>
                    </div>
                </el-form-item>
            </el-form>
        </el-row>

        <el-row class="select tables">
            <el-table :data="tableData" border style="width: 100%" class="tabs">
                <el-table-column prop="id" sortable label="编号" width="200"></el-table-column>
                <el-table-column prop="name" label="应用名称" width="240"></el-table-column>
                <el-table-column prop="appType" label="应用类型" width="170">
                    <template slot-scope="scope">
                        <p>{{appTypeListFirst[scope.row.appType].label}}</p>
                    </template>
                </el-table-column>
                <el-table-column prop="os" label="系统平台" width="170">
                    <template slot-scope="scope">
                        <p>{{osList[parseInt(scope.row.os) - 1].label}}</p>
                    </template>
                </el-table-column>
                <el-table-column prop="package" label="APK包名称" width="380"></el-table-column>
                <el-table-column prop="createTime" sortable label="创建时间" width="220"></el-table-column>
                <!-- <el-table-column prop="status" label="审核状态" width="180">
                    <template slot-scope="scope">
                        <el-tag type="warning" v-if="scope.row.status == 0">待审核</el-tag>
                        <el-tag type="success" v-else-if="scope.row.status == 1">审核通过</el-tag>
                        <el-tag type="danger" v-else>审核未通过</el-tag>
                    </template>
                </el-table-column> -->
                <el-table-column label="操作" width="200">
                    <template slot-scope="scope">
                        <el-button size="mini" @click="handleEdit(scope.row)">
                            编辑
                        </el-button>
                        <el-button @click.native.prevent="deleteRow(scope.row)"
                            type="danger" size="mini">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <div class="tables">
                <el-pagination class="tabs" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPageNo" :page-sizes="sizes" :page-size="eachPageCapacity" layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
                </el-pagination>
            </div>
        </el-row>

        <el-dialog class="dialog" title="编辑应用" :visible.sync="dialogFormVisible" width="32%" :close-on-click-modal="false" @close="handleClose">
            <el-form ref="form" :model="form" :rules="formRules">
                <el-form-item label="应用类型" prop="appType" label-width="85px">
                    <el-select v-model="form.appType" filterable placeholder="请选择应用类型">
                        <el-option v-for="item in appTypeList" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item label="应用名称" prop="name" label-width="85px">
                    <el-row :gutter="20">
                        <el-col :span="14" style="padding: 0">
                            <div class="grid-content">
                                <el-input v-model="form.name"></el-input>
                            </div>
                        </el-col>
                        <el-col :span="10"></el-col>
                    </el-row>
                </el-form-item>

                <el-form-item label="系统平台" prop="os" label-width="85px">
                    <el-radio-group v-model="form.os" :disabled="idEditDisabled">
                        <el-radio v-for="item in osList" :key="item.value" :label="item.value" :value="item.value">{{item.label}}</el-radio>
                    </el-radio-group>
                </el-form-item>

                <el-form-item label="地址类型" prop="urlType" label-width="85px">
                    <el-select v-model="form.urlType" placeholder="请选择地址类型" :disabled="idEditDisabled">
                        <el-option v-for="item in urlTypeList" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item label="选择应用" v-if="form.urlType == 1" label-width="85px" required>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <el-upload ref="upload" class="upload-demo"
                                    with-credentials="true"
                                    :action="fileUpload"
                                    :before-upload="beforeAvatarUpload"
                                    :on-success="uploadSuccess"
                                    :file-list="fileList"
                                    :limit="1"
                                    :on-exceed="handleExceed"
                                    :on-remove="handleRemove"
                                    :disabled="idEditDisabled">
                                <el-button slot="trigger" size="small" type="primary">选择应用</el-button>
                            </el-upload>
                        </el-col>
                    </el-row>
                </el-form-item>

                <el-form-item label="链接地址" prop="url" v-else label-width="85px" required>
                    <el-row :gutter="20">
                        <el-col :span="14" style="padding: 0">
                            <div class="grid-content">
                                <el-input v-model="form.url" :disabled="idEditDisabled"></el-input>
                            </div>
                        </el-col>
                        <el-col :span="10"></el-col>
                    </el-row>
                </el-form-item>

                <el-form-item label="应用版本" prop="version" v-if="form.urlType == 1" label-width="85px">
                    <el-row :gutter="20">
                        <el-col :span="14" style="padding: 0">
                            <div class="grid-content">
                                <el-input v-model="form.version" disabled></el-input>
                            </div>
                        </el-col>
                        <el-col :span="10"></el-col>
                    </el-row>
                </el-form-item>
                <el-form-item label="APK包名称" prop="package" v-if="form.urlType == 1" label-width="85px">
                    <el-row :gutter="20">
                        <el-col :span="14" style="padding: 0">
                            <div class="grid-content">
                                <el-input v-model="form.package" disabled></el-input>
                            </div>
                        </el-col>
                        <el-col :span="10"></el-col>
                    </el-row>
                </el-form-item>

                <el-form-item label="上传图标" v-if="0" label-width="85px">
                    <div class="center">
                        <div class="user">
                            <img class="avatar" :src="srcIcon"/>
                        </div>
                        <vue-core-image-upload
                            crop-ratio="4:3"
                            class="btn btn-primary"
                            crop="true"
                            :url="imgUpload"
                            inputAccept="image/*"
                            extensions="png,jpg,gif"
                            text=""
                            compress="20"
                            @imageuploaded="iconUploaded">
                        </vue-core-image-upload>
                    </div>
                </el-form-item>

                <el-form-item label="应用截图" v-if="0" label-width="85px">
                    <div class="center">
                        <div class="user">
                            <img class="avatar" :src="srcImg"/>
                        </div>
                        <vue-core-image-upload
                            crop-ratio="4:3"
                            class="btn btn-primary"
                            crop="true"
                            :url="imgUpload"
                            inputAccept="image/*"
                            extensions="png,jpg,gif"
                            text=""
                            compress="20"
                            @imageuploaded="imgUploaded">
                        </vue-core-image-upload>
                    </div>
                </el-form-item>

                <el-form-item label="应用描述" prop="description" label-width="85px">
                    <el-row :gutter="20">
                        <el-col :span="14" style="padding: 0">
                            <div class="grid-content">
                                <el-input type="textarea" :autosize="{ minRows: 3, maxRows: 6}" v-model="form.description"></el-input>
                            </div>
                        </el-col>
                        <el-col :span="10"></el-col>
                    </el-row>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancle('form')">取 消</el-button>
                <el-button type="primary" @click="submit('form')">确 定</el-button>
            </div>
        </el-dialog>

    </div>
</template>

<script>
import VueCoreImageUpload from 'vue-core-image-upload'

export default {
    components: {
        VueCoreImageUpload
    },

    data() {
        var validateUrl = (rule, value, callback) => {
            if(parseInt(this.form.urlType) == 2) {
                if (!value) {
                    callback(new Error('请输入链接地址'));
                } else {
                    var reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
                    if (!reg.test(this.form.linkUrl)) {
                        callback(new Error('请输入正确链接地址'));
                    }
                    callback();
                }
            }
        };

        return {
            formInline: {
                createTime: '',
                name: '',
                appType: ''
            },
            appTypeListFirst: [
                {
                    value: '',
                    label: '应用类型(不限)'
                },
                {
                    value: '1',
                    label: '社交沟通'
                },
                {
                    value: '2',
                    label: '休闲娱乐'
                },
                {
                    value: '3',
                    label: '报刊杂志'
                },
                {
                    value: '4',
                    label: '新闻资讯'
                },
                {
                    value: '5',
                    label: '图像音乐视频'
                },
                {
                    value: '6',
                    label: '工具'
                },
                {
                    value: '7',
                    label: '生活助手'
                },
                {
                    value: '8',
                    label: '金融理财'
                },
                {
                    value: '9',
                    label: '教育学习'
                },
                {
                    value: '10',
                    label: '其他'
                },
                {
                    value: '11',
                    label: '系统安全'
                },
                {
                    value: '12',
                    label: '通讯社交'
                },
                {
                    value: '13',
                    label: '视频影音'
                },
                {
                    value: '14',
                    label: '新闻阅读'
                },
                {
                    value: '15',
                    label: '生活休闲'
                },
                {
                    value: '16',
                    label: '主题壁纸'
                },
                {
                    value: '17',
                    label: '办公商务'
                },
                {
                    value: '18',
                    label: '摄影摄像'
                },
                {
                    value: '19',
                    label: '购物优惠'
                },
                {
                    value: '20',
                    label: '地图旅游'
                },
                {
                    value: '21',
                    label: '教育学习'
                },
                {
                    value: '22',
                    label: '金融理财'
                },
                {
                    value: '23',
                    label: '医疗健康'
                }
            ],
            pickerCreateTime: {
                shortcuts: [{
                    text: '今天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime());
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '昨天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '本周',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(start.getTime() + 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            dialogFormVisible: false,
            editedIndex: -1,
            tableData: [],
            currentPageNo: 1,
            eachPageCapacity: 10,
            totalCount: 1,
            sizes: [10, 25, 50, 100, 200],
            form: {
                appType: '',
                name: '',
                os: '',
                urlType: '',
                url: '',
                description: '',
                version: '',
                package: '',
                packageSize: '',
                folder: '',
                id: ''
            },
            formRules: {
                name: [
                    { required: true, message: '请输入名称', trigger: 'change' },
                    { min: 1, max: 10, message: '长度在10个字符以内', trigger: 'blur' }
                ],
                appType: [
                    { required: true, message: '请选择应用类型', trigger: 'change' }
                ],
                os: [
                    { required: true, message: '请选择系统平台', trigger: 'change' }
                ],
                urlType: [
                    { required: true, message: '请选择地址类型', trigger: 'change' }
                ],
                url: [
                    { validator: validateUrl, trigger: 'blur' }
                ],
                description: [
                    { min: 0, max: 100, message: '长度在100个字符以内', trigger: 'blur' }
                ]
            },
            appTypeList: [
                {
                    value: '1',
                    label: '社交沟通'
                },
                {
                    value: '2',
                    label: '休闲娱乐'
                },
                {
                    value: '3',
                    label: '报刊杂志'
                },
                {
                    value: '4',
                    label: '新闻资讯'
                },
                {
                    value: '5',
                    label: '图像音乐视频'
                },
                {
                    value: '6',
                    label: '工具'
                },
                {
                    value: '7',
                    label: '生活助手'
                },
                {
                    value: '8',
                    label: '金融理财'
                },
                {
                    value: '9',
                    label: '教育学习'
                },
                {
                    value: '10',
                    label: '其他'
                },
                {
                    value: '11',
                    label: '系统安全'
                },
                {
                    value: '12',
                    label: '通讯社交'
                },
                {
                    value: '13',
                    label: '视频影音'
                },
                {
                    value: '14',
                    label: '新闻阅读'
                },
                {
                    value: '15',
                    label: '生活休闲'
                },
                {
                    value: '16',
                    label: '主题壁纸'
                },
                {
                    value: '17',
                    label: '办公商务'
                },
                {
                    value: '18',
                    label: '摄影摄像'
                },
                {
                    value: '19',
                    label: '购物优惠'
                },
                {
                    value: '20',
                    label: '地图旅游'
                },
                {
                    value: '21',
                    label: '教育学习'
                },
                {
                    value: '22',
                    label: '金融理财'
                },
                {
                    value: '23',
                    label: '医疗健康'
                }
            ],
            osList: [
                {
                    value: '1',
                    label: 'android'
                },
                {
                    value: '2',
                    label: 'ios'
                }
            ],
            urlTypeList: [
                {
                    value: '1',
                    label: '自有地址'
                },
                {
                    value: '2',
                    label: '第三方提供地址 '
                }
            ],
            percentage: 0,
            imgUpload: '',
            srcIcon: '../../../src/assets/images/tool/add.png',
            srcImg: '../../../src/assets/images/tool/add.png',
            fileUpload: this.$store.state.fileUpload,
            fileList: [],
            list: null,
            isDisabled: false,
            idEditDisabled: false,
            appUrl: ''
        }
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.fileList = [];
            this.imgUpload = this.$store.state.imgUpload;
            this.fileUpload = this.$store.state.fileUpload;

            this.formInline.appType = this.appTypeListFirst[0].value;
            this.initCreateTime();
            this.getInfo();
        },

        handleExceed(files, fileList) {
            if(fileList.length == 1) {
                this.$message({
                    showClose: true,
                    type: 'warning',
                    message: '只能上传一个应用包'
                });
            }
            return false;
        },

        handleClose() {
            this.cancle('form');
        },

        initCreateTime() {
            let date = new Date();
            this.formInline.createTime = [date.getTime() - 3600 * 1000 * 24 * 14, date.getTime()];
        },

        handleCreateTime() {
            if(!!this.formInline.createTime) {
                let utc = this.formInline.createTime[1] - this.formInline.createTime[0];
                let day = utc / (24 * 60 * 60 * 1000);

                if(parseInt(day) > 30) {
                    this.$message({
                        showClose: true,
                        type: 'warning',
                        message: '创建时间不能超过30天'
                    });
                    this.initCreateTime();
                    return false;
                }

                return this.getInfo();
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写创建时间范围'
                });
                return false;
            }
        },

        handleSizeChange(val) {
            this.eachPageCapacity = val;
            this.getInfo();
        },

        handleCurrentChange(val) {
            this.currentPageNo = val;
            this.getInfo();
        },

        handleEdit(val) {
            this.dialogFormVisible = true;
            this.fileList = [];

            if(val == -1) {
                this.editedIndex = -1;
                this.isDisabled = false;
                this.idEditDisabled = false;
                this.form.appType = this.appTypeList[0].value;
                this.form.os = this.osList[0].value;
                this.form.urlType = this.urlTypeList[0].value;
            } else {
                this.editedIndex = 1;
                this.isDisabled = true;
                this.idEditDisabled = true;
                this.form.appType = this.appTypeList[parseInt(val.appType) - 1].value;
                this.form.name = val.name;
                this.form.os = this.osList[parseInt(val.os) - 1].value;
                this.form.urlType = this.urlTypeList[parseInt(val.urlType) - 1].value;
                this.form.url = val.url;
                this.form.description = val.description;
                this.form.version = val.version;
                this.form.package = val.package;
                this.form.packageSize = val.packageSize;
                this.form.folder = val.folder;
                this.form.id = val.id;

                if(val.appType == '1') {
                    this.fileList.push({
                        name: val.name,
                        appPackage: val.appPackage,
                        packageSize: val.packageSize,
                        url: val.url,
                        version: val.version
                    })
                    this.appUrl = val.url;
                } else {
                    this.form.url = val.url;
                }
                this.form.description = val.description;
            }
        },

        deleteRow(val) {
            this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.removeItem({id: val.id})
                    .then(res => {
                        if(res.code == '200') {
                            this.getInfo();

                            this.$message({
                                showClose: true,
                                type: 'success',
                                message: "成功删除该项"
                            });
                        } else {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: res.message
                            });
                        }
                    })
                    .catch(err => {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: err
                        });
                    });
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },

        removeItem(param) {
            return new Promise((resolve, reject) => {
                this.$request.delete(this.$store.state.delApp, param)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        search() {
            this.getInfo();
        },

        cancle(formName) {
            this.$refs[formName].resetFields();
            this.dialogFormVisible = false;
            this.isDisabled = false;
            this.idEditDisabled = false;
            this.fileList = [];
            this.form = {
                appType: '',
                name: '',
                os: '',
                urlType: '',
                url: '',
                description: '',
                version: '',
                package: '',
                packageSize: '',
                folder: '',
                id: ''
            };
            return true;
        },

        submit(formName) {
            this.$refs[formName].validate(valid => {
                if(valid) {
                    if(this.editedIndex == -1) {
                        this.createApp();
                    } else {
                        this.editApp();
                    }
                } else {
                    console.log('Fail to validate the form data');
                }
            });
        },

        formatForm() {
            let params = {
                folder: this.list && this.list.folder ? this.list.folder : '',
                package: this.list && this.list.package ? this.list.package : '',
            }

            let url = this.form.urlType == '1' ? this.appUrl : this.form.url;
            this.$set(this.form, 'url', url);
            return Object.assign(params, this.form);
        },

        create() {
            let parmas = this.formatForm();

            return new Promise((resolve, reject) => {
                this.$request.post(this.$store.state.createApp, parmas)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        edit() {
            let parmas = this.formatForm();

            return new Promise((resolve, reject) => {
                this.$request.put(this.$store.state.editApp, parmas)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        editApp() {
            this.edit()
                .then(res => {
                    let data = res.data;

                    if(res.code == '200') {
                        this.getInfo();
                        this.dialogFormVisible = false;

                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "编辑应用成功"
                        });
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                    this.cancle('form');
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    this.cancle('form');
                });
        },

        createApp() {
            this.create()
                .then(res => {
                    let data = res.data;

                    if(res.code == '200') {
                        this.getInfo();
                        this.dialogFormVisible = false;

                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "新建应用成功"
                        });
                    } else if(res.code == '400') {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "无效的链接地址"
                        });
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                    this.cancle('form');
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    this.cancle('form');
                });
        },

        getInfo() {
            this.tableData = [];

            if(!this.formInline.createTime) {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写创建时间范围'
                });
                return false;
            }

            this.getApplication()
                .then(res => {
                    if(res.code == '200') {
                        if(res.data && res.data.length > 0) {
                            let list = {};

                            res.data.forEach(item => {
                                this.tableData.push(item);
                            });
                        }
                        this.totalCount = res.page.totalCount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取数据失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getApplication() {
            return new Promise((resolve, reject) => {
                let params = {
                    name: this.formInline.name,
                    startTime: this.$utils.formatDate(new Date(this.formInline.createTime[0]), "yyyy-MM-dd"),
                    endTime: this.$utils.formatDate(new Date(this.formInline.createTime[1]), "yyyy-MM-dd"),
                    eachPageCapacity: this.eachPageCapacity,
                    currentPageNo: this.currentPageNo,
                    appType: this.formInline.appType
                }

                this.$request.get(this.$store.state.getApplication, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        iconUploaded(res) {
            if(res.code == '200') {
                if (res.data.url) {
                    console.log(res.data.url);

                    let cropArgs = {
                        toCropImgH: parseInt(res.data.srcParams.h),
                        toCropImgW: parseInt(res.data.srcParams.w),
                        toCropImgX: parseInt(res.data.srcParams.x),
                        toCropImgY: parseInt(res.data.srcParams.y),
                        name: res.data.name,
                        height: res.data.height,
                        width: res.data.width,
                        url: res.data.url,
                        title: '',
                        id: '',
                        folder: res.data.folder,
                        format: res.data.format,
                        ratio: res.data.ratio
                    }
                    this.imgList.push(cropArgs);
                    console.log(this.imgList);

                    this.$message({
                        showClose: true,
                        type: 'success',
                        message: "上传图片成功"
                    });
                }
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: res.message
                });
            }
        },

        imgUploaded(res) {
            if(res.code == '200') {
                if (res.data.url) {
                    console.log(res.data.url);

                    let cropArgs = {
                        toCropImgH: parseInt(res.data.srcParams.h),
                        toCropImgW: parseInt(res.data.srcParams.w),
                        toCropImgX: parseInt(res.data.srcParams.x),
                        toCropImgY: parseInt(res.data.srcParams.y),
                        name: res.data.name,
                        height: res.data.height,
                        width: res.data.width,
                        url: res.data.url,
                        title: '',
                        id: '',
                        folder: res.data.folder,
                        format: res.data.format,
                        ratio: res.data.ratio
                    }
                    this.imgList.push(cropArgs);
                    console.log(this.imgList);

                    this.$message({
                        showClose: true,
                        type: 'success',
                        message: "上传图片成功"
                    });
                }
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: res.message
                });
            }
        },

        beforeAvatarUpload(file) {
            this.isDisabled = true;
        },

        uploadSuccess(res, file, fileList) {
            if(res.code == 200) {

                this.list = res.data;
                this.fileList = fileList;
                this.form.version = res.data.version;
                this.form.package = res.data.package;
                this.form.packageSize = res.data.packageSize;
                this.form.folder = res.data.folder;
                this.appUrl = res.data.url;

                this.$message({
                    showClose: true,
                    type: 'success',
                    message: "上传应用成功"
                });
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: "上传应用失败"
                });
            }
        },

        handleRemove(file, fileList) {
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .application-container {
        height: auto;
        background-color: $white;
        box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

        .select {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            padding: 0 20px;
            margin: 0 0 15px !important;
        }

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }

        .tables {
            padding: 25px 30px 0;
        }

        .el-row {
            &:last-child {
              margin-bottom: 0;
            }
        }

        .el-col {
            border-radius: 4px;
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-create {
                margin: 19px 0;
            }

            .dsp-botton {
                @include green-botton;
            }

            .dsp-botton-gray {
                @include gray-botton;
            }
        }

        .grid-word {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .word {
                align-self: center;
            }
        }

        .grid-time {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .time {
                align-self: center;
            }
        }

        .dsp-botton-red {
            @include red-botton;
        }

        .tabs {
            padding: 25px 0;
            float: right;
        }

        .center {
            height: 170px;
        }

        .g-core-image-upload-btn {
            top: -185px;
            height: 170px;
            width: 170px;
            left: 70px;
        }

        /* .upload{
            padding: 4px 10px;
            height: 30px;
            line-height: 30px;
            position: relative;
            border: 1px solid green;
            text-decoration: none;
            color: #666;
            border-radius: 4px;
            background: green;
            color: #fff;
        }

        .change{
            position: absolute;
            overflow: hidden;
            right: 0;
            top: 0;
            opacity: 0;
        } */

        .el-progress {
            margin-top: 6px !important;
        }

        .demo-form-inline {
            height: 100%;
            width: 100%;

            .el-form-item:not(:first-child) {
                margin: 22px 10px !important;
            }

            .el-form-item:first-child {
                margin: 22px 10px 22px 30px !important;
            }
        }
    }
</style>
