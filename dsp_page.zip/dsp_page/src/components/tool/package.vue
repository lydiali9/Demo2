<template>
    <div class="package-container">
        <el-row class="selection">
            <el-form :inline="true" :model="formInline" ref="formInline" class="demo-form-inline">
                <el-form-item label="创建时间" prop="deliverTime">
                    <div class="grid-content bg-create time">
                        <el-date-picker :clearable="false" size="middle" v-model="formInline.createTime" type="daterange" align="right"unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerDeliverTime" @change="handleCreateTime">
                        </el-date-picker>
                    </div>
                </el-form-item>

                <el-form-item prop="promotionId">
                    <div class="grid-content bg-create word">
                        <el-input placeholder="名称、描述模糊查询" v-model="formInline.keyword" class="input-with-select" @keyup.enter.native="search" clearable>
                            <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
                        </el-input>
                    </div>
                </el-form-item>

                <el-form-item>
                    <div class="grid-content bg-create word">
                        <el-button class="dsp-botton" @click="handleEdit(-1)" align="middle">新建定向包</el-button>
                    </div>
                </el-form-item>
            </el-form>
        </el-row>

        <el-row class="select tables"> 
            <el-table :data="tableData" border style="width: 100%" class="tabs">
                <el-table-column prop="id" sortable label="编号"></el-table-column>
                <el-table-column prop="title" label="定向包名称"></el-table-column>
                <!-- <el-table-column prop="des" label="定向包描述" width="460"></el-table-column> -->
                <el-table-column prop="createTime" sortable label="创建时间"></el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button size="mini" @click="handleEdit(scope.row)">
                            编辑
                        </el-button>
                        <el-button @click.native.prevent="deleteRow(scope.row)"
                            type="danger" size="mini">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <div class="tables">
                <el-pagination class="tabs" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPageNo" :page-sizes="sizes" :page-size="eachPageCapacity" layout="total, sizes, prev, pager, next, jumper" 
                :total="totalCount">
                </el-pagination>
            </div>
        </el-row>

        <el-dialog class="dialog" title="编辑定向包" :visible.sync="dialogFormVisible" width="45%" :close-on-click-modal="false" @close="handleClose">
            <el-form ref="form" :model="form" :rules="formRules">
                <el-form-item label="名称" prop="title" label-width="65px">
                    <el-row :gutter="20">
                        <el-col :span="14" style="padding: 0">
                            <div class="grid-content">
                                <el-input v-model="form.title"></el-input>
                            </div>
                        </el-col>
                        <el-col :span="10"></el-col>
                    </el-row>
                </el-form-item>

                <el-form-item label="地域" prop="areaType" label-width="65px">
                    <el-radio-group v-model="form.areaType" size="medium">
                        <el-radio-button v-for="item in areaList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                    </el-radio-group>
                </el-form-item>

                <el-form-item v-if="isShowArea" v-model="form.area">
                    <input readonly="readonly" id="area-list" class="area-duoxuan" :value="form.area" :data-value="form.area"></input>
                </el-form-item>

                <el-form-item label="性别" prop="sex" label-width="65px">
                    <el-radio-group v-model="form.sex" size="medium">
                        <el-radio-button v-for="item in sexList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                    </el-radio-group>
                </el-form-item>

                <el-form-item label="年龄" prop="age" label-width="65px">
                    <el-checkbox-group v-model="form.age" size="medium">
                        <el-checkbox-button v-for="item in ageItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-checkbox-button>
                    </el-checkbox-group>
                </el-form-item>

                <el-form-item label="平台" prop="platform" label-width="65px">
                    <el-radio-group v-model="form.platform" size="medium">
                        <el-radio-button v-for="item in platformItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-radio-button>
                    </el-radio-group>
                </el-form-item>
                
                <el-form-item label="网络" prop="network" label-width="65px">
                    <el-checkbox-group v-model="form.network" size="medium">
                        <el-checkbox-button v-for="item in networkItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-checkbox-button>
                    </el-checkbox-group>
                </el-form-item>

                <el-form-item label="运营商" prop="networkOperator">
                    <el-checkbox-group v-model="form.networkOperator" size="medium">
                        <el-checkbox-button v-for="item in networkOperatorItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-checkbox-button>
                    </el-checkbox-group>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancle('form')">取 消</el-button>
                <el-button type="primary" @click="submit('form')">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            formInline: {
                createTime: '',
                promotionId: '',
                appId: '',
                keyword: ''
            },
            tableData: [],
            currentPageNo: 1,
            eachPageCapacity: 10,
            totalCount: 1,
            sizes: [10, 25, 50, 100, 200],
            pickerDeliverTime: {
                shortcuts: [{
                    text: '今天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime());
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '昨天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '本周',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(start.getTime() + 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            dialogFormVisible: false,
            form: {
                userId: '',
                title: '',
                area: '',
                areaType: [],
                sex: '',
                age: [],
                platform: '',
                network: [],
                networkOperator: [],
                phoneBrand: [],
                isTemplate: 1,
                id: ''
            },
            formRules: {
                title: [
                    { required: true, message: '请输入名称', trigger: 'change' },
                    { min: 1, max: 20, message: '长度在20个字符以内', trigger: 'blur' }
                ],
                areaType: [
                    { required: true, message: '请选择地域', trigger: 'change' }
                ],
                sex: [
                    { required: true, message: '请选择性别', trigger: 'change' }
                ],
                age: [
                    { required: true, message: '请选择年龄', trigger: 'change' }
                ],
                platform: [
                    { required: true, message: '请选择平台', trigger: 'change' }
                ],
                network: [
                    { required: true, message: '请选择网络', trigger: 'change' }
                ],
                networkOperator: [
                    { required: true, message: '请选择运营商', trigger: 'change' }
                ]
            },
            isShowArea: false,
            ageItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: '0~18'
                },
                {
                    value: '2',
                    label: '18~23'
                },
                {
                    value: '3',
                    label: '24~30'
                },
                {
                    value: '4',
                    label: '31~40'
                },
                {
                    value: '5',
                    label: '41~49'
                },
                {
                    value: '6',
                    label: '50~100'
                }
            ],
            platformItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: 'ios'
                },
                {
                    value: '2',
                    label: 'android'
                }
            ],
            networkItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: 'wifi'
                },
                {
                    value: '2',
                    label: '2g'
                },
                {
                    value: '3',
                    label: '3g'
                },
                {
                    value: '4',
                    label: '4g'
                },
                {
                    value: '5',
                    label: '5g'
                }
            ],
            networkOperatorItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '70120',
                    label: '移动'
                },
                {
                    value: '70123',
                    label: '联通'
                },
                {
                    value: '70121',
                    label: '电信'
                }
            ],
            sexList: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: '男'
                },
                {
                    value: '2',
                    label: '女'
                }
            ],
            areaList: [
                {
                    value: '1',
                    label: '不限'
                },
                {
                    value: '2',
                    label: '按省市'
                }
            ],
            editedIndex: -1
        }
    },
    created() {
        this.init();
    },
    mounted() {
        this.$watch('form.areaType', this.areaType);
        this.$watch('form.age', this.age);
        this.$watch('form.network', this.network);
        this.$watch('form.networkOperator', this.networkOperator);
    },
    methods: {
        init() {
            this.initCreateTime();
            this.initCanlendar();
            this.getInfo();
        },

        handleClose() {
            this.cancle('form');
        },

        initCreateTime() {
            let date = new Date();
            this.formInline.createTime = [date.getTime() - 3600 * 1000 * 24 * 14, date.getTime()];
        },

        initCanlendar() {
            $('#target').weekly_schedule();
            $('.schedule').on('selectionmade', function() {
                console.log("Selection Made");
            }).on('selectionremoved', function() {
                console.log("Selection Removed");
            });
        },

        search() {
            this.getInfo();
        },

        create() {
            let parmas = this.formatForm();

            return new Promise((resolve, reject) => {
                this.$request.post(this.$store.state.createPackage, this.form)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        edit() {
            let parmas = this.formatForm();

            return new Promise((resolve, reject) => {
                this.$request.put(this.$store.state.editPackage, this.form)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        formatForm() {
            if(this.form.areaType == '2') {
                let areaList = [];
                let areaStr = $("#area-list").val();

                if(areaStr && areaStr.length > 0) {
                    areaList = areaStr.split("-");
                }
                this.form.area = areaList;
                console.log(this.form.area);
            }
        },
        createPackage() {
            this.create()
                .then(res => {
                    let data = res.data;

                    if(res.code == '200') {
                        this.getInfo();
                        this.dialogFormVisible = false;

                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "新建定向包成功"
                        });
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                    this.cancle('form');
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    this.cancle('form');
                });
        },

        editPackage() {
            this.edit()
                .then(res => {
                    let data = res.data;

                    if(res.code == '200') {
                        this.getInfo();
                        this.dialogFormVisible = false;

                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "编辑定向包成功"
                        });
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                    this.cancle('form');
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    this.cancle('form');
                });
        },

        submit(formName) {
            this.$refs[formName].validate(valid => {
                if(valid) {
                    if(this.editedIndex > -1) {
                        this.editPackage();
                    } else {
                        this.createPackage();
                    }
                } else {
                    console.log('Fail to validate the form data');
                }
            });
        },

        cancle(formName) {
            this.$refs[formName].resetFields();
            this.dialogFormVisible = false;
        },

        deleteRow(val) {
            this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.removeItem({id: val.id})
                    .then(res => {
                        if(res.code == '200') {
                            this.getInfo();
                            
                            this.$message({
                                showClose: true,
                                type: 'success',
                                message: "成功删除该项"
                            });
                        } else {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: res.message
                            });
                        }
                    })
                    .catch(err => {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: err
                        });
                    });
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },

        removeItem(param) {
            return new Promise((resolve, reject) => {
                this.$request.delete(this.$store.state.delPackage, param)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        handleEdit(val) {
            this.dialogFormVisible = true;

            if(val == -1) {
                this.form.areaType = this.areaList[0].value;
                this.form.sex = this.sexList[0].value;
                this.form.age = [this.ageItems[0].value];
                this.form.platform = this.platformItems[0].value;
                this.form.network = [this.networkItems[0].value];
                this.form.networkOperator = [this.networkOperatorItems[0].value];
            } else {
                this.editedIndex = 1;
                this.form.id = val.id;
                this.form.title = val.title;
                this.form.isTemplate = 1;
                this.form.sex = this.sexList[val.sex].value;
                this.renderArea(val.area);
                this.renderAge(val.age);
                this.form.platform = this.platformItems[val.platform].value;
                this.renderNetwork(val.network);
                this.renderRetworkOperator(val.networkOperator);
            }
        },

        renderRetworkOperator(networkOperators) {
            networkOperators = JSON.parse(networkOperators);

            if(networkOperators && networkOperators.length > 0) {
                let list = [];
                networkOperators.forEach(item => {
                    this.networkOperatorItems.forEach((networkOperator, index) => {
                        if(item == networkOperator.value) {
                            list.push(this.networkOperatorItems[index].value);
                        }
                    });
                });
                this.form.networkOperator = list;
            } else {
                this.form.networkOperator = [this.networkOperatorItems[0].value];
            }
        },

        renderNetwork(networks) {
            networks = JSON.parse(networks);
            if(networks && networks.length > 0) {
                let list = [];
                networks.forEach(item => {
                    this.networkItems.forEach((network, index) => {
                        if(item == network.value) {
                            list.push(this.networkItems[index].value);
                        }
                    });
                });
                this.form.network = list;
            } else {
                this.form.network = [this.networkItems[0].value];
            }
        },

        renderAge(ages) {
            ages = JSON.parse(ages);

            if(ages && ages.length > 0) {
                let list = [];
                ages.forEach(item => {
                    this.ageItems.forEach((age, index) => {
                        if(item == age.value) {
                            list.push(this.ageItems[index].value);
                        }
                    });
                });
                this.form.age = list;
            } else {
                this.form.age = [this.ageItems[0].value];
            }
        },

        renderArea(data) {
            if(!!data) {
                data = JSON.parse(data);

                if(data.length > 0) {
                    this.form.areaType = this.areaList[1].value;
                    this.setAreaList(data);
                } else {
                    this.form.areaType = this.areaList[0].value;
                    this.form.area = "";
                }
            }
        },

        setAreaList(areaList) {
            if(!!areaList) {
                this.form.area = areaList.join('-');

                setTimeout(() => {
                    $("input#area-list.area-duoxuan").data("value", this.form.area);
                    $("input#area-list.area-duoxuan").val(this.form.area);
                }, 6000);
            }
        },

        areaType(val) {
            switch(val) {
                case "2":
                    this.isShowArea = true;
                    break;
                default:
                    this.isShowArea = false;
            }
        },

        handleCheckBox(val, name) {
            if(val.length == 1 && val[0] == '0'){
                return true;
            }

            if(val.length > 0) {
                if(!val.includes('0')) {
                    return true
                } else {
                    if(val[val.length - 1] == '0') {
                        return this.form[name] = ['0'];
                    } else {
                        return this.form[name].splice(this.form[name].indexOf('0'), 1);
                    }
                }
            }
        },

        age(val) {
            this.handleCheckBox(val, 'age');
        },

        network(val) {
            this.handleCheckBox(val, 'network');
        },

        networkOperator(val) {
            this.handleCheckBox(val, 'networkOperator');
        },

        handleCreateTime() {
            if(!!this.formInline.createTime) {
                let utc = this.formInline.createTime[1] - this.formInline.createTime[0];
                let day = utc / (24 * 60 * 60 * 1000);

                if(parseInt(day) > 30) {
                    this.$message({
                        showClose: true,
                        type: 'warning',
                        message: '创建时间不能超过30天'
                    });
                    this.initCreateTime();
                    return false;
                }

                return this.getInfo();
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写创建时间范围'
                });
                return false;
            }
        },

        handleSizeChange(val) {
            this.eachPageCapacity = val;
            this.getInfo();
        },

        handleCurrentChange(val) {
            this.currentPageNo = val;
            this.getInfo();
        },

        getInfo() {
            this.tableData = [];

            if(!this.formInline.createTime) {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写创建时间范围'
                });
                return false;
            }

            this.getPackage()
                .then(res => {
                    if(res.code == '200') {
                        if(res.data && res.data.length > 0) {
                            let list = {};
                            if(res.data && res.data.length > 0)
                                this.tableData = res.data;
                        }
                        this.totalCount = res.page.totalCount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取数据失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getPackage() {
            return new Promise((resolve, reject) => {
                let params = {
                    keyword: this.formInline.keyword,
                    startTime: this.$utils.formatDate(new Date(this.formInline.createTime[0]), "yyyy-MM-dd"),
                    endTime: this.$utils.formatDate(new Date(this.formInline.createTime[1]), "yyyy-MM-dd"),
                    eachPageCapacity: this.eachPageCapacity,
                    currentPageNo: this.currentPageNo
                }

                this.$request.get(this.$store.state.getPackage, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .package-container {
        height: auto;
        background-color: $white;
        box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

        .select {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            padding: 0 20px;
            margin: 0 0 15px !important;
        }

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }

        .demo-form-inline {
            height: 100%;
            width: 100%;
            
            .el-form-item:not(:first-child) {
                margin: 22px 10px !important;
            }

            .el-form-item:first-child {
                margin: 22px 10px 22px 30px !important;
            }
        }

        .tables {
            padding: 25px 30px 0;
        }

        .el-row {
            &:last-child {
              margin-bottom: 0;
            }
        }

        .el-col {
            border-radius: 4px;
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-create {
                margin: 19px 0;
            }

            .dsp-botton {
                @include green-botton;
            }

            .dsp-botton-gray {
                @include gray-botton;
            }
        }

        .grid-word {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .word {
                align-self: center;
            }
        }

        .grid-time {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .time {
                align-self: center;
            }
        }

        .dsp-botton-red {
            @include red-botton;
        }

        .tabs {
            padding: 25px 0;
            float: right;
        }

        input.area-duoxuan {
            border: 1px solid $border-color;
            height: 40px;
            width: 350px;
            line-height: 40px;
            font-size: $font-size-2;
            color: $form-label-color;
            padding: 0 20px;
            margin: 0 65px;
            border-radius: 4px;
        }

        .dialog {
            min-width: 645px;
        }
    }
</style>
