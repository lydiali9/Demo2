<template>
    <div class="matrial-container">
        <el-row class="selection">
            <el-form :inline="true" :model="formInline" ref="formInline" class="demo-form-inline">
                <el-form-item label="创建时间" prop="createTime">
                    <div class="grid-content bg-create time">
                        <el-date-picker :clearable="false" size="middle" v-model="formInline.createTime" type="daterange" align="right"unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerCreateTime" @change="handleCreateTime">
                        </el-date-picker>
                    </div>
                </el-form-item>

                <el-form-item prop="title">
                    <div class="grid-content bg-create word">
                        <el-input placeholder="素材名称模糊查询" v-model="formInline.title" class="input-with-select" @keyup.enter.native="search" clearable>
                            <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
                        </el-input>
                    </div>
                </el-form-item>

                <el-form-item>
                    <div class="grid-content bg-create word">
                        <el-button class="dsp-botton" @click="create" align="middle">新建素材</el-button>
                    </div>
                </el-form-item>
            </el-form>
        </el-row>

        <el-row class="select tables"> 
            <el-row>
                <div v-for="(item, index) in imagesData" :key="index">
                    <el-col :xs="10" :sm="8" :md="6" :lg="4">
                        <div class="grid-content thumbnail">
                            <div class="user">
                                <img class="images" :src="item.imgServerUrl"/>
                            </div>
                            <div class="images-text">
                                <p class="images-label">
                                    <span>名称:</span>
                                    <span>{{item.title}}</span>
                                </p>
                                <p class="images-label">
                                    <span>创建时间:</span>
                                    <span>{{item.createTime}}</span>
                                </p>
                                <p class="images-label">
                                    <span>尺寸:</span>
                                    <span>{{item.width}} x {{item.height}}</span>
                                </p>
                            </div>
                        </div>
                    </el-col>
                </div>
            </el-row>

            <div class="tables">
                <el-pagination class="tabs" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPageNo" :page-sizes="sizes" :page-size="eachPageCapacity" layout="total, sizes, prev, pager, next, jumper" 
                :total="totalCount">
                </el-pagination>
            </div>
        </el-row>

        <el-dialog class="dialog" title="新建素材" :visible.sync="dialogFormVisible" width="512px" :close-on-click-modal="false" @close="handleClose">
            <el-form ref="form" :model="form" :rules="formRules">
                <el-form-item label="素材名称" prop="title" label-width="85px" required>
                    <el-row :gutter="20">
                        <el-col :span="14" style="padding: 0">
                            <div class="grid-content">
                                <el-input v-model="form.title"></el-input>
                            </div>
                        </el-col>
                        <el-col :span="10"></el-col>
                    </el-row>
                </el-form-item>

                <el-form-item label="素材上传" prop="type" label-width="85px" required>
                    <el-radio-group @change="handleType" v-model="form.type" size="medium">
                        <el-radio-button v-for="item in formList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                        </el-radio-group>
                </el-form-item>

                <el-form-item v-if="form.type == 1" label-width="85px" class="item-height">
                    <el-row>
                        <div v-for="item in imgList" :key="item.name" :label="item.name">
                            <el-col :sm="12" :md="10" :lg="8" :xl="6" style="height: 190px">
                                <div class="thumb">
                                    <div class="img-container">
                                        <img v-if="item.imgServerUrl == '' || 'undefined' == typeof(item.imgServerUrl) " class="avatar" :src="item.url"/>
                                        <img v-else class="avatar" :src="item.imgServerUrl"/>
                                    </div>
                                </div>
                            </el-col>
                        </div>
                        <el-col :sm="12" :md="10" :lg="8" :xl="6" v-show="imgList.length == 1 ? 0 : 1" style="height: 190px">
                            <img class="avatar" :src="smallUrl"/>
                            <vue-core-image-upload
                                crop-ratio="1.3"
                                class="btn btn-primary"
                                :crop="false"
                                :url="imgUpload"
                                inputAccept="image/jpg,image/jpeg,image/png"
                                text=""
                                :data="typeData"
                                @imageuploaded="imgeUploaded">
                            </vue-core-image-upload>
                        </el-col>
                    </el-row>
                </el-form-item>

                <el-form-item v-else="form.type == 2" label-width="85px" class="item-height">
                    <el-form-item prop="bigImageType">
                        <el-radio-group v-model="form.bigImageType" size="small" style="margin-bottom: 22px;"  @change="handleBigImageType">
                            <el-radio-button v-for="item in bigImageTypeList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                    <el-row>
                        <div v-for="item in largeImgList" :key="item.name" :label="item.name">
                            <el-col :sm="12" :md="10" :lg="8" :xl="6" style="height: 190px">
                                <div class="thumb">
                                    <div class="img-container">
                                        <img v-if="item.imgServerUrl == '' || 'undefined' == typeof(item.imgServerUrl) " class="avatar" :src="item.url"/>
                                        <img v-else class="avatar" :src="item.imgServerUrl"/>
                                    </div>
                                </div>
                            </el-col>
                        </div>
                        <el-col v-if="form.bigImageType == 1" :sm="12" :md="10" :lg="8" :xl="6" v-show="largeImgList.length == 1 ? 0 : 1" style="height: 190px">
                            <img class="avatar" :src="largeUrl1"/>
                            <vue-core-image-upload
                                crop-ratio="4.82"
                                class="btn btn-primary"
                                :crop="false"
                                :url="imgUpload"
                                inputAccept="image/jpg,image/jpeg,image/png"
                                text=""
                                :data="typeData"
                                @imageuploaded="largeImgUploaded">
                            </vue-core-image-upload>
                        </el-col>
                        <el-col v-else-if="form.bigImageType == 2" :sm="12" :md="10" :lg="8" :xl="6" v-show="largeImgList.length == 1 ? 0 : 1" style="height: 190px">
                            <img class="avatar" :src="largeUrl2"/>
                            <vue-core-image-upload
                                crop-ratio="1.78"
                                class="btn btn-primary"
                                :crop="false"
                                :url="imgUpload"
                                inputAccept="image/jpg,image/jpeg,image/png"
                                text=""
                                :data="typeData"
                                @imageuploaded="largeImgUploaded">
                            </vue-core-image-upload>
                        </el-col>
                        <el-col v-else="form.bigImageType == 3" :sm="12" :md="10" :lg="8" :xl="6" v-show="largeImgList.length == 1 ? 0 : 1" style="height: 190px">
                            <img class="avatar" :src="largeUrl3"/>
                            <vue-core-image-upload
                                crop-ratio="0.56"
                                class="btn btn-primary"
                                :crop="false"
                                :url="imgUpload"
                                inputAccept="image/jpg,image/jpeg,image/png"
                                text=""
                                :data="typeData"
                                @imageuploaded="largeImgUploaded">
                            </vue-core-image-upload>
                        </el-col>
                    </el-row>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancle('form')">取 消</el-button>
                <el-button type="primary" @click="submit('form')">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import VueCoreImageUpload from 'vue-core-image-upload'

export default {
    components: {
        VueCoreImageUpload
    },

    data() {
        return {
            formInline: {
                createTime: '',
                title: '',
                size: ''
            },
            sizeList: [],
            pickerCreateTime: {
                shortcuts: [{
                    text: '今天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime());
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '昨天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '本周',
                    onClick(picker) {handleCreateTime
                        const end = new Date();
                        const start = new Date();
                        end.setTime(start.getTime() + 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            imagesData: [],
            currentPageNo: 1,
            eachPageCapacity: 10,
            totalCount: 1,
            sizes: [24, 48, 92, 184, 368],
            dialogFormVisible: false,
            form: {
                title: '',
                type: '',
                bigImageType: ''
            },
            formRules: {
                title: [
                    { required: true, message: '请填写素材名称', trigger: 'change' },
                    { min: 1, max: 10, message: '长度在10个字符以内', trigger: 'blur' }
                ],
                type: [
                    { required: true, message: '请选择图片类型', trigger: 'change' }
                ]
            },
            formList: [
                {
                    label: '小图',
                    value: '1'
                },
                {
                    label: '大图',
                    value: '2'
                }
            ],
            imgList: [],
            largeImgList: [],
            imgUpload: this.$store.state.imgUpload,
            url: '',
            smallUrl: '',
            largeUrl1: '',
            largeUrl2: '',
            largeUrl3: '',
            bigImageTypeList: [
                {
                    label: '横幅大图',
                    value: '1'
                },
                {
                    label: '横版大图',
                    value: '2'
                },
                {
                    label: '竖版大图',
                    value: '3'
                }
            ],
            typeData: {}
        }
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.initCreateTime();
            this.getInfo();
        },

        handleClose() {
            this.cancle('form');
        },

        initCreateTime() {
            let date = new Date();
            this.formInline.createTime = [date.getTime() - 3600 * 1000 * 24 * 14, date.getTime()];
        },

        cancle(formName) {
            this.$refs[formName].resetFields();
            this.imgList = [];
            this.largeImgList = [];
            this.dialogFormVisible = false;
        },

        formatForm() {
            let fields = {};

            if(this.form.type == 1) {
                fields = this.imgList.length > 0 ? this.imgList[0] : {};
            }

            if(this.form.type == 2) {
                fields = this.largeImgList.length > 0 ? this.largeImgList[0] : {};
            }
            
            return Object.assign(this.form, fields);
        },

        createMaterial() {
            let parmas = this.formatForm();

            return new Promise((resolve, reject) => {
                this.$request.post(this.$store.state.createMaterial, parmas)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        submit(formName) {
            this.$refs[formName].validate(valid => {
                if(valid) {
                    this.createMaterial()
                        .then(res => {
                            if(res.code == '200') {
                                this.dialogFormVisible = false;
                                this.getInfo();

                                this.$message({
                                    showClose: true,
                                    type: 'success',
                                    message: "成功创建图片素材"
                                });
                            } else {
                                this.$message({
                                    showClose: true,
                                    type: 'error',
                                    message: res.message
                                });
                            }
                            this.cancle(formName);
                        })
                        .catch(err => {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: err
                            });
                            this.cancle(formName);
                        });
                } else {
                    console.log('Fail to validate the form data');
                }
            });
        },

        handleType(val) {
            this.typeData = {
                type: this.form.type,
                bigImageType: this.form.bigImageType
            };

            switch(val) {
                case '1':
                    this.largeImgList = [];
                    break;
                case '2':
                    this.imgList = [];
                    break;
                default:
                    break;
            }
        },

        handleBigImageType(val) {
            this.typeData = {
                type: this.form.type,
                bigImageType: this.form.bigImageType
            };
            this.largeImgList = [];
        },

        handleCreateTime() {
            if(!!this.formInline.createTime) {
                let utc = this.formInline.createTime[1] - this.formInline.createTime[0];
                let day = utc / (24 * 60 * 60 * 1000);

                if(parseInt(day) > 30) {
                    this.$message({
                        showClose: true,
                        type: 'warning',
                        message: '创建时间不能超过30天'
                    });
                    this.initCreateTime();
                    return false;
                }

                return this.getInfo();
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写创建时间范围'
                });
                return false;
            }
        },

        handleSizeChange(val) {
            this.eachPageCapacity = val;
            this.getInfo();
        },

        handleCurrentChange(val) {
            this.currentPageNo = val;
            this.getInfo();
        },

        search() {
            this.getInfo();
        },

        getInfo() {
            this.imagesData = [];
            if(!this.formInline.createTime) {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写创建时间范围'
                });
                return false;
            }

            this.getImagesList()
                .then(res => {
                    if(res.code == '200') {
                        if(res.data && res.data.length > 0) {
                            res.data.forEach(item => {
                                let createTime = item.createTime ? this.$utils.formatDate(new Date(item.createTime), 'yyyy-MM-dd') : '';
                                this.$set(item, 'createTime', createTime);
                                this.imagesData.push(item);
                            });
                        }
                        this.totalCount = res.page.totalCount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取图片列表失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getImagesList() {
            return new Promise((resolve, reject) => {
                let params = {
                    title: this.formInline.title,
                    startTime: this.$utils.formatDate(new Date(this.formInline.createTime[0]), "yyyy-MM-dd"),
                    endTime: this.$utils.formatDate(new Date(this.formInline.createTime[1]), "yyyy-MM-dd"),
                    eachPageCapacity: this.eachPageCapacity,
                    currentPageNo: this.currentPageNo
                }

                this.$request.get(this.$store.state.getImages, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        create() {
            this.dialogFormVisible = true;
            this.form.type = 1;
            this.form.bigImageType = 1;
            this.imgUpload = this.$store.state.imgUpload;
            this.url = '.../../../src/assets/images/tool/add.png';
            this.smallUrl = '.../../../src/assets/images/tool/small.png';
            this.largeUrl1 = '.../../../src/assets/images/tool/large1.png';
            this.largeUrl2 = '.../../../src/assets/images/tool/large2.png';
            this.largeUrl3 = '.../../../src/assets/images/tool/large3.png';
            this.typeData = {
                type: this.form.type,
                bigImageType: this.form.bigImageType
            };
        },

        imgeUploaded(res) {
            if(res.code == '200') {
                if (res.data.url) {

                    let cropArgs = {
                        name: res.data.name,
                        height: res.data.height,
                        width: res.data.width,
                        url: res.data.url,
                        id: '',
                        folder: res.data.folder,
                        format: res.data.format,
                        ratio: res.data.ratio,
                        absoluteName: res.data.absoluteName,
                        bigImageType: res.data.bigImageType,
                        type: res.data.type
                    }
                    this.imgList.push(cropArgs);
                    console.log(this.imgList);
                    
                    this.$message({
                        showClose: true,
                        type: 'success',
                        message: "上传图片成功"
                    });
                }
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: res.message
                });
            }
        },

        largeImgUploaded(res) {
            if(res.code == '200') {
                if (res.data.url) {

                    let cropArgs = {
                        name: res.data.name,
                        height: res.data.height,
                        width: res.data.width,
                        url: res.data.url,
                        id: '',
                        folder: res.data.folder,
                        format: res.data.format,
                        ratio: res.data.ratio,
                        absoluteName: res.data.absoluteName,
                        bigImageType: res.data.bigImageType,
                        type: res.data.type
                    }
                    this.largeImgList.push(cropArgs);
                    console.log(this.largeImgList);

                    this.$message({
                        showClose: true,
                        type: 'success',
                        message: "上传图片成功"
                    });
                }
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: res.message
                });
            }
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .matrial-container {
        height: auto;
        background-color: $white;
        box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

        .select {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            padding: 0 20px;
            margin: 0 0 15px !important;
        }

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }

        .tables {
            padding: 25px 30px 0;
        }

        .el-row {
            &:last-child {
              margin-bottom: 0;
            }
        }

        .el-col {
            border-radius: 4px;
        }

        .thumbnail {
            display: block;
            text-align: center;
            max-width: 200px;
            border-radius: 4px;
            border: 1px solid #e6e1e1;
            margin: 0 15px 25px;
            padding: 9px;

            .images {
                max-width: 100%;
                height: auto;
                width: 200px;
                height: 180px;
            }

            .images-text {
                .images-label {
                    font-size: 14px;
                    color: #606266;
                    line-height: 25px;
                    padding: 0 12px 0 0;
                    width: 100%;
                    box-sizing: border-box;
                    text-align: center;
                }
            }
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-create {
                margin: 19px 0;
            }

            .dsp-botton {
                @include green-botton;
            }
        }

        .grid-word {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .word {
                align-self: center;
            }
        }

        .grid-time {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .time {
                align-self: center;
            }
        }

        .tabs {
            padding: 25px 0;
            float: right;
        }
    
        .dialog {
            min-width: 512px;

            .thumb {
                display: block;
                text-align: center;
                max-width: 170px;
                border-radius: 4px;
                border: 1px solid #e6e1e1;
                padding: 9px;
                width: 170px;
                height: 170px;

                .img-container {
                    .avatar {
                        width: 170px;
                        height: 170px;
                    }
                }
            }

            .g-core-image-upload-btn {
                position: relative;
                overflow: hidden;
                height: 170px;
                top: -184px;
                width: 170px;
            }
        }

        .item-height {
            height: 190px;
        }

        .demo-form-inline {
            height: 100%;
            width: 100%;
            
            .el-form-item:not(:first-child) {
                margin: 22px 10px !important;
            }

            .el-form-item:first-child {
                margin: 22px 10px 22px 42px !important;
            }
        }
    }
</style>
