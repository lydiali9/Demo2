<template>
    <div class="register-container">
        <div class="item">
            <div class="section">
                <div class="logo-container"><img class="logo" src="../../assets/images/home/logo.png"></div>
                <div class="des">欢迎使用英威诺投放管理平台</div>
            </div>
            <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                <el-form-item prop="email">
                    <el-input v-model="ruleForm.email" placeholder="请输入邮箱"></el-input>
                </el-form-item>
                <el-form-item prop="pass">
                    <el-input type="password" v-model="ruleForm.pass" auto-complete="off" placeholder="请输入密码"></el-input>
                </el-form-item>

                <el-form-item prop="checkPass">
                    <el-input type="password" v-model="ruleForm.checkPass" auto-complete="off" placeholder="请确认密码"></el-input>
                </el-form-item>

                <el-form-item>
                    <el-input placeholder="请输入内容" v-model="ruleForm.code" class="input-with-select">
                        <el-button slot="append" @click="handleChangeCode('ruleForm')">{{codeLabel}}</el-button>
                    </el-input>
                </el-form-item>
                <el-form-item>
                    <!-- <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
                    <el-button @click="resetForm('ruleForm')">重置</el-button> -->

                    <el-button type="primary" @click="submitForm('ruleForm')" class="dsp-botton">提交注册</el-button>
                </el-form-item>
            </el-form>
            <div class="section">
                <span class="tip">已经有账号了？</span>
                <span class="small" @click="login">立即登录</span>
            </div>
        </div>
    </div>
</template>

<script>
    import {mapActions, mapState} from 'vuex';
    import crypto from "crypto";

    export default {
        data() {
            var validatePass = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('请输入密码'));
                } else {
                    if (this.ruleForm.checkPass !== '') {
                        this.$refs.ruleForm.validateField('checkPass');
                    }
                    callback();
                }
            };

            var validatePass2 = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('请再次输入密码'));
                } else if (value !== this.ruleForm.pass) {
                    callback(new Error('两次输入密码不一致!'));
                } else {
                    callback();
                }
            };

            return {
                ruleForm: {
                    email: '',
                    pass: '',
                    checkPass: '',
                    code: ''
                },
                codeLabel: '获取验证码',
                rules: {
                    email: [
                        { required: true, message: '该项为必填项', trigger: 'blur' },
                        { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }
                    ],
                    pass: [
                        { required: true, validator: validatePass, trigger: 'blur' }
                    ],
                    checkPass: [
                        { required: true, validator: validatePass2, trigger: 'blur' }
                    ],
                }
            }
        },
        methods: {
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.register()
                            .then(res => {
                                if(res.code == '200') {
                                    this.$message({
                                        showClose: true,
                                        type: 'success',
                                        message: "注册成功"
                                    });
                                } else if(res.code == '10006') {
                                    this.$message({
                                        showClose: true,
                                        type: 'error',
                                        message: "验证码错误"
                                    });
                                } else if(res.code == '10007') {
                                    this.$message({
                                        showClose: true,
                                        type: 'error',
                                        message: "邮箱已注册"
                                    });
                                } else {
                                    this.$message({
                                        showClose: true,
                                        type: 'error',
                                        message: res.message
                                    });
                                }
                            })
                            .catch(err => {
                                this.$message({
                                    showClose: true,
                                    type: 'error',
                                    message: err
                                });
                            });
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },

            resetForm(formName) {
                this.$refs[formName].resetFields();
            },

            handleChangeCode(formName) {
                this.$refs[formName].validate(valid => {
                    if(valid) {
                        this.timeWait(120);
                        this.getCode()
                            .then(res => {
                                if(res.code == '200') {
                                    let data = res.data;

                                    this.$message({
                                        showClose: true,
                                        type: 'success',
                                        message: "验证码已成功发送至邮箱，请注意查收！"
                                    });
                                } else {
                                    this.$message({
                                        showClose: true,
                                        type: 'error',
                                        message: res.message
                                    });
                                }
                            })
                            .catch(err => {
                                this.$message({
                                    showClose: true,
                                    type: 'error',
                                    message: err
                                });
                            });
                    }
                });
            },

            getCode() {
                return new Promise((resolve, reject) => {
                    this.$request.post(this.$store.state.getCode, { email: this.ruleForm.email })
                        .then(data => {
                            resolve(data);
                        }).catch(err => {
                            reject(err);
                        });
                });
            },

            timeWait(time) {
                setTimeout(() => {
                    if (time >= 0) {
                        this.codeLabel = time + "S";
                        time--;
                        this.timeWait(time);
                    } else {
                        this.codeLabel = "重新发送";
                    }
                }, 1000);
            },

            register() {
                let params = {
                    email: this.ruleForm.email,
                    password: this.ruleForm.checkPass,
                    verificationCode: this.ruleForm.code
                };

                return new Promise((resolve, reject) => {
                    this.$request.post(this.$store.state.register, params)
                        .then(data => {
                            resolve(data);
                        }).catch(err => {
                            reject(err);
                        });
                });
            },

            login() {
                this.$router.push({path: '/login'})
            }
        }
    }
</script>

<style lang="scss" scoped>
    @import '../../assets/style/color.scss';

    .register-container {
        display: flex;
        height: 100vh;
        width: 100%;
        align-items: center;
        justify-content: left;
        margin: 0;
        padding: 0;
        background-image:url('../../assets/images/home/backgroud.png');
        background-repeat:no-repeat;
        background-position:center;

        .el-input {
            width: 80% !important;
        }

        .item {
            width: 530px;
            margin-left: 10%;

            .logo-container {
                width: 100%;
                height: 40px;
                text-align: center;

                .logo {
                    height: 40px;
                    width: 200px;
                }
            }

            .section {
                margin: 0 0 68px;
                text-align: center;

                .des {
                    margin: 26px 0 0;
                    text-align: center;
                    font-size: $font-size-3;
                    color: $font-color;
                }

                .small {
                    font-size: $font-size-1;
                    color: $green;
                    cursor: pointer;
                }

                .tip {
                    font-size: $font-size-1;
                    color: $font-color;
                }

                .center {
                    margin: 0 5px;
                }
            }
        }

        .el-button {
            span {
                font-size: $font-size-1 !important;
                color: $blue !important;
            }
        }

        .dsp-botton {
            background-color: $green;
            width: 80%;
            margin: 30px 0;
            border: none;

            &:active {
                color: $white;
                border-color: $green;
                outline: 0;
            }

            &:hover {
                color: $white;
                border-color: $green;
                outline: 0;
            }

            &:focus {
                color: $white;
                border-color: $green;
                outline: 0;
            }
        }
    }
</style>
