<template>
    <el-header>
        <el-row :gutter="20">
            <el-col :xs="4" :sm="4" :md="3" :lg="3" :xl="3">
                <div class="grid-content">
                    <span class="left">
                        <img class="logo" src="../../assets/images/home/logo1.png">
                    </span>
                </div>
            </el-col>
            <el-col :xs="5" :sm="5" :md="4" :lg="3" :xl="3">
                <div class="grid-content grid-flex-1">
                    <span class="left logo-words">投放管理平台</span>
                </div>
            </el-col>
            <el-col :xs="6" :sm="6" :md="11" :lg="14" :xl="14">
                <div class="grid-content">&nbsp;</div>
            </el-col>
            <el-col :xs="2" :sm="2" :md="1" :lg="1" :xl="1">
                <div class="grid-content">
                    <img class="headphone" src="../../assets/images/home/headphone.png">
                </div>
            </el-col>
            <el-col :xs="4" :sm="4" :md="3" :lg="2" :xl="2">
                <div class="grid-content grid-flex">
                    <span class="alert">欢迎您！{{name}}</span>
                </div>
            </el-col>
            <el-col :xs="3" :sm="3" :md="2" :lg="1" :xl="1">
                <div class="grid-content grid-flex curse" @click="handleLogout">
                    <span class="logout">退出</span>
                </div>
            </el-col>
        </el-row>
    </el-header>
</template>


<script>
    export default {
        data() {
            return {
                name: ''
            }
        },
        created() {
            /*if(this.getCookie('userId')) {
                this.name = localStorage.getItem('userName');
            }*/
            this.init();
        },
        methods: {
            init() {
                this.getUserInfo()
                    .then(res => {
                        let data = res.data;

                        if(res.code == '200') {
                            this.name = data.userName;
                        } else {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: res.message
                            });
                        }
                    })
                    .catch(err => {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: err
                        });
                        console.log(err);
                    })

            },

            getUserInfo() {
                return new Promise((resolve, reject) => {
                    this.$request.get(this.$store.state.getUserInfo, {})
                        .then(data => {
                            resolve(data);
                        }).catch(err => {
                            reject(err);
                        });
                });
            },

            handleLogout() {
                this.logout()
                    .then(res => {
                        if(res.code == '200') {
                            this.delCookie('userId');
                            this.delCookie('menus');
                            localStorage.removeItem('menu_list');
                            localStorage.removeItem('has_ad');
                            this.$router.push('/login');
                        } else {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: res.message
                            });
                        }
                    })
                    .catch(err => {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: err
                        });
                        console.log(err);
                    })
            },

            logout() {
                return new Promise((resolve, reject) => {
                    this.$request.post(this.$store.state.logout, {})
                        .then(data => {
                            resolve(data);
                        }).catch(err => {
                            reject(err);
                        });
                });
            }
        }
    }
</script>


<style lang="scss" scoped>
    @import '../../assets/style/color.scss';

    .el-header {
        background-color: $green;
        color: $white;
        box-shadow: 0 5px 5px hsla(0,0%,60%,.09)!important;
        min-width: 998px;
        min-height: 60px;
        height: auto;
        width: 100%;
        margin: 0 0 2px 0;

        .logo {
            margin-right: 18px;
            line-height: 60px !important;
            margin-top: 21px;
        }

        .grid-flex-1 {
            height: 60px;
            display: flex;
            justify-content: flex-start;

            .logo-words {
                font-size: 18px;
                color: $white;
                align-self: center;
            }
        }

        .grid-flex {
            height: 60px;
            display: flex;
            justify-content: flex-end;

            .alert {
                font-size: $font-size-2;
                color:$white;
                align-self: center;
            }

            .logout {
                font-size: $font-size-3;
                color: $white;
                align-self: center;
            }
        }

        .curse {
            cursor: pointer;
        }

        .headphone {
            height: 45px;
            width: 45px;
            margin-top: 7.5px;
        }
    }
</style>
