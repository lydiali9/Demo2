<template>
    <el-aside class="side-container">
        <el-menu :default-active="onRoutes" class="el-menu-vertical-demo" unique-opened router>
            <template v-for="item in items">
                <template v-if="item.subs">
                    <el-submenu :index="item.index">
                        <template slot="title">
                            <img class="img" :src="item.icon"/>
                            {{ item.title }}
                        </template>
                        <el-menu-item class="sub-title" v-for="(subItem, i) in item.subs" :key="i" :index="subItem.index"> {{ subItem.title
                            }}
                        </el-menu-item>
                    </el-submenu>
                </template>
                <template v-else>
                    <el-menu-item :index="item.index">
                        <img class="img" :src="item.icon"/>
                        {{ item.title }}
                    </el-menu-item>
                </template>
            </template>
        </el-menu>
    </el-aside>
</template>

<script>
    export default {
        data() {
            return {
                items: this.$store.state.user.menus
            }
        },
        created() {
            if(this.getCookie('userId')) {
                this.items = JSON.parse(localStorage.getItem('menu_list'));
            }
        },
        computed: {
            onRoutes() {
                return this.$route.path.replace('/', '');
            }
        }
    }
</script>

<style>
    .el-aside {
        background-color: #fff;
        text-align: center;
        height: 100vh;
        width: 184px !important;
        background: #fff;
        overflow: scroll;
    }

    /* aside {
        box-shadow: 5px 0 0 0 hsla(0,0%,60%,.09) !important;
    } */

    .side-container .img {
        margin-right: 5px;
    }

    .side-container .el-menu {
        border-right: none !important;
    }

    .side-container .el-menu-item, .el-submenu__title {
        text-align: left;
        height: 42px !important;
        line-height: 42px !important;
        font-size: 14px !important;
        color: $font-color !important;
        padding-left: 24px !important;
    }

    .side-container .el-menu-item.is-active {
        color: #5ca96d;
        border-left: 4px solid #5ca96d;
        padding-left: 20px !important;
    }

    .side-container .sidebar > ul {
        height: auto;
        min-height: 100%;
    }

    .side-container .sub-title {
        padding-left: 48px !important;
    }

    .side-container .sub-title.is-active {
        padding-left: 44px !important;
    }
</style>
