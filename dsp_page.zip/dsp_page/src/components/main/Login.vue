<template>
    <div class="login-container">
        <div class="item">
            <div class="section">
                <div class="logo-container"><img class="logo" src="../../assets/images/home/logo.png"></div>
                <div class="des">欢迎使用英威诺投放管理平台</div>
            </div>
            <el-form status-icon :model="loginForm" :rules="rules" ref="loginForm" label-width="100px" class="demo-ruleForm">
                <el-form-item prop="username">
                    <el-input v-model="loginForm.username" placeholder="请输入用户名"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input type="password" v-model="loginForm.password" placeholder="请输入密码" auto-complete="off"></el-input>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="submitForm('loginForm')" class="dsp-botton">登陆</el-button>
                </el-form-item>
            </el-form>
            <div class="section">
                <span class="small" @click="retrievePwd">忘记密码</span>
                <!--<span class="small center">|</span>
                <span class="small" @click="register">注册新用户</span>-->
            </div>
        </div>
    </div>
</template>

<script>
    import {mapActions, mapState} from 'vuex';
    import crypto from "crypto";

    export default {
        data() {
            return {
                loginForm: {
                    username: '',
                    password: ''
                },
                rules: {
                    username: [
                        { required: true, message: '请输入用户名', trigger: 'blur' },
                    ],
                    password: [
                        { required: true, message: '请输入密码', trigger: 'blur' }
                    ],
                },
                showLogin: false,
            }
        },
        methods: {
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.login(this.loginForm)
                            .then(res => {
                                if(res.code == '200') {
                                    let data = res.data;

                                    this.$store.commit("handleMenus", data.menu);
                                    this.setCookie('userId', data.userId, 3);
                                    localStorage.setItem('has_ad', data.hasAd);
                                    localStorage.setItem('userName', data.userName);
                                    this.setCookie('menus', JSON.stringify(this.$store.state.user.menus), 3);
                                    this.$router.push({path: '/index'})
                                } else {
                                    this.$message({
                                        showClose: true,
                                        type: 'error',
                                        message: res.message
                                    });
                                }
                            })
                            .catch(err => {
                                this.$message({
                                    showClose: true,
                                    type: 'error',
                                    message: err
                                });
                            });
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "请输入正确的用户名密码"
                        });
                        return false;
                    }
                });
            },

            login(params) {
                return new Promise((resolve, reject) => {
                    this.$request.post(this.$store.state.login, params)
                        .then(data => {
                            resolve(data);
                        }).catch(err => {
                            reject(err);
                        });
                });
            },

            createMd5(str){
                var hasher = crypto.createHash("md5");
                hasher.update(str);
                return hasher.digest('hex');
            },

            register() {
                this.$router.push({path: '/register'});
            },

            retrievePwd() {
                this.$router.push({path: '/retrievePwd'});
            }
        }
    }
</script>

<style lang="scss" scoped>
    @import '../../assets/style/color.scss';

    .login-container {
        display: flex;
        height: 100vh;
        width: 100%;
        align-items: center;
        justify-content: left;
        margin: 0;
        padding: 0;
        background-image:url('../../assets/images/home/backgroud.png');
        background-repeat:no-repeat;
        background-position:center;

        .el-input {
            width: 80% !important;
        }

        .item {
            width: 530px;
            margin-left: 10%;

            .logo-container {
                width: 100%;
                height: 40px;
                text-align: center;

                .logo {
                    height: 40px;
                    width: 200px;
                }
            }

            .section {
                margin: 0 0 68px;
                text-align: center;

                .des {
                    margin: 26px 0 0;
                    text-align: center;
                    font-size: $font-size-3;
                    color: $font-color;
                }

                .small {
                    font-size: $font-size-1;
                    color: $green;
                    cursor: pointer;
                }

                .center {
                    margin: 0 5px;
                }
            }
        }

        .dsp-botton {
            background-color: $green;
            width: 80%;
            margin: 30px 0;
            border: none;

            &:active {
                color: $white;
                border-color: $green;
                outline: 0;
            }

            &:hover {
                color: $white;
                border-color: $green;
                outline: 0;
            }

            &:focus {
                color: $white;
                border-color: $green;
                outline: 0;
            }
        }
    }
</style>
