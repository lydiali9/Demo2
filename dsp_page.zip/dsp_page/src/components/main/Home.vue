<template>
    <div>
        <vHead></vHead>
        <el-container class="body-container">
            <vSide></vSide>
            <el-main>
                <transition name="move" mode="out-in">
                    <router-view/>
                </transition>
            </el-main>
        </el-container>
    </div>
</template>


<script>
    import vHead from './NavBar.vue'
    import vSide from './SideBar.vue'

    export default {
        components:{
            vHead, vSide
        }
    }
</script>


<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    
    .el-main {
        background-color: $body-background;
        color: #333;
        height: auto;
        padding: 0 16px !important;
        // min-width: 700px;

        .el-container {
            margin-bottom: 40px;
        }
    }
  
    .body-container {
        width: 100% !important;
    }
</style>
