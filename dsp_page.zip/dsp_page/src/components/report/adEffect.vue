<template>
    <div class="report-container">
        <el-row class="selection">
            <el-form :inline="true" :model="formInline" ref="formInline" class="demo-form-inline">
                <el-form-item label="时间范围" prop="time">
                    <div class="grid-content bg-create time">
                        <el-date-picker :clearable="false" size="middle" v-model="formInline.time" type="daterange" align="right"unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerTime" @change="handleTime">
                        </el-date-picker>
                    </div>
                </el-form-item>

                <el-form-item>
                    <div class="grid-content bg-create time">
                        <el-checkbox v-model="checked" @change="compare">比较</el-checkbox>
                    </div>
                </el-form-item>

                <el-form-item prop="compareTime">
                    <div class="grid-content bg-create time">
                        <el-date-picker :clearable="false" size="middle" v-model="formInline.compareTime" type="daterange" align="right"unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerCompareTime" @change="handleCompareTime" :disabled="checked == false">
                        </el-date-picker>
                    </div>
                </el-form-item>

                <el-form-item prop="promotionId">
                    <el-select v-model="formInline.promotionId" @change="handlePromotionId" filterable placeholder="请选择推广">
                        <el-option v-for="item in promotionIdList" :key="item.id" :label="item.title" :value="item.id">
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item prop="adId">
                    <el-select v-model="formInline.adId" @change="handleAdId" filterable placeholder="请选择广告ID">
                        <el-option v-for="item in adIdList" :key="item.id" :label="item.name" :value="item.id">
                        </el-option>
                    </el-select>
                </el-form-item>
            </el-form>
        </el-row>

        <div class="grid-line">
            <el-row type="flex" class="checkbox-row" justify="center">
                <el-col :span="8">
                    <div class="grid-content">
                        <el-checkbox-group v-model="checkboxGroup" size="medium" @change="handleCheckedItem">
                            <el-checkbox-button :disabled="checkboxGroup.includes(item.value) ? true : false" v-for="item in items" :label="item.value" :key="item.value"> {{item.label}}</el-checkbox-button>
                        </el-checkbox-group>
                    </div>
                </el-col>
            </el-row>
        </div>
        <div id="line" class="line">
            <template>
                <chart :options="list"></chart>
            </template>
        </div>


        <el-row class="select tables">
            <el-table :data="tableData" border show-summary sum-text="" style="width: 100%" class="tabs" :summary-method="getSummaries" :default-sort="{prop: 'date', order: 'descending'}">
                <el-table-column prop="date" sortable label="时间" width="220"></el-table-column>
                <el-table-column prop="adId" label="广告ID" width="240"></el-table-column>
                <el-table-column prop="totalCost" sortable label="总消费"></el-table-column>
                <el-table-column prop="pv" sortable label="展示数"></el-table-column>
                <el-table-column prop="click" sortable label="点击数"></el-table-column>
                <el-table-column prop="ctr" sortable label="点击率"></el-table-column>
                <el-table-column prop="ecpm" sortable label="ECPM(元)"></el-table-column>
                <el-table-column prop="ecpc" sortable label="ECPC(元)"></el-table-column>
            </el-table>
        </el-row>
    </div>
</template>

<script>
export default {
    data() {
        return {
            formInline: {
                time: '',
                promotionId: '',
                adId: '',
                compareTime: ''
            },
            adIdList: [],
            promotionIdList: [],
            pickerTime: {
                shortcuts: [{
                    text: '今天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime());
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '昨天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '本周',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            pickerCompareTime: {
                shortcuts: [{
                    text: '今天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime());
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '昨天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '本周',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            checkboxGroup: [],
            items: [
                {
                    value: 0,
                    isDisabled: true,
                    label: '总消费'
                },
                {
                    value: 1,
                    isDisabled: true,
                    label: '展示数'
                },
                {
                    value: 2,
                    isDisabled: false,
                    label: '点击数'
                },
                {
                    value: 3,
                    isDisabled: false,
                    label: '点击率'
                },
                {
                    value: 4,
                    isDisabled: false,
                    label: 'ECPM(元)'
                },
                {
                    value: 5,
                    isDisabled: false,
                    label: 'ECPC(元)'
                }
            ],
            list: {
                color: ['#5793f3', '#d14a61', '#675bba'],
                title: {
                    text: '折线图堆叠'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'cross'
                    }
                },
                legend: {
                    data: ['总消费', '展示数', '点击数', '点击率', 'ECPM(元)', 'ECPC(元)']
                },
                grid: {},
                xAxis: {},
                yAxis: null,
                series: [
                ]
            },
            tableData: [],
            checked: false,
            singleGrid: {
                top: 70,
                bottom: 50
            },
            compareGrid: {
                top: 70,
                bottom: 50
            },
            singleXAxis: {
                type: 'category',
                boundaryGap: true,
                data: []
            },
            compareXAxis: [
                {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLine: {
                        onZero: false,
                        lineStyle: {
                            color: '#d14a61'
                        }
                    },
                    axisPointer: {
                        label: {
                            formatter: function (params) {
                                return params.value;
                            }
                        }
                    },
                    data: []
                },
                {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLine: {
                        onZero: false,
                        lineStyle: {
                            color: '#5793f3'
                        }
                    },
                    axisPointer: {
                        label: {
                            formatter: function (params) {
                                return params.value;
                            }
                        }
                    },
                    data: []
                }
            ],
            singleYAxis: [],
            compareYAxis: {
                type: 'value'
            }
        }
    },
    created() {
        this.checkboxGroup = [this.items[0].value, this.items[1].value];
        this.initialize();
    },
    mounted() {
    },
    methods: {
        compare(val) {
            if(val) {
                this.checkboxGroup.shift();
            } else {
                let index = this.checkboxGroup[0] == 5 ? 0 : this.checkboxGroup[0] + 1;
                this.checkboxGroup.push(this.items[index].value);
            }

            this.handleTime();
        },

        getSummaries(param) {
            const { columns, data } = param;
            const sums = [];

            columns.forEach((column, index) => {
                if (index === 0) {
                    sums[index] = '合计';
                    return;
                }

                if (index == 1) {
                    return;
                }

                if(index == 5) {
                    const sum = (...arr) => [].concat(...arr).reduce((acc, val) => acc + val, 0);

                    const clickValues = data.map(item => Number(item['click']));
                    const pvValues = data.map(item => Number(item['pv']));

                    let totalClickValues = new Number(sum(clickValues));
                    let totalPvValues = new Number(sum(pvValues));

                    let ctr = (totalClickValues/totalPvValues*100).toFixed(2);
                    sums[index] = isNaN(ctr) ? 0 : ctr;
                    sums[index] += '%';
                    return;
                }

                if(index > 5) {
                    return;
                }

                const values = data.map(item => Number(item[column.property]));
                if (!values.every(value => isNaN(value))) {
                    let total = values.reduce((prev, curr) => {
                        const value = Number(curr);

                        if (!isNaN(value)) {
                            return prev + curr;
                        } else {
                            return prev;
                        }
                    }, 0);

                    sums[index] = total.toFixed(2);
                }
            });

            return sums;
        },

        formatCompareHoursData(realData, compareTimeFirst, compareTimeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[compareTimeFirst]) {
                    let option = realData[compareTimeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);
                    this.list.xAxis[1].data.push(option.date);

                    let val = {
                        date: option.date,
                        adId: option.adId ? option.adId : '-',
                        click: option.click,
                        ecpc: option.ecpc == 0 ? option.ecpc : (!!option.ecpc ? (option.ecpc).toFixed(2) : '-'),
                        pv: option.pv,
                        totalCost: option.totalCost == 0 ? option.totalCost : (!!option.totalCost ? (option.totalCost).toFixed(2) : '-'),
                        ctr: option.ctr == 0 ? option.ctr : (!!option.ctr ? (option.ctr).toFixed(2) + '%' : '-'),
                        ecpm: option.ecpm == 0 ? option.ecpm : (!!option.ecpm ? (option.ecpm).toFixed(2) : '-')
                    };
                    this.tableData.push(val);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis[1].data.push(compareTimeFirst);

                    let val = {
                        date: compareTimeFirst,
                        adId: '-',
                        click: 0,
                        ecpc: 0,
                        pv: 0,
                        totalCost: 0,
                        ctr: 0,
                        ecpm: 0
                    };
                    this.tableData.push(val);
                }
                compareTimeFirst = this.$utils.getNextHourByDate(compareTimeFirst);
            } while(compareTimeFirst != this.$utils.getNextHourByDate(compareTimeSecond));

            let list = [{
                name: '总消费2',
                data: totalCostData
            },{
                name: '展示数2',
                data: pvData
            },{
                name: '点击数2',
                data: clickData
            },{
                name: '点击率2',
                data: ctrData
            },{
                name: 'ECPM(元)2',
                data: ecpmData
            },{
                name: 'ECPC(元)2',
                data: ecpcData
            }];

            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        xAxisIndex: 1,
                        data: val.data
                    }
                    if(index == idx) {
                        this.list.series.unshift(item);
                    }
                });
            });

            return true;
        },

        formatCompareDailyData(realData, compareTimeFirst, compareTimeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[compareTimeFirst]) {
                    let option = realData[compareTimeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);
                    this.list.xAxis[1].data.push(option.date);

                    let val = {
                        date: option.date,
                        adId: option.adId ? option.adId : '-',
                        click: option.click,
                        ecpc: option.ecpc == 0 ? option.ecpc : (!!option.ecpc ? (option.ecpc).toFixed(2) : '-'),
                        pv: option.pv,
                        totalCost: option.totalCost == 0 ? option.totalCost : (!!option.totalCost ? (option.totalCost).toFixed(2) : '-'),
                        ctr: option.ctr == 0 ? option.ctr : (!!option.ctr ? (option.ctr).toFixed(2) + '%' : '-'),
                        ecpm: option.ecpm == 0 ? option.ecpm : (!!option.ecpm ? (option.ecpm).toFixed(2) : '-')
                    };
                    this.tableData.push(val);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis[1].data.push(compareTimeFirst);

                    let val = {
                        date: compareTimeFirst,
                        adId: '-',
                        click: 0,
                        ecpc: 0,
                        pv: 0,
                        totalCost: 0,
                        ctr: 0,
                        ecpm: 0
                    };
                    this.tableData.push(val);
                }
                compareTimeFirst = this.$utils.getNextDay(compareTimeFirst);
            } while(compareTimeFirst != this.$utils.getNextDay(compareTimeSecond));

            let list = [{
                name: '总消费2',
                data: totalCostData
            },{
                name: '展示数2',
                data: pvData
            },{
                name: '点击数2',
                data: clickData
            },{
                name: '点击率2',
                data: ctrData
            },{
                name: 'ECPM(元)2',
                data: ecpmData
            },{
                name: 'ECPC(元)2',
                data: ecpcData
            }];
            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        xAxisIndex: 1,
                        data: val.data
                    }
                    if(index == idx) {
                        this.list.series.unshift(item);
                    }
                });
            });

            return true;
        },

        getDayForCompareTime() {
            this.initCompareChartData()
                .then(res => {
                    if(res.code == '200') {

                        let realData = {};

                        if(res.data && res.data.length > 0) {
                            res.data.forEach(option => {
                                realData[option.date] = option;
                            });
                        }

                        let compareTimeFirst = this.$utils.formatDate(this.formInline.compareTime[0], "yyyy-MM-dd");
                        let compareTimeSecond = this.$utils.formatDate(this.formInline.compareTime[1], "yyyy-MM-dd");

                        if(compareTimeFirst == compareTimeSecond) {
                            this.formatCompareHoursData(realData, compareTimeFirst + " 00:00:00", compareTimeSecond + " 23:00:00");
                        } else {
                            this.formatCompareDailyData(realData, compareTimeFirst, compareTimeSecond);
                        }
                        console.log(this.list);
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        initCompareChartData() {
            return new Promise((resolve, reject) => {
                let searchStartDate = this.$utils.formatDate(new Date(this.formInline.compareTime[0]), "yyyy-MM-dd");
                let searchEndDate = this.$utils.formatDate(new Date(this.formInline.compareTime[1]), "yyyy-MM-dd");

                if(searchStartDate == searchEndDate) {
                    searchStartDate = searchStartDate.toString() + " 00:00:00";
                    searchEndDate = searchEndDate.toString() + " 23:59:59"
                }

                let params = {
                    type: 'ad',
                    searchStartDate: searchStartDate,
                    searchEndDate: searchEndDate,
                    promotionId: this.formInline.promotionId,
                    adId: this.formInline.adId
                }
                let utc = this.formInline.compareTime[1] - this.formInline.compareTime[0];
                let day = utc / (24 * 60 * 60 * 1000);
                let url = '';

                if(parseInt(day) >= 1) {
                    url = this.$store.state.getAdReportDaily;
                } else {
                    url = this.$store.state.getAdReportHourly;
                }
                this.$request.get(url, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        initialize() {
            let date = new Date();
            this.formInline.time = [new Date(date.getTime() - 3600 * 1000 * 24 * 7), new Date(date.getTime() - 3600 * 1000 * 24 * 1)];
            this.formInline.compareTime = [new Date(date.getTime() - 3600 * 1000 * 24 * 14), new Date(date.getTime() - 3600 * 1000 * 24 * 8)];
            this.getPromote();
        },

        handleTime() {
            let date = this.formInline.time[0];
            let utc = this.formInline.time[1] - this.formInline.time[0];
            let day = utc / (24 * 60 * 60 * 1000);

            if(parseInt(day) > 30) {
                this.$message({
                    showClose: true,
                    type: 'warning',
                    message: '时间返回不能超过30天'
                });
                return false;
            } else {
                if(this.checked) {
                    this.formInline.compareTime = [new Date(date - 3600 * 1000 * 24 * (parseInt(day) + 1)), new Date(date - 3600 * 1000 * 24 * 1)];
                }
            }

            if(!this.checked) {
                this.initData(0);
            } else {
                this.initData(1);
            }
        },

        handleCompareTime() {
            let date = this.formInline.compareTime[0];
            let utc = this.formInline.compareTime[1] - this.formInline.compareTime[0];
            let day = utc / (24 * 60 * 60 * 1000);

            if(parseInt(day) > 30) {
                this.$message({
                    showClose: true,
                    type: 'warning',
                    message: '比较时间范围不能超过30天'
                });
                return false;
            } else {
                if(this.checked) {
                    this.formInline.time = [new Date(date.getTime() + 3600 * 1000 * 24 * (parseInt(day) + 1)), new Date(date.getTime() + 3600 * 1000 * 24 * (parseInt(day) * 2 + 1))];

                    this.initData(1);
                }
            }
            return true;
        },

        getPromote() {
            this.promotionIdList = [{id: '', title: '选择推广（不限）'}];

            this.getPromotionIds()
                .then(res => {
                    if(res.code == '200') {

                        if(res.data && res.data.length > 0) {
                            res.data.forEach(item => {
                                this.promotionIdList.push(item);
                            });
                            this.formInline.promotionId = this.promotionIdList[0].id;
                        }
                        this.getAd();
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取推广列表失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getPromotionIds() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.queryPromote, {category: 2})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        getAd() {
            this.adIdList = [{id: '', name: '广告ID(不限)'}];

            this.getAdIDList()
                .then(res => {
                    if(res.code == '200') {
                         if(res.data && res.data.length > 0) {
                            res.data.forEach(item => {
                                item = {
                                    id: item.adId,
                                    name: item.adId
                                }
                                this.adIdList.push(item);
                            });
                            this.formInline.adId = this.adIdList[0].id;
                        }
                        if(!this.checked) {
                            this.initData(0);
                        } else {
                            this.initData(1);
                        }
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取广告列表失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getAdIDList() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.queryAd, { promotionId: this.formInline.promotionId })
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        handlePromotionId(val) {
            if(!!val) {
                this.getAd();
            } else {
                this.adIdList = [{id: '', name: '广告ID(不限)'}];
                this.formInline.adId = this.adIdList[0].id;

                if(!this.checked) {
                    this.initData(0);
                } else {
                    this.initData(1);
                }
            }
        },

        handleAdId(val) {
            if(!this.checked) {
                this.initData(0);
            } else {
                this.initData(1);
            }
        },

        handleCheckedItem(item) {
            if(!this.checked) {
                this.checkboxGroup.shift();
                this.initData(0);
            } else {
                this.checkboxGroup.shift();
                this.initData(1);
            }
        },

        formatDailyData(realData, timeFirst, timeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[timeFirst]) {
                    let option = realData[timeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);

                    this.list.xAxis[0].data.push(option.date);

                    let val = {
                        date: option.date,
                        adId: option.adId ? option.adId : '-',
                        click: option.click,
                        ecpc: option.ecpc == 0 ? option.ecpc : (!!option.ecpc ? (option.ecpc).toFixed(2) : '-'),
                        pv: option.pv,
                        totalCost: option.totalCost == 0 ? option.totalCost : (!!option.totalCost ? (option.totalCost).toFixed(2) : '-'),
                        ctr: option.ctr == 0 ? option.ctr : (!!option.ctr ? (option.ctr).toFixed(2) + '%' : '-'),
                        ecpm: option.ecpm == 0 ? option.ecpm : (!!option.ecpm ? (option.ecpm).toFixed(2) : '-')
                    };
                    this.tableData.push(val);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis[0].data.push(timeFirst);

                    let val = {
                        date: timeFirst,
                        adId: '-',
                        click: 0,
                        ecpc: 0,
                        pv: 0,
                        totalCost: 0,
                        ctr: 0,
                        ecpm: 0
                    };
                    this.tableData.push(val);
                }
                timeFirst = this.$utils.getNextDay(timeFirst);
            }while (timeFirst != this.$utils.getNextDay(timeSecond));

            let list = [{
                name: '总消费1',
                data: totalCostData
            },{
                name: '展示数1',
                data: pvData
            },{
                name: '点击数1',
                data: clickData
            },{
                name: '点击率1',
                data: ctrData
            },{
                name: 'ECPM(元)1',
                data: ecpmData
            },{
                name: 'ECPC(元)1',
                data: ecpcData
            }];

            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        data: val.data
                    }
                    if(index == idx) {
                        this.list.series.push(item);
                    }
                });
            });

            return true;
        },

        formatHoursData(realData, timeFirst, timeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[timeFirst]) {
                    let option = realData[timeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);

                    this.list.xAxis[0].data.push(option.date);

                    let val = {
                        date: option.date,
                        adId: option.adId ? option.adId : '-',
                        click: option.click,
                        ecpc: option.ecpc == 0 ? option.ecpc : (!!option.ecpc ? (option.ecpc).toFixed(2) : '-'),
                        pv: option.pv,
                        totalCost: option.totalCost == 0 ? option.totalCost : (!!option.totalCost ? (option.totalCost).toFixed(2) : '-'),
                        ctr: option.ctr == 0 ? option.ctr : (!!option.ctr ? (option.ctr).toFixed(2) + '%' : '-'),
                        ecpm: option.ecpm == 0 ? option.ecpm : (!!option.ecpm ? (option.ecpm).toFixed(2) : '-')
                    };
                    this.tableData.push(val);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis[0].data.push(timeFirst);

                    let val = {
                        date: timeFirst,
                        adId: '-',
                        click: 0,
                        ecpc: 0,
                        pv: 0,
                        totalCost: 0,
                        ctr: 0,
                        ecpm: 0
                    };
                    this.tableData.push(val);
                }
                timeFirst = this.$utils.getNextHourByDate(timeFirst);
            }while (timeFirst != this.$utils.getNextHourByDate(timeSecond));

            let list = [{
                name: '总消费1',
                data: totalCostData
            },{
                name: '展示数1',
                data: pvData
            },{
                name: '点击数1',
                data: clickData
            },{
                name: '点击率1',
                data: ctrData
            },{
                name: 'ECPM(元)1',
                data: ecpmData
            },{
                name: 'ECPC(元)1',
                data: ecpcData
            }];

            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        data: val.data
                    }
                    if(index == idx) {
                        this.list.series.push(item);
                    }
                });
            });

            return true;
        },

        initFirstDateForCompare() {
            this.initChartData()
                .then(res => {
                    if(res.code == '200') {

                        this.list.xAxis[0].data = [];
                        this.list.xAxis[1].data = [];
                        this.list.series = [];
                        this.tableData = [];
                        let realData = {};

                        if(res.data && res.data.length > 0) {
                            res.data.forEach(option => {
                                realData[option.date] = option;
                            });
                        }
                        let timeFirst = this.$utils.formatDate(this.formInline.time[0], "yyyy-MM-dd");
                        let timeSecond = this.$utils.formatDate(this.formInline.time[1], "yyyy-MM-dd");

                        if(timeFirst == timeSecond) {
                            this.formatHoursData(realData, timeFirst + " 00:00:00", timeSecond + " 23:00:00");
                        } else {
                            this.formatDailyData(realData, timeFirst, timeSecond);
                        }

                        this.getDayForCompareTime();
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        initData(data) {
            if(data) {
                this.list.grid = this.compareGrid;
                this.list.xAxis = this.compareXAxis;
                this.list.yAxis = this.compareYAxis;

                this.initFirstDateForCompare();
            } else {
                this.list.grid = this.singleGrid;
                this.list.xAxis = this.singleXAxis;
                this.list.yAxis = this.singleYAxis;

                this.initFirstDate();
            }
        },

        formatInitDailyData(realData, timeFirst, timeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[timeFirst]) {
                    let option = realData[timeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);

                    this.list.xAxis.data.push(option.date);

                    let val = {
                        date: option.date,
                        adId: option.adId ? option.adId : '-',
                        click: option.click,
                        ecpc: option.ecpc == 0 ? option.ecpc : (!!option.ecpc ? (option.ecpc).toFixed(2) : '-'),
                        pv: option.pv,
                        totalCost: option.totalCost == 0 ? option.totalCost : (!!option.totalCost ? (option.totalCost).toFixed(2) : '-'),
                        ctr: option.ctr == 0 ? option.ctr : (!!option.ctr ? (option.ctr).toFixed(2) + '%' : '-'),
                        ecpm: option.ecpm == 0 ? option.ecpm : (!!option.ecpm ? (option.ecpm).toFixed(2) : '-')
                    };
                    this.tableData.push(val);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis.data.push(timeFirst);

                    let val = {
                        date: timeFirst,
                        adId: '-',
                        click: 0,
                        ecpc: 0,
                        pv: 0,
                        totalCost: 0,
                        ctr: 0,
                        ecpm: 0
                    };
                    this.tableData.push(val);
                }
                timeFirst = this.$utils.getNextDay(timeFirst);
            }while (timeFirst != this.$utils.getNextDay(timeSecond));

            let list = [{
                name: '总消费',
                data: totalCostData
            },{
                name: '展示数',
                data: pvData
            },{
                name: '点击数',
                data: clickData
            },{
                name: '点击率',
                data: ctrData
            },{
                name: 'ECPM(元)',
                data: ecpmData
            },{
                name: 'ECPC(元)',
                data: ecpcData
            }];

            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        data: val.data
                    }
                    let yAxisItem = {};

                    if(index == idx) {
                        this.list.series.push(item);
                        if(val.name.includes("率")) {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                min: 0,
                                max: 100,
                                axisLabel: {
                                    formatter: '{value}%'
                                }
                            }
                        } else {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                axisLabel: {
                                    formatter: '{value}'
                                }
                            }
                        }
                        this.list.yAxis.push(yAxisItem);
                    }
                });
            });

            return true;
        },

        formatInitHoursData(realData, timeFirst, timeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[timeFirst]) {
                    let option = realData[timeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);

                    this.list.xAxis.data.push(option.date);

                    let val = {
                        date: option.date,
                        adId: option.adId ? option.adId : '-',
                        click: option.click,
                        ecpc: option.ecpc == 0 ? option.ecpc : (!!option.ecpc ? (option.ecpc).toFixed(2) : '-'),
                        pv: option.pv,
                        totalCost: option.totalCost == 0 ? option.totalCost : (!!option.totalCost ? (option.totalCost).toFixed(2) : '-'),
                        ctr: option.ctr == 0 ? option.ctr : (!!option.ctr ? (option.ctr).toFixed(2) + '%' : '-'),
                        ecpm: option.ecpm == 0 ? option.ecpm : (!!option.ecpm ? (option.ecpm).toFixed(2) : '-')
                    };
                    this.tableData.push(val);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis.data.push(timeFirst);

                    let val = {
                        date: timeFirst,
                        adId: '-',
                        click: 0,
                        ecpc: 0,
                        pv: 0,
                        totalCost: 0,
                        ctr: 0,
                        ecpm: 0
                    };
                    this.tableData.push(val);
                }
                timeFirst = this.$utils.getNextHourByDate(timeFirst);
            }while (timeFirst != this.$utils.getNextHourByDate(timeSecond));

            let list = [{
                name: '总消费',
                data: totalCostData
            },{
                name: '展示数',
                data: pvData
            },{
                name: '点击数',
                data: clickData
            },{
                name: '点击率',
                data: ctrData
            },{
                name: 'ECPM(元)',
                data: ecpmData
            },{
                name: 'ECPC(元)',
                data: ecpcData
            }];

            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        data: val.data
                    }
                    let yAxisItem = {};

                    if(index == idx) {
                        this.list.series.push(item);
                        if(val.name.includes("率")) {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                min: 0,
                                max: 100,
                                axisLabel: {
                                    formatter: '{value}%'
                                }
                            }
                        } else {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                axisLabel: {
                                    formatter: '{value}'
                                }
                            }
                        }
                        this.list.yAxis.push(yAxisItem);
                    }
                });
            });

            return true;
        },

        initFirstDate() {
            this.initChartData()
                .then(res => {
                    if(res.code == '200') {

                        this.list.xAxis.data = [];
                        this.list.yAxis = [];
                        this.list.series = [];
                        this.tableData = [];
                        let realData = {};

                        if(res.data && res.data.length > 0) {
                            res.data.forEach(option => {
                                realData[option.date] = option;
                            });
                        }
                        let timeFirst = this.$utils.formatDate(this.formInline.time[0], "yyyy-MM-dd");
                        let timeSecond = this.$utils.formatDate(this.formInline.time[1], "yyyy-MM-dd");

                        if(timeFirst == timeSecond) {
                            this.formatInitHoursData(realData, timeFirst + " 00:00:00", timeSecond + " 23:00:00");
                        } else {
                            this.formatInitDailyData(realData, timeFirst, timeSecond);
                        }
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }

                    this.list.series[0]. yAxisIndex = 0;
                    this.list.series[1]. yAxisIndex = 1;
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        initChartData() {
            return new Promise((resolve, reject) => {
                let searchStartDate = this.$utils.formatDate(new Date(this.formInline.time[0]), "yyyy-MM-dd");
                let searchEndDate = this.$utils.formatDate(new Date(this.formInline.time[1]), "yyyy-MM-dd");

                if(searchStartDate == searchEndDate) {
                    searchStartDate = searchStartDate.toString() + " 00:00:00";
                    searchEndDate = searchEndDate.toString() + " 23:59:59"
                }

                let params = {
                    type: 'ad',
                    searchStartDate: searchStartDate,
                    searchEndDate: searchEndDate,
                    promotionId: this.formInline.promotionId,
                    adId: this.formInline.adId
                }
                let utc = this.formInline.time[1] - this.formInline.time[0];
                let day = utc / (24 * 60 * 60 * 1000);
                let url = '';

                if(parseInt(day) >= 1) {
                    url = this.$store.state.getAdReportDaily;
                } else {
                    url = this.$store.state.getAdReportHourly;
                }
                this.$request.get(url, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .report-container {
        height: auto;
        background-color: $white;
        box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

        .el-checkbox-button.is-disabled {
            .el-checkbox-button__inner {
                color: #fff !important;
                background-color: #409EFF !important;
                border-color: #409EFF !important;
                -webkit-box-shadow: -1px 0 0 0 #8cc5ff !important;
                box-shadow: -1px 0 0 0 #8cc5ff !important;
            }
        }

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }

        .demo-form-inline {
            height: 100%;
            width: 100%;

            .el-form-item:not(:first-child) {
                margin: 22px 10px !important;
            }

            .el-form-item:first-child {
                margin: 22px 10px 22px 30px !important;
            }
        }

        .el-row {
            &:last-child {
              margin-bottom: 0;
            }
        }

        .el-col {
            border-radius: 4px;
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-create {
                margin: 19px 0;
            }
        }

        .grid-line {
            background-color: $white;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            height: 52px;
            margin: 0;
            padding: 0;

            .checkbox-row {
                margin: 45px 0 0;
            }
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-purple {
                font-size: $font-size-3;
                color: $font-color;
                text-align: center;
                line-height: 116px;
            }

            .grid-item {
                text-align: center;
            }
        }

        .echarts {
            width: 100% !important;
            height: 400px;
        }

        .line {
            background-color: $white;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            height: 462px;
            margin: 0;

            #line {
                width: 958px;
            }
        }

        .select {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            padding: 45px 30px;
        }

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }
    }
</style>
