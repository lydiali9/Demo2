<template>
    <div class="home-container">
        <div class="grid-introduct">账户概况</div>
        <el-row :gutter="20">
            <el-col :span="20">
                <div class="grid-content">
                    <el-row>
                        <el-col :span="6">
                            <div class="bg-white">
                                <div class="grid-item num">{{consumptionToday}}</div>
                                <div class="grid-item des">今日预估消费 /元</div>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div class="grid-content bg-white">
                                <div class="grid-item num">{{balance}}</div>
                                <div class="grid-item des">账户余额 /元</div>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div class="grid-content bg-white">
                                <div class="grid-item num">{{availableBalance}}</div>
                                <div class="grid-item des">可用余额 /元</div>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div class="grid-content bg-white">
                                <div class="grid-item num">{{frozenAmount}}</div>
                                <div class="grid-item des">冻结金额 /元</div>
                            </div>
                        </el-col>
                    </el-row>
                </div>
            </el-col>
            <el-col :span="4">
                <div class="grid-content-two bg-white" @click="skip">
                    <!-- <span>数量:</span> -->
                    <span>{{auditFailNum}}</span>
                </div>
                <div class="grid-content-two words bg-white">
                    <p>审核未通过广告</p>
                </div>
            </el-col>
        </el-row>


        <el-row :gutter="20" style="margin: 15px 0 10px">
            <el-col :span="4" style="padding-left: 0; padding-right: 0;">
                <div class="grid-introduct">数据概况</div>
            </el-col>
            <el-col :span="16">&nbsp;</el-col>
            <el-col :span="4" style="padding-left: 0; padding-right: 0;">
                <div class="grid-content introduct">
                    <div class="grid-content dsp-select">
                        <el-select v-model="time" filterable placeholder="请选择">
                            <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                </div>
            </el-col>
        </el-row>

        <div class="grid-tab">
            <el-row>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content title">
                        总消费
                    </div>
                </el-col>
              <el-col :span="4" class="grid-row">
                    <div class="grid-content title">
                        展示数
                    </div>
                </el-col>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content title">
                        点击数
                    </div>
                </el-col>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content title">
                        点击率
                    </div>
                </el-col>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content title">
                        ECPM(元)
                    </div>
                </el-col>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content title">
                        ECPC(元)
                    </div>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content row">
                        {{totalCostNum}}
                    </div>
                </el-col>
              <el-col :span="4" class="grid-row">
                    <div class="grid-content row">
                        {{pvNum}}
                    </div>
                </el-col>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content row">
                        {{clickNum}}
                    </div>
                </el-col>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content row">
                        {{ctrNum}}
                    </div>
                </el-col>
                <el-col :span="4" class="grid-row">
                    <div class="grid-content row">
                        {{ecpmNum}}
                    </div>
                </el-col>
                <el-col :span="4"class="grid-row">
                    <div class="grid-content row">
                        {{ecpcNum}}
                    </div>
                </el-col>
            </el-row>
        </div>

        <div class="grid-line">
            <el-row type="flex" justify="center">
                <el-col :span="8">
                    <div class="grid-content">
                        <el-checkbox-group v-model="checkboxGroup" size="medium" @change="handleCheckedItem">
                            <el-checkbox-button :disabled="checkboxGroup.includes(item.value) ? true : false" v-for="item in items" :label="item.value" :key="item.value">
                                {{item.label}}
                            </el-checkbox-button>
                        </el-checkbox-group>

                    </div>
                </el-col>
            </el-row>
        </div>
        <div id="line" class="line">
            <template>
                <chart :options="list"></chart>
            </template>
        </div>

        <el-dialog class="step" :visible.sync="dialogVisible" width="43%" :close-on-click-modal="false">
            <ul class="box">
                <li class="common-style">
                    <img @click="back" v-bind:class="{ 'greyBackImg': active == 0, 'greenBackImg': active != 0 }"/>
                </li>
                <li>
                    <div v-show="active == 0">
                        <div class="new-title">
                            <span class="title">欢迎使用英威诺广告投放管理平台，给您介绍一下如何创建广告吧！</span>
                        </div>
                        <el-row>
                            <el-col :span="12">
                                <div class="grid-content bg-purple">
                                    <img class="step-img" src="../../assets/images/home/backgroup.png"/>
                                </div>
                            </el-col>
                            <el-col :span="12">
                                <ul class="grid-content bg-purple-light">
                                    <li>1. 每个广告由推广计划、广告ID、素材三层组成。</li>
                                    <li>2. 每个推广计划可以包含多个广告ID、每个广告ID可以包含多套素材。</li>
                                    <li>3. 广告创建步骤请点击下一步。</li>
                                </ul>
                            </el-col>
                        </el-row>
                    </div>
                    <div v-show="active == 1">
                        <div class="new-title">
                            <span class="title">您的账户尚无广告，给您介绍一下如何创建广告吧！
                            </span>
                        </div>
                        <el-row class="step-two">
                            <el-col :span="12">
                                <el-button class="dsp-botton" align="middle">新建推广计划</el-button>
                                <ul class="grid-content bg-purple-light word-li">
                                    <li>1. 您想推广网页还是应用？</li>
                                    <li>2. 您想面向哪些用户推广？</li>
                                    <li>3. 您的预算、愿意出多少价格及付费方式？</li>
                                </ul>
                            </el-col>
                            <el-col :span="12">
                                <el-button class="dsp-botton" align="middle">创建广告</el-button>
                                <ul class="grid-content bg-purple-light word-li">
                                    <li>1. 上传您精心设计的素材图片。</li>
                                    <li>2. 配上优美的标题文字。</li>
                                </ul>
                            </el-col>
                        </el-row>
                    </div>
                    <div v-show="active == 2">
                        <div class="new-title">
                            <span class="title">广告创建示意</span>
                        </div>
                        <img class="stepthree-img" src="../../assets/images/home/introduction.png"/>
                        <div class="step-title">广告创建</div>
                        <el-row>
                            <el-col :span="12">
                                <ul class="grid-content bg-purple">
                                    <li>1. 点击"推广计划"。</li>
                                </ul>
                            </el-col>
                            <el-col :span="12">
                                <ul class="grid-content bg-purple">
                                    <li>2. 点击"新建推广计划"。</li>
                                </ul>
                            </el-col>
                        </el-row>
                    </div>
                    <div v-show="active == 3">
                        <div class="new-title">
                            <span class="title">投放数据查询</span>
                        </div>
                        <el-row class="step-two">
                            <el-col :span="12">
                                <span>
                                    <img class="stepfour-img" src="../../assets/images/home/introduction-four.png"/>
                                </span>
                            </el-col>
                            <el-col :span="12">
                                <div class="step-title-four">效果数据</div>
                                <ul class="grid-content bg-purple-four">
                                    <li>1. 点击"报表统计"。</li>
                                    <li>2. 在左侧导航栏选择所需要查看的详细项。</li>
                                </ul>
                            </el-col>
                        </el-row>
                        <div class="four-button">
                            <el-button class="dsp-botton" @click="learn" align="middle">学习完毕，前去创建广告</el-button>
                        </div>
                    </div>
                </li>
                <li class="common-style">
                    <img @click="next" v-bind:class="{ 'greenNextImg': active != 3, 'greyNextImg': active == 3 }"/>
                </li>
            </ul>

            <span style="margin: 25px 45px;">
                <el-steps :active="active" align-center finish-status="success" class="grid-process" :space="10">
                    <el-step title=""></el-step>
                    <el-step title=""></el-step>
                    <el-step title=""></el-step>
                    <el-step title=""></el-step>
                </el-steps>
            </span>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: false,
            active: 0,
            totalCostNum: 0,
            pvNum: 0,
            clickNum: 0,
            ctrNum: 0,
            ecpmNum: 0,
            ecpcNum: 0,
            consumptionToday: null,
            balance: null,
            availableBalance: null,
            frozenAmount: null,
            auditFailNum: 0,
            options: [
                {
                    value: '1',
                    label: '过去7天'
                },
                {
                    value: '2',
                    label: '过去30天'
                },
                {
                    value: '3',
                    label: '昨天'
                },
                {
                    value: '4',
                    label: '今天'
                }
            ],
            time: '',
            searchStartDate: '',
            searchEndDate: '',
            items: [
                {
                    value: 0,
                    label: '总消费',
                    isDisabled: true
                },
                {
                    value: 1,
                    label: '展示数',
                    isDisabled: true
                },
                {
                    value: 2,
                    label: '点击数',
                    isDisabled: false
                },
                {
                    value: 3,
                    label: '点击率',
                    isDisabled: false
                },
                {
                    value: 4,
                    label: 'ECPM(元)',
                    isDisabled: false
                },
                {
                    value: 5,
                    label: 'ECPC(元)',
                    isDisabled: false
                }
            ],
            checkboxGroup: [],
            list: {
                color: ['#5793f3', '#d14a61', '#675bba'],
                title: {
                    text: '折线图堆叠'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'cross'
                    }
                },
                legend: {
                    data: ['总消费', '展示数', '点击数', '点击率', 'ECPM(元)', 'ECPC(元)']
                },
                grid: {
                    top: 70,
                    bottom: 50
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: true,
                    data: []
                },
                yAxis: [],
                series: [
                ]
            }
        }
    },
    mounted() {
        this.initData();
    },
    created() {
        if(localStorage.getItem('has_ad') != null && localStorage.getItem('has_ad') == "false") {
            this.dialogVisible = true;
        }

        this.active = 0;
        this.time = this.options[0].value;
        this.checkboxGroup = [this.items[0].value, this.items[1].value];
        this.initialize();
    },
    watch: {
        time: function(val) {
            switch(val) {
                case '1':
                    this.searchEndDate = this.$utils.formatDate(new Date(), "yyyy-MM-dd");
                    this.searchStartDate = this.$utils.formatDate(new Date(new Date().getTime() - 3600 * 1000 * 24 * 7), "yyyy-MM-dd");
                    break;
                case '2':
                    this.searchEndDate = this.$utils.formatDate(new Date(), "yyyy-MM-dd");
                    this.searchStartDate = this.$utils.formatDate(new Date(new Date().getTime() - 3600 * 1000 * 24 * 30), "yyyy-MM-dd");
                    break;
                case '3':
                    let date = this.$utils.formatDate(new Date(new Date().getTime() - 3600 * 1000 * 24 * 1), "yyyy-MM-dd");
                    this.searchStartDate = date + ' 00:00:00';
                    this.searchEndDate = date + ' 23:59:59';
                    break;
                case '4':
                    let dateTime = this.$utils.formatDate(new Date(new Date().getTime()), "yyyy-MM-dd");
                    this.searchStartDate = dateTime + ' 00:00:00';
                    this.searchEndDate = dateTime + ' 23:59:59';
                    break;
                default:
                    return false;
            }
            this.initData()
        }
    },
    methods: {
        initialize() {
            this.initAccount();
            this.auditFailAdNum();
        },

        back() {
            if(this.active <= 0) {
                return false;
            }
            return this.active--;
        },

        next() {
            if(this.active >= 3) {
                return false;
            }
            return this.active++;
        },

        learn() {
            return this.$router.push({path: '/advert'});
        },

        auditFailAdNum() {
            this.getAuditFail()
                .then(res => {
                    if(res.code == 200) {
                        let data = res.data;
                        this.auditFailNum = data.auditFailCount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: "未通过广告数"
                    });
                });
        },

        getAuditFail() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.auditFail, {})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        handleCheckedItem(item) {
            this.checkboxGroup.shift();
            this.initChartData();
        },

        initAccount() {
            this.getInitData()
                .then(res => {
                    if(res.code == 200) {
                        let data = res.data;

                        this.consumptionToday = data.consumptionToday;
                        this.balance = data.balance;
                        this.availableBalance = data.availableBalance;
                        this.frozenAmount = data.frozenAmount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: "获取帐户概况失败"
                    });
                });
        },

        formatInitDailyData(realData, timeFirst, timeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[timeFirst]) {
                    let option = realData[timeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);

                    this.list.xAxis.data.push(option.date);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis.data.push(timeFirst);
                }
                timeFirst = this.$utils.getNextDay(timeFirst);
            }while (timeFirst != this.$utils.getNextDay(timeSecond));

            let list = [{
                name: '总消费',
                data: totalCostData
            },{
                name: '展示数',
                data: pvData
            },{
                name: '点击数',
                data: clickData
            },{
                name: '点击率',
                data: ctrData
            },{
                name: 'ECPM(元)',
                data: ecpmData
            },{
                name: 'ECPC(元)',
                data: ecpcData
            }];

            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        data: val.data
                    }
                    let yAxisItem = {};

                    if(index == idx) {
                        this.list.series.push(item);

                        if(val.name.includes("率")) {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                min: 0,
                                max: 100,
                                axisLabel: {
                                    formatter: '{value}%'
                                }
                            }
                        } else {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                axisLabel: {
                                    formatter: '{value}'
                                }
                            }
                        }
                        this.list.yAxis.push(yAxisItem);
                    }
                });
            });

            return true;
        },

        formatInitHoursData(realData, timeFirst, timeSecond) {
            let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];

            do {
                if(!!realData[timeFirst]) {
                    let option = realData[timeFirst];

                    totalCostData.push(option.totalCost);
                    pvData.push(option.pv);
                    clickData.push(option.click);
                    ctrData.push(option.ctr);
                    ecpmData.push(option.ecpm);
                    ecpcData.push(option.ecpc);

                    this.list.xAxis.data.push(option.date);
                } else {
                    totalCostData.push(0);
                    pvData.push(0);
                    clickData.push(0);
                    ctrData.push(0);
                    ecpmData.push(0);
                    ecpcData.push(0);

                    this.list.xAxis.data.push(timeFirst);
                }
                timeFirst = this.$utils.getNextHourByDate(timeFirst);
            }while (timeFirst != this.$utils.getNextHourByDate(timeSecond));

            let list = [{
                name: '总消费',
                data: totalCostData
            },{
                name: '展示数',
                data: pvData
            },{
                name: '点击数',
                data: clickData
            },{
                name: '点击率',
                data: ctrData
            },{
                name: 'ECPM(元)',
                data: ecpmData
            },{
                name: 'ECPC(元)',
                data: ecpcData
            }];

            this.checkboxGroup.forEach(index => {
                list.forEach((val, idx) => {
                    let item = {
                        name: val.name,
                        type: 'line',
                        data: val.data
                    }
                    let yAxisItem = {};

                    if(index == idx) {
                        this.list.series.push(item);

                        if(val.name.includes("率")) {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                min: 0,
                                max: 100,
                                axisLabel: {
                                    formatter: '{value}%'
                                }
                            }
                        } else {
                            yAxisItem = {
                                type: 'value',
                                name: val.name,
                                axisLabel: {
                                    formatter: '{value}'
                                }
                            }
                        }
                        this.list.yAxis.push(yAxisItem);
                    }
                });
            });

            return true;
        },

        initChartData() {
            const sum = (...arr) => [].concat(...arr).reduce((acc, val) => acc + val, 0);

            this.getChartData()
                .then(res => {
                    if(res.code == '200') {
                        let [totalCostData, pvData, clickData, ctrData, ecpmData, ecpcData] = [[], [], [], [], [], []];
                        this.list.xAxis.data = [];
                        this.list.yAxis = [];
                        this.list.series = [];

                        let realData = {};

                        if(res.data && res.data.length > 0) {
                            res.data.forEach(option => {
                                totalCostData.push(option.totalCost);
                                pvData.push(option.pv);
                                clickData.push(option.click);
                                ctrData.push(option.ctr);
                                ecpmData.push(option.ecpm);
                                ecpcData.push(option.ecpc);

                                realData[option.date] = option;
                            });
                        }

                        this.totalCostNum = new Number(sum(totalCostData)).toFixed(2);
                        this.pvNum = new Number(sum(pvData)).toFixed(2);
                        this.clickNum = new Number(sum(clickData)).toFixed(2);
                        this.ctrNum = this.pvNum == 0 ? 0 : (this.clickNum/this.pvNum*100).toFixed(2) + '%';
                        this.ecpmNum = this.pvNum == 0 ? 0 : (this.totalCostNum/this.pvNum*1000).toFixed(2);

                        let timeFirst = this.$utils.formatDate(new Date(this.searchStartDate), "yyyy-MM-dd");
                        let timeSecond = this.$utils.formatDate(new Date(this.searchEndDate), "yyyy-MM-dd");

                        if(timeFirst == timeSecond) {
                            this.formatInitHoursData(realData, timeFirst + " 00:00:00", timeSecond + " 23:00:00");
                        } else {
                            this.formatInitDailyData(realData, timeFirst, timeSecond);
                        }
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                    this.list.series[0]. yAxisIndex = 0;
                    this.list.series[1]. yAxisIndex = 1;
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: "获取数据概况失败"
                    });
                });
        },

        getInitData() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.account, {})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        initData() {
            if(this.searchStartDate && this.searchEndDate) {
                this.initChartData();
            }
        },

        getChartData() {
            let params = {
                searchStartDate: this.searchStartDate,
                searchEndDate: this.searchEndDate,
                type: 'user'
            };

            return new Promise((resolve, reject) => {
                if(this.time == '1' || this.time == '2') {
                    this.$request.get(this.$store.state.getAdReportDaily, params)
                        .then(data => {
                            resolve(data);
                        }).catch(err => {
                            reject(err);
                        });
                } else {
                    this.$request.get(this.$store.state.getAdReportHourly, params)
                        .then(data => {
                            resolve(data);
                        }).catch(err => {
                            reject(err);
                        });
                }
            });
        },

        skip() {
            return this.$router.push({path: '/advert', query : { state : 2}});
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .echarts {
        width: 100% !important;
        height: 400px;
    }

    .home-container .el-checkbox-button__inner {
        color: #fff !important;
        background-color: #409EFF !important;
        border-color: #409EFF !important;
        -webkit-box-shadow: -1px 0 0 0 #8cc5ff !important;
        box-shadow: -1px 0 0 0 #8cc5ff !important;
    }

    .home-container {
        height: auto;

        .grid-process {
            width: 100%;
            display: flex;
            justify-content:center;
            margin-top: 20px;
        }

        .stepthree-img {
            text-align: center;
        }

        .stepfour-img {
            text-align: center;
            width: 260px;
        }

        .four-button {
            width: 100%;
            display: flex;
            justify-content:center;

            .dsp-botton {
                @include green-botton;
                margin-bottom: 62px;
            }
        }

        .step-two {
            display: flex;
            justify-content: center;

            div:last-child {
            }

            .dsp-botton {
                @include green-botton;
                text-align: center;
                margin-left: 50px;
            }

            .word-li {
                margin: 16px 24px 64px 0;
                border: 1px solid #eeeeee;
                box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
                border-radius: 4px;
                padding: 5px;
                width: 224px;
                height: 124px;
            }
        }

        .bg-purple-light {
            font-size: $font-size-2;
            color: $content-color;
            line-height: 28px;
        }

        .bg-purple-four {
            font-size: $font-size-2;
            color: $content-color;
            line-height: 28px;
            margin-left: 50px;
            width: 200px;

            li {
                text-align: left;
            }
        }

        .bg-purple {
            li {
                font-size: $font-size-2;
                color: $content-color;
                line-height: 28px;
                text-align: center;
                margin-bottom: 66px;
            }
        }

        .step-title {
            font-size: $font-size-3;
            color: $font-color;
            margin: 36px 0 16px;
            text-align: center;
        }

        .step-title-four {
            font-size: $font-size-3;
            color: $font-color;
            margin: 0 16px 10px 50px;
            text-align: left;
        }

        .new-title {
            font-size: $font-size-5;
            color: $font-color;
            margin-bottom: 86px;
            width: 100%;
            display: flex;
            justify-content: center;

            .title {
                border-bottom: 2px solid $green;
                padding-bottom: 12px;
                text-align: center;
            }
        }

        .greyBackImg {
            width: 45px;
            height: 75px;
            background-image: url(../../assets/images/home/backGrey.png);
            background-repeat: no-repeat;
            border-radius: 5px;
            border: none;
            margin-top: 155px;
        }

        .greenBackImg {
            width: 45px;
            height: 75px;
            background-image: url(../../assets/images/home/backGreen.png);
            background-repeat: no-repeat;
            border-radius: 5px;
            border: none;
            margin-top: 155px;
        }

        .greenNextImg {
            width: 45px;
            height: 75px;
            background-image: url(../../assets/images/home/nextGreen.png);
            background-repeat: no-repeat;
            border-radius: 5px;
            border: none;
            margin-top: 155px;
        }

        .greyNextImg {
            width: 45px;
            height: 75px;
            background-image: url(../../assets/images/home/nextGrey.png);
            background-repeat: no-repeat;
            border-radius: 5px;
            border: none;
            margin-top: 155px;
        }

        .box {
            display: flex;
            justify-content: space-between;

            .common-style {
                background: #fff;
                text-align: left;
                cursor: pointer;
            }
        }

        .el-row {
            margin-bottom: 20px;

            &:last-child {
              margin-bottom: 0;
            }
        }

        .el-col {
            border-radius: 4px;
        }

        .bg-white {
            background: $white;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            width: 100%;
        }

        .grid-felx {
            border-radius: 4px;
            min-height: 116px;
            height: auto;
            display: flex;
            justify-content: center;

            .grid-introduct {
                align-self: center;
                font-weight: bold;
            }
        }

        .grid-introduct {
            align-self: center;
            height: 56px;
            line-height: 56px;
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-purple {
                font-size: $font-size-3;
                color: $font-color;
                text-align: center;
                line-height: 116px;
            }

            .grid-item {
                text-align: center;
            }
        }

        .num {
            min-height: 68px;
            font-size: $font-size-9;
            color: $green;
            line-height: 68px;
        }

        .des {
            font-size: $font-size-2;
            color: $font-color;
            min-height: 48px;
            line-height: 48px;
        }

        .introduct {
            float: right;
        }

        .grid-content-two {
            border-radius: 4px;
            min-height: 68px;
            display: flex;
            justify-content: center;
            cursor: pointer;

            p {
                font-size: $font-size-2;
                color: $font-color;
                align-self: center;
            }

            span:first-child {
                font-size: $font-size-1;
                color: $small-font-color;
                align-self: center;
            }

            span:last-child {
                font-size: $font-size-9;
                color: $orange;
                align-self: center;
            }
        }

        .words {
            min-height: 48px;
            text-align: center;
            font-size: $font-size-2;
        }

        .row-bg {
            padding: 10px 0;
            background-color: #f9fafc;
        }

        .grid-container {
            background-color: $white;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            height: 78px;

            .flex {
                display: flex;
                justify-content: center;
                min-height: 78px;
                height: auto;
            }

            .grid-data {
                border-radius: 4px;
                align-self: center;
                font-weight: bold;
            }

            .dsp-select {
                margin: 20px 20px 0 20px;
            }

            .dsp-botton {
                background-color: $green;

                &:active {
                    color: $white;
                    border-color: $green;
                    outline: 0;
                }

                &:hover {
                    color: $white;
                    border-color: $green;
                    outline: 0;
                }

                &:focus {
                    color: $white;
                    border-color: $green;
                    outline: 0;
                }
            }
        }

        .grid-tab {
            margin: 0 0 10px;
            .el-row {
                margin: 0 !important;
            }

            .grid-row {
                min-height: 52px;
                height: auto;
                display: flex;
                justify-content: center;
            }

            .el-row:first-child {
                background-color: $title-background;
                align-self: center;
            }

            .el-row:last-child {
                background-color: $white;
                align-self: center;
                box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            }

            .title {
                font-size: $font-size-2;
                color: $content-color;
                align-self: center;
            }

            .row {
                font-size: $font-size-2;
                color: $font-color;
                align-self: center;
            }
        }

        .line {
            background-color: $white;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            height: 462px;
            margin: 0;
            padding: 0 0 45px;

            #line {
                width: 958px;
            }
        }

        .grid-line {
            background-color: $white;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            height: 52px;
            margin: 0;
            padding-top: 25px;
        }
    }
</style>
