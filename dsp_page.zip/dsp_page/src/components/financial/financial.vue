<template>
    <div class="report-container">
        <el-row class="selection">
            <el-form :inline="true" :model="formInline" ref="formInline" class="demo-form-inline">
                <el-form-item label="时间范围" prop="time">
                    <div class="grid-content bg-create time">
                        <el-date-picker :clearable="false" size="middle" v-model="formInline.time" type="daterange" align="right"unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerTime" @change="handleTime">
                        </el-date-picker>
                    </div>
                </el-form-item>
            </el-form>
        </el-row>

        <el-row :gutter="20" style="margin-top: 15px">
            <el-col :span="24">
                <div class="grid-content bg-white">
                    <el-row>
                        <el-col :span="4" class="grid-felx">
                            <div class="grid-introduct">今日概况</div>
                        </el-col>
                        <el-col :span="5">
                            <div class="grid-item num">{{consumptionToday}}</div>
                            <div class="grid-item des">今日预估消费/元</div>
                        </el-col>
                        <el-col :span="5">
                            <div class="grid-content">
                                <div class="grid-item num">{{balance}}</div>
                                <div class="grid-item des">账户余额/元</div>
                            </div>
                        </el-col>
                        <el-col :span="5">
                            <div class="grid-content">
                                <div class="grid-item num">{{availableBalance}}</div>
                                <div class="grid-item des">可用余额/元</div>
                            </div>
                        </el-col>
                        <el-col :span="5">
                            <div class="grid-content">
                                <div class="grid-item num">{{frozenAmount}}</div>
                                <div class="grid-item des">冻结金额/元</div>
                            </div>
                        </el-col>
                    </el-row>
                </div>
            </el-col>
        </el-row>

        <el-row class="select tables">
            <el-table :data="tableData" border show-summary sum-text="" style="width: 100%" class="tabs">
                <el-table-column prop="date" label="日期" width="220"></el-table-column>
                <el-table-column prop="rechargeAmount" label="充值金额"></el-table-column>
                <el-table-column prop="returnAmount" label="返货金额"></el-table-column>
                <el-table-column prop="consumptionAmount" label="消费金额"></el-table-column>
                <el-table-column prop="frozenAmount" label="冻结金额"></el-table-column>
                <el-table-column prop="balance" label="账户余额（冻结+可用）"></el-table-column>
            </el-table>

            <div class="tables">
                <el-pagination class="tabs" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPageNo" :page-sizes="sizes" :page-size="eachPageCapacity" layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
                </el-pagination>
            </div>
        </el-row>
    </div>
</template>

<script>
export default {
    data() {
        return {
            formInline: {
                time: ''
            },
            pickerTime: {
                shortcuts: [{
                    text: '今天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime());
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '昨天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '本周',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            tableData: [],
            currentPageNo: 1,
            eachPageCapacity: 10,
            totalCount: 1,
            sizes: [10, 25, 50, 100, 200],
            consumptionToday: null,
            balance: null,
            availableBalance: null,
            frozenAmount: null
        }
    },
    created() {
        this.initialize();
    },
    methods: {
        initialize() {
            this.initTime();
            this.initData();
            this.initAccount();
        },

        initTime() {
            let date = new Date();
            this.formInline.time = [date.getTime() - 3600 * 1000 * 24 * 1, date.getTime()];
        },

        initAccount() {
            this.getInitData()
                .then(res => {
                    if(res.code == 200) {
                        let data = res.data;

                        this.consumptionToday = data.consumptionToday;
                        this.balance = data.balance;
                        this.availableBalance = data.availableBalance;
                        this.frozenAmount = data.frozenAmount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: "获取帐户概况失败"
                    });
                });
        },

        getInitData() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.account, {})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        handleTime() {

            if(!!this.formInline.time) {
                let utc = this.formInline.time[1] - this.formInline.time[0];
                let day = utc / (24 * 60 * 60 * 1000);

                if(parseInt(day) > 30) {
                    this.$message({
                        showClose: true,
                        type: 'warning',
                        message: '所选时间范围不能超过30天'
                    });
                    this.initTime();
                    return false;
                }

                return this.initData();
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写时间范围'
                });
                return false;
            }
        },

        handleSizeChange(val) {
            this.eachPageCapacity = val;
            this.initData();
        },

        handleCurrentChange(val) {
            this.currentPageNo = val;
            this.initData();
        },

        initData() {
            this.tableData = [];

            this.getData()
                .then(res => {
                    if(res.code == '200') {
                        if(res.data && res.data.length > 0) {
                            res.data.forEach(option => {
                                this.tableData.push(option);
                            });
                            this.totalCount = res.page.totalCount;
                        }
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getData() {
            return new Promise((resolve, reject) => {
                let params = {
                    eachPageCapacity: this.eachPageCapacity,
                    currentPageNo: this.currentPageNo,
                    searchStartDate: this.$utils.formatDate(new Date(this.formInline.time[0]), "yyyy-MM-dd"),
                    searchEndDate: this.$utils.formatDate(new Date(this.formInline.time[1]), "yyyy-MM-dd")
                }

                this.$request.get(this.$store.state.getAccountFlow, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .report-container {
        height: auto;
        background-color: $white;
        box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }

        .num {
            min-height: 68px;
            font-size: $font-size-9;
            color: $green;
            line-height: 68px;
        }

        .des {
            font-size: $font-size-2;
            color: $font-color;
            min-height: 48px;
            line-height: 48px;
        }

        .demo-form-inline {
            height: 100%;
            width: 100%;

            .el-form-item:not(:first-child) {
                margin: 22px 10px !important;
            }

            .el-form-item:first-child {
                margin: 22px 10px 22px 30px !important;
            }
        }

        .el-row {
            &:last-child {
              margin-bottom: 0;
            }
        }

        .el-col {
            border-radius: 4px;
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-create {
                margin: 19px 0;
            }

            .bg-purple {
                font-size: $font-size-3;
                color: $font-color;
                text-align: center;
                line-height: 116px;
            }

            .grid-item {
                text-align: center;
            }
        }

        .bg-white {
            background: $white;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
        }

        .grid-felx {
            border-radius: 4px;
            min-height: 116px;
            height: auto;
            display: flex;
            justify-content: center;

            .grid-introduct {
                align-self: center;
                height: 56px;
                line-height: 56px;
            }
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-purple {
                font-size: $font-size-3;
                color: $font-color;
                text-align: center;
                line-height: 116px;
            }

            .grid-item {
                text-align: center;
            }
        }

        .select {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            padding: 45px 30px;
        }

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }

        .tables {
            padding: 25px 30px 0;
        }

        .tabs {
            padding: 25px 0;
            float: right;
        }
    }
</style>
