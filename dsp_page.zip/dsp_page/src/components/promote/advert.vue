<template>
    <div class="adver-container">
        <el-row class="selection">
            <el-form :inline="true" :model="formInline" ref="formInline" class="demo-form-inline">
                <div class="select-time" prop="timeIntervalType">
                    <el-select v-model="formInline.timeIntervalType" @change="handleTimeIntervalType">
                        <el-option v-for="item in timeIntervalTypeList" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </div>

                <div class="time-container" prop="deliverTime">
                    <div class="grid-content bg-create time">
                        <el-date-picker :clearable="false" size="middle" v-model="formInline.deliverTime" type="daterange" align="right"unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerDeliverTime" @change="handleDeliverTime">
                        </el-date-picker>
                    </div>
                </div>

                <el-form-item prop="state">
                    <el-select filterable v-model="formInline.state" placeholder="请输入广告状态" @change="handleState">
                        <el-option v-for="item in stateList" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>

                <!-- <el-form-item prop="keyword">
                    <div class="grid-content bg-create word">
                        <el-input placeholder="推广标题、ID模糊查询" v-model="formInline.keyword" class="input-with-select" @keyup.enter.native="search" clearable>
                            <el-button slot="append" icon="el-icon-search" @click="search"></el-button>
                        </el-input>
                    </div>
                </el-form-item> -->
                <el-form-item prop="promotionId">
                    <el-select v-model="formInline.promotionId" @change="handleTitle" filterable placeholder="请选择推广">
                        <el-option v-for="item in promotionIdList" :key="item.id" :label="item.title" :value="item.id">
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item prop="adId">
                    <el-select v-model="formInline.adId" @change="handleAdId" filterable placeholder="请选择广告ID">
                        <el-option v-for="item in adIdList" :key="item.id" :label="item.name" :value="item.id">
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item>
                    <div class="grid-content bg-create word">
                        <el-button class="dsp-botton" @click="create" align="middle">新建广告</el-button>
                    </div>
                </el-form-item>
            </el-form>
        </el-row>

        <el-row class="select tables">
            <el-table :data="tableData" border style="width: 100%" class="tabs">
                <el-table-column prop="adId" sortable label="广告ID" width="200"></el-table-column>
                <el-table-column prop="matNum" sortable label="素材数量" width="105"></el-table-column>
                <el-table-column prop="title" label="推广名称" width="200"></el-table-column>
                <el-table-column prop="deliverTime" sortable label="投放时间" width="220"></el-table-column>
                <el-table-column prop="totalCost" sortable label="总花费(元)" width="120"></el-table-column>
                <el-table-column prop="pv" sortable label="展示数" width="100"></el-table-column>
                <el-table-column prop="click" sortable label="点击数" width="100"></el-table-column>
                <el-table-column prop="ctr" sortable label="点击率" width="100"></el-table-column>
                <el-table-column prop="ecpc" sortable label="ECPC(元)" width="120"></el-table-column>
                <el-table-column prop="ecpm" sortable label="ECPM(元)" width="120"></el-table-column>
                <el-table-column label="状态" width="110">
                    <template slot-scope="scope">
                        <el-tag type="warning" v-if="scope.row.reviewStatus == 0">待审核</el-tag>
                        <p v-else-if="scope.row.reviewStatus == 1">
                            <el-tag type="warning" v-if="scope.row.reviewStatus == 1 && scope.row.status == 'flag'">待上线</el-tag>
                            <el-switch v-else-if="scope.row.reviewStatus == 1 && (scope.row.status == true || scope.row.status == false)" v-model="scope.row.status" @change="handleStatue(scope.row)">
                            </el-switch>

                            <el-tag type="danger" v-else-if="scope.row.reviewStatus == 1 && scope.row.status == 3">过期</el-tag>
                            <el-tag type="danger" v-else-if="scope.row.reviewStatus == 1 && scope.row.status == 4">废弃</el-tag>
                        </p>
                        <el-popover trigger="hover" placement="top" v-else-if="scope.row.reviewStatus == 2">
                            <p>原因: {{ scope.row.noPassReason }}</p>
                            <div slot="reference" class="name-wrapper">
                                <el-tag type="danger">审核未通过</el-tag>
                            </div>
                        </el-popover>
                        <el-tag type="danger" v-else-if="scope.row.reviewStatus == 3">强制下线</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="105">
                    <template slot-scope="scope">
                        <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">
                            编辑
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>

            <div class="tables">
                <el-pagination class="tabs" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPageNo" :page-sizes="sizes" :page-size="eachPageCapacity" layout="total, sizes, prev, pager, next, jumper" :total="totalCount">
                </el-pagination>
            </div>
        </el-row>
    </div>
</template>

<script>
export default {
    data() {
        return {
            stateList: [
                {
                    value: '0',
                    label: '状态(不限)'
                },
                {
                    value: '1',
                    label: '待审核'
                },
                {
                    value: '2',
                    label: '审核未通过'
                },
                {
                    value: '3',
                    label: '强制下线'
                },
                {
                    value: '4',
                    label: '待上线'
                },
                {
                    value: '5',
                    label: '已上线'
                },
                {
                    value: '6',
                    label: '已下线'
                },
                {
                    value: '7',
                    label: '已过期'
                },
                {
                    value: '8',
                    label: '废弃'
                }
            ],
            formInline: {
                deliverTime: '',
                // keyword: '',
                promotionId: '',
                adId: '',
                appId: '',
                state: '',
                status: '',
                reviewStatus: '',
                timeIntervalType: null
            },
            promotionIdList: [],
            adIdList: [],
            pickerDeliverTime: {
                shortcuts: [{
                    text: '今天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime());
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '昨天',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                        picker.$emit('pick', [start, end]);
                    }
                }, {
                    text: '本周',
                    onClick(picker) {
                        const end = new Date();
                        const start = new Date();
                        end.setTime(start.getTime() + 3600 * 1000 * 24 * 7);
                        picker.$emit('pick', [start, end]);
                    }
                }]
            },
            tableData: [],
            currentPageNo: 1,
            eachPageCapacity: 10,
            totalCount: 1,
            sizes: [10, 25, 50, 100, 200],
            timeIntervalTypeList: [
                {
                    label: '创建时间',
                    value: '1'
                },
                {
                    label: '投放时间',
                    value: '2'
                }
            ]
        }
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            this.formInline.timeIntervalType = this.timeIntervalTypeList[1].value;
            this.filterState();
            this.initDeliverTime();
            this.getAdList();
        },

        handleAdId() {
            this.getInfo();
        },

        handleTitle() {
            this.getInfo();
        },

        filterState() {
            let flag = this.$route.query.state;
            if(!!flag) {
                this.formInline.state = this.stateList[parseInt(flag)].value;
                this.formInline.status = '';
                this.formInline.reviewStatus = 2;
            } else {
                this.formInline.status = '';
                this.formInline.reviewStatus = '';
                this.formInline.state = this.stateList[0].value;
            }
        },

        getAdList() {
            this.adIdList = [{id: '', name: '广告ID(不限)'}];

            this.getAdIDList()
                .then(res => {
                    if(res.code == '200') {
                         if(res.data && res.data.length > 0) {
                            res.data.forEach(item => {
                                item = {
                                    id: item.adId,
                                    name: item.adId
                                }
                                this.adIdList.push(item);
                            });
                            this.formInline.adId = this.adIdList[0].id;
                            this.getPromote();
                        }
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getAdIDList() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.queryAd, { promotionId: this.formInline.promotionId })
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        getPromote() {
            this.promotionIdList = [{id: '', title: '选择推广（不限）'}];

            this.getPromotionIds()
                .then(res => {
                    if(res.code == '200') {

                        if(res.data && res.data.length > 0) {
                            res.data.forEach(item => {
                                this.promotionIdList.push(item);
                            });
                            this.formInline.promotionId = this.promotionIdList[0].id;
                        }
                        this.getInfo();
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getPromotionIds() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.queryPromote, {category: 3})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        initDeliverTime() {
            let date = new Date();
            this.formInline.deliverTime = [date.getTime() - 3600 * 1000 * 24 * 7, date.getTime()];
        },

        handleTimeIntervalType() {
            if(!!this.formInline.deliverTime) {
                return this.getInfo();
            }
            return false;
        },

        handleState(val) {
            switch(val) {
                case '0':
                    this.formInline.reviewStatus = '';
                    this.formInline.status = '';
                    break;
                case '1':
                    this.formInline.reviewStatus = 0;
                    this.formInline.status = '';
                    break;
                case '2':
                    this.formInline.reviewStatus = 2;
                    this.formInline.status = '';
                    break;
                case '3':
                    this.formInline.reviewStatus = 3;
                    this.formInline.status = '';
                    break;
                case '4':
                    this.formInline.status = 0;
                    this.formInline.reviewStatus = '';
                    break;
                case '5':
                    this.formInline.status = 1;
                    this.formInline.reviewStatus = '';
                    break;
                case '6':
                    this.formInline.status = 2;
                    this.formInline.reviewStatus = '';
                    break;
                case '7':
                    this.formInline.status = 3;
                    this.formInline.reviewStatus = '';
                    break;
                case '8':
                    this.formInline.status = 4;
                    this.formInline.reviewStatus = '';
                    break;
                default:
                    break;
            }
            this.getInfo();
        },

        handleStatue(row) {
            let param = {
                adId: row.adId,
                status: row.status == true ? 1 : 2
            };

            let tip = row.status == true ? '此操作将上线该广告, 是否继续?' : '此操作将下线该广告, 是否继续?'

            this.$confirm(tip, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.handleChangeStatus(param);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消操作'
                    });
                    this.getInfo();
                });
        },

        handleChangeStatus(param) {
            this.changeStatus(param)
                .then(res => {
                    if(res.code == '200') {
                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "更新状态成功"
                        });
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "更新状态失败"
                        });
                    }
                    this.getInfo();
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        changeStatus(params) {
            return new Promise((resolve, reject) => {
                this.$request.put(this.$store.state.changeAdStatus, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        search() {
            this.getInfo();
        },

        handleDeliverTime() {
            if(!!this.formInline.deliverTime) {
                let utc = this.formInline.deliverTime[1] - this.formInline.deliverTime[0];
                let day = utc / (24 * 60 * 60 * 1000);

                if(parseInt(day) > 30) {
                    this.$message({
                        showClose: true,
                        type: 'warning',
                        message: '所选时间范围不能超过30天'
                    });
                    this.initDeliverTime();
                    return false;
                }
                return this.getInfo();
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写时间范围'
                });
                return false;
            }
        },

        handleSizeChange(val) {
            this.eachPageCapacity = val;
            this.getInfo();
        },

        handleCurrentChange(val) {
            this.currentPageNo = val;
            this.getInfo();
        },

        getInfo() {
            this.tableData = [];

            if(!this.formInline.deliverTime) {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '请填写时间范围'
                });
                return false;
            }

            this.getAdver()
                .then(res => {

                    if(res.code == '200') {
                        if(res.data && res.data.length > 0) {
                            let list = {};

                            res.data.forEach(item => {
                                let status = '';
                                if(item.status == 0) {
                                    status = 'flag'
                                } else if(item.status == 1) {
                                    status = true
                                } else if(item.status == 2) {
                                    status = false
                                } else {
                                    status = item.status
                                }
                                this.$set(item, 'status', status);

                                if(!item.statistic) {
                                    let statistic = {
                                        click: 0,
                                        ctr: 0,
                                        ecpc: 0,
                                        ecpm: 0,
                                        pv: 0,
                                        totalCost: 0
                                    }
                                    item = Object.assign({statistic: statistic}, item);
                                }

                                let deliverStartTime = this.$utils.formatDate(new Date(item.promotion.deliverStartTime), "yyyy-MM-dd");
                                let deliverEndTime = this.$utils.formatDate(new Date(item.promotion.deliverEndTime), "yyyy-MM-dd");

                                list = Object.assign(item, {deliverTime: deliverStartTime + '  ~  ' + deliverEndTime}, item.statistic, item.promotion);

                                if(list.ctr && list.ctr != 0) {
                                    let ctr = (list.ctr).toFixed(2) + '%';
                                    this.$set(list, 'ctr', ctr);
                                }

                                if(list.ctr && list.ctr == 0) {
                                    let ctr = '0.00%';
                                    this.$set(list, 'ctr', ctr);
                                }

                                this.tableData.push(list);
                            });
                        }
                        this.totalCount = res.page.totalCount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取数据失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getAdver() {
            return new Promise((resolve, reject) => {
                let params = {
                    // keyword: this.formInline.keyword,
                    deliverStartTime: this.$utils.formatDate(new Date(this.formInline.deliverTime[0]), "yyyy-MM-dd"),
                    deliverEndTime: this.$utils.formatDate(new Date(this.formInline.deliverTime[1]), "yyyy-MM-dd"),
                    eachPageCapacity: this.eachPageCapacity,
                    currentPageNo: this.currentPageNo,
                    status: this.formInline.status,
                    reviewStatus: this.formInline.reviewStatus,
                    timeIntervalType: this.formInline.timeIntervalType,
                    promotionId: this.formInline.promotionId,
                    adId: this.formInline.adId
                }

                this.$request.get(this.$store.state.getAdver, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        create() {
            this.$router.push({ name: 'adEdit', path: '/adEdit'});
        },

        remove(formName) {
            this.$refs[formName].resetFields();
            this.getInfo();
        },

        handleEdit(index, row) {
            this.$router.push({ name: 'adEdit', path: '/adEdit', query: {id: row.adId}});
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .adver-container {
        height: auto;
        background-color: $white;
        box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

        .select {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            padding: 0 20px;
            margin: 0 0 15px !important;
        }

        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;

            .el-form--inline .el-form-item {
                display: inline-block;
                margin: 22px 30px;
                vertical-align: top;
            }
        }

        .demo-form-inline {
            height: 100%;
            width: 100%;
        }

        .tables {
            padding: 25px 30px 0;
        }

        .el-row {
            &:last-child {
              margin-bottom: 0;
            }
        }

        .el-col {
            border-radius: 4px;
        }

        .grid-content {
            border-radius: 4px;
            height: auto;

            .bg-create {
                margin: 19px 0;
            }

            .dsp-botton {
                @include green-botton;
            }

            .dsp-botton-gray {
                @include gray-botton;
            }
        }

        .grid-word {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .word {
                align-self: center;
            }
        }

        .grid-time {
            min-height: 78px;
            height: auto;
            display: flex;
            justify-content: flex-start;

            .time {
                align-self: center;
            }
        }

        .dsp-botton-red {
            @include red-botton;
        }

        .tabs {
            padding: 25px 0;
            float: right;
        }

        .select-time {
            display: inline-block;
            margin: 22px 0 22px 30px;
            vertical-align: top;

            .el-select {
                width: 105px !important;
            }
        }

        .time-container {
            display: inline-block;
            margin: 22px 10px 22px 0;
            vertical-align: top;
        }

        .el-form--inline .el-form-item {
            margin: 22px 10px !important;
        }
    }
</style>
