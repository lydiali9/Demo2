<template>
    <div class="adversting-container">
        <el-row class="selection">
            <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{ path: '/advert' }">广告管理</el-breadcrumb-item>
                <el-breadcrumb-item>{{ formTitle }}</el-breadcrumb-item>
            </el-breadcrumb>
        </el-row>

        <div class="steps">
            <div type="flex" justify="center">
                <el-form ref="form" :model="form" :rules="formRules">
                    <div align="left" class="step-item">
                        <el-form-item label="推广名称" prop="promotionId" label-width="145px">
                            <el-select filterable v-model="form.promotionId" placeholder="请选择推广名称" :disabled="isEdit">
                                <el-option v-for="item in promotionIdList" :key="item.id" :label="item.title" :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>

                        <el-form-item label="添加素材" prop="type" label-width="145px" required>
                            <el-radio-group @change="handleType" v-model="form.type" size="medium">
                                <el-radio-button v-for="item in formList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item v-if="form.type == 1" label-width="145px">
                            <el-row>
                                <div v-for="(item, index) in imgList" :key="item.name" :label="item.name">
                                    <el-col :sm="24" :md="12" :lg="8" :xl="8">
                                        <div class="grid-content">
                                            <div class="img-container">
                                                <p class="circle" @click="remove(1, index)">x</p>
                                                <div class="user">
                                                    <img v-if="item.imgServerUrl == '' || 'undefined' == typeof(item.imgServerUrl) " class="avatar" :src="item.url"/>
                                                    <img v-else class="avatar" :src="item.imgServerUrl"/>
                                                </div>
                                                <el-input minlength="170px" class="img-input" v-model="item.title" placeholder="请输入创意标题（6~25个字符）"></el-input>
                                            </div>
                                        </div>
                                    </el-col>
                                </div>
                                <el-col :sm="24" :md="12" :lg="8" :xl="8" v-show="imgList.length == 5 ? 0 : 1">
                                        <div class="grid-content">
                                            <div class="img-item">
                                                <div class="user">
                                                    <img class="avatar" :src="smallUrl"/>
                                                </div>
                                                <div class="layout">
                                                    <span class="cloud-upload-image" @click="selectImages">图片库</span>
                                                    <vue-core-image-upload
                                                        crop-ratio="1.33"
                                                        class="btn btn-primary"
                                                        :crop="false"
                                                        :url="imgUpload"
                                                        inputAccept="image/jpg,image/jpeg,image/png"
                                                        text="本地"
                                                        :data="typeData"
                                                        @imageuploaded="imgeUploaded">
                                                    </vue-core-image-upload>
                                                </div>
                                            </div>
                                        </div>
                                    </el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item v-else-if="form.type == 2" label-width="145px">
                            <el-form-item prop="bigImageType">
                                <el-radio-group v-model="form.bigImageType" size="small" style="margin-bottom: 22px;" @change="handleBigImageType">
                                    <el-radio-button v-for="item in bigImageTypeList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-row>
                                <div v-for="(item, index) in largeImgList" :key="item.name" :label="item.name">
                                    <el-col :sm="12" :md="10" :lg="8" :xl="8">
                                        <div class="grid-content">
                                            <div class="img-container">
                                                <p class="circle" @click="remove(2, index)">x</p>
                                                <div class="user">
                                                    <img v-if="item.imgServerUrl == '' || 'undefined' == typeof(item.imgServerUrl) " class="avatar" :src="item.url"/>
                                                    <img v-else class="avatar" :src="item.imgServerUrl"/>
                                                </div>
                                                <el-input minlength="170px" class="img-input" v-model="item.title" placeholder="请输入创意标题（6~25个字符）"></el-input>
                                            </div>
                                        </div>
                                    </el-col>
                                </div>
                                <el-col :sm="12" :md="10" :lg="8" :xl="8" v-if="form.bigImageType == 1" v-show="largeImgList.length == 5 ? 0 : 1">
                                    <div class="grid-content">
                                        <div class="img-item">
                                            <div class="user">
                                                <img class="avatar" :src="largeUrl1"/>
                                            </div>
                                            <div class="layout">
                                                <span class="cloud-upload-image" @click="selectImages">图片库</span>
                                                <vue-core-image-upload
                                                    crop-ratio="4.82"
                                                    class="btn btn-primary"
                                                    :crop="false"
                                                    :url="imgUpload"
                                                    inputAccept="image/jpg,image/jpeg,image/png"
                                                    text="本地"
                                                    :data="typeData"
                                                    @imageuploaded="largeImgUploaded">
                                                </vue-core-image-upload>
                                            </div>
                                        </div>
                                    </div>
                                </el-col>
                                <el-col :sm="12" :md="10" :lg="8" :xl="8" v-else-if="form.bigImageType == 2" v-show="largeImgList.length == 5 ? 0 : 1">
                                    <div class="grid-content">
                                        <div class="img-item">
                                            <div class="user">
                                                <img class="avatar" :src="largeUrl2"/>
                                            </div>
                                            <div class="layout">
                                                <span class="cloud-upload-image" @click="selectImages">图片库</span>
                                                <vue-core-image-upload
                                                    crop-ratio="1.78"
                                                    class="btn btn-primary"
                                                    :crop="false"
                                                    :url="imgUpload"
                                                    inputAccept="image/jpg,image/jpeg,image/png"
                                                    text="本地"
                                                    :data="typeData"
                                                    @imageuploaded="largeImgUploaded">
                                                </vue-core-image-upload>
                                            </div>
                                        </div>
                                    </div>
                                </el-col>
                                <el-col :sm="12" :md="10" :lg="8" :xl="8" v-else="form.bigImageType == 3" v-show="largeImgList.length == 5 ? 0 : 1">
                                    <div class="grid-content">
                                        <div class="img-item">
                                            <div class="user">
                                                <img class="avatar" :src="largeUrl3"/>
                                            </div>
                                            <div class="layout">
                                                <span class="cloud-upload-image" @click="selectImages">图片库</span>
                                                <vue-core-image-upload
                                                    crop-ratio="0.56"
                                                    class="btn btn-primary"
                                                    :crop="false"
                                                    :url="imgUpload"
                                                    inputAccept="image/jpg,image/jpeg,image/png"
                                                    text="本地"
                                                    :data="typeData"
                                                    @imageuploaded="largeImgUploaded">
                                                </vue-core-image-upload>
                                            </div>
                                        </div>
                                    </div>
                                </el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item v-else-if="form.type == 3">
                            <el-row>
                                <span class="add-icon">
                                    <img class="avatar" @click="addGroup" :src="url"/>
                                </span>
                                <span class="img-list">
                                    <span class="add-img" v-for="(list, index) in groupImgList" :key="list.random">
                                        <div class="img-group">
                                            <div v-for="(item, num) in list.imageList" :key="item.updateTime">
                                                <p class="circle" @click="remove(3, index)">x</p>
                                                <div class="img-option">
                                                    <el-col :sm="12" :md="10" :lg="8" :xl="8">
                                                        <div class="grid-content">
                                                            <div class="group-img-container">
                                                                <div class="user">
                                                                    <img v-if="item.imgServerUrl == '' || 'undefined' == typeof(item.imgServerUrl) " class="avatar" :src="item.url"/>
                                                                    <img v-else class="avatar" :src="item.imgServerUrl"/>
                                                                </div>
                                                                <div class="layout">
                                                                    <span class="cloud-upload-image" @click="selectGroupImages(index, num)">图片库</span>
                                                                    <vue-core-image-upload
                                                                        crop-ratio="4:3"
                                                                        class="btn btn-primary"
                                                                        :crop="false"
                                                                        :url="imgUpload"
                                                                        inputAccept="image/jpg,image/jpeg,image/png"
                                                                        text="本地"
                                                                        :data="typeData"
                                                                        @imageuploading="groupImgUploading(index, num)"
                                                                        @imageuploaded="groupImgUploaded">
                                                                    </vue-core-image-upload>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </el-col>
                                                </div>
                                            </div>
                                            <el-input minlength="170px" class="img-input" v-model="list.title" placeholder="请输入创意标题（6~25个字符）"></el-input>
                                        </div>
                                    </span>
                                </span>
                            </el-row>
                        </el-form-item>

                        <el-form-item label="第三方展示监控链接" class="lg-form" prop="pvReportUrl">
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input v-model="form.pvReportUrl" clearable></el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item label="第三方点击监控链接" class="lg-form" prop="clickReportUrl">
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input v-model="form.clickReportUrl" clearable></el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item v-if="0" label="视频播放第三方监控链接" class="lg-form" prop="videoStartPlayReportUrl">
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input v-model="form.videoStartPlayReportUrl" clearable></el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item v-if="0" label="视频播完第三方监控链接" class="lg-form" prop="videoEndPlayReportUrl">
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input v-model="form.videoEndPlayReportUrl" clearable></el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item class="handle">
                            <el-button @click="cancle('form')">取消</el-button>
                            <el-button class="dsp-botton" @click="submit('form')" align="middle">提交</el-button>
                        </el-form-item>
                    </div>
                </el-form>
            </div>
        </div>

        <el-dialog title="图片库" :visible.sync="dialogFormVisible">
            <el-form :model="dialogForm">
                <el-row class="select tables">
                    <div v-for="(item, index) in imagesData" :key="index">
                        <el-col :sm="12" :md="8" :lg="6">
                            <div class="thumbnail" :class="{ active: item.isActive }" @click="filterImage(index, item)">
                                <div class="user">
                                    <img v-if="item.imgServerUrl == '' || 'undefined' == typeof(item.imgServerUrl) " class="images" :src="item.url"/>
                                    <img v-else class="images" :src="item.imgServerUrl"/>
                                </div>
                                <div class="images-text">
                                    <p class="images-label">
                                        <span>名称:</span>
                                        <span>{{item.title}}</span>
                                    </p>
                                    <p class="images-label">
                                        <span>创建时间:</span>
                                        <span>{{item.createTime}}</span>
                                    </p>
                                    <p class="images-label">
                                        <span>尺寸:</span>
                                        <span>{{item.width}} x {{item.height}}</span>
                                    </p>
                                </div>
                            </div>
                        </el-col>
                    </div>
                </el-row>
                
                <div class="select tables">
                    <el-pagination class="tabs" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPageNo" :page-sizes="sizes" :page-size="eachPageCapacity" layout="total, sizes, prev, pager, next, jumper" 
                    :total="totalCount">
                    </el-pagination>
                </div>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="submitDialog">确 定</el-button>
            </div>
        </el-dialog>
        
    </div>
</template>

<script>
import VueCoreImageUpload from 'vue-core-image-upload'

export default {
    components: {
        VueCoreImageUpload
    },

    data() {
        var validatePvReportUrl = (rule, value, callback) => {
            if (!!value) {
                var reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
                if (!reg.test(this.form.pvReportUrl)) {
                    callback(new Error('请输入正确的第三方展示监控链接'));
                }
                callback();
            } else {
                callback();
            }
        };

        var validateClickReportUrl = (rule, value, callback) => {
            if (!!value) {
                var reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
                if (!reg.test(this.form.clickReportUrl)) {
                    callback(new Error('请输入正确的第三方点击监控链接'));
                }
                callback();
            } else {
                callback();
            }
        };

        var validateVideoStartPlayReportUrl = (rule, value, callback) => {
            if (!value) {
                callback(new Error('请输入链接'));
            } else {
                // verify the url
                var reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
                if (!reg.test(this.form.videoStartPlayReportUrl)) {
                    callback(new Error('请输入正确的视频播放第三方监控链接'));
                }
                callback();
            }
        };

        var validateVideoEndPlayReportUrl = (rule, value, callback) => {
            if (!value) {
                callback(new Error('请输入链接'));
            } else {
                // verify the url
                var reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
                if (!reg.test(this.form.videoEndPlayReportUrl)) {
                    callback(new Error('请输入正确的视频播完第三方监控链接'));
                }
                callback();
            }
        };
    
        return {
            form: {
                promotionId: '',
                pvReportUrl: '',
                clickReportUrl: '',
                videoStartPlayReportUrl: '',
                videoEndPlayReportUrl: '',
                type: null,
                bigImageType: null,
                imageGroupId: '',
                version: ''
            },
            title: '',
            formRules: {
                promotionId: [
                    { required: true, message: '请选择广告计划', trigger: 'change' }
                ],
                pvReportUrl: [
                    { validator: validatePvReportUrl, trigger: 'blur' }
                ],
                clickReportUrl: [
                    { validator: validateClickReportUrl, trigger: 'blur' }
                ]
                /*videoStartPlayReportUrl: [
                    { validator: validateVideoStartPlayReportUrl, trigger: 'blur' }
                ],
                videoEndPlayReportUrl: [
                    { validator: validateVideoEndPlayReportUrl, trigger: 'blur' }
                ]*/
            },
            formList: [
                {
                    label: '小图',
                    value: '1'
                },
                {
                    label: '大图',
                    value: '2'
                },
                {
                    label: '图组',
                    value: '3'
                }
            ],
            bigImageTypeList: [
                {
                    label: '横幅大图',
                    value: '1'
                },
                {
                    label: '横版大图',
                    value: '2'
                },
                {
                    label: '竖版大图',
                    value: '3'
                }
            ],
            editedIndex: -1,
            promotionIdList: [],
            imgUpload: this.$store.state.imgUpload,
            url: '',
            smallUrl: '',
            largeUrl1: '',
            largeUrl2: '',
            largeUrl3: '',
            imgList: [],
            largeImgList: [],
            groupImgList: [],
            groupNum: 0,
            idxFlag: null,
            indexFlag: null,
            imageList: [],
            adId: '',
            typeData: {},
            dialogFormVisible: false,
            imagesData: [],
            currentPageNo: 1,
            eachPageCapacity: 10,
            totalCount: 1,
            sizes: [24, 48, 92, 184, 368],
            dialogForm: {},
            isActive: false,
            selectedImage: {},
            dialogIdxFlag: null,
            dialogNumFlag: null,
            isEdit: false
        }
    },

    computed: {
        formTitle () {
            return this.editedIndex === -1 ? '新建广告' : '编辑广告'
        }
    },

    watch: {
    },

    created () {
        this.imgUpload = this.$store.state.imgUpload;
        this.url = '.../../../src/assets/images/tool/add.png';
        this.smallUrl = '.../../../src/assets/images/tool/small.png';
        this.largeUrl1 = '.../../../src/assets/images/tool/large1.png';
        this.largeUrl2 = '.../../../src/assets/images/tool/large2.png';
        this.largeUrl3 = '.../../../src/assets/images/tool/large3.png';
        this.form.type = 1;
        this.form.bigImageType = 1;

        if(!!this.$route.query.id) {
            this.isEdit = true;
        } else {
            this.typeData = {
                type: this.form.type,
                bigImageType: this.form.bigImageType
            };
        }

        this.initialize();
    },

    methods: {
        remove(type, index) {
            if(type == 1) {
                this.imgList.splice(index, 1);
            }

             if(type == 2) {
                this.largeImgList.splice(index, 1);
            }

            if(type == 3) {
                this.groupImgList.splice(index, 1);
            }
        },

        submitDialog() {
            switch(parseInt(this.form.type)) {
                case 1:
                    this.imgList.push(this.selectedImage);
                    break;
                case 2:
                    this.largeImgList.push(this.selectedImage);
                    break;
                case 3:
                    if(this.groupImgList && this.groupImgList[this.dialogIdxFlag] && this.groupImgList[this.dialogIdxFlag].imageList && this.groupImgList[this.dialogIdxFlag].imageList.length > 0) {
                        this.groupImgList[this.dialogIdxFlag].imageList[this.dialogNumFlag] = this.selectedImage;
                    }

                    this.groupImgList = JSON.parse(JSON.stringify(this.groupImgList));
                    break;
                default:
                    break;
            }
            return this.dialogFormVisible = false;
        },

        filterImage(index, data) {
            let list = [];

            this.imagesData.forEach((item, idx) => {
                if(idx == index) {
                    this.$set(item, 'isActive', true);
                    list.push(item);
                } else {
                    this.$set(item, 'isActive', false);
                    list.push(item);
                }
            });

            this.imagesData = list;
            return this.selectedImage = data;
        },

        handleSizeChange(val) {
            this.eachPageCapacity = val;
            this.initDialogData();
        },

        handleCurrentChange(val) {
            this.currentPageNo = val;
            this.initDialogData();
        },

        initDialogData() {
            this.imagesData = [];

            this.getImagesList()
                .then(res => {
                    if(res.code == '200') {
                        if(res.data && res.data.length > 0) {
                            res.data.forEach(item => {
                                let createTime = item.createTime ? this.$utils.formatDate(new Date(item.createTime), 'yyyy-MM-dd') : '';
                                this.$set(item, 'createTime', createTime);

                                item = Object.assign(item, {isActive: false});
                                this.imagesData.push(item);
                            });
                            console.log(this.imagesData);
                        }
                        this.totalCount = res.page.totalCount;
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取图片列表失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        selectImages() {
            this.selectedImage = {};
            this.dialogFormVisible = true;

            this.initDialogData();
        },

        selectGroupImages(index, num) {
            this.selectedImage = {};
            this.dialogFormVisible = true;
            this.dialogIdxFlag = index;
            this.dialogNumFlag = num;
        },

        getImagesList() {
            return new Promise((resolve, reject) => {
                let params = {
                    eachPageCapacity: this.eachPageCapacity,
                    currentPageNo: this.currentPageNo,
                    type: this.form.type,
                    bigImageType: this.form.bigImageType
                }

                this.$request.get(this.$store.state.getImages, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        handleType(val) {
            switch(parseInt(val)) {
                case 1:
                    this.largeImgList = [];
                    this.groupImgList = [];
                    break;
                case 2:
                    this.form.bigImageType = this.form.bigImageType ? this.form.bigImageType : 1;
                    this.imgList = [];
                    this.groupImgList = [];
                    break;
                case 3:
                    this.groupNum = 0;
                    this.addGroup();
                    this.imgList = [];
                    this.largeImgList = [];
                    break;
                default:
                    break;
            }

            this.typeData = {
                type: this.form.type,
                bigImageType: this.form.bigImageType
            };
        },

        handleBigImageType(val) {
            this.largeImgList = [];
            
            this.typeData = {
                type: this.form.type,
                bigImageType: this.form.bigImageType
            };
        },

        addGroup() {
            let items = {
                imageGroupId: '',
                imageList: [
                    {
                        name: '',
                        url: '../../../src/assets/images/tool/small.png',
                    },
                    {
                        name: '',
                        url: '../../../src/assets/images/tool/small.png',
                    },
                    {
                        name: '',
                        url: '../../../src/assets/images/tool/small.png',
                    }
                ],
                title: '',
                random: new Date().getTime()
            };

            if(this.groupNum < 5) {
                this.groupNum++;
                this.groupImgList.push(items);
            } else {
                this.$message({
                    showClose: true,
                    type: 'warning',
                    message: "最多只能上传五组图组"
                });
            }
        },

        imgeUploaded(res) {
            if(res.code == '200') {
                if (res.data.url) {

                    let cropArgs = {
                        name: res.data.name,
                        height: res.data.height,
                        width: res.data.width,
                        url: res.data.url,
                        id: '',
                        folder: res.data.folder,
                        format: res.data.format,
                        ratio: res.data.ratio,
                        absoluteName: res.data.absoluteName,
                        bigImageType: res.data.bigImageType,
                        type: res.data.type
                    }
                    this.imgList.push(cropArgs);
                    console.log(this.imgList);
                    
                    this.$message({
                        showClose: true,
                        type: 'success',
                        message: "上传图片成功"
                    });
                }
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: res.message
                });
            }
        },

        largeImgUploaded(res) {
            if(res.code == '200') {
                if (res.data.url) {

                    let cropArgs = {
                        name: res.data.name,
                        height: res.data.height,
                        width: res.data.width,
                        url: res.data.url,
                        id: '',
                        folder: res.data.folder,
                        format: res.data.format,
                        ratio: res.data.ratio,
                        absoluteName: res.data.absoluteName,
                        bigImageType: res.data.bigImageType,
                        type: res.data.type
                    }
                    this.largeImgList.push(cropArgs);
                    console.log(this.largeImgList);

                    this.$message({
                        showClose: true,
                        type: 'success',
                        message: "上传图片成功"
                    });
                }
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: res.message
                });
            }
        },

        groupImgUploading(index, num) {
            this.indexFlag = index;
            return this.numFlag = num;
        },

        groupImgUploaded(res) {
            if(res.code == '200') {
                if (res.data.url) {
                    let cropArgs = {
                        name: res.data.name,
                        height: res.data.height,
                        width: res.data.width,
                        url: res.data.url,
                        id: '',
                        folder: res.data.folder,
                        format: res.data.format,
                        ratio: res.data.ratio,
                        absoluteName: res.data.absoluteName,
                        bigImageType: res.data.bigImageType,
                        type: res.data.type
                    }

                    this.groupImgList[this.indexFlag].title = '';
                    this.groupImgList[this.indexFlag].imageGroupId = this.indexFlag;
                    
                    if(this.groupImgList && this.groupImgList[this.indexFlag] && this.groupImgList[this.indexFlag].imageList && this.groupImgList[this.indexFlag].imageList.length > 0) {
                        this.groupImgList[this.indexFlag].imageList[this.numFlag] = cropArgs;
                    }

                    this.groupImgList = JSON.parse(JSON.stringify(this.groupImgList));
                    console.log(this.groupImgList);

                    this.$message({
                        showClose: true,
                        type: 'success',
                        message: "上传图片成功"
                    });
                }
            } else {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: res.message
                });
            }
        },

        initialize() {
            let hash = window.location.hash;
            this.promotionIdList = [];

            this.getPromotionIds()
                .then(res => {
                    if(res.code == '200') {
                        
                        if(res.data && res.data.length > 0) {
                            this.promotionIdList = res.data;
                            if(hash.includes('?')) {
                                this.getPageData();
                            } else {
                                this.form.promotionId = this.promotionIdList[0].id;
                            }
                        }
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取广告计划列表失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        getPageData() {
            this.editedIndex = 1;
            let hash = window.location.hash;
            let id = hash.split('=')[1];
            this.adId = id;

            this.getAdvertById({adId: id})
                .then(res => {
                    if(res.code == '200') {
                        let data = res.data;

                        this.renderPage(data);
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取广告计划失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                    console.log(err);
                })
        },

        renderPage(data) {
            this.form = {
                promotionId: data.promotionId,
                pvReportUrl: data.pvReportUrl ? data.pvReportUrl : '',
                clickReportUrl: data.clickReportUrl ? data.clickReportUrl : '',
                videoStartPlayReportUrl: data.videoStartPlayReportUrl ?  data.videoStartPlayReportUrl : '',
                videoEndPlayReportUrl: data.videoEndPlayReportUrl ? data.videoEndPlayReportUrl : '',
                type: data.materialInfo && data.materialInfo.type ? data.materialInfo.type : 1,
                version: data.version
            };
            if(data.materialInfo && data.materialInfo.materialList && data.materialInfo.materialList.length > 0) {
                switch(parseInt(data.materialInfo.type)) {
                    case 1:
                        this.renderSamllImgList(data.materialInfo.materialList);
                        break;
                    case 2:
                        this.renderLargeImgList(data.materialInfo.materialList);
                        this.form.bigImageType = data.materialInfo.bigImageType;
                        break;
                    case 3:
                        this.renderGroupImgList(data.materialInfo.materialList);
                        break;
                    default:
                        break;
                }
            }
            this.typeData = {
                type: this.form.type,
                bigImageType: this.form.bigImageType ? this.form.bigImageType : 1
            };
        },

        renderGroupImgList(data) {
            if(data) {
                this.groupImgList = data;
            }
        },

        renderLargeImgList(data) {
            if(data) {
                data.forEach(list => {
                    list.imageList.forEach(item => {
                        let cropArgs = {
                            folder: item.folder,
                            format: item.format,
                            name: item.name,
                            height: item.height,
                            width: item.width,
                            url: item.url,
                            imgServerUrl: item.imgServerUrl,
                            imageId: item.imageId,
                            ratio: item.ratio,
                            title: list.title,
                            materialId: item.materialId
                        }
                        this.largeImgList.push(cropArgs);
                    });
                });
                console.log(this.largeImgList);
            }
        },

        renderSamllImgList(data) {
            if(data) {
                data.forEach(list => {
                    list.imageList.forEach(item => {
                        let cropArgs = {
                            folder: item.folder,
                            format: item.format,
                            name: item.name,
                            height: item.height,
                            width: item.width,
                            url: item.url,
                            imgServerUrl: item.imgServerUrl,
                            imageId: item.imageId,
                            ratio: item.ratio,
                            title: list.title,
                            materialId: item.materialId
                        }
                        this.imgList.push(cropArgs);
                    });
                });
                console.log(this.imgList);
            }
        },

        getAdvertById(param) {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.getAdvertById, param)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        getPromotionIds() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.queryPromote, {category: 1})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        cancle(formName) {
            this.$refs[formName].resetFields();
            return this.$router.push({path: '/advert'});
        },

        createAdvert() {
            this.create()
                .then(res => {
                    let data = res.data;

                    if(res.code == '200') {
                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "新建广告计划成功"
                        });
                        this.$router.push({path: '/advert'});
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                        this.$router.push({path: '/advert'});
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                });
        },

        verifyImagesTitle(type) {
            let list = [];
            let flag = true;

            switch(type) {
                case 1:
                    list = this.imgList;
                    break;
                case 2:
                    list = this.largeImgList;
                    break;
                case 3:
                    list = this.groupImgList;
                    break;
                default:
                    break;
            }
            list.forEach(item => {
                if(item.title == undefined || item.title == '') {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: '请输入图片的创意标题'
                    });
                    flag = false;
                    return;
                } else {
                    if(item.title.length < 6 || item.title.length > 25) {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: '图片标题的长度为6到25'
                        });
                        flag = false;
                        return;
                    }
                }
            });

            return flag;
        },

        verifyImages() {
            switch(parseInt(this.form.type)) {
                case 1:
                    if(this.imgList.length <= 0) {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: '请添加素材'
                        });
                        return false;
                    } else {
                        return this.verifyImagesTitle(1);
                    }
                    break;
                case 2:
                    if(this.largeImgList.length <= 0) {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: '请添加素材'
                        });
                        return false;
                    } else {
                        return this.verifyImagesTitle(2);
                    }
                    break;
                case 3:
                    if(this.groupImgList.length > 0) {
                        let status = true;
                        this.groupImgList.forEach(item => {
                            item.imageList.forEach(val => {
                                if(val.url == '../../../src/assets/images/tool/small.png') {
                                    this.$message({
                                        showClose: true,
                                        type: 'error',
                                        message: '组图每组必须添加三张图片'
                                    });
                                    status = false;
                                    return status;
                                }
                                return status;
                            });
                            return status;
                        });
                        if(status) {
                            status = this.verifyImagesTitle(3);
                        }
                        return status;
                    }
                    break;
                default:
                    break;
            }
            return true;
        },

        submit(formName) {
            let hash = window.location.hash;
            let isCorrect = this.verifyImages();
            
            this.$refs[formName].validate(valid => {
                if(valid && isCorrect) {
                    if(parseInt(this.form.type) == 1) {
                        this.imageList = this.imgList;
                    } else if(parseInt(this.form.type) == 2) {
                        this.imageList = this.largeImgList;
                    } else if(parseInt(this.form.type) == 3) {
                        this.imageList = this.groupImgList;
                    }
                    if(hash.includes("?")) {
                        this.editAdvert();
                    } else {
                        this.createAdvert();
                    }
                } else {
                    console.log('Fail to validate the form data');
                }
            });
        },

        editAdvert() {
            this.edit()
                .then(res => {
                    let data = res.data;

                    if(res.code == '200') {
                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "更新广告计划成功"
                        });
                        this.$router.push({path: '/advert'});
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                        this.$router.push({path: '/advert'});
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                });
        },

        create() {
            let parmas = this.formatForm();

            return new Promise((resolve, reject) => {
                this.$request.post(this.$store.state.createAd, parmas)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        edit() {
            let parmas = this.formatForm();

            return new Promise((resolve, reject) => {
                this.$request.put(this.$store.state.editAd, parmas)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        formatForm() {
            let imageList = [];

            let params = {
                adId: this.adId,
                promotionId: this.form.promotionId,
                pvReportUrl: this.form.pvReportUrl,
                clickReportUrl: this.form.clickReportUrl,
                videoStartPlayReportUrl: this.form.videoStartPlayReportUrl,
                videoEndPlayReportUrl: this.form.videoEndPlayReportUrl,
                version: this.form.version
            }
            if(this.imageList) {
                if(parseInt(this.form.type) == 1 || parseInt(this.form.type) == 2) {
                    this.imageList.forEach(item => {
                        let field = {
                            title: item.title,
                            imageGroupId: '',
                            id: item.materialId,
                            imageList: item
                        }
                        imageList.push(field);
                    });

                } else if(parseInt(this.form.type) == 3) {
                    imageList = this.groupImgList;
                }
            }

            let materialInfo = {
                type: this.form.type,
                bigImageType: this.form.bigImageType,
                materialList: imageList
            }

            return Object.assign(params, {materialInfo: materialInfo});
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';
    
    .adversting-container {
        height: auto;

        .circle {
            position: absolute;
            cursor: pointer;
            color: #fff;
            width: 18px;
            line-height: 18px;
            height: 18px;
            border-radius: 9px;
            background-color: #ff635c;
            text-align: center;
            display: block;
            opacity: 0;
            z-index: 10;
            top: -9px;
            right: -6px;
            -webkit-transition: opacity .2s ease-in-out;
            transition: opacity .2s ease-in-out;
        }

        .img-group {
            position: relative;
            border: 1px solid #e6e1e1;
            border-radius: 4px;
            margin-bottom: 22px;
            
            &:hover {
                border: 1px solid red;
                border-radius: 4px;

                .circle {
                    position: absolute;
                    cursor: pointer;
                    color: #fff;
                    width: 18px;
                    line-height: 18px;
                    height: 18px;
                    border-radius: 9px;
                    background-color: #ff635c;
                    text-align: center;
                    display: block;
                    opacity: initial;
                    z-index: 10;
                    top: -9px;
                    right: -6px;
                    -webkit-transition: opacity .2s ease-in-out;
                    transition: opacity .2s ease-in-out;
                }
            }
        }

        .grid-content {
            width: 100%;
            height: 100%;
        }

        .img-option {
            width: 100%;
            height: 100%;
        }

        @media all and (min-width:1200px) and (max-width:1640px){
            .img-group {
                min-width: 570px;
            }
        }

        @media all and (min-width:747px) and (max-width:1200px){
            .img-group {
                min-width: 400px;
            }
        }

        .add-icon {
            width: 148px;
            height: 170px;
            display: flex;
            justify-content: center;
            float: left;

            img {
                align-self: center;
                height: 68px;
                width: 68px;
                cursor: pointer;
            }
        }

        .add-img {
            float: left;
            width: 100%;
            margin: 0 0 22px 0;
        }

        .img-list {
            float: left;
            width: 595px;
            max-width: 595px;
            min-width: 188px;
        }

        .el-row {
            /* @media only screen and (min-width: 1304px) {
                .el-col-lg-8 {
                    width: 33.33333% !important;
                }
            }
            
            @media only screen and (min-width: 1160px) {
                .el-col-md-10 {
                    width: 41.66667%  !important;
                }
            } */

        }

        .group-img-container {
            height: 170px;
            display: block;
            text-align: center;
            border-radius: 4px;
            border: 1px solid #e6e1e1;
            margin: 5px;
            padding: 9px;
            width: 170px;

            .el-input__inner {
                border: none !important;
            }

            .user {
                height: 170px;
                width: 168px;
                min-width: 168px;
                border-radius: 4px;
                display: flex;
                justify-content: center;
                cursor: pointer;

                .avatar {
                    align-self: center;
                    width: 168px;
                    height: 170px;
                }
            }

            .layout {
                position: relative;
                overflow: hidden;
                top: -179px;
                height: 188px;
                min-width: 188px;
                width: 188px;
                left: -9px;
                cursor: pointer;

                &:hover {
                    background: rgba(0, 0, 0, 0.5);
                    color: $font-color;
                    font-size: 14px;
                }

                .g-core-image-upload-btn {
                    position: relative;
                    overflow: hidden;
                    height: 188px;
                    min-width: 94px;
                    width: 94px;
                    left: -9px;
                    line-height: 188px;
                    cursor: pointer;
                    color: $white;
                    text-align: center;
                }

                .cloud-upload-image {
                    position: relative;
                    overflow: hidden;
                    height: 188px;
                    min-width: 94px;
                    width: 94px;
                    float: right;
                    line-height: 188px;
                    cursor: pointer;
                    color: $white;
                    text-align: center;
                }
            }

            .img-input {
                width: 170px;
            }

            .el-input__inner {
                border-bottom: 1px solid #dcdfe6 !important;
            }
        }

        .img-container {
            position: relative;
            height: 210px;
            margin: 0 30px 50px 0;
            display: block;
            text-align: center;
            max-width: 170px;
            min-width: 170px;
            padding: 9px;
            border: 1px solid #e6e1e1;
            border-radius: 4px;

            &:hover {
                border: 1px solid red;
                border-radius: 4px;

                .circle {
                    position: absolute;
                    cursor: pointer;
                    color: #fff;
                    width: 18px;
                    line-height: 18px;
                    height: 18px;
                    border-radius: 9px;
                    background-color: #ff635c;
                    text-align: center;
                    display: block;
                    opacity: initial;
                    z-index: 10;
                    top: -9px;
                    right: -6px;
                    -webkit-transition: opacity .2s ease-in-out;
                    transition: opacity .2s ease-in-out;
                }
            }

            .el-input__inner {
                border: none !important;
            }

            .user {
                height: 170px;
                width: 168px;
                min-width: 100%;
                display: flex;
                justify-content: center;
                cursor: pointer;

                .avatar {
                    align-self: center;
                    width: 168px;
                    height: 170px;
                }
            }

            .layout {
                position: relative;
                overflow: hidden;
                top: -189px;
                height: 188px;
                min-width: 188px;
                width: 188px;
                cursor: pointer;

                &:hover {
                    background: rgba(0, 0, 0, 0.5);
                    color: $font-color;
                    font-size: 14px;
                }

                .g-core-image-upload-btn {
                    position: relative;
                    overflow: hidden;
                    height: 188px;
                    min-width: 94px;
                    width: 94px;
                    line-height: 188px;
                    cursor: pointer;
                    color: $white;
                    text-align: center;
                }

                .cloud-upload-image {
                    position: relative;
                    overflow: hidden;
                    height: 188px;
                    min-width: 94px;
                    width: 94px;
                    float: right;
                    line-height: 188px;
                    cursor: pointer;
                    color: $white;
                    text-align: center;
                }
            }

            .img-input {
                top: 9px;
                width: 188px;
                left: -9px;
            }

            .el-input__inner {
                border-bottom: 1px solid #dcdfe6 !important;
            }
        }

        .img-item {
            height: 188px;
            margin: 0 30px 22px 0;

            .el-input__inner {
                border: none !important;
            }

            .user {
                height: 170px;
                width: 168px;
                min-width: 168px;
                border: 1px solid #e6e1e1;
                border-radius: 4px;
                padding: 9px;
                display: flex;
                justify-content: center;
                cursor: pointer;

                .avatar {
                    align-self: center;
                    width: 168px;
                    height: 170px;
                }
            }

            .layout {
                position: relative;
                overflow: hidden;
                top: -189px;
                height: 188px;
                min-width: 188px;
                width: 188px;
                cursor: pointer;

                &:hover {
                    background: rgba(0, 0, 0, 0.5);
                    color: $font-color;
                    font-size: 14px;
                }

                .g-core-image-upload-btn {
                    position: relative;
                    overflow: hidden;
                    height: 188px;
                    min-width: 94px;
                    width: 94px;
                    line-height: 188px;
                    cursor: pointer;
                    color: $white;
                    text-align: center;
                }

                .cloud-upload-image {
                    position: relative;
                    overflow: hidden;
                    height: 188px;
                    min-width: 94px;
                    width: 94px;
                    float: right;
                    line-height: 188px;
                    cursor: pointer;
                    color: $white;
                    text-align: center;
                }
            }

            .img-input {
                min-width: 170px;
                width: 90%;
            }

            .el-input__inner {
                border-bottom: 1px solid #dcdfe6 !important;
            }
        }
        
        .selection {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            background-color: $white;
            padding: 0 30px;

            .el-breadcrumb {
                align-items: center;
                height: 78px;
                width: 100%;
                display: flex;
            }
        }

        .el-col {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }

        .el-form-item__label {
            text-align: left !important;
            min-width: 165px;
            width: auto;
        }

        .handle {
            margin: 50px 0 0;
        }

        .steps {
            min-height: 107px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            background-color: $white;

            .step-item {
                margin: 0;
                padding: 45px 20%;

                .label-width {
                    width: 80px;
                }
            }

            .step-item-two {
                margin: 0;
                padding: 0 20%;
            }
        }

        .dsp-botton {
            @include green-botton;
        }

        .select {
            min-height: 78px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            padding: 0 20px;
            margin: 0 0 15px !important;
        }

        .tables {
            padding: 25px 30px 0;
        }

        .tabs {
            padding: 25px 0;
            float: right;
        }

        .active {
            border: 1px solid $green;
            border-radius: 5px;
            box-shadow: 0 2px 12px 0 $green !important;
        }

        .thumbnail {
            display: block;
            text-align: center;
            max-width: 200px;
            border-radius: 4px;
            border: 1px solid #e6e1e1;
            margin: 0 15px 25px;
            padding: 9px;

            &:active {
                border: 1px solid $green;
                border-radius: 5px;
                box-shadow: 0 2px 12px 0 $green !important;
            }

            .images {
                max-width: 100%;
                height: auto;
                width: 200px;
                height: 180px;
            }

            .images-text {
                .images-label {
                    font-size: 14px;
                    color: #606266;
                    line-height: 25px;
                    padding: 0 12px 0 0;
                    width: 100%;
                    box-sizing: border-box;
                    text-align: center;
                }
            }
        }
    }
</style>