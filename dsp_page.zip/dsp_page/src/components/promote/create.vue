<template>
    <div class="create-container">
        <div class="steps grid-felx">
            <el-steps :active="active" finish-status="success" align-center class="grid-process">
                <el-step title="广告类型"></el-step>
                <el-step title="用户定向"></el-step>
                <el-step title="预算与出价"></el-step>
            </el-steps>
        </div>

        <div class="steps">
            <div type="flex" justify="center">
                <div v-show="active == 0" align="left" class="step-item">
                    <el-form ref="form" :model="form" :rules="formRules" label-width="85px">
                        <el-form-item label="推广名称" prop="title">
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input v-model="form.title" clearable placeholder="请输入推广名称"></el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item label="推广类型" class="type" prop="type" required>
                            <el-row>
                                <div @click="selectType">
                                    <el-col class="type-item" :class="{'type-item-active': isActive}">
                                        <el-card v-model="form.type" shadow="hover" :body-style="{ padding: '20px' }">
                                            <img src="../../assets/images/promote/page.png" class="image">
                                            <div style="padding: 5px 15px 14px;">
                                                <div class="name"><span>落地页</span></div>
                                                <div class="bottom clearfix">
                                                    <time class="time">提升落地页的展示量、点击量、转化量
                                                    </time>
                                                </div>
                                            </div>
                                        </el-card>
                                    </el-col>
                                </div>
                                <div @click="selectType">
                                    <el-col class="type-item" :class="{'type-item-active': !isActive}">
                                        <el-card shadow="hover" @click="selectType" :body-style="{ padding: '20px' }">
                                            <img src="../../assets/images/promote/app.png" class="image">
                                            <div style="padding: 5px 15px 14px;">
                                                <div class="name"><span>App应用</span></div>
                                                <div class="bottom clearfix">
                                                    <time class="time">提升APP应用的下载、安装、激活
                                                    </time>
                                                </div>
                                            </div>
                                        </el-card>
                                    </el-col>
                                </div>
                              </el-row>
                        </el-form-item>

                        <el-form-item label="链接地址" v-if="isActive" prop="linkUrl" required>
                            <el-row :gutter="20">
                                <el-col :span="14">
                                    <div class="grid-content">
                                        <el-input placeholder="请输入链接地址" v-model="form.linkUrl" :disabled="isDisabledChargeMode" clearable>
                                            <el-button slot="append" @click="scan">链接浏览</el-button>
                                        </el-input>
                                    </div>
                                </el-col>
                                <el-col :span="10"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item label="应用名称" v-else prop="appId" required>
                            <el-select v-model="form.appId" filterable placeholder="请选择应用名称" :disabled="isDisabledChargeMode">
                                <el-option v-for="item in appIdList" :key="item.value" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                            <span class="application-tip">(请在工具中录入推广应用)</span>
                        </el-form-item>

                        <el-form-item label="推广产品" prop="product">
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input v-model="form.product" clearable　placeholder="请输入推广产品"></el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item class="handle">
                            <el-button @click="cancleForm('form')">取消</el-button>
                            <el-button class="dsp-botton" @click="nextForm('form')" align="middle">下一步</el-button>
                        </el-form-item>
                    </el-form>
                </div>
                <div v-show="active == 1" align="left" class="step-item">
                    <el-form ref="secondForm" :model="secondForm" :rules="secondFormRules" label-width="100px">
                        <el-form-item label="复制已有定向" prop="orientationType">
                            <el-select v-model="secondForm.orientationType" filterable placeholder="请复制已有定向" @change="handleOrientationType">
                                <el-option v-for="item in orientationTypeList" :key="item.id" :label="item.title" :value="item.id">
                                </el-option>
                            </el-select>
                        </el-form-item>

                        <el-form-item label="地域" prop="areaType">
                            <el-radio-group v-model="secondForm.areaType" size="medium">
                                <el-radio-button v-for="item in areaList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item v-if="isShowArea" v-model="secondForm.area" >
                            <input readonly="readonly" id="area-list" class="area-duoxuan" :value="secondForm.area" :data-value="secondForm.area"></input>
                        </el-form-item>

                        <el-form-item label="性别" prop="sex">
                            <el-radio-group v-model="secondForm.sex" size="medium">
                                <el-radio-button v-for="item in sexList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item label="年龄" prop="age">
                            <el-checkbox-group v-model="secondForm.age" size="medium">
                                <el-checkbox-button v-for="item in ageItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-checkbox-button>
                            </el-checkbox-group>
                        </el-form-item>

                        <el-form-item label="平台" prop="platform">
                            <el-radio-group v-model="secondForm.platform" size="medium">
                                <el-radio-button v-for="item in platformItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item label="网络" prop="network">
                            <el-checkbox-group v-model="secondForm.network" size="medium">
                                <el-checkbox-button v-for="item in networkItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-checkbox-button>
                            </el-checkbox-group>
                        </el-form-item>

                        <el-form-item label="运营商" prop="networkOperator">
                            <el-checkbox-group v-model="secondForm.networkOperator" size="medium">
                                <el-checkbox-button v-for="item in networkOperatorItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-checkbox-button>
                            </el-checkbox-group>
                        </el-form-item>

                        <!-- <el-form-item label="手机品牌" prop="phoneBrand">
                            <el-radio-group v-model="secondForm.phoneBrand">
                                <el-button>不限</el-button>

                                <el-popover class="popover" placement="bottom" trigger="click">
                                    <el-transfer :data="phoneBrandItems"></el-transfer>
                                        <el-transfer v-model="phoneBrand" :data="phoneBrandItems"></el-transfer>
                                    <el-button slot="reference">按品牌</el-button>
                                </el-popover>
                            </el-radio-group>
                        </el-form-item> -->

                        <el-form-item class="handle">
                            <el-button  @click="canclSecondForm('secondForm')">取消</el-button>
                            <el-button class="dsp-botton" @click="back" align="middle">上一步</el-button>
                            <el-button class="dsp-botton" @click="nextSecondForm('secondForm')" align="middle">下一步</el-button>
                            <!-- <el-button class="dsp-botton" @click="createNewPackage('secondForm')" align="middle" :disabled="isDisabledCreateOrientation">创建定向包</el-button> -->
                        </el-form-item>
                    </el-form>
                </div>
                <div v-show="active == 2" align="left" class="step-item">
                    <el-form ref="thirdForm" :model="thirdForm" :rules="thirdFormRules" label-width="95px">

                        <el-form-item label="预算" prop="budgetAmount" required>
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input placeholder="请输入金额, 不得低于500的正整数" v-model="thirdForm.budgetAmount" class="input-with-select" clearable>
                                            <el-select filterable v-model="thirdForm.budgetType" slot="prepend" placeholder="请选择预算">
                                                <el-option v-for="item in budgetTypeList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                                            </el-select>
                                            <template slot="append">元</template>
                                        </el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item label="投放时间" prop="promotionOnlineTimes" required>
                            <el-date-picker v-model="thirdForm.promotionOnlineTimes" type="daterange" unlink-panels start-placeholder="开始日期" end-placeholder="结束日期" :default-time="['00:00:00', '23:59:59']" :picker-options="pickerOptions">
                            </el-date-picker>
                        </el-form-item>

                        <el-form-item label="投放时段" prop="deliverTimeType">
                            <el-radio-group v-model="thirdForm.deliverTimeType" size="medium">
                                <el-radio-button v-for="item in timeItemList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <div class="container" v-show="isShowWeeklyCalendar">
                            <div id="target">
                            </div>
                        </div>

                        <el-popover ref="popover" placement="top-start" title="提示" width="500" trigger="hover" content="标准投放(推荐)：系统会优化您的投放，让预算在设定的时间段内稳定的消耗完，以尽可能地从更多流量中挑选最优的流量。
                        加速投放：尽可能的将广告投放出去，可能会在较短的时间内消耗完预算，也会因为竞争环境的变化导致预算消耗出现较大的波动。 在投放周期内，如果预算消耗小于预期，建议通过优化创意、调整受众人群和出价来优化，和投放方式选择无关。">
                        </el-popover>
                        <i v-popover:popover class="header-icon el-icon-question"></i>
                        <el-form-item label="投放方式" prop="deliverType" label-width="80px">
                            <el-radio-group v-model="thirdForm.deliverType" size="medium">
                                <el-radio-button v-for="item in deliverTypeList" :key="item.value" :label="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item label="采买方式" prop="buyType">
                            <el-radio-group v-model="thirdForm.buyType" size="medium">
                                <el-radio-button v-for="item in buyTypeItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item label="付费方式" prop="chargeMode" class="payment">
                            <el-radio-group v-model="thirdForm.chargeMode" size="medium" :disabled="isDisabledChargeMode">
                                <el-radio-button v-for="item in chargeModeItems" :label="item.value" :key="item.value" :value="item.value">{{item.label}}</el-radio-button>
                            </el-radio-group>
                        </el-form-item>

                        <el-form-item label="出价" prop="payAmountUnit" required>
                            <el-row :gutter="20">
                                <el-col :span="12">
                                    <div class="grid-content">
                                        <el-input v-model="thirdForm.payAmountUnit" placeholder="请输入出价, 不得低于１.0元" clearable>
                                            <template slot="append">元</template>
                                        </el-input>
                                    </div>
                                </el-col>
                                <el-col :span="12"></el-col>
                            </el-row>
                        </el-form-item>

                        <el-form-item class="handle">
                            <el-button @click="cancleThirdForm('thirdForm')">取消</el-button>
                            <el-button class="dsp-botton" @click="back" align="middle">上一步</el-button>
                            <el-button class="dsp-botton" @click="submitThirdForm('thirdForm')" align="middle">提交</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        var validateLinkUrl = (rule, value, callback) => {
            if(this.isActive) {
                if (!value) {
                    callback(new Error('请输入链接'));
                } else {
                    // verify the url
                    var reg=/(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
                    if (!reg.test(this.form.linkUrl)) {
                        callback(new Error('请输入正确链接'));
                    }
                    callback();
                }
            }
        };

        var validateAppId = (rule, value, callback) => {
            if(!this.isActive) {
                if (!value) {
                    callback(new Error('请选择应用类型'));
                } else {
                    callback();
                }
            }
        };

        var checkBudgetAmount = (rule, value, callback) => {
            if (!value && value != 0) {
                return callback(new Error('请填写预算金额'));
            } else {
                setTimeout(() => {
                    var re = /^([1-9][0-9]*)$/;

                    if(re.test(value)) {
                        if (value < 500) {
                            callback(new Error('日预算金额不得低于500元'));
                        } else {
                            callback();
                        }
                    } else {
                        callback(new Error('预算金额为正整数'));
                    }
                }, 1000);
            }
        };

        var checkPayAmountUnit = (rule, value, callback) => {
            if (!value && value != 0) {
                return callback(new Error('请填写出价'));
            } else {
                setTimeout(() => {
                    var re = /^[1-9]\d*(\.\d{1,2})?$/;

                    if(re.test(value)) {
                        if (value < 1) {
                            callback(new Error('出价金额不得低于1元'));
                        } else {
                            callback();
                        }
                    } else {
                        callback(new Error('出价金额为正整数或者小数点精确到两位正小数'));
                    }
                }, 1000);
            }
        };

        var checkPromotionOnlineTimes = (rule, value, callback) => {
            if (!value) {
                return callback(new Error('请填写投放时间'));
            } else {
                setTimeout(() => {
                    let utc = value[1] - value[0];
                    let day = utc / (24 * 60 * 60 * 1000);

                    if(parseInt(day) > 30) {
                        callback(new Error('投放时间不能超过30天'));
                    } else {
                        callback();
                    }
                }, 1000);
            }
        };

        return {
            pickerOptions: {
                disabledDate(time) {
                    return (time.getTime() + 3600 * 1000 * 24 * 1) < Date.now();
                }
            },
            isShowArea: false,
            active: 0,
            appIdList: [],
            form: {
                title: '',
                type: 1,
                appId: '',
                linkUrl: '',
                product: '',
                orientation: {},
                promotionOnlineTimeList: {},
                isTemplate: 0
            },
            formRules: {
                title: [
                    { required: true, message: '请输入推广名称', trigger: 'blur' },
                    { min: 1, max: 20, message: '长度在20个字符以内', trigger: 'blur' }
                ],
                linkUrl: [
                    { validator: validateLinkUrl, trigger: 'blur' }
                ],
                appId: [
                    { validator: validateAppId, trigger: 'blur' }
                ],
                product: [
                    { required: true, message: '请输入推广产品', trigger: 'blur' },
                    { min: 1, max: 50, message: '长度在50个字符以内', trigger: 'blur' }
                ]
            },
            isActive: true,
            ageItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: '0~18'
                },
                {
                    value: '2',
                    label: '18~23'
                },
                {
                    value: '3',
                    label: '24~30'
                },
                {
                    value: '4',
                    label: '31~40'
                },
                {
                    value: '5',
                    label: '41~49'
                },
                {
                    value: '6',
                    label: '50~100'
                }
            ],
            platformItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: 'ios'
                },
                {
                    value: '2',
                    label: 'android'
                }
            ],
            networkItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: 'wifi'
                },
                {
                    value: '2',
                    label: '2g'
                },
                {
                    value: '3',
                    label: '3g'
                },
                {
                    value: '4',
                    label: '4g'
                },
                {
                    value: '5',
                    label: '5g'
                }
            ],
            networkOperatorItems: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '70120',
                    label: '移动'
                },
                {
                    value: '70123',
                    label: '联通'
                },
                {
                    value: '70121',
                    label: '电信'
                }
            ],
            sexList: [
                {
                    value: '0',
                    label: '不限'
                },
                {
                    value: '1',
                    label: '男'
                },
                {
                    value: '2',
                    label: '女'
                }
            ],
            areaList: [
                {
                    value: '1',
                    label: '不限'
                },
                {
                    value: '2',
                    label: '按省市'
                }
            ],
            secondForm: {
                area: '',
                areaType: [],
                sex: '',
                age: [],
                platform: '',
                network: [],
                networkOperator: [],
                phoneBrand: [],
                orientationType: ''
            },
            secondFormRules: {
                areaType: [
                    { required: true, message: '请选择地域', trigger: 'change' }
                ],
                sex: [
                    { required: true, message: '请选择性别', trigger: 'change' }
                ],
                age: [
                    { required: true, message: '请选择年龄', trigger: 'change' }
                ],
                platform: [
                    { required: true, message: '请选择平台', trigger: 'change' }
                ],
                network: [
                    { required: true, message: '请选择网络', trigger: 'change' }
                ],
                networkOperator: [
                    { required: true, message: '请选择运营商', trigger: 'change' }
                ]
            },
            orientationTypeList: [],
            thirdForm: {
                budgetType: '',
                budgetAmount: null,
                promotionOnlineTimes: null,
                deliverTimeType: '',
                deliverType: '',
                buyType: '',
                chargeMode: '',
                payAmountUnit: null
            },
            thirdFormRules: {
                budgetType: [
                    { required: true, message: '请选择预算', trigger: 'change' }
                ],
                budgetAmount: [
                    { validator: checkBudgetAmount, trigger: 'blur' }
                ],
                promotionOnlineTimes: [
                    { validator: checkPromotionOnlineTimes, trigger: 'blur' }
                ],
                deliverTimeType: [
                    { required: true, message: '请填写投放时段', trigger: 'change' }
                ],
                deliverType: [
                    { required: true, message: '请填写投放方式', trigger: 'change' }
                ],
                buyType: [
                    { required: true, message: '请填写采买方式', trigger: 'change' }
                ],
                chargeMode: [
                    { required: true, message: '请填写付费方式', trigger: 'change' }
                ],
                payAmountUnit: [
                    { validator: checkPayAmountUnit, trigger: 'blur' }
                ]
            },
            isDisabledChargeMode: false,
            isShowWeeklyCalendar: false,
            timeItemList: [
                {
                    value: '1',
                    label: '不限'
                },
                {
                    value: '2',
                    label: '指定时间段'
                }
            ],
            deliverTypeList: [
                {
                    label: "标准投放（推荐）",
                    value: "1"
                },
                {
                    label: "加速投放",
                    value: "2"
                }
            ],
            budgetTypeList: [
                {
                    label: "日预算",
                    value: "1"
                }
            ],
            buyTypeItems: [
                {
                    label: "竞争购买",
                    value: "1"
                },
                {
                    label: "私有化采买",
                    value: "2"
                }
            ],
            chargeModeItems: [
                {
                    label: "按展示付费（CPM）",
                    value: "1"
                },
                {
                    label: "按点击付费(CPC)",
                    value: "2"
                }
            ],
            phoneBrand: [1, 2],
            phoneBrandItems: [
                {
                    key: 1,
                    label: "123"
                },
                {
                    key: 2,
                    label: "456"
                },
                {
                    key: 3,
                    label: "789"
                }
            ],
            flag: 0,
            orientationId: null,
            orientation: {},
            isDisabledCreateOrientation: false
        }
    },
    watch: {

    },

    mounted() {
        this.$watch('secondForm.areaType', this.areaType);
        this.$watch('secondForm.age', this.age);
        this.$watch('secondForm.network', this.network);
        this.$watch('secondForm.networkOperator', this.networkOperator);

        this.$watch('thirdForm.deliverTimeType', this.showWeeklyCalendar);
    },
    computed: {
    },
    created() {
        this.initializeAppTypeList();
        let hash = window.location.hash;

        if(hash.includes("?")) {
            this.isDisabledChargeMode = true;
            localStorage.removeItem('selectedHours');
        }
    },
    methods: {
        initializeAppTypeList() {
            this.appIdList = [];

            this.getPromoteTypeList()
                .then(res => {
                    if(res.code == 200) {
                        if(res.data && res.data.length > 0) {
                            let data = res.data;

                            data.forEach(val => {
                                let item = {
                                    value: val.id,
                                    label: val.name
                                };
                                this.appIdList.push(item);
                            });
                        }
                        this.getAllPackage();
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取推广类型失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                });
        },

        getPromoteTypeList() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.getApplist, {})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        getAllPackage() {
            this.orientationTypeList = [{ id: '', title: '无'}];

            this.getPackageList()
                .then(res => {
                    if(res.code == 200) {
                        if(res.data && res.data.length > 0) {
                            let data = res.data;
                            data.forEach(item => {
                                this.orientationTypeList.push(item);
                            });
                        }
                        this.initialize();
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: "获取推广类型失败"
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                });
        },

        getPackageList() {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.getPackagelist, {})
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        showWeeklyCalendar(val) {
            switch(val) {
                case "2":
                    this.isShowWeeklyCalendar = true;
                    break;
                default:
                    this.isShowWeeklyCalendar = false;
            }
        },

        handleOrientationType(id) {
            if(!!id) {
                this.getOrientationById({id: id})
                    .then(res => {

                        if(res.code == 200 && res.data) {
                            this.orientation = res.data;
                            this.secondFormData(res.data);
                        } else {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: res.message
                            });
                        }
                    })
                    .catch(err => {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: err
                        });
                    });
            } else {
                let hash = window.location.hash;

                if(!hash.includes("?")) {
                    this.renderSecondFormData();
                }
            }
        },

        getOrientationById(param) {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.getOrientationById, param)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        initCanlendar() {
            let hash = window.location.hash;

            $('#target').weekly_schedule();

            $('.schedule').on('selectionmade', function() {
                console.log("Selection Made");
            }).on('selectionremoved', function() {
                console.log("Selection Removed");
            });

            if(hash.includes("?")) {
                $('#target').weekly_schedule("setSelectedHour");
            }
        },

        initialize() {
            let hash = window.location.hash;

            if(hash.includes("?")) {
                let str = hash.split('?');
                let id = str[1].split('=')[1];

                this.getPromote({id: id})
                    .then(res => {
                        if(res.code == 200) {

                            if(res.data && !!res.data) {
                                let data = res.data;
                                this.renderPages(data);
                            } else {
                                this.initEachModel();
                            }
                        } else {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: "此推广计划不存在"
                            });
                        }
                    })
                    .catch(err => {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: err
                        });
                    });
            } else {
                this.initEachModel();
            }
        },

        renderSecondFormData() {
            this.secondForm.areaType = this.areaList[0].value;
            this.secondForm.sex = this.sexList[0].value;
            this.secondForm.age = [this.ageItems[0].value];
            this.secondForm.platform = this.platformItems[0].value;
            this.secondForm.network = [this.networkItems[0].value];
            this.secondForm.networkOperator = [this.networkOperatorItems[0].value];
            this.secondForm.orientationType = this.orientationTypeList.length > 0 ? this.orientationTypeList[0].id : '';
        },

        initEachModel() {
            this.form.appId = this.appIdList.length > 0 ? this.appIdList[0].value : '';

            this.renderSecondFormData();

            this.thirdForm.budgetType = this.budgetTypeList[0].value;
            this.thirdForm.deliverTimeType = this.timeItemList[0].value;
            this.thirdForm.deliverType = this.deliverTypeList[0].value;
            this.thirdForm.buyType = this.buyTypeItems[0].value;
            this.thirdForm.chargeMode = this.chargeModeItems[0].value;
        },

        renderPages(data) {
            this.form.title = data.title ? data.title : '';
            this.form.type = data.type || data.type == 1 ? data.type : 1;
            this.isActive = this.form.type == 1 ? true : false;
            this.form.linkUrl = data.linkUrl ? data.linkUrl : '';

            this.renderAppId(data.appId);
            this.form.product = data.product ? data.product : '';

            this.secondFormData(data.orientation);
            this.secondForm.orientationType = this.orientationTypeList[0].id;
            this.orientationId = data.orientationId ? data.orientationId : '';
            this.thirdForm.budgetType = data.budgetType ? this.budgetTypeList[parseInt(data.budgetType) - 1].value : '';
            this.thirdForm.budgetAmount = data.budgetAmount || data.budgetAmount == 0 ? data.budgetAmount : '';
            this.thirdForm.deliverType = data.deliverType ? this.deliverTypeList[parseInt(data.deliverType) - 1].value : '';
            this.thirdForm.buyType = data.buyType ? this.buyTypeItems[parseInt(data.buyType) - 1].value : '';
            this.thirdForm.chargeMode = data.chargeMode ? this.chargeModeItems[parseInt(data.chargeMode) - 1].value : '';
            this.thirdForm.payAmountUnit = data.payAmountUnit || data.payAmountUnit == 0 ? data.payAmountUnit : '';
            this.thirdForm.promotionOnlineTimes = [new Date(data.deliverStartTime), new Date(data.deliverEndTime)];
            this.renderDeliverTimeType(data.deliverTimeType, data.promotionOnlineTimeList);
        },

        renderAppId(val) {
            if(this.appIdList.length > 0) {
                this.appIdList.forEach((item, index) => {
                    if(item.value = val) {
                        this.form.appId = this.appIdList[index].value;
                    }
                });
            }
        },

        secondFormData(data) {
            this.renderArea(data.area);
            this.secondForm.sex = this.sexList[data.sex].value;
            this.renderAge(data.age);
            this.secondForm.platform = this.platformItems[data.platform].value;
            this.renderNetwork(data.network);
            this.renderRetworkOperator(data.networkOperator);
        },

        renderDeliverTimeType(data, timeList) {
            if(parseInt(data) == 2) {
                this.thirdForm.deliverTimeType = this.timeItemList[1].value;
                this.isShowWeeklyCalendar = true;
                this.formatSelectedHour(timeList);
            } else {
                this.thirdForm.deliverTimeType = this.timeItemList[0].value;
                this.isShowWeeklyCalendar = false;
            }
        },

        formatSelectedHour(data) {
            if(data.length > 0) {
                let hourList = [[], [], [], [], [], [], []];

                for(var i = 0; i < data.length; i++) {
                    let item = data[i];
                    let day = item.startTime.split(' ')[0];
                    let week = this.$utils.getWeekByDate(new Date(day));
                    let startTime = item.startTime.split(' ')[1];
                    let endTime = item.endTime.split(' ')[1];

                    do {
                        hourList[parseInt(week) - 1].push(this.$utils.formatHour(startTime));
                        startTime = this.$utils.getNextHour(startTime);
                    }while (startTime != endTime);
                }
                localStorage.removeItem('selectedHours');
                localStorage.setItem('selectedHours', JSON.stringify(hourList));
            }
        },

        renderArea(data) {
            if(!!data) {
                data = JSON.parse(data);

                if(data.length > 0) {
                    this.secondForm.areaType = this.areaList[1].value;
                    this.setAreaList(data);
                } else {
                    this.secondForm.areaType = this.areaList[0].value;
                    this.secondForm.area = "";
                }
            } else {
                this.secondForm.areaType = this.areaList[0].value;
                this.secondForm.area = "";
            }
        },

        setAreaList(areaList) {
            if(!!areaList) {
                this.secondForm.area = areaList.join('-');

                $("input#area-list.area-duoxuan").data("value", this.secondForm.area);
                $("input#area-list.area-duoxuan").val(this.secondForm.area);
            }
        },

        renderRetworkOperator(networkOperators) {
            networkOperators = JSON.parse(networkOperators);

            if(networkOperators && networkOperators.length > 0) {
                let list = [];
                networkOperators.forEach(item => {
                    this.networkOperatorItems.forEach((networkOperator, index) => {
                        if(item == networkOperator.value) {
                            list.push(this.networkOperatorItems[index].value);
                        }
                    });
                });
                this.secondForm.networkOperator = list;
            } else {
                this.secondForm.networkOperator = [this.networkOperatorItems[0].value];
            }
        },

        renderNetwork(networks) {
            networks = JSON.parse(networks);
            if(networks && networks.length > 0) {
                let list = [];
                networks.forEach(item => {
                    this.networkItems.forEach((network, index) => {
                        if(item == network.value) {
                            list.push(this.networkItems[index].value);
                        }
                    });
                });
                this.secondForm.network = list;
            } else {
                this.secondForm.network = [this.networkItems[0].value];
            }
        },

        renderAge(ages) {
            ages = JSON.parse(ages);

            if(ages && ages.length > 0) {
                let list = [];
                ages.forEach(item => {
                    this.ageItems.forEach((age, index) => {
                        if(item == age.value) {
                            list.push(this.ageItems[index].value);
                        }
                    });
                });
                this.secondForm.age = list;
            } else {
                this.secondForm.age = [this.ageItems[0].value];
            }
        },

        getPromote(param) {
            return new Promise((resolve, reject) => {
                this.$request.get(this.$store.state.getPromotebyId, param)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        areaType(val) {
            switch(val) {
                case "2":
                    this.isShowArea = true;

                    break;
                default:
                    this.isShowArea = false;
            }
        },

        handleCheckBox(val, name) {
            if(val.length == 1 && val[0] == '0'){
                return true;
            }

            if(val.length > 0) {
                if(!val.includes('0')) {
                    return true
                } else {
                    if(val[val.length - 1] == '0') {
                        return this.secondForm[name] = ['0'];
                    } else {
                        return this.secondForm[name].splice(this.secondForm[name].indexOf('0'), 1);
                    }
                }
            }
        },

        age(val) {
            this.handleCheckBox(val, 'age');
        },

        network(val) {
            this.handleCheckBox(val, 'network');
        },

        networkOperator(val) {
            this.handleCheckBox(val, 'networkOperator');
        },

        cancleForm(formName) {
            this.$refs[formName].resetFields();
            this.$router.push({path: '/promote'});
        },

        nextForm(formName) {
            let hash = window.location.hash;

            this.$refs[formName].validate(valid => {
                if(valid) {
                    if (this.active++ > 2) {
                        return this.active;
                    }

                    if(hash.includes("?")) {
                        $("input#area-list.area-duoxuan").data("value", this.secondForm.area);
                        $("input#area-list.area-duoxuan").val(this.secondForm.area);
                    }
                } else {
                    console.log('Fail to next');
                }
            });
        },

        canclSecondForm(formName) {
            this.$refs[formName].resetFields();
            this.$router.push({path: '/promote'});
        },

        back() {
            localStorage.removeItem('selectedHours');
            return this.active--;
        },

        createNewPackage(formName) {
            this.$refs[formName].validate(valid => {
                if(valid) {
                    this.createPackage();
                } else {
                    console.log('Fail to validate the form data');
                }
            });
        },

        createPackage() {
            this.create()
                .then(res => {
                    let data = res.data;

                    if(res.code == '200') {
                        this.$message({
                            showClose: true,
                            type: 'success',
                            message: "新建定向包成功"
                        });
                    } else {
                        this.$message({
                            showClose: true,
                            type: 'error',
                            message: res.message
                        });
                    }
                })
                .catch(err => {
                    this.$message({
                        showClose: true,
                        type: 'error',
                        message: err
                    });
                });
        },

        create() {
            let parmas = {
                age: this.secondForm.age,
                area: this.secondForm.area,
                areaType: this.secondForm.areaType,
                id: '',
                isTemplate: '1',
                network: this.secondForm.network,
                networkOperator: this.secondForm.networkOperator,
                platform: this.secondForm.platform,
                sex: this.secondForm.sex,
                title: ''
            }

            return new Promise((resolve, reject) => {
                this.$request.post(this.$store.state.createPackage, parmas)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        nextSecondForm(formName) {
            let areaList = [];
            let areaStr = $("#area-list").val();

            if(areaStr && areaStr.length > 0) {
                areaList = areaStr.split("-");
            }

            this.secondForm.area = areaList;

            this.$refs[formName].validate(valid => {
                if(valid) {
                    if (this.active++ > 2) {
                        return this.active;
                    }
                    if(this.flag == 0){
                        this.initCanlendar();
                        this.flag++;
                    }
                } else {
                    console.log('Fail to next');
                }
            });
        },

        cancleThirdForm(formName) {
            this.$refs[formName].resetFields();
            let id = this.$route.query.id;
            if(!!id) {
                localStorage.removeItem('selectedHours');
            }
            this.$router.push({path: '/promote'});
        },

        submitThirdForm(formName) {
            let hash = window.location.hash;

            if(hash.includes("?")) {
                this.editPromote(formName);
            } else {
                this.createPromote(formName);
            }
        },

        editPromote(formName) {
            this.$refs[formName].validate(valid => {
                let falg = this.validatePromotionOnlineTimes();

                if(valid && falg) {
                    this.edit()
                        .then(res => {
                            let data = res.data;
                            if(res.code == '200') {
                                this.$message({
                                    showClose: true,
                                    type: 'success',
                                    message: "更新推广计划成功"
                                });
                                this.$router.push({path: '/promote'});
                            } else {
                                this.$message({
                                    showClose: true,
                                    type: 'error',
                                    message: res.message
                                });
                                this.$router.push({path: '/promote'});
                            }
                            localStorage.removeItem('selectedHours');
                        })
                        .catch(err => {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: err
                            });
                            localStorage.removeItem('selectedHours');
                        });
                    this.active++;
                } else {
                    console.log('Fail to next');
                    localStorage.removeItem('selectedHours');
                }
            });
        },

        createPromote(formName) {
            this.$refs[formName].validate(valid => {
                let falg = this.validatePromotionOnlineTimes();

                if(valid && falg) {
                    this.submit()
                        .then(res => {
                            let data = res.data;

                            if(res.code == '200') {
                                this.$message({
                                    showClose: true,
                                    type: 'success',
                                    message: "新建推广计划成功"
                                });
                                this.$router.push({path: '/promote'});
                            } else {
                                this.$message({
                                    showClose: true,
                                    type: 'error',
                                    message: res.message
                                });
                                this.$router.push({path: '/promote'});
                            }
                        })
                        .catch(err => {
                            this.$message({
                                showClose: true,
                                type: 'error',
                                message: err
                            });
                        });
                    this.active++;
                } else {
                    console.log('Fail to next');
                }
            });
        },

        edit() {
            let params = this.formatParams();
            let deliverTimeType = this.formatTimeList();
            this.form.promotionOnlineTimeList = deliverTimeType;

            let hash = window.location.hash;
            let id = window.location.hash.split("?")[1].split("=")[1];
            let fields = Object.assign(params, {id: id, orientationId: this.orientationId});

            return new Promise((resolve, reject) => {
                this.$request.put(this.$store.state.edit, fields)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        submit() {
            let params = this.formatParams();
            let deliverTimeType = this.formatTimeList();
            this.form.promotionOnlineTimeList = deliverTimeType;

            return new Promise((resolve, reject) => {
                this.$request.post(this.$store.state.create, params)
                    .then(data => {
                        resolve(data);
                    }).catch(err => {
                        reject(err);
                    });
            });
        },

        formatTimeList() {
            let result = [];

            let startTime = this.$utils.formatDate(this.thirdForm.promotionOnlineTimes[0], "yyyy-MM-dd");
            let endTime = this.$utils.formatDate(this.thirdForm.promotionOnlineTimes[1], "yyyy-MM-dd");

            let flag = this.$utils.getNextDay(endTime);
            let fragment = $('#target').weekly_schedule("getSelectedHour");
            fragment = this.formatFragment(fragment);

            do {
                let week = this.$utils.getWeekByDate(new Date(startTime)) - 1;

                if(fragment[week] && fragment[week].length > 0) {
                    for (var i = 0; i < fragment[week].length; i++) {
                        let item = fragment[week][i];
                        let list = {};

                        for (var j = 0; j <= item.length - 1; j++) {
                            let time = item[j].split('-');

                            if(time[1] == "0:00:00") {
                                list = {
                                    startTime: startTime + ' ' + time[0],
                                    endTime: this.$utils.getNextDay(startTime) + ' ' + time[1]
                                };
                            } else {
                                list = {
                                    startTime: startTime + ' ' + time[0],
                                    endTime: startTime + ' ' + time[1]
                                };
                            }

                            result.push(list);
                        }
                    }
                }
                startTime = this.$utils.getNextDay(startTime);
            }while (startTime != flag);

            if(result.length == 0 && this.thirdForm.promotionOnlineTimes) {
                let timeFirst = this.$utils.formatDate(this.thirdForm.promotionOnlineTimes[0], "yyyy-MM-dd");
                let timeSecond = this.$utils.formatDate(this.thirdForm.promotionOnlineTimes[1], "yyyy-MM-dd");

                do {
                    let item = {
                        startTime: timeFirst + ' 00:00:00',
                        endTime: this.$utils.getNextDay(timeFirst) + ' 00:00:00'
                    };
                    result.push(item);
                    timeFirst = this.$utils.getNextDay(timeFirst);
                } while(timeFirst != this.$utils.getNextDay(timeSecond));
            }

            return result;
        },

        formatFragment(list) {
            let result = [];

            for(let i = 0; i <= list.length - 1; i++) {
                let startTime = '';
                let endTime = '';
                let time = [];
                let flagStart = '';
                let flagEnd = '';

                for(let j = 0; j <= list[i].length - 1; j++) {
                    let item = list[i][j];

                    if(list[i].length > 0 && item.includes('-')) {
                        item = item.split('-');
                        flagStart = item[0];

                        if(list[i].length == 1) {
                            time.push([flagStart + '-' + item[1]]);
                        }

                        if(flagStart != endTime) {
                            if(!endTime && !endTime.toString()) {
                                startTime = flagStart;
                            }
                            if(flagStart && endTime && !!flagStart.toString() && !!endTime.toString()) {
                                time.push([startTime + '-' + endTime]);
                                startTime = flagStart;
                            }
                            endTime = item[1];
                        } else {
                            endTime = item[1];
                            if(j == list[i].length - 1) {
                                time.push([startTime + '-' + endTime]);
                            }
                        }
                    }
                }
                result.push(time);
            }
            return result;
        },

        formatParams() {
            this.form.orientation = this.secondForm;
            let result = Object.assign(this.form, this.thirdForm);

            if(result.type == 0) {
                delete result.appId;
            }
            return result;
        },

        validatePromotionOnlineTimes() {
            let startTime = this.$utils.formatDate(new Date(this.thirdForm.promotionOnlineTimes[0]), "yyyy-MM-dd")
            let currentTime = this.$utils.formatDate(new Date(), "yyyy-MM-dd")

            if(new Date(startTime).getTime() < new Date(currentTime).getTime()) {
                this.$message({
                    showClose: true,
                    type: 'error',
                    message: '投放时间的开始时间必须大于等于当前时间'
                });
                return false;
            }
            return true;
        },

        selectType() {
            if(this.isDisabledChargeMode == true) {
                return true;
            }

            this.form.type = this.isActive ? 2 : 1;
            return this.isActive = this.isActive ? false : true;
        },

        scan() {
            if(this.form.linkUrl) {
                return window.open(this.form.linkUrl);
            }
        }
    }
}
</script>
<style lang="scss" scoped>
    @import '../../assets/style/color.scss';
    @import '../../assets/style/common.scss';

    .create-container {
        height: auto;

        .application-tip {
            color: $red;
            margin-left: 15px;
        }

        .city-item {
            margin: 10px 0px;
            display: flex;
        }

        .el-col {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }

        .el-form-item__label {
            text-align: left !important;
        }

        .handle {
            margin: 50px 0 0;
        }

        .el-checkbox-group.sub-area {
            float: right !important;
        }

        .container {
            margin: 0 0 22px;
        }

        .steps {
            min-height: 107px;
            height: auto;
            box-shadow: 0 5px 5px hsla(0,0%,60%,.09) !important;
            background-color: $white;

            .step-item {
                margin: 15px 0;
                padding: 45px 20%;
            }
        }

        .dsp-botton {
            @include green-botton;
        }

        .type {
            .time {
                font-size: $font-size-2;
                color: $small-font-color;
                line-height: 16px;
            }

            .type-item {
                width: 230px;
                margin: 0 15px 10px 0;
                cursor: pointer;
            }

            .type-item-active {
                border: 1px solid $green;
                border-radius: 5px;
                box-shadow: 0 2px 12px 0 $green !important;
            }

            .name {
                font-size: $font-size-4;
                color: $font-color;
                width: 154px;
                height: 35px;
                text-align: center;
            }

            .bottom {
                margin-top: 7px;
                line-height: 12px;
            }

            .button {
                padding: 0;
                float: right;
            }

            .image {
                width: 100px;
                height: 150px;
                padding: 0 43px;
                display: block;
            }

            .clearfix:before,
            .clearfix:after {
                display: table;
                content: "";
            }

            .clearfix:after {
                clear: both
            }
        }

        .popover {
            width: 400px;
            height: 380px;
        }

        .grid-felx {
            border-radius: 4px;
            min-height: 107px;
            height: auto;
            display: flex;
            justify-content: center;

            .grid-process {
                align-self: center;
                width: 50%;
                font-size: $font-size-2;
                color: $content-color;
            }
        }

        input.area-duoxuan {
            border: 1px solid $border-color;
            height: 40px;
            width: 350px;
            line-height: 40px;
            font-size: $font-size-2;
            color: $form-label-color;
            padding: 0 20px;
            border-radius: 4px;
        }

        .input-with-select {
            .el-select {
                width: 95px;
            }
        }

        .header-icon {
            float: left;
            margin-top: 10px;
            color: #d9d9d9;
            cursor: pointer;
        }
    }
</style>
