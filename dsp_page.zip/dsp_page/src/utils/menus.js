/**
 * Created by yuhua.li on 2018.06.26
 */

const menuItems = {

    menus: [
        {
            "index": "index",
            "icon": "../src/assets/images/home/home.png",
            "title": "首页"
        },
        {
            "index": "promote",
            "icon": "../src/assets/images/home/promote.png",
            "title": "推广",
            "subs": [
                {
                    "index": "promote",
                    "title": "推广计划"
                },
                {   
                    "index": "advert",
                    "title": "广告"
                }
            ]
        },
        {
            "index": "tool",
            "icon": "../src/assets/images/home/tool.png",
            "title": "工具",
            "subs": [
                {
                    "index": "material",
                    "title": "素材"
                },
                {   
                    "index": "application",
                    "title": "应用"
                },
                {
                    "index": "package",
                    "title": "定向包"
                }
            ]
        },
        {
            "index": "report",
            "icon": "../src/assets/images/home/report.png",
            "title": "报表统计",
            "subs": [
                {
                    "index": "report",
                    "title": "账号报表"
                },
                {   
                    "index": "programEffect",
                    "title": "推广效果"
                },
                {
                    "index": "adEffect",
                    "title": "广告效果"
                }
            ]
        },
        {
            "index": "account",
            "icon": "../src/assets/images/home/account.png",
            "title": "账户中心",
            "subs": [
                {
                    "index": "userInfo",
                    "title": "用户信息"
                }
            ]
        },
        {
            "index": "financial",
            "icon": "../src/assets/images/home/account.png",
            "title": "财务管理",
            "subs": [
                {
                    "index": "financial",
                    "title": "财务管理"
                }
            ]
        }
    ]
}

export default menuItems
