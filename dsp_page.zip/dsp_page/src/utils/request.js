/**
 * Created by yuhua.li on 2018.06.25
 */
import axios from 'axios';

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
axios.defaults.headers.post['X-Requested-With'] = 'XMLHttpRequest';
axios.defaults.withCredentials = true;

let postPromise = (url, data) => {
    return new Promise((resolve, reject) => {
        axios.post(url, data, {
            timeout: 30000
        }).then((response) => {
            let data = response.data;
            
            if (data && data.code == "403" || data.code == "409" || data.code == "10005" || data.code == "10003") {
                window.location.href = window.location.origin + process.env.SOURCE_URL+ '/#/login';
            } else {
                resolve(data);
            }
        }).catch((err) => {
            reject(err);
        });
    });
};

let getPromise = (url, data) => {
    return new Promise((resolve, reject) => {
        axios.get(url, {params: data}, { timeout: 30000 })
            .then((response) => {
                let data = response.data;

                if (data && data.code == "403" || data.code == "409" || data.code == "10005" || data.code == "10003") {
                    window.location.href = window.location.origin + process.env.SOURCE_URL+ '/#/login';
                } else {
                    resolve(data);
                }
            }).catch((err) => {
                reject(err);
            });
    });
};

let putPromise = (url, data) => {
    return new Promise((resolve, reject) => {
        axios.put(url, data, { timeout: 30000 })
            .then((response) => {
                let data = response.data;

                if (data && data.code == "403" || data.code == "409" || data.code == "10005" || data.code == "10003") {
                    window.location.href = window.location.origin + process.env.SOURCE_URL+ '/#/login';
                } else {
                    resolve(data);
                }
            }).catch((err) => {
                reject(err);
            });
    });
};

let deletePromise = (url, data) => {
    return new Promise((resolve, reject) => {
        axios.delete(url, {params: data}, { timeout: 30000 })
            .then((response) => {
                let data = response.data;

                if (data && data.code == "403" || data.code == "409" || data.code == "10005" || data.code == "10003") {
                    window.location.href = window.location.origin + process.env.SOURCE_URL+ '/#/login';
                } else {
                    resolve(data);
                }
            }).catch((err) => {
                reject(err);
            });
    });
};

const request = {
    post: postPromise,
    get: getPromise,
    put: putPromise,
    delete: deletePromise
}

export default request