/**
 * Created by yuhua.li on 2018.6.25
 */
function padLeftZero(str) {
    return ('00' + str).substr(str.length);
}

const utils = {

    isEmpty: function (s) {
        if (s == null || s.trim() == "" || s.replace(/(^s*)|(s*$)/g, "").length == 0) {
            return true;
        }
        return false;
    },

    getWeekByDate(date) {
        var str = "";
        switch (date.getDay()) {
            case 0:
                str = "7";
                break;
            case 1:
                str = "1";
                break;
            case 2:
                str = "2";
                break;
            case 3:
                str = "3";
                break;
            case 4:
                str = "4";
                break;
            case 5:
                str = "5";
                break;
            case 6:
                str = "6";
                break;
        }
        return str;
    },

    getNextDay(day) {
        day = new Date(day);
        day = +day + 1000 * 60 * 60 * 24;
        day = new Date(day);

        let month = (day.getMonth() + 1) < 10 ? "0"+ (day.getMonth() + 1) : (day.getMonth() + 1);
        let d = day.getDate() < 10 ? "0"+ day.getDate() : day.getDate();

        return day.getFullYear() + "-" + month + "-" + d;
    },

    // 09:00:00
    getNextHour(hour) {
        let time = hour.split(":")[0];
        time = parseInt(time) + 1;

        if(time < 10) {
            time = "0" + time;
        }

        if(time == 24) {
            time = "00";
        }

        return time + ":00:00";
    },

    // 2018-07-09 09:00:00
    getNextHourByDate(year) {
        let hour = year.split(" ")[1];
        let time = hour.split(":")[0];
        time = parseInt(time) + 1;

        if(time < 10) {
            time = "0" + time;
        }
        
        if(time == 24) {
            time = "00";
        }

        return year.split(" ")[0] + " " + time + ":00:00";
    },

    formatHour(hour) {
        let time = hour.split(":")[0];
        return parseInt(time) + ":00:00";
    },

    //转换时间格式
    formatDate(date, fmt) {
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
        }
        let o = {
            'M+': date.getMonth() + 1,
            'd+': date.getDate(),
            'h+': date.getHours(),
            'm+': date.getMinutes(),
            's+': date.getSeconds()
        };
        for (let k in o) {
            if (new RegExp(`(${k})`).test(fmt)) {
                let str = o[k] + '';
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : padLeftZero(str));
            }
        }
        return fmt;
    }
}

export default utils
