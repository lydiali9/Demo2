import Vue from 'vue'
import App from './App'
import router from './router'
import axios from 'axios'
// import 'element-ui/lib/theme-chalk/index.css';
import '@/theme/index.css'
import ElementUI from 'element-ui'

import request from './utils/request'
import Utils from './utils/utils'
import Menus from './utils/menus'

import ECharts from 'vue-echarts/components/ECharts'
import 'echarts/lib/chart/line';
import 'echarts/lib/component/tooltip'

Vue.use(ElementUI);
Vue.component('chart', ECharts)

Vue.prototype.$axios = axios;
Vue.prototype.$request = request;
Vue.prototype.$utils = Utils;
Vue.prototype.$menus = Menus;

Vue.config.productionTip = false

Vue.prototype.setCookie = (c_name, value, expiredays) => {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
}

function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return (unescape(arr[2]));
    else
        return null;
}
Vue.prototype.getCookie = getCookie;

Vue.prototype.delCookie = (name) => {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = getCookie(name);
    if (cval != null)
        document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
}

router.beforeEach((to, from, next) => {
    let items = [];

    if(to.fullPath != "/index") {
        localStorage.removeItem('has_ad');
    }

    if(to.fullPath == "/" || to.fullPath == "/login" || to.fullPath == "/register" || to.fullPath == "/retrievePwd") {
        next();
    } else {
        if(!getCookie('userId')) {
            next({path: '/login'})
        } else {
            items = JSON.parse(getCookie('menus')) || [];

            if (!items.indexOf(to.fullPath) > -1) {
                next();
            } else {
                next({path: '/login'});
            }
        }
    }
})

new Vue({
    el: '#app',
    router,
    template: '<App/>',
    components: {App},
    methods: {}
});
