module.exports = {
    NODE_ENV: '"production"',
    SERVER_URL: '"http://123.59.77.71:8099/"',
    SOURCE_URL: '""'
}
