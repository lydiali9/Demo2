var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
    NODE_ENV: '"development"',
    // SERVER_URL: '"http://192.168.3.253:8099/"',
    // SERVER_URL: '"http://192.168.9.18:8099/"',
    SERVER_URL: '"http://123.59.77.71:8099/"',
    SOURCE_URL: '""'
})
