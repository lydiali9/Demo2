module.exports = {
    NODE_ENV: '"production"',
    SERVER_URL: '"http://121.201.57.76:11999/api/"',
    SOURCE_URL: '""'
}
