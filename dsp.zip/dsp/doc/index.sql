ALTER TABLE dspv2_t_ad_report_daily ADD INDEX index_t_ad_report_daily_combine (`date`, `user_id`, `promotion_id`, `ad_id`);
ALTER TABLE dspv2_t_ad_report_daily ADD INDEX index_t_ad_report_daily_date (`date`);
ALTER TABLE dspv2_t_ad_report_daily ADD INDEX index_t_ad_report_daily_user_id (`user_id`);
ALTER TABLE dspv2_t_ad_report_daily ADD INDEX index_t_ad_report_daily_promotion_id (`promotion_id`);
ALTER TABLE dspv2_t_ad_report_daily ADD INDEX index_t_ad_report_daily_ad_id (`ad_id`);

ALTER TABLE dspv2_t_ad_report_hourly ADD INDEX index_ad_report_hourly_combine (`date`, `user_id`, `promotion_id`, `ad_id`);
ALTER TABLE dspv2_t_ad_report_hourly ADD INDEX index_ad_report_hourly_date (`date`);
ALTER TABLE dspv2_t_ad_report_hourly ADD INDEX index_ad_report_hourly_user_id (`user_id`);
ALTER TABLE dspv2_t_ad_report_hourly ADD INDEX index_ad_report_hourly_promotion_id (`promotion_id`);
ALTER TABLE dspv2_t_ad_report_hourly ADD INDEX index_ad_report_hourly_ad_id (`ad_id`);