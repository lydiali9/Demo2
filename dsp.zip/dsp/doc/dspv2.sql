/*
Navicat MySQL Data Transfer

Source Server         : 广告测试
Source Server Version : 50623
Source Host           : 123.59.77.13:3306
Source Database       : db_mta

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2018-08-15 11:15:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dspv2_t_account
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_account`;
CREATE TABLE `dspv2_t_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '账户id',
  `user_id` int(11) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT NULL COMMENT '账户余额',
  `status` tinyint(4) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账户表';

-- ----------------------------
-- Table structure for dspv2_t_account_flow
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_account_flow`;
CREATE TABLE `dspv2_t_account_flow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT 'user_id',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `type` tinyint(4) DEFAULT NULL COMMENT '收入类型:1=收入,2=支出',
  `source` tinyint(4) DEFAULT NULL COMMENT '这笔收支的来源:1=充值,2=赠送,3=广告消耗',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '余额',
  `status` tinyint(4) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL COMMENT '操作人,-1:代表系统操作',
  `memo` text,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账户流水表';

-- ----------------------------
-- Table structure for dspv2_t_account_flow_report
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_account_flow_report`;
CREATE TABLE `dspv2_t_account_flow_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT NULL COMMENT '日期',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `recharge_amount` decimal(10,2) DEFAULT NULL COMMENT '充值金额',
  `return_amount` decimal(10,2) DEFAULT NULL COMMENT '返货金额',
  `consumption_amount` decimal(10,2) DEFAULT NULL COMMENT '消费金额',
  `frozen_amount` decimal(10,2) DEFAULT NULL COMMENT '冻结金额',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '用户余额',
  `available_balance` decimal(10,2) DEFAULT NULL COMMENT '可用余额',
  `create_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for dspv2_t_account_frozen
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_account_frozen`;
CREATE TABLE `dspv2_t_account_frozen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `frozen_date` timestamp NULL DEFAULT NULL,
  `frozen_amount` decimal(10,2) DEFAULT NULL COMMENT '账户冻结金额',
  `promotion_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '该天是否已经结算,0:未结算(冻结),1:已结算,2:删除',
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `create_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账户冻结表';

-- ----------------------------
-- Table structure for dspv2_t_account_recharge_apply
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_account_recharge_apply`;
CREATE TABLE `dspv2_t_account_recharge_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录id',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id(对应的是t_user中的user_id)',
  `type` tinyint(4) DEFAULT NULL COMMENT '充值类型,1:预付款,0:后付款',
  `recharge_amount` decimal(10,2) DEFAULT NULL COMMENT '充值金额',
  `return_amount` decimal(10,2) DEFAULT NULL COMMENT '返货金额',
  `requester_user_id` int(10) DEFAULT NULL COMMENT '发起人的user_id',
  `requester` varchar(50) DEFAULT NULL COMMENT '发起人',
  `auditor_user_id` int(11) DEFAULT NULL COMMENT '审核人的user_id',
  `auditor` varchar(50) DEFAULT NULL COMMENT '审核人',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` tinyint(4) DEFAULT NULL COMMENT '审核状态,0:未审核,1:审核通过,2:审核不通过',
  `reason` varchar(255) DEFAULT NULL COMMENT '审核未通过的原因',
  `audit_time` timestamp NULL DEFAULT NULL COMMENT '审核时间',
  `create_time` timestamp NULL DEFAULT NULL COMMENT '创建时间，发起时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for dspv2_t_account_settle_flow
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_account_settle_flow`;
CREATE TABLE `dspv2_t_account_settle_flow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `promotion_id` bigint(20) DEFAULT NULL,
  `settle_date` date DEFAULT NULL COMMENT '结算的日期',
  `actual_amount` decimal(10,2) DEFAULT NULL COMMENT '实扣金额',
  `settle_amount` decimal(10,2) DEFAULT NULL COMMENT '本次应扣金额',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '结算记录的日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='结算金额的记录表(可用于金额回滚、错误数据重新结算)';

-- ----------------------------
-- Table structure for dspv2_t_ad
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_ad`;
CREATE TABLE `dspv2_t_ad` (
  `ad_id` bigint(20) NOT NULL COMMENT '广告ID',
  `user_id` int(11) DEFAULT NULL,
  `operator` int(11) DEFAULT NULL,
  `promotion_id` int(20) DEFAULT NULL COMMENT '主键ID',
  `title` varchar(50) DEFAULT NULL COMMENT '推广title-图片规格-index',
  `type` tinyint(4) DEFAULT NULL COMMENT '广告类型：0=普通广告，1=c类广告',
  `pv_report_url` text COMMENT 'pv上报url',
  `click_report_url` text COMMENT 'click上报url',
  `video_start_play_report_url` text COMMENT '视频播放上报url',
  `video_end_play_report_url` text COMMENT '视频播放完成上报url',
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) DEFAULT NULL COMMENT '广告状态,0=待上线,1=上线,2=下线,3=过期,4=废弃',
  `review_status` tinyint(4) DEFAULT NULL COMMENT '广告审核状态,0=待审核,1=审核通过,2=审核不通过,3=强制下线',
  `no_pass_reason` varchar(50) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告数据表';

-- ----------------------------
-- Table structure for dspv2_t_ad_history
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_ad_history`;
CREATE TABLE `dspv2_t_ad_history` (
  `ad_id` bigint(20) NOT NULL COMMENT '广告ID',
  `user_id` int(11) DEFAULT NULL,
  `promotion_id` int(11) DEFAULT NULL COMMENT '主键ID',
  `operator` int(11) DEFAULT NULL,
  `memo` text COMMENT 'operator-date-opition',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告历史表，记录更新历史';

-- ----------------------------
-- Records of dspv2_t_ad_history
-- ----------------------------

-- ----------------------------
-- Table structure for dspv2_t_ad_material
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_ad_material`;
CREATE TABLE `dspv2_t_ad_material` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `type` tinyint(1) DEFAULT NULL COMMENT '1=小图；2=大图；3=图组；4=视频',
  `title` varchar(25) DEFAULT NULL,
  `big_image_type` tinyint(1) DEFAULT NULL COMMENT '大图(type=2)类型：1=横幅大图，2=横版大图，3=竖版大图。',
  `ratio_id` int(11) DEFAULT NULL COMMENT '广告比例ID',
  `image_group_id` tinyint(1) DEFAULT NULL COMMENT '组图(type=3)id',
  `ad_id` bigint(20) DEFAULT NULL COMMENT '广告ID',
  `image_id` int(11) DEFAULT NULL,
  `source` varchar(10) DEFAULT NULL COMMENT '素材来源',
  `operator` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(1) DEFAULT NULL COMMENT '图片素材状态：0=初始化状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for dspv2_t_ad_report_daily
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_ad_report_daily`;
CREATE TABLE `dspv2_t_ad_report_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT NULL COMMENT '格式:yyyy-MM-dd HH:mm:ss',
  `user_id` int(11) DEFAULT NULL,
  `promotion_id` bigint(20) DEFAULT NULL COMMENT '推广id',
  `promotion_title` varchar(50) DEFAULT NULL COMMENT '推广名称',
  `ad_id` bigint(20) DEFAULT NULL,
  `ad_title` varchar(50) DEFAULT NULL COMMENT '广告名称',
  `impression` int(11) DEFAULT NULL,
  `request` int(11) DEFAULT NULL,
  `pv` int(11) DEFAULT NULL,
  `click` int(11) DEFAULT NULL,
  `ctr` decimal(4,2) DEFAULT NULL COMMENT '点击率百分比',
  `ecpm` decimal(10,2) DEFAULT NULL COMMENT '平均每千次展现费用，单位元。',
  `ecpc` decimal(10,2) DEFAULT NULL COMMENT '平均点击费用，单位元',
  `total_cost` decimal(10,2) DEFAULT NULL COMMENT '消费（元）',
  `status` tinyint(4) DEFAULT NULL COMMENT '数据状态：1:正常的(可用的),2:废弃的(不可用)',
  `create_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `index_t_ad_report_daily_combine` (`date`,`user_id`,`promotion_id`,`ad_id`),
  KEY `index_t_ad_report_daily_date` (`date`),
  KEY `index_t_ad_report_daily_user_id` (`user_id`),
  KEY `index_t_ad_report_daily_promotion_id` (`promotion_id`),
  KEY `index_t_ad_report_daily_ad_id` (`ad_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告天极统计报表';

-- ----------------------------
-- Table structure for dspv2_t_ad_report_hourly
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_ad_report_hourly`;
CREATE TABLE `dspv2_t_ad_report_hourly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT NULL COMMENT '格式:yyyy-MM-dd HH:mm:ss',
  `user_id` int(11) DEFAULT NULL,
  `promotion_id` bigint(20) DEFAULT NULL COMMENT '推广id',
  `promotion_title` varchar(50) DEFAULT NULL,
  `ad_id` bigint(20) DEFAULT NULL,
  `ad_title` varchar(50) DEFAULT NULL,
  `impression` int(11) DEFAULT NULL,
  `request` int(11) DEFAULT NULL,
  `pv` int(11) DEFAULT NULL,
  `click` int(11) DEFAULT NULL,
  `ctr` decimal(4,2) DEFAULT NULL COMMENT '点击率百分比',
  `ecpm` decimal(10,2) DEFAULT NULL COMMENT '平均每千次展现费用，单位元。',
  `ecpc` decimal(10,2) DEFAULT NULL COMMENT '平均点击费用，单位元',
  `total_cost` decimal(10,2) DEFAULT NULL COMMENT '消费（元）',
  `status` tinyint(4) DEFAULT NULL COMMENT '数据状态：1:正常的(可用的),2:废弃的(不可用)',
  `create_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `index_ad_report_hourly_combine` (`date`,`user_id`,`promotion_id`,`ad_id`),
  KEY `index_ad_report_hourly_date` (`date`),
  KEY `index_ad_report_hourly_user_id` (`user_id`),
  KEY `index_ad_report_hourly_promotion_id` (`promotion_id`),
  KEY `index_ad_report_hourly_ad_id` (`ad_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告小时级统计报表';

-- ----------------------------
-- Table structure for dspv2_t_ad_space
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_ad_space`;
CREATE TABLE `dspv2_t_ad_space` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL COMMENT '广告位名称',
  `app_id` int(11) DEFAULT NULL COMMENT '所属应用ID',
  `width` int(11) DEFAULT NULL COMMENT '宽',
  `height` int(11) DEFAULT NULL COMMENT '高',
  `ratio` decimal(10,2) DEFAULT NULL COMMENT '宽高比',
  `belong_ratio_id` int(11) NOT NULL,
  `operator` int(11) DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL COMMENT '状态',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告位表';

-- ----------------------------
-- Records of dspv2_t_ad_space
-- ----------------------------
INSERT INTO `dspv2_t_ad_space` VALUES ('11', '订阅页', '3', '272', '238', '1.14', '3', null, '0', '2018-08-03 14:36:17', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('41', '信息流广告图文广告', '8', '210', '140', '1.50', '5', null, '0', '2018-08-13 11:41:43', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('95', 'XXX', '272', '1024', '574', '1.78', '6', null, '0', '2018-08-11 11:25:42', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('115', '信息流广告', '20', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:36:47', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('139', '信息流通栏广告位', '29', '1008', '498', '2.02', '6', null, '0', '2018-08-03 14:37:05', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('140', '信息流非通栏广告位', '29', '324', '210', '1.54', '5', null, '0', '2018-08-03 14:37:16', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('152', '二级页横幅广告', '29', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:37:28', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('155', '二级页图文广告', '36', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:37:30', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('156', '二级页通栏广告', '36', '1024', '574', '1.78', '6', null, '0', '2018-08-03 14:37:46', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('157', '二级页图文多功能广告', '36', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:37:48', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('158', '二级页横幅广告', '36', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:37:59', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('197', '卡片式SDK图文广告', '43', '195', '147', '1.33', '4', null, '0', '2018-08-03 14:38:05', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('198', '原生一级页通栏广告', '43', '1020', '573', '1.78', '6', null, '0', '2018-08-03 14:38:12', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('199', '原生一级页图文广告', '43', '288', '216', '1.33', '4', null, '0', '2018-08-03 14:38:20', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('265', '二级页横幅广告', '66', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:38:26', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('266', '二级页图文多功能广告', '66', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:38:33', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('268', '二级页图文广告', '66', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:38:40', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('289', '详情页JS广告-二级页横幅广告', '3', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:38:46', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('290', '详情页JS广告-二级页图文多功能广告', '3', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:38:53', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('291', '详情页JS广告-二级页通栏广告', '3', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:39:09', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('292', '详情页JS广告-二级页图文广告', '3', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:39:19', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('330', '卡片信息流广告', '29', '324', '210', '1.54', '5', null, '0', '2018-08-03 14:41:19', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('336', '卡片式SDK大图Banner广告', '43', '996', '549', '1.81', '6', null, '0', '2018-08-03 14:42:17', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('339', '二级页通栏广告', '76', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:51', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('340', '二级页应用下载广告', '76', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:40:34', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('341', '二级页图文信息流', '76', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:05', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('343', '信息流通栏广告', '76', '1020', '600', '1.70', '6', null, '0', '2018-08-03 14:41:59', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('344', '信息流普通广告', '76', '267', '201', '1.33', '4', null, '0', '2018-08-03 14:41:00', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('359', '二级页图文广告', '80', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:12', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('360', '二级页通栏广告', '80', '1024', '574', '1.78', '6', null, '0', '2018-08-03 14:42:07', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('361', '二级页图文多功能广告', '80', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:40:28', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('362', '二级页横幅广告', '80', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:47', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('423', '信息流普通广告1（短列表）', '76', '267', '201', '1.33', '4', null, '0', '2018-08-03 14:41:02', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('454', '二级页横幅', '43', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:42', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('455', '二级页通栏广告', '43', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:59', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('456', '二级页下载', '43', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:40:18', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('457', '二级页图文', '43', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:03', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('460', '列表页信息流小图广告', '92', '60', '45', '1.33', '4', null, '0', '2018-08-03 14:41:04', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('461', '详情页顶部横幅广告', '92', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:44', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('483', '阿里草堂机开屏广告', '92', '240', '320', '0.75', '2', null, '0', '2018-08-03 14:39:50', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('487', 'adabtest实验3二级页顶部图文', '76', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:07', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('511', '信息流普通广告（首屏）', '94', '324', '210', '1.54', '5', null, '0', '2018-08-03 14:41:39', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('520', '信息流小图广告（第9个位置）', '29', '270', '198', '1.36', '4', null, '0', '2018-08-03 14:41:13', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('530', '信息流大图广告（第9个位置）', '29', '984', '413', '2.38', '8', null, '0', '2018-08-03 14:42:27', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('535', '详情页图文广告', '94', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:10', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('559', '金立浏览器大图', '106', '1010', '564', '1.79', '6', null, '0', '2018-08-03 14:42:12', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('560', '浏览器二级页通栏', '106', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:49', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('572', '运动卡片通栏广告', '107', '1080', '607', '1.78', '6', null, '0', '2018-08-03 14:42:07', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('573', '运动卡片非通栏广告', '107', '540', '720', '0.75', '2', null, '0', '2018-08-03 14:39:52', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('574', '浏览器二级页横幅', '106', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:52', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('576', '浏览器二级页图文', '106', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:40:51', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('577', '运动二级页图文', '107', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:00', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('578', '运动二级页下载', '107', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:40:26', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('579', '运动二级页通栏', '107', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:47', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('580', '运动二级页横幅', '107', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:40', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('581', '详情页大图广告', '94', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:52', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('622', '列表小图广告', '126', '320', '240', '1.33', '4', null, '0', '2018-08-03 14:40:52', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('623', '列表大图广告', '126', '984', '555', '1.77', '6', null, '0', '2018-08-03 14:42:03', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('625', '列表小图广告', '129', '270', '198', '1.36', '4', null, '0', '2018-08-03 14:41:17', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('626', '列表大图广告', '129', '984', '413', '2.38', '8', null, '0', '2018-08-03 14:42:32', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('629', '导航模块1', '126', '96', '96', '1.00', '3', null, '0', '2018-08-03 14:40:29', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('630', '导航模块2', '126', '48', '48', '1.00', '3', null, '0', '2018-08-03 14:40:30', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('633', '算命大全-信-头', '124', '600', '500', '1.20', '4', null, '0', '2018-08-03 14:40:46', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('634', '详情页小图广告', '126', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:40:57', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('647', '金立美图卡片-列表页大图广告', '135', '1024', '574', '1.78', '6', null, '0', '2018-08-03 14:42:08', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('648', '金立美图卡片-列表页小图广告', '135', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:40:58', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('649', '金立美图卡片-详情页顶部横幅广告', '135', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:44', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('651', '金立美图卡片-详情页通栏广告', '135', '1024', '574', '1.78', '6', null, '0', '2018-08-03 14:42:11', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('652', '金立美图卡片-详情页相关推荐小图广告', '135', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:40:59', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('684', '详情页顶部', '140', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:43', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('686', '相关推荐信息流', '140', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:40:53', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('706', '详情页横幅广告', '129', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:41', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('715', '详情页小图广告', '126', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:40:31', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('726', '详情页中部通栏广告', '126', '1024', '574', '1.78', '6', null, '0', '2018-08-03 14:42:10', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('727', '详情页底部通栏广告', '126', '1024', '574', '1.78', '6', null, '0', '2018-08-03 14:42:09', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('728', '详情页横幅广告（尺寸跟信息流一致）', '34', '984', '413', '2.38', '8', null, '0', '2018-08-03 14:42:27', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('734', '天气二级页顶部横幅', '146', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:41', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('735', '天气二级页通栏广告', '146', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:44', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('736', '天气二级页小图广告', '146', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:01', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('764', '猎鹰浏览器-A-横幅', '150', '640', '100', '6.40', '10', null, '0', '2018-08-03 14:43:00', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('767', '详情页通栏广告', '140', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:46', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('820', '魅族搜索详情页横幅广告（尺寸跟信息流一致）', '129', '984', '413', '2.38', '8', null, '0', '2018-08-03 14:42:28', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('875', '玩车达人-信息流', '195', '640', '320', '2.00', '7', null, '0', '2018-08-03 14:42:25', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('898', '详情页大图广告', '210', '1024', '574', '1.78', '6', null, '0', '2018-08-03 14:42:06', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('902', '列表大图广告', '213', '984', '555', '1.77', '6', null, '0', '2018-08-03 14:42:00', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('903', '列表小图广告', '213', '320', '240', '1.33', '4', null, '0', '2018-08-03 14:40:53', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('920', '塔罗说-信息流', '218', '600', '500', '1.20', '4', null, '0', '2018-08-03 14:40:45', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('931', '快财经-ba-01-头', '222', '640', '100', '6.40', '10', null, '0', '2018-08-03 14:43:02', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('934', '快财经-na-01-头', '222', '680', '410', '1.66', '6', null, '0', '2018-08-03 14:41:51', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('935', '学理财日报-na-01-头', '224', '680', '410', '1.66', '6', null, '0', '2018-08-03 14:41:43', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('950', '凯迪信息流', '236', '160', '160', '1.00', '3', null, '0', '2018-08-03 14:40:35', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('957', '金立美图卡片小图广告', '135', '468', '351', '1.33', '4', null, '0', '2018-08-03 14:40:50', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('971', '详情页小浮窗广告', '110', '200', '200', '1.00', '3', null, '0', '2018-08-03 14:40:15', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('972', '详情页大图', '251', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:45', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('973', '详情页小图', '251', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:10', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('989', '酷派详情页小浮窗广告', '3', '200', '200', '1.00', '3', null, '0', '2018-08-03 14:40:27', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('990', '华为详情页小浮窗', '72', '200', '200', '1.00', '3', null, '0', '2018-08-03 14:40:37', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('991', '金立浏览器详情页小浮窗', '106', '200', '200', '1.00', '3', null, '0', '2018-08-03 14:40:25', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('992', '金立浏览器（新）小浮窗', '146', '200', '200', '1.00', '3', null, '0', '2018-08-03 14:40:16', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('995', '连尚横幅', '256', '480', '96', '5.00', '9', null, '0', '2018-08-03 14:42:55', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('996', '连尚信息流', '256', '480', '96', '5.00', '9', null, '0', '2018-08-03 14:42:52', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1017', '列表小图广告', '261', '320', '240', '1.33', '4', null, '0', '2018-08-03 14:41:02', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1020', '详情页大图广告', '261', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:40', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1021', '详情页横幅广告', '261', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:38', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1034', '浏览器二级页横幅', '266', '1080', '224', '4.82', '9', null, '0', '2018-08-03 14:42:39', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1035', '浏览器二级页通栏', '266', '1024', '618', '1.66', '6', null, '0', '2018-08-03 14:41:41', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1036', '浏览器二级页下载', '266', '140', '140', '1.00', '3', null, '0', '2018-08-03 14:40:32', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1037', '浏览器二级页图文', '266', '240', '180', '1.33', '4', null, '0', '2018-08-03 14:41:09', '0000-00-00 00:00:00');
INSERT INTO `dspv2_t_ad_space` VALUES ('1042', '全球趣闻-A-信息流', '272', '640', '320', '2.00', '6', null, '0', '2018-08-11 11:25:49', '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for dspv2_t_ad_strategy
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_ad_strategy`;
CREATE TABLE `dspv2_t_ad_strategy` (
  `strategy_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '策略ID',
  `ad_id` bigint(20) DEFAULT NULL,
  `ad_space` varchar(1000) DEFAULT NULL COMMENT '广告位，存json数组',
  `optimized_ad_space` varchar(1000) DEFAULT NULL,
  `weight` tinyint(2) DEFAULT NULL COMMENT '权重',
  `et_url` tinyint(1) DEFAULT NULL COMMENT '是否为et url',
  `user_pv_limit` int(11) DEFAULT NULL COMMENT '单用户pv限量',
  `user_click_limit` int(11) DEFAULT NULL COMMENT '单用户点击限量',
  `is_template` tinyint(1) DEFAULT NULL COMMENT '是否为策略模板',
  `operator` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`strategy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告策略表';

-- ----------------------------
-- Table structure for dspv2_t_app
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_app`;
CREATE TABLE `dspv2_t_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '主账户',
  `name` varchar(50) DEFAULT NULL COMMENT '应用名称',
  `app_type` text COMMENT '应用类型，例如：“社交沟通”等',
  `os` varchar(20) DEFAULT NULL COMMENT '操作系统：ios，android，winphone',
  `package` varchar(100) DEFAULT NULL,
  `package_size` double DEFAULT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `url_type` tinyint(4) DEFAULT NULL COMMENT '1=自有地址，2=第三方提供地址',
  `folder` varchar(100) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='应用表';

-- ----------------------------
-- Table structure for dspv2_t_const_ad_space_ratio
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_const_ad_space_ratio`;
CREATE TABLE `dspv2_t_const_ad_space_ratio` (
  `id` int(11) NOT NULL,
  `ratio` decimal(4,2) DEFAULT NULL COMMENT '宽高比例',
  `title` varchar(20) DEFAULT NULL COMMENT '标题',
  `min_width` int(11) DEFAULT NULL COMMENT '最小宽度',
  `min_height` int(11) DEFAULT NULL COMMENT '最小高度',
  `description` varchar(50) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告位比例常量表';

-- ----------------------------
-- Records of dspv2_t_const_ad_space_ratio
-- ----------------------------
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('1', '0.56', '大图-竖屏-0.56', '720', '1280', '广告主、优化师和运营可见', '2018-08-10 17:53:03', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('2', '0.75', '大图-竖屏-0.75', '600', '800', '老渠道酷派，优化师和运营可见', '2018-08-10 17:53:07', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('3', '0.99', '大图-竖屏-0.99', '200', '200', '优化师和运营可见', '2018-08-10 17:53:11', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('4', '1.33', '小图-1.33', '320', '240', '广告主、优化师和运营可见', '2018-08-10 17:52:54', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('5', '1.50', '小图-1.5', '480', '320', '优化师和运营可见', '2018-08-10 17:52:41', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('6', '1.78', '大图-横屏-1.78', '1024', '576', '广告主、优化师和运营可见', '2018-08-10 17:53:15', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('7', '2.00', '大图-横屏-2', '996', '498', '优化师和运营可见', '2018-08-10 17:53:18', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('8', '2.38', '大图-横屏-2.38', '984', '413', '优化师和运营可见', '2018-08-10 17:53:22', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('9', '4.82', '大图-横屏-4.38', '480', '98', '优化师和运营可见', '2018-08-10 17:53:27', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('10', '6.40', '大图-横屏-6.4', '640', '100', '优化师和运营可见', '2018-08-10 17:53:30', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_const_ad_space_ratio` VALUES ('11', '1.33', '组图-1.33', '320', '240', '广告主、优化师和运营可见', '2018-08-10 17:53:39', '0000-00-00 00:00:00', '0');

-- ----------------------------
-- Table structure for dspv2_t_image
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_image`;
CREATE TABLE `dspv2_t_image` (
  `image_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `url` varchar(255) DEFAULT NULL,
  `img_server_url` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `width` smallint(5) DEFAULT NULL,
  `height` smallint(5) DEFAULT NULL,
  `format` varchar(10) DEFAULT NULL,
  `ratio` double DEFAULT NULL COMMENT '比例',
  `tag` text,
  `is_template` tinyint(4) DEFAULT NULL COMMENT '是否为样本图片',
  `template_id` bigint(20) DEFAULT NULL COMMENT '模板ID',
  `title` varchar(50) DEFAULT NULL COMMENT '图片标题',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) DEFAULT NULL COMMENT '图片类型，1=小图、2=大图',
  `big_image_type` tinyint(4) DEFAULT NULL COMMENT '大图类型，当type=2时该字段有值，1=横幅，2=横版，3=竖版',
  `status` tinyint(4) DEFAULT NULL COMMENT '图片素材状态：0=初始化状态',
  PRIMARY KEY (`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告素材图片';

-- ----------------------------
-- Table structure for dspv2_t_orientation
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_orientation`;
CREATE TABLE `dspv2_t_orientation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL COMMENT '定向包名称',
  `sex` tinyint(1) DEFAULT NULL COMMENT '推广所面向用户的性别，1=男，2=女',
  `age` varchar(100) DEFAULT NULL COMMENT '取值枚举：多选存json, a) <18, b) 18~23 , c) 24~30, d) 31~40, e) 41~49, f) >50',
  `platform` varchar(100) DEFAULT NULL COMMENT '取值枚举：多选a) ios；b) android；c) pc；d) winphone',
  `network` varchar(100) DEFAULT NULL COMMENT '取值枚举：a) wifi；b) 2g；c) 3g；d) 4g；e) 5g',
  `network_operator` varchar(100) DEFAULT NULL COMMENT '网络运营商枚举值：a) CMCC(70120)；b) CTCC(70121)；c) CUCC(70123)；d) UNKNOWN(-1)',
  `area` text COMMENT '地域，存储json',
  `phone_brand` text COMMENT '手机品牌，存储json，格式待定，暂时不提供',
  `is_template` tinyint(1) DEFAULT NULL COMMENT '是否为模板：0=否，1=是',
  `operator` int(11) DEFAULT NULL COMMENT '操作者',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for dspv2_t_permission
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_permission`;
CREATE TABLE `dspv2_t_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sys` varchar(10) DEFAULT NULL COMMENT '所属系统',
  `permission` varchar(50) DEFAULT NULL COMMENT '权限url',
  `description` varchar(100) DEFAULT NULL COMMENT '描述',
  `method` varchar(10) DEFAULT NULL COMMENT '请求方法: POST, PUT, GET, DELETE等',
  `type` varchar(10) DEFAULT NULL COMMENT '权限类型，menu,function',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限表';

-- ----------------------------
-- Records of dspv2_t_permission
-- ----------------------------
INSERT INTO `dspv2_t_permission` VALUES ('1', 'PMS', '/advertiser', '广告主', 'GET', 'menu', '2018-07-25 14:03:24', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('2', 'PMS', '/advertiser/id', '广告主详情', 'GET', 'button', '2018-07-25 14:03:26', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('3', 'PMS', '/ad', '获取广告列表、获取单个广告', 'GET', 'button', '2018-08-01 14:33:24', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('4', 'PMS', '/ad/review', '审核广告', 'PUT', 'button', '2018-08-01 14:34:41', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('5', 'PMS', '/ad/strategy', '设置广告策略', 'POST', 'button', '2018-07-25 14:03:34', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('6', 'PMS', '/ad/material', '广告素材', 'GET', 'func', '2018-07-26 16:10:30', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('7', 'PMS', '/adPosition/ratio', '广告位按比例查询分组', 'GET', 'func', '2018-07-26 16:10:26', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('8', 'PMS', '/accountRechargeApply', '获取账户充值申请列表、获取申请详情', 'GET', 'func', '2018-08-01 14:38:00', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('9', 'PMS', '/accountRechargeApply', '保存账户充值申请', 'POST', 'func', '2018-08-01 14:38:20', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('10', 'PMS', '/ad/enforcementOffline', '强制下线广告', 'PUT', 'func', '2018-08-01 14:35:16', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('11', 'PMS', '/user', '获取用户信息', 'GET', 'func', '2018-07-26 16:45:43', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('12', 'PMS', '/image', '图片列表', 'GET', 'func', '2018-07-26 17:26:58', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('13', 'PMS', '/image/upload', '图片上传', 'POST', 'func', '2018-07-26 18:05:49', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('14', 'PMS', '/file', '图片拉取', 'GET', 'func', '2018-07-26 19:14:27', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('15', 'PMS', '/ad/material/optimization', '素材优化', 'POST', 'func', '2018-07-26 20:05:19', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('16', 'PMS', '/ad/strategy', '更新广告策略', 'PUT', 'func', '2018-07-27 10:23:17', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('17', 'PMS', '/openUser/simple', '获取广告主列表(简要信息)', 'GET', 'func', '2018-07-27 14:11:38', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('18', 'PMS', '/logout', '用户登出', 'POST', 'func', '2018-07-27 14:12:58', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('19', 'PMS', '/accountRechargeApply', '审核账户充值申请', 'PUT', 'func', '2018-07-31 17:24:15', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('20', 'PMS', '/adWithData', '获取广告列表(带有数据)', 'GET', 'func', '2018-08-14 16:14:10', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('21', 'PMS', '/ad/weight', '设置广告权重', 'PUT', 'func', '2018-08-14 16:14:13', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('22', 'PMS', '/adPosition/ratio', '广告位比例', 'GET', 'func', '2018-08-14 16:14:53', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('23', 'PMS', '/image', '创建图片', 'POST', 'func', '2018-08-14 16:14:11', '0000-00-00 00:00:00', '0');
INSERT INTO `dspv2_t_permission` VALUES ('24', 'PMS', '/ad/optimise', '优化师拉取广告详情', 'GET', 'func', '2018-08-14 16:14:08', '0000-00-00 00:00:00', '0');

-- ----------------------------
-- Table structure for dspv2_t_permission_group
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_permission_group`;
CREATE TABLE `dspv2_t_permission_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) DEFAULT NULL COMMENT '权限组名称',
  `description` varchar(20) DEFAULT NULL COMMENT '权限组描述',
  `sys` varchar(10) DEFAULT NULL COMMENT '系统',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限组';

-- ----------------------------
-- Records of dspv2_t_permission_group
-- ----------------------------
INSERT INTO `dspv2_t_permission_group` VALUES ('1', 'super_admin', '超级管理员', 'PMS');
INSERT INTO `dspv2_t_permission_group` VALUES ('2', 'ad_review', '广告审核菜单', 'PMS');
INSERT INTO `dspv2_t_permission_group` VALUES ('3', 'ad_manage', '广告管理菜单', 'PMS');
INSERT INTO `dspv2_t_permission_group` VALUES ('4', 'base_permission', '基本权限', 'PMS');
INSERT INTO `dspv2_t_permission_group` VALUES ('5', 'recharge_manage', '充值管理菜单', 'PMS');
INSERT INTO `dspv2_t_permission_group` VALUES ('6', 'recharge_review', '充值审核菜单', 'PMS');
INSERT INTO `dspv2_t_permission_group` VALUES ('7', 'ad_material', '素材库菜单', 'PMS');
INSERT INTO `dspv2_t_permission_group` VALUES ('8', 'ad_optimizer', '广告优化菜单', 'PMS');

-- ----------------------------
-- Table structure for dspv2_t_permission_group_rel
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_permission_group_rel`;
CREATE TABLE `dspv2_t_permission_group_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) DEFAULT NULL,
  `permission_group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dspv2_t_permission_group_rel
-- ----------------------------
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('1', '1', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('2', '2', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('3', '3', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('4', '4', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('5', '5', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('6', '6', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('7', '7', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('8', '8', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('9', '9', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('10', '10', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('11', '11', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('12', '12', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('13', '13', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('14', '14', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('15', '15', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('16', '16', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('17', '17', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('18', '18', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('19', '3', '2');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('20', '4', '2');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('21', '3', '3');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('22', '5', '3');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('23', '7', '3');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('24', '10', '3');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('25', '16', '3');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('26', '11', '4');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('27', '18', '4');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('28', '8', '5');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('29', '9', '5');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('30', '17', '5');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('31', '8', '6');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('32', '19', '6');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('33', '20', '8');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('34', '12', '8');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('35', '19', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('36', '20', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('37', '21', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('38', '22', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('39', '23', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('40', '24', '1');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('41', '22', '7');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('42', '13', '7');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('43', '12', '7');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('44', '23', '7');
INSERT INTO `dspv2_t_permission_group_rel` VALUES ('45', '24', '7');

-- ----------------------------
-- Table structure for dspv2_t_promotion
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_promotion`;
CREATE TABLE `dspv2_t_promotion` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `app_id` int(11) DEFAULT NULL,
  `orientation_id` int(11) DEFAULT NULL,
  `parent_user_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL COMMENT '推广计划名标题',
  `type` smallint(1) DEFAULT NULL COMMENT '推广的广告类型',
  `link_url` text,
  `product` text,
  `budget_type` tinyint(1) DEFAULT NULL COMMENT '预算类型：1=日预算，2=周预算，3=月预算',
  `budget_amount` decimal(10,2) DEFAULT NULL COMMENT '预算金额，单位元',
  `deliver_type` tinyint(1) DEFAULT NULL COMMENT '推广投放类型，1=标准投放，2=加速投放',
  `deliver_start_time` timestamp NULL DEFAULT NULL COMMENT '投放起始日期',
  `deliver_end_time` timestamp NULL DEFAULT NULL COMMENT '投放结束日期',
  `deliver_time_type` tinyint(1) unsigned zerofill DEFAULT NULL COMMENT '是否限制投放时段,1=不限,2=限制',
  `buy_type` tinyint(1) DEFAULT NULL COMMENT '推广采买方式：1=竞争购买，2=私有化采买',
  `charge_mode` tinyint(1) DEFAULT NULL COMMENT '收费模式：1=按展示付费（CPM），2=按点击付费(CPC)',
  `pay_amount_unit` decimal(10,2) DEFAULT NULL COMMENT '付费的单价',
  `operator` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) DEFAULT NULL COMMENT '0=暂停,1=启用,2=废弃',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='推广计划';

-- ----------------------------
-- Table structure for dspv2_t_promotion_budget
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_promotion_budget`;
CREATE TABLE `dspv2_t_promotion_budget` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `promotion_id` bigint(20) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL COMMENT '预算金额',
  `operator` int(11) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) DEFAULT NULL COMMENT '0=初始化状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='推广预算';

-- ----------------------------
-- Table structure for dspv2_t_promotion_online_time
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_promotion_online_time`;
CREATE TABLE `dspv2_t_promotion_online_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) DEFAULT NULL COMMENT '主键ID',
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `create_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` char(19) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for dspv2_t_role
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_role`;
CREATE TABLE `dspv2_t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL COMMENT '描述',
  `sys` varchar(10) DEFAULT NULL COMMENT '系统',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色表';

-- ----------------------------
-- Records of dspv2_t_role
-- ----------------------------
INSERT INTO `dspv2_t_role` VALUES ('1', 'admin', '管理员', 'PMS');
INSERT INTO `dspv2_t_role` VALUES ('2', 'opt', '运营人员', 'PMS');
INSERT INTO `dspv2_t_role` VALUES ('3', 'advertiser', '广告主', 'DSP');
INSERT INTO `dspv2_t_role` VALUES ('4', 'ad_optimizer', '广告优化师', 'PMS');
INSERT INTO `dspv2_t_role` VALUES ('5', 'financial_staff', '财务人员', 'PMS');

-- ----------------------------
-- Table structure for dspv2_t_role_ad_space_ratio_rel
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_role_ad_space_ratio_rel`;
CREATE TABLE `dspv2_t_role_ad_space_ratio_rel` (
  `role_id` int(11) DEFAULT NULL,
  `ad_space_ratio_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色广告位比例关联表';

-- ----------------------------
-- Records of dspv2_t_role_ad_space_ratio_rel
-- ----------------------------

-- ----------------------------
-- Table structure for dspv2_t_role_permission_group_rel
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_role_permission_group_rel`;
CREATE TABLE `dspv2_t_role_permission_group_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `permission_group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色与权限组关联表';

-- ----------------------------
-- Records of dspv2_t_role_permission_group_rel
-- ----------------------------
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('1', '1', '1');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('2', '2', '2');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('3', '2', '3');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('4', '2', '4');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('5', '2', '5');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('6', '4', '4');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('7', '4', '7');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('8', '4', '8');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('9', '5', '4');
INSERT INTO `dspv2_t_role_permission_group_rel` VALUES ('10', '5', '6');

-- ----------------------------
-- Table structure for dspv2_t_user_role_rel
-- ----------------------------
DROP TABLE IF EXISTS `dspv2_t_user_role_rel`;
CREATE TABLE `dspv2_t_user_role_rel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色关联表';
