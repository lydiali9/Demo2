#!/bin/bash
cd `dirname $0`
BIN_DIR=`pwd`
cd ..
DEPLOY_DIR=`pwd`
LIB_DIR=${DEPLOY_DIR}/lib
CONF_DIR=${DEPLOY_DIR}/conf
LOG_DIR=${DEPLOY_DIR}/logs

ENV=`ls ${CONF_DIR}/application-* | awk -F '\\\\-' '{print $NF}' | cut -d '.' -f1`

if [ ! -d ${LOG_DIR} ]; then
    mkdir ${LOG_DIR}
fi

SERVER_PORT=`sed '/^port/!d;s/.*=//' conf/application-${ENV}.yml | tr -d '\r'`
SERVER_IP=`sed '/^address/!d;s/.*=//' conf/application-${ENV}.yml | tr -d '\r'`
SERVER_NAME="dsp"

#1、mem参数
PARAM_MEM=" -server "
PARAM_MEM=${PARAM_MEM}" -Xmx2g "
PARAM_MEM=${PARAM_MEM}" -Xms2g "
PARAM_MEM=${PARAM_MEM}" -Xmn1g "
PARAM_MEM=${PARAM_MEM}" -Xss256k "
PARAM_MEM=${PARAM_MEM}" -XX:+DisableExplicitGC "
PARAM_MEM=${PARAM_MEM}" -XX:+UseConcMarkSweepGC "
PARAM_MEM=${PARAM_MEM}" -XX:+CMSParallelRemarkEnabled "
PARAM_MEM=${PARAM_MEM}" -XX:+UseCMSCompactAtFullCollection "
PARAM_MEM=${PARAM_MEM}" -XX:LargePageSizeInBytes=128m "
PARAM_MEM=${PARAM_MEM}" -XX:+UseFastAccessorMethods "
PARAM_MEM=${PARAM_MEM}" -XX:+UseCMSInitiatingOccupancyOnly "
PARAM_MEM=${PARAM_MEM}" -XX:CMSInitiatingOccupancyFraction=70 "
PARAM_MEM=${PARAM_MEM}" -XX:+PrintSafepointStatistics "
PARAM_MEM=${PARAM_MEM}" -XX:PrintSafepointStatisticsCount=1 "
PARAM_MEM=${PARAM_MEM}" -XX:-DisableExplicitGC "
#2、gc参数
PARAM_GC=" -XX:+PrintGCDetails "
PARAM_GC=${PARAM_GC}" -XX:+PrintGCTimeStamps "
PARAM_GC=${PARAM_GC}" -XX:+PrintHeapAtGC "
PARAM_GC=${PARAM_GC}" -XX:+PrintTenuringDistribution "
PARAM_GC=${PARAM_GC}" -Xloggc:${LOG_DIR}/dsp_gc.log "
PARAM_GC=${PARAM_GC}" -XX:-UseGCLogFileRotation "
PARAM_GC=${PARAM_GC}" -XX:+PrintGCApplicationConcurrentTime "
PARAM_GC=${PARAM_GC}" -XX:+PrintGCApplicationStoppedTime "
PARAM_GC=${PARAM_GC}" -XX:-UseGCLogFileRotation "
PARAM_GC=${PARAM_GC}" -XX:GCLogFileSize=10M "

#3、jmx参数
PARAM_JMX=" -Dcom.sun.management.jmxremote.port=1099 "
PARAM_JMX=${PARAM_JMX}" -Dcom.sun.management.jmxremote.rmi.port=1099 "
PARAM_JMX=${PARAM_JMX}" -Dcom.sun.management.jmxremote.ssl=false "
PARAM_JMX=${PARAM_JMX}" -Dcom.sun.management.jmxremote.authenticate=false "
PARAM_JMX=${PARAM_JMX}" -Djava.rmi.server.hostname=121.201.57.93 "

#4、服务检测
PIDS=`ps -ef|grep java|grep ${DEPLOY_DIR}|awk '{print $2}'`
if [ -n "${PIDS}" ]; then
  echo "ERROR: ${SERVER_NAME} already started!"
  echo "PID:${PIDS}"
  exit 1
fi

#5、端口检测
if [ -n "${SERVER_PORT}" ]; then
    SERVER_PORT_COUNT=`netstat -tln | grep -w ${SERVER_PORT} | wc -l`
    if [ ${SERVER_PORT_COUNT} -gt 0 ]; then
        echo "ERROR: The ${SERVER_NAME} port ${SERVER_PORT} already used!"
        exit 1
    fi
fi

JAVA_OPTS=${PARAM_MEM}${PARAM_GC}
if [ "$2" = "jmx" ]; then
    JAVA_OPTS=${JAVA_OPTS}${PARAM_JMX}
fi

LIB_JARS=`ls ${LIB_DIR}|grep .jar|awk '{print "'${LIB_DIR}'/"$0}'|tr "\n" ":"`

#echo "LIB_JARS: ${LIB_JARS}"
#echo "JAVA_OPTS: ${JAVA_OPTS}"

nohup java ${JAVA_OPTS} -classpath ${CONF_DIR}:${LIB_JARS} com.inveno.ad.dsp.ServerStarter  --spring.profiles.active=${ENV} > ${LOG_DIR}/stdout.log 2>&1 &
COUNT=0
while [ ${COUNT} -lt 1 ]; do
    echo -e ".\c"
    sleep 1
    COUNT=`ps -ef | grep java | grep "${DEPLOY_DIR}" | awk '{print $2}' | wc -l`
    if [ ${COUNT} -gt 0 ]; then
        break
    fi
done

echo "OK!"
PID=`ps -f | grep java | grep "${DEPLOY_DIR}" | awk '{print $2}'`
echo "PID: $PID"
echo "STDOUT: ${LOG_DIR}/stdout.log"
