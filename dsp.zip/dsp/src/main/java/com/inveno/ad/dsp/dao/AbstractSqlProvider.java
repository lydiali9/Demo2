package com.inveno.ad.dsp.dao;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import javax.activation.UnsupportedDataTypeException;
import java.text.MessageFormat;
import java.util.List;

/**
 * @author by sugang on 2018/4/2.
 */
abstract public class AbstractSqlProvider {

    public static final String PARAM_BATCH_LIST = "list";

    protected void appendORCondition(SQL sql, List<?> conditionList, String col) throws UnsupportedDataTypeException {
        for (int i = 0; i < conditionList.size(); i++) {
            Object condition = conditionList.get(i);
            if (condition instanceof String) {
                if (StringUtils.isNotBlank((String) condition)) {
                    if (i > 0) {
                        sql.OR();
                    }
                    sql.WHERE(String.format("`%s`=#{list[%d]}", col, i));
                }
            } else if (condition instanceof Integer
                    || condition instanceof Long
                    || condition instanceof Character
                    || condition instanceof Double
                    || condition instanceof Boolean) {
                if (i > 0) {
                    sql.OR();
                }
                sql.WHERE(String.format("`%s`=#{list[%d]}", col, i));
            } else {
                throw new UnsupportedDataTypeException();
            }
        }
    }

    protected void append(StringBuilder sql, MessageFormat mf, List<?> list, String separator) {
        for (int i = 0; i < list.size(); i++) {
            sql.append("(");
            sql.append(mf.format(new Object[]{i}));
            sql.append(")");
            if (i < list.size() - 1) {
                sql.append(separator);
            }
        }
    }

}
