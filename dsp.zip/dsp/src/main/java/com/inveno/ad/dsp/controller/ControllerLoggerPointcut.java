package com.inveno.ad.dsp.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.inveno.ad.dsp.vo.BaseVo;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
@Aspect
@Component
public class ControllerLoggerPointcut {

    private static ThreadLocal<Long> timeTreadLocal = new ThreadLocal<>();
    private static ConcurrentMap<Class<?>, Logger> loggerMap = new ConcurrentHashMap<>();
    private static ConcurrentMap<Method, String> uriMap = new ConcurrentHashMap<>();

    @Pointcut("execution(public * com.inveno.ad.dsp.controller..*(..))")
    private void log() {
    }

    @Before("log()")
    public void logBeforeController(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Logger logger = getLogger(signature.getDeclaringType());
        timeTreadLocal.set(System.currentTimeMillis());
        if (ArrayUtils.isNotEmpty(joinPoint.getArgs())) {
            JSONArray jsonArray = new JSONArray();
            for (Object obj : joinPoint.getArgs()) {
                if (obj instanceof BaseVo || obj.getClass().getPackage().getName().equals("java.util")) {
                    jsonArray.add(obj);
                }
            }
            logger.info("uri:{}, request:{}", getMethodAndUri(joinPoint), JSON.toJSONString(jsonArray));
        } else {
            logger.info("uri:{}, request:null");
        }
    }

    @AfterReturning(pointcut = "log()", returning = "retValue")
    public void logAfterController(JoinPoint joinPoint, Object retValue) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Logger logger = getLogger(signature.getDeclaringType());
        logger.info("uri:{}, cost: {}ms, response:{}",
                getMethodAndUri(joinPoint),
                System.currentTimeMillis() - timeTreadLocal.get(),
                JSON.toJSONString(retValue));
        timeTreadLocal.remove();
    }

    private String getMethodAndUri(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        String uri = uriMap.get(method);
        if (StringUtils.isBlank(uri)) {
            Map<String, List<String>> methodUriMap = new HashMap<>();
            PostMapping postMapping = method.getAnnotation(PostMapping.class);
            if (null != postMapping) {
                if (ArrayUtils.isNotEmpty(postMapping.value())) {
                    methodUriMap.put(PostMapping.class.getSimpleName(), Arrays.asList(postMapping.value()));
                }
            }
            GetMapping getMapping = method.getAnnotation(GetMapping.class);
            if (null != getMapping) {
                if (ArrayUtils.isNotEmpty(getMapping.value())) {
                    methodUriMap.put(GetMapping.class.getSimpleName(), Arrays.asList(getMapping.value()));
                }
            }
            DeleteMapping deleteMapping = method.getAnnotation(DeleteMapping.class);
            if (null != deleteMapping) {
                if (ArrayUtils.isNotEmpty(deleteMapping.value())) {
                    methodUriMap.put(DeleteMapping.class.getSimpleName(), Arrays.asList(deleteMapping.value()));
                }
            }
            PutMapping putMapping = method.getAnnotation(PutMapping.class);
            if (null != putMapping) {
                if (ArrayUtils.isNotEmpty(putMapping.value())) {
                    methodUriMap.put(PutMapping.class.getSimpleName(), Arrays.asList(putMapping.value()));
                }
            }
            uri = JSON.toJSONString(methodUriMap);
            uriMap.put(method, uri);
        }
        return uri;
    }

    private Logger getLogger(Class<?> clazz) {
        Logger logger = loggerMap.get(clazz);
        if (null == logger) {
            logger = LoggerFactory.getLogger(clazz);
            loggerMap.putIfAbsent(clazz, logger);
        }
        return logger;
    }

}
