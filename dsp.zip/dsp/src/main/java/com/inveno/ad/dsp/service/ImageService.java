package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.model.ImageModel;
import com.inveno.ad.dsp.model.PageModel;

/**
 * <p>Title: {@link ImageService}</p>
 * <p>Description: 图片service类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/18
 */
public interface ImageService {

    /**
     * 图片上传
     * @param imageModel 参数
     * @throws Exception 异常抛出
     */
    void uploadImage(ImageModel imageModel) throws Exception;

    /**
     * 图片裁剪
     * @param imageModel 详细信息
     * @return 裁剪后信息
     * @throws Exception 异常抛出
     */
    ImageModel crop(ImageModel imageModel) throws Exception;

    /**
     * 分页查询图片模板
     * @param pageModel 查询条件
     * @throws Exception 异常抛出
     */
    void pageQuery(PageModel<ImageModel> pageModel) throws Exception;

    /**
     * 创建模板
     * @param imageModel 详细信息
     * @return 图片模板ID
     * @throws Exception 异常抛出
     */
    Long create(ImageModel imageModel) throws Exception;

    /**
     * 上传并裁剪图片
     * @param imageModel 图片详情
     * @param data 图片字节数据
     * @return 裁剪后图片的详情
     * @throws Exception 异常抛出
     */
    ImageModel uploadAndCrop(ImageModel imageModel, byte[] data) throws Exception;

    /**
     * 删除图片
     * @param imageModel 图片详细信息
     * @throws Exception 异常抛出
     */
    void delete(ImageModel imageModel) throws Exception;

}
