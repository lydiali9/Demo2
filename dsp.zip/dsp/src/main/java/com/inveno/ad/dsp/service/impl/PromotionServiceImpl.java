package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.dao.*;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.*;
import com.inveno.ad.dsp.service.PromotionService;
import com.inveno.ad.dsp.util.DateUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>Title: {@link PromotionServiceImpl}</p>
 * <p>Description: 推广计划service实现类</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
@Service
public class PromotionServiceImpl implements PromotionService {

    private static Logger logger = LoggerFactory.getLogger(PromotionServiceImpl.class);

    @Autowired
    private AccountDao accountDao;
    @Autowired
    private AccountFrozenDao accountFrozenDao;
    @Autowired
    private OrientationDao orientationDao;
    @Autowired
    private PromotionDao promotionDao;
    @Autowired
    private PromotionBudgetDao promotionBudgetDao;
    @Autowired
    private PromotionOnlineTimeDao promotionOnlineTimeDao;
    @Autowired
    private AdDao adDao;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public Long create(PromotionModel promotionModel) throws Exception {
        // 1、计算并冻结账户金额
        AccountModel accountModel = accountDao.selectByUserId(promotionModel.getUserId());
        if (null == accountModel) {
            throw new DspException(RetCode.ERR_ACCOUNT_INSUFFICIENT_BALANCE);
        }
        // 目前只支持日预算。
        // 1.1) 当前新增推广总金额。
        BigDecimal budgetAmount = promotionModel.getBudgetAmount();
        List<PromotionOnlineTimeModel> promotionOnlineTimeList = promotionModel.getPromotionOnlineTimeList();
        Date startTime = null;
        Date endTime = null;
        if (CollectionUtils.isNotEmpty(promotionOnlineTimeList)) {
            startTime = promotionOnlineTimeList.stream().min(Comparator.comparing(PromotionOnlineTimeModel::getStartTime)).get().getStartTime();
            endTime = promotionOnlineTimeList.stream()
                    .map(e -> Date.from(e.getEndTime().toInstant()))
                    .min(Comparator.reverseOrder())
                    .get();
        }
        long dayInterval = Period.between(startTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), endTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()).getDays() + 1;
        BigDecimal totalBudgetAmount = BigDecimal.valueOf(dayInterval).multiply(budgetAmount);
        // 1.2) 账户冻结总金额
        AccountFrozenModel param = new AccountFrozenModel();
        param.setUserId(promotionModel.getUserId());
        param.setStatus(AccountFrozenStatusEnum.FROZEN.getValue());
        List<AccountFrozenModel> existAccountFrozenList = accountFrozenDao.selectFrozenRecordByUserId(param);
        BigDecimal frozenAmount = BigDecimal.ZERO;
        if (CollectionUtils.isNotEmpty(existAccountFrozenList)) {
            frozenAmount = existAccountFrozenList.stream()
                    .filter(e -> e.getStatus().equals(AccountFrozenStatusEnum.FROZEN.getValue()))
                    .map(AccountFrozenModel::getFrozenAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
        }
        // 1.3) 校验是否余额不足
        if (accountModel.getBalance().compareTo(totalBudgetAmount.add(frozenAmount)) < 0) {
            throw new DspException(RetCode.ERR_PROMOTION_INSUFFICIENT_BALANCE);
        }

        // 2、插入定向包记录。
        Date date = new Date();
        promotionModel.getOrientation().setStatus(0);
        promotionModel.getOrientation().setCreateTime(date);
        promotionModel.getOrientation().setUserId(promotionModel.getUserId());
        promotionModel.getOrientation().setOperator(promotionModel.getOperator());
        orientationDao.insert(promotionModel.getOrientation());
        Integer orientationId = promotionModel.getOrientation().getId();
        logger.debug("orientation_id={}", orientationId);
        // 3、插入推广表
        promotionModel.setCreateTime(date);
        promotionModel.setOrientationId(orientationId);
        promotionModel.setStatus(PromotionStatusEnum.ONLINE.getValue());
        promotionModel.setDeliverStartTime(startTime);
        promotionModel.setDeliverEndTime(endTime);
        promotionDao.insert(promotionModel);
        logger.debug("promotion_id={}", promotionModel.getId());
        // 4、冻结金额，因为按天级结算，因此，冻结金额每天插入一条记录。
        List<AccountFrozenModel> accountFrozenModelList = new ArrayList<>(promotionOnlineTimeList.size());
        Set<Date> frozenDateSet = new HashSet<>();
        for (PromotionOnlineTimeModel promotionOnlineTimeModel : promotionOnlineTimeList) {
            Date frozenDate = DateUtils.parseDate(DateFormatUtils.format(promotionOnlineTimeModel.getStartTime(), DateUtils.FMT_yyyyMMdd), DateUtils.FMT_yyyyMMdd);
            if (!frozenDateSet.contains(frozenDate)) {
                frozenDateSet.add(frozenDate);
                AccountFrozenModel accountFrozenModel = new AccountFrozenModel();
                accountFrozenModel.setPromotionId(promotionModel.getId());
                accountFrozenModel.setCreateTime(date);
                accountFrozenModel.setFrozenAmount(budgetAmount);
                accountFrozenModel.setFrozenDate(frozenDate);
                accountFrozenModel.setStatus(0);
                accountFrozenModel.setUserId(promotionModel.getUserId());
                accountFrozenModelList.add(accountFrozenModel);
            }
        }
        accountFrozenDao.batchInsert(accountFrozenModelList);

        // 5、插入推广预算表记录，方便线上系统对预算放量的监控。
        PromotionBudgetModel promotionBudgetModel = new PromotionBudgetModel();
        promotionBudgetModel.setCreateTime(date);
        promotionBudgetModel.setAmount(promotionModel.getBudgetAmount());
        promotionBudgetModel.setOperator(promotionModel.getOperator());
        promotionBudgetModel.setPromotionId(promotionModel.getId());
        promotionBudgetModel.setStatus(PromotionBudgetStatusEnum.VALID.getValue());
        promotionBudgetDao.insert(promotionBudgetModel);
        logger.debug("promotion_budget_id={}", promotionBudgetModel.getId());
        // 6、插入投放时间表记录。
        for (PromotionOnlineTimeModel promotionOnlineTimeModel : promotionOnlineTimeList) {
            promotionOnlineTimeModel.setEndTime(Date.from(promotionOnlineTimeModel.getEndTime().toInstant()));
            promotionOnlineTimeModel.setPromotionId(promotionModel.getId());
            promotionOnlineTimeModel.setCreateTime(date);
            promotionOnlineTimeModel.setStatus(0);
        }
        promotionOnlineTimeDao.batchInsert(promotionOnlineTimeList);
        // 7、确认数据金额未被修改
        AccountModel updAccountParamModel = new AccountModel();
        updAccountParamModel.setUserId(promotionModel.getUserId());
        updAccountParamModel.setVersion(accountModel.getVersion());
        int i = accountDao.incrVersionByUserId(updAccountParamModel);
        if (i != 1) {
            throw new DspException(RetCode.ERR_PROMOTION_INFORMATION_CHANGED);
        }
        return promotionModel.getId();
    }

    @Override
    public boolean delete(Integer id) throws Exception {
        return false;
    }

    /**
     * 涉及金额、时间多种情况处理：
     * 1、金额变大，时间天数未变
     *    a) 判断余额。
     *    b) 更新账户冻结表。
     *    c) 更新推广预算表。
     *    d) 更新推广上线时间表。
     * 2、金额变小，时间天数未变
     *    a) 当日金额取最大值，因此不变更，当日之后的冻结记录全部更新至最小值。
     *    b) 更新推广预算表。
     *    c) 更新上线时间表。
     * 3、时间增加，金额未变
     *    a) 判断余额。
     *    b) 新增冻结表记录。
     *    c) 更新推广预算表记录。
     *    d) 更新推广上线时间表。
     * 4、时间减少，金额未变
     *    a) 删除冻结表记录。
     *    d) 更新推广上线时间表。
     * 5、金额变大，时间增加
     *    a) 判断余额。
     *    b) 更新账户冻结表。
     *    c) 更新推广预算表。
     *    d) 更新推广上线时间表。
     * 6、金额变大，时间减少
     *    a) 判断余额。
     *    b) 更新账户冻结表。
     *    c) 更新推广预算表。
     *    d) 更新推广上线时间表。
     * 7、金额变小，时间增加
     *    a) 判断余额。
     *    b) 更新账户冻结表。
     *    c) 更新推广预算表。
     *    d) 更新推广上线时间表。
     * 8、金额变小，时间减少
     *    a) 更新账户冻结表。
     *    b) 更新推广预算表。
     *    c) 更新推广上线时间表。
     * @param updatePromotionModel 新的推广计划内容
     * @return 是否更新成功
     * @throws Exception 异常抛出
     */
    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public boolean update(PromotionModel updatePromotionModel) throws Exception {
        PromotionModel promotionInDb = promotionDao.selectById(updatePromotionModel.getId());
        if (!promotionInDb.getLinkUrl().equals(updatePromotionModel.getLinkUrl())
                || (null != promotionInDb.getAppId() && !promotionInDb.getAppId().equals(updatePromotionModel.getAppId()))) {
            throw new DspException(RetCode.ERR_PROMOTION_LINK_URL_APP_CANNOT_EDIT);
        }
        AccountFrozenModel param = new AccountFrozenModel();
        param.setUserId(updatePromotionModel.getUserId());
        param.setStatus(AccountFrozenStatusEnum.FROZEN.getValue());
        // 用户所有的有效的冻结流水
        List<AccountFrozenModel> userAccountFrozenList = accountFrozenDao.selectFrozenRecordByUserId(param);
        // 用户所更新的推广的冻结流水
        List<AccountFrozenModel> userCurrPromotionAccountFrozenList = userAccountFrozenList.stream()
                .filter(e -> e.getPromotionId().equals(updatePromotionModel.getId()))
                .collect(Collectors.toList());
        LocalDate today = LocalDate.now();
        // 大于等于今天的待更新日期集合
        List<LocalDate> updatePromotionOnlineDateGetTodayList = updatePromotionModel.getPromotionOnlineTimeList().stream()
                .map(e -> e.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())
                .filter(e -> !today.isAfter(e))
                .collect(Collectors.toList());
        // 大于等于今天的已有冻结流水日期集合
        List<LocalDate> accountFrozenDateGteTodayList = userAccountFrozenList.stream()
                .filter(e -> e.getPromotionId().equals(updatePromotionModel.getId()))
                .map(e -> e.getFrozenDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())
                .filter(e -> !today.isAfter(e))
                .collect(Collectors.toList());
        List<PromotionOnlineTimeModel> updatePromotionOnlineTimeList = updatePromotionModel.getPromotionOnlineTimeList();
        //1、校验金额
        AccountModel accountModel = accountDao.selectByUserId(updatePromotionModel.getUserId());
        // 1.1) 非当前推广冻结金额总和。
        BigDecimal notCurrentPromotionTotalFrozenAmount = userAccountFrozenList.stream()
                .filter(e -> !e.getPromotionId().equals(updatePromotionModel.getId()))
                .map(AccountFrozenModel::getFrozenAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        // 1.2) 当前推广，今天之前的冻结金额总和。
        BigDecimal currentPromotionTotalFrozenAmountBfToday = BigDecimal.valueOf(userAccountFrozenList.stream()
                .filter(e -> !today.isBefore(e.getFrozenDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
                .filter(e -> e.getPromotionId().equals(updatePromotionModel.getId()))
                .map(AccountFrozenModel::getFrozenAmount)
                .mapToDouble(BigDecimal::doubleValue)
                .sum());
        // 1.3) 当前推广当天的金额取修改前后最大的值。
        BigDecimal currentPromotionFrozenAmountToday = BigDecimal.ZERO;
        if (accountFrozenDateGteTodayList.contains(today) || updatePromotionOnlineDateGetTodayList.contains(today)) {
            currentPromotionFrozenAmountToday = promotionInDb.getBudgetAmount().max(updatePromotionModel.getBudgetAmount());
        }
        // 1.4) 当前推广大于今天的修改金额总和
        BigDecimal currentPromotionFrozenAmountAfToday = BigDecimal.valueOf(updatePromotionOnlineTimeList.stream()
                .filter(e -> today.isBefore(e.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
                .count()).multiply(updatePromotionModel.getBudgetAmount());
        if (accountModel.getBalance().compareTo(notCurrentPromotionTotalFrozenAmount
                .add(currentPromotionTotalFrozenAmountBfToday)
                .add(currentPromotionFrozenAmountToday)
                .add(currentPromotionFrozenAmountAfToday)) < 0) {
            throw new DspException(RetCode.ERR_PROMOTION_INSUFFICIENT_BALANCE);
        }

        // 2、如果修改后金额不等于之前的金额，或者时间区间有更改，冻结表记录更新。
        Date date = new Date();
        boolean isAmountUpdated = updatePromotionModel.getBudgetAmount().compareTo(promotionInDb.getBudgetAmount()) != 0;
        logger.debug("amount changed: {}", isAmountUpdated);
        boolean isOnlineDateUpdated = !(updatePromotionOnlineDateGetTodayList.containsAll(accountFrozenDateGteTodayList)
                && accountFrozenDateGteTodayList.containsAll(updatePromotionOnlineDateGetTodayList))
                || (!updatePromotionOnlineDateGetTodayList.isEmpty() && accountFrozenDateGteTodayList.isEmpty());
        logger.debug("online time changed: {}", isOnlineDateUpdated);
        if (isAmountUpdated || isOnlineDateUpdated) {
            List<Integer> needReinsertRecordIdList = new ArrayList<>();
            // 更新后的日期集合。
            List<LocalDate> updatedOnlineDate = updatePromotionOnlineTimeList.stream()
                    .map(e -> e.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())
                    .distinct()
                    .collect(Collectors.toList());
            for (AccountFrozenModel accountFrozenModel : userCurrPromotionAccountFrozenList) {
                LocalDate frozenDate = accountFrozenModel.getFrozenDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                if (!frozenDate.isBefore(today)) {
                    if (!updatedOnlineDate.contains(frozenDate)) {
                        // 1、不包含在修改后时间区间中的记录需要删除。
                        needReinsertRecordIdList.add(accountFrozenModel.getId());
                    } else if (today.isBefore(frozenDate)
                            && accountFrozenModel.getFrozenAmount().compareTo(updatePromotionModel.getBudgetAmount()) != 0) {
                        // 2、包含在修改后时间区间中的记录，如果日期大于等于今天，金额不等于修改后的值，需要重新插入冻结记录。
                        needReinsertRecordIdList.add(accountFrozenModel.getId());
                    } else if (today.isEqual(frozenDate)
                            && accountFrozenModel.getFrozenAmount().compareTo(updatePromotionModel.getBudgetAmount()) < 0) {
                        // 3、包含在修改后时间区间中的记录，如果日期等于今天，变更后的金额大于之前的金额，则当日的冻结流水记录需要重新插入。
                        needReinsertRecordIdList.add(accountFrozenModel.getId());
                    }
                }
            }
            logger.debug("need reinsert record: {}", needReinsertRecordIdList);
            if (CollectionUtils.isNotEmpty(needReinsertRecordIdList)) {
                // 更改需要重新插入的有效记录状态
                Map<String, Object> params = new HashMap<>(2);
                params.put(AccountFrozenDao.PARAM_UPDATE_TIME, date);
                params.put(AccountFrozenDao.PARAM_STATUS, AccountFrozenStatusEnum.DELETE.getValue());
                params.put(AbstractSqlProvider.PARAM_BATCH_LIST, needReinsertRecordIdList);
                accountFrozenDao.batchUpdateStatus(params);
            }
            // 仍然保留的冻结流水记录日期集合
            List<LocalDate> effectiveAccountFrozenDateList = userCurrPromotionAccountFrozenList.stream()
                    .filter(e -> !needReinsertRecordIdList.contains(e.getId()))
                    .map(e -> e.getFrozenDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())
                    .collect(Collectors.toList());
            logger.debug("effective frozen date record: {}", effectiveAccountFrozenDateList);

            // 新增的冻结流水记录
            List<AccountFrozenModel> newAccountFrozenModelList = new ArrayList<>();
            // 防止当天有多个时间段，用于去掉重复判断
            Set<LocalDate> frozenDateSet = new HashSet<>();
            for (PromotionOnlineTimeModel promotionOnlineTimeModel : updatePromotionOnlineTimeList) {
                LocalDate frozenDate = promotionOnlineTimeModel.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                if (!effectiveAccountFrozenDateList.contains(frozenDate) && !frozenDateSet.contains(frozenDate)) {
                    frozenDateSet.add(frozenDate);
                    AccountFrozenModel accountFrozenModel = new AccountFrozenModel();
                    accountFrozenModel.setPromotionId(updatePromotionModel.getId());
                    accountFrozenModel.setCreateTime(date);
                    accountFrozenModel.setFrozenAmount(updatePromotionModel.getBudgetAmount());
                    accountFrozenModel.setFrozenDate(DateUtils.parseDate(DateFormatUtils.format(promotionOnlineTimeModel.getStartTime(), DateUtils.FMT_yyyyMMdd), DateUtils.FMT_yyyyMMdd));
                    accountFrozenModel.setStatus(AccountFrozenStatusEnum.FROZEN.getValue());
                    accountFrozenModel.setUserId(updatePromotionModel.getUserId());
                    newAccountFrozenModelList.add(accountFrozenModel);
                }
            }
            if (!newAccountFrozenModelList.isEmpty()) {
                accountFrozenDao.batchInsert(newAccountFrozenModelList);
            }
        }
        // 3、更新推广表。
        // 3.1) 不允许修改落地页或者app类型。
        Date startTime = updatePromotionOnlineTimeList.stream().min(Comparator.comparing(PromotionOnlineTimeModel::getStartTime)).get().getStartTime();
        Date endTime = updatePromotionOnlineTimeList.stream()
                .map(e -> Date.from(e.getEndTime().toInstant()))
                .min(Comparator.reverseOrder())
                .get();
        updatePromotionModel.setCreateTime(null);
        updatePromotionModel.setUpdateTime(date);
        updatePromotionModel.setDeliverStartTime(startTime);
        updatePromotionModel.setDeliverEndTime(endTime);
        promotionDao.updateByIdWithoutNull(updatePromotionModel);
        // 4、推广预算表插入最新修改的金额值，变更之前的记录状态。
        if (promotionInDb.getBudgetAmount().compareTo(updatePromotionModel.getBudgetAmount()) != 0) {
            List<PromotionBudgetModel> promotionBudgetModelList = promotionBudgetDao.selectByPromotionId(updatePromotionModel.getId());
            Integer id = promotionBudgetModelList.stream().filter(e -> PromotionBudgetStatusEnum.VALID.getValue() == e.getStatus()).map(PromotionBudgetModel::getId).findFirst().get();
            PromotionBudgetModel updateExistPromotionBudgetModel = new PromotionBudgetModel();
            updateExistPromotionBudgetModel.setId(id);
            updateExistPromotionBudgetModel.setStatus(PromotionBudgetStatusEnum.INVALID.getValue());
            updateExistPromotionBudgetModel.setUpdateTime(date);
            updateExistPromotionBudgetModel.setOperator(updatePromotionModel.getOperator());
            promotionBudgetDao.updateStatusById(updateExistPromotionBudgetModel);
            PromotionBudgetModel promotionBudgetModel = new PromotionBudgetModel();
            promotionBudgetModel.setCreateTime(date);
            promotionBudgetModel.setAmount(updatePromotionModel.getBudgetAmount());
            promotionBudgetModel.setOperator(updatePromotionModel.getOperator());
            promotionBudgetModel.setPromotionId(updatePromotionModel.getId());
            promotionBudgetModel.setStatus(PromotionBudgetStatusEnum.VALID.getValue());
            promotionBudgetDao.insert(promotionBudgetModel);
        }
        // 5、推广时间今天之后的全部删除，插入新的时间记录。
        List<PromotionOnlineTimeModel> promotionOnlineTimeModelList = promotionOnlineTimeDao.selectByPromotionId(updatePromotionModel.getId());
        // 5.1) 找出大于等于今天的日期记录并删除
        List<Integer> promotionOnlineTimeIdList = promotionOnlineTimeModelList.stream()
                .filter(e -> !today.isAfter(e.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
                .map(PromotionOnlineTimeModel::getId)
                .collect(Collectors.toList());
        int count = promotionOnlineTimeDao.batchDelete(promotionOnlineTimeIdList);
        logger.debug("delete {} rows dspv2_t_promotion_online_time.", count);
        // 5.2) 插入大于等于今天的日期记录
        List<PromotionOnlineTimeModel> gteTodayUpdatePromotionOnlineTimeList = updatePromotionOnlineTimeList.stream()
                .filter(e -> !today.isAfter(e.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
                .peek(e -> {
                    e.setPromotionId(updatePromotionModel.getId());
                    e.setCreateTime(date);
                    e.setStatus(0);
                    e.setEndTime(Date.from(e.getEndTime().toInstant()));
                })
                .collect(Collectors.toList());
        promotionOnlineTimeDao.batchInsert(gteTodayUpdatePromotionOnlineTimeList);
        // 6、修改关联定向包记录
        updatePromotionModel.getOrientation().setUpdateTime(date);
        updatePromotionModel.getOrientation().setStatus(0);
        updatePromotionModel.getOrientation().setOperator(updatePromotionModel.getOperator());
        updatePromotionModel.getOrientation().setId(promotionInDb.getOrientationId());
        orientationDao.updateById(updatePromotionModel.getOrientation());
        // 7、更新账户版本，确认金额在执行本次修改期间未被其它操作修改。
        AccountModel updAccountParamModel = new AccountModel();
        updAccountParamModel.setUserId(updatePromotionModel.getUserId());
        updAccountParamModel.setVersion(accountModel.getVersion());
        count = accountDao.incrVersionByUserId(updAccountParamModel);
        if (count != 1) {
            throw new DspException(RetCode.ERR_PROMOTION_INFORMATION_CHANGED);
        }
        return true;
    }

    @Override
    public PageModel<PromotionModel> pageQuery(PageModel<PromotionModel> pageRequest) throws Exception {
        int totalCount = promotionDao.pageQueryTotalCount(pageRequest);
        pageRequest.setTotalCount(totalCount);
        if (totalCount > 0) {
            List<PromotionModel> promotionModelList = promotionDao.pageQuery(pageRequest);
            pageRequest.setResponse(promotionModelList);
        }
        return pageRequest;
    }

    @Override
    public List<PromotionModel> list(PromotionModel promotionModel) {
        List<PromotionModel> promotionModelList;
        if (promotionModel.getCategory() == 2) {
            // 查询所有的推广
            promotionModelList = promotionDao.selectAllPromotionByUserId(promotionModel.getUserId());
        } else if (promotionModel.getCategory() == 1) {
            // 查询有效的推广
            promotionModel.setStatus(PromotionStatusEnum.DISCARD.getValue());
            promotionModel.setDeliverEndTime(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()));
            promotionModelList = promotionDao.selectAvailablePromotionByUserId(promotionModel);
        } else if (promotionModel.getCategory() == 3) {
            // 查询非废弃推广
            promotionModel.setStatus(PromotionStatusEnum.DISCARD.getValue());
            promotionModel.setDeliverEndTime(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()));
            promotionModelList = promotionDao.selectNotDiscardPromotionByUserId(promotionModel);
        } else {
            throw new DspException(RetCode.ERR_PARAM, "category", promotionModel.getCategory());
        }
        return promotionModelList;
    }

    @Override
    public PromotionModel getById(Long id) {
        PromotionModel promotionModel = promotionDao.selectById(id);
        OrientationModel orientationModel = orientationDao.selectById(promotionModel.getOrientationId());
        promotionModel.setOrientation(orientationModel);
        List<PromotionOnlineTimeModel> promotionOnlineTimeModelList = promotionOnlineTimeDao.selectByPromotionId(id);
        promotionModel.setPromotionOnlineTimeList(promotionOnlineTimeModelList);
        return promotionModel;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void switchPromotionStatus(PromotionModel promotionModel) {
        PromotionModel promotionModelInDb = promotionDao.selectById(promotionModel.getId());
        if (promotionModel.getStatus().equals(promotionModelInDb.getStatus())) {
            throw new DspException(RetCode.ERR_PROMOTION_STATUS);
        }

        Date date = new Date();
        PromotionModel updatePromotionModel = new PromotionModel();
        updatePromotionModel.setId(promotionModel.getId());
        updatePromotionModel.setOperator(promotionModel.getOperator());
        updatePromotionModel.setUpdateTime(date);

        AdModel adUpdateModel = new AdModel();
        adUpdateModel.setPromotionId(promotionModel.getId());
        adUpdateModel.setOperator(promotionModel.getOperator());
        adUpdateModel.setUpdateTime(date);

        if (PromotionStatusEnum.OFFLINE.getValue() == promotionModel.getStatus()) {
            if (PromotionStatusEnum.ONLINE.getValue() != promotionModelInDb.getStatus()) {
                throw new DspException(RetCode.ERR_PROMOTION_STATUS);
            }
            updatePromotionModel.setStatus(PromotionStatusEnum.OFFLINE.getValue());
            adUpdateModel.setStatus(AdStatusEnum.OFFLINE.getValue());
            adDao.switchToOfflineByPromotionId(adUpdateModel);
            // 推广下线需要把当日之后全部未跑量的冻结记录删除，退款给用户。
        } else if (PromotionStatusEnum.ONLINE.getValue() == promotionModel.getStatus()) {
            if (PromotionStatusEnum.OFFLINE.getValue() != promotionModelInDb.getStatus()) {
                throw new DspException(RetCode.ERR_PROMOTION_STATUS);
            }
            updatePromotionModel.setStatus(PromotionStatusEnum.ONLINE.getValue());
            adUpdateModel.setStatus(AdStatusEnum.ONLINE.getValue());
            adDao.switchToOnlineByPromotionId(adUpdateModel);
            // 推广上线需要把当日之后未跑量的冻结记录添加，计算冻结金额是否足够。
        } else if (PromotionStatusEnum.DISCARD.getValue() == promotionModel.getStatus()) {
            List<AdModel> adModelList = adDao.selectByPromotionId(promotionModel.getId());
            if (CollectionUtils.isNotEmpty(adModelList)) {
                throw new DspException(RetCode.ERR_PROMOTION_DISCARD_FAIL, "Promotion related ad.");
            }
            updatePromotionModel.setStatus(PromotionStatusEnum.DISCARD.getValue());
            // 删除所有的冻结流水
            AccountFrozenModel accountFrozenModel = new AccountFrozenModel();
            accountFrozenModel.setPromotionId(promotionModel.getId());
            accountFrozenModel.setUpdateTime(date);
            accountFrozenModel.setStatus(AccountFrozenStatusEnum.DELETE.getValue());
            accountFrozenDao.updateByPromotionIdWithoutNull(accountFrozenModel);
            // 删除预算表
            PromotionBudgetModel promotionBudgetModel = new PromotionBudgetModel();
            promotionBudgetModel.setOperator(promotionModel.getOperator());
            promotionBudgetModel.setStatus(PromotionBudgetStatusEnum.INVALID.getValue());
            promotionBudgetModel.setUpdateTime(date);
            promotionBudgetModel.setPromotionId(promotionModel.getId());
            promotionBudgetDao.updateStatusByPromotionId(promotionBudgetModel);
        } else {
            throw new DspException(RetCode.ERR_PROMOTION_STATUS);
        }
        promotionDao.updateByIdWithoutNull(updatePromotionModel);
        // 切换该推广下所有广告为指定状态。
    }

}
