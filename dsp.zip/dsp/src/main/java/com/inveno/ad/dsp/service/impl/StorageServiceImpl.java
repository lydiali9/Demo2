package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.conf.AppConfigProperties;
import com.inveno.ad.dsp.exception.StorageException;
import com.inveno.ad.dsp.service.StorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.stream.Stream;

/**
 * <p>Title: {@link StorageServiceImpl}</p>
 * <p>Description: 存储服务实现类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/7
 */
@Service
public class StorageServiceImpl implements StorageService {

    private static Logger logger = LoggerFactory.getLogger(StorageServiceImpl.class);

    private final Path rootLocation;

    @Autowired
    public StorageServiceImpl(AppConfigProperties appConfigProperties) {
        this.rootLocation = Paths.get(appConfigProperties.getFileRootLocation());
        try {
            Files.createDirectories(rootLocation);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new StorageException("Could not initialize storage", e);
        }
    }

    @Override
    public void store(MultipartFile file, String folder, CopyOption... copyOptions) {
        try {
            if (file.isEmpty()) {
                throw new StorageException("Failed to store empty file " + file.getOriginalFilename());
            }
            Path folderLocation = rootLocation.resolve(folder);
            Files.createDirectories(folderLocation);
            Files.copy(file.getInputStream(), folderLocation.resolve(file.getOriginalFilename()), copyOptions);
        } catch (FileAlreadyExistsException e) {
            throw new StorageException("File already exists", e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new StorageException("Failed to store file " + file.getOriginalFilename() + ". reason:" + e.getMessage(), e);
        }
    }

    @Override
    public void createDirectories(String dirs) {
        try {
            Path folderLocation = rootLocation.resolve(dirs);
            Files.createDirectories(folderLocation);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new StorageException("Failed create dirs " + dirs + ". reason:" + e.getMessage(), e);
        }
    }

    @Override
    public void store(InputStream inputStream, String relativePath, CopyOption... copyOptions) {
        try {
            Files.copy(inputStream, rootLocation.resolve(relativePath), copyOptions);
        } catch (FileAlreadyExistsException e) {
            throw new StorageException("File already exists", e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new StorageException("Failed to store file " + relativePath + ". reason:" + e.getMessage(), e);
        }
    }

    @Override
    public void store(InputStream inputStream, String folder, String name, CopyOption... copyOptions) {
        try {
            createDirectories(folder);
            String relativePath = String.format("%s/%s", folder, name);
            Files.copy(inputStream, rootLocation.resolve(relativePath), copyOptions);
        } catch (FileAlreadyExistsException e) {
            throw new StorageException("File already exists", e);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new StorageException("Failed to store file " + name + ". reason:" + e.getMessage(), e);
        }
    }

    @Override
    public Stream<Path> loadAll() {
        try {
            return Files.walk(this.rootLocation, 3)
                    .filter(path -> !path.equals(this.rootLocation))
                    .filter(path -> !path.toFile().isDirectory())
                    .map(this.rootLocation::relativize);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw new StorageException("Failed to read stored files", e);
        }
    }

    @Override
    public Path load(String filename) {
        return rootLocation.resolve(filename);
    }

    @Override
    public Resource loadAsResource(String filename) {
        try {
            Path file = load(filename);
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new StorageException("Could not read file: " + filename);
            }
        } catch (MalformedURLException e) {
            throw new StorageException("Could not read file: " + filename, e);
        }
    }

    @Override
    public void deleteAll() {
        FileSystemUtils.deleteRecursively(rootLocation.toFile());
    }

    @Override
    public void delete(String file) throws IOException {
        Path filePath = load(file);
        FileSystemUtils.deleteRecursively(filePath);
    }


    @Override
    public boolean exist(String path) throws MalformedURLException {
        Path file = load(path);
        Resource resource = new UrlResource(file.toUri());
        return resource.exists();
    }

    @Override
    public Path move(String srcFiePath, String targetFilePath) throws Exception {
        Path srcFile = rootLocation.resolve(srcFiePath);
        Path targetFile = rootLocation.resolve(targetFilePath);
        return Files.move(srcFile, targetFile);
    }

}
