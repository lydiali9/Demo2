package com.inveno.ad.dsp.model;

import java.util.Date;

public class UserModel extends BaseModel{

    private Integer userId;
    //用户名
    private String username;
    //用户密码
    private String password;
    private String email;
    private Integer parentId;
    //用户真实姓名
    private String realname;
    //职位
    private String position;
    //电话
    private String telephone;
    //用户IP地址
    private String userIp;
    //上次登陆IP地址
    private String lastIp;
    //用户是否在线
    private String online;
    //用户状态,启用还是禁用
    private String state;
    //最后一次修改时间
    private Date lastUpdTime;
    //备注
    private String memo;
    //类别创建时间
    private Date createTime;
    //当前登录用户所能查看的后台id集(xjr)
    private String userSys;
    //用户类型
    private Integer type;
    //第三方账号信息id
    private Integer firmId;
    //子账户的权限是否可以传播
    private String isPropagate;
    //帐户的登录权限，默认1为可以登录，0为不可以登录
    private Integer openClose;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getUserIp() {
        return userIp;
    }

    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }

    public String getLastIp() {
        return lastIp;
    }

    public void setLastIp(String lastIp) {
        this.lastIp = lastIp;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Date getLastUpdTime() {
        return lastUpdTime;
    }

    public void setLastUpdTime(Date lastUpdTime) {
        this.lastUpdTime = lastUpdTime;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUserSys() {
        return userSys;
    }

    public void setUserSys(String userSys) {
        this.userSys = userSys;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getFirmId() {
        return firmId;
    }

    public void setFirmId(Integer firmId) {
        this.firmId = firmId;
    }

    public String getIsPropagate() {
        return isPropagate;
    }

    public void setIsPropagate(String isPropagate) {
        this.isPropagate = isPropagate;
    }

    public Integer getOpenClose() {
        return openClose;
    }

    public void setOpenClose(Integer openClose) {
        this.openClose = openClose;
    }
}
