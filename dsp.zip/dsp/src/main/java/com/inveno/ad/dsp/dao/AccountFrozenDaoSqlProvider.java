package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.model.AccountFrozenModel;
import org.apache.ibatis.jdbc.SQL;

import javax.activation.UnsupportedDataTypeException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

/**
 * <p>Title: {@link AccountFrozenDaoSqlProvider}</p>
 * <p>Description: 账户冻结金额表sql提供类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public class AccountFrozenDaoSqlProvider extends AbstractSqlProvider {

    @SuppressWarnings("unchecked")
    public String batchInsert(Map<Object, Object> map) {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO dspv2_t_account_frozen(");
        sql.append("user_id,frozen_amount,frozen_date,promotion_id,create_time,update_time,status)");
        sql.append(" VALUES ");
        String pattern = " #'{'list[{0}].userId'}', #'{'list[{0}].frozenAmount'}', #'{'list[{0}].frozenDate'}', " +
                " #'{'list[{0}].promotionId'}',#'{'list[{0}].createTime'}',#'{'list[{0}].updateTime'}'" +
                ",#'{'list[{0}].status'}'";
        MessageFormat mf = new MessageFormat(pattern);
        List<AccountFrozenModel> promotionOnlineTimeModelList = (List<AccountFrozenModel>) map.get(PARAM_BATCH_LIST);
        append(sql, mf, promotionOnlineTimeModelList, Constants.SEPARATOR_COMMA);
        return sql.toString();
    }

    @SuppressWarnings("unchecked")
    public String batchDelete(Map<Object, Object> params) throws UnsupportedDataTypeException {
        SQL sql = new SQL();
        sql.DELETE_FROM("`dspv2_t_account_frozen`");
        List<Integer> idList = (List<Integer>) params.get(PARAM_BATCH_LIST);
        appendORCondition(sql, idList, "id");
        return sql.toString();
    }

    @SuppressWarnings("unchecked")
    public String batchUpdateStatus(Map<Object, Object> params) throws UnsupportedDataTypeException {
        SQL sql = new SQL();
        sql.UPDATE("`dspv2_t_account_frozen`");
        sql.SET("update_time=#{updateTime}");
        sql.AND();
        sql.SET("status=#{status}");
        List<Integer> idList = (List<Integer>) params.get(PARAM_BATCH_LIST);
        appendORCondition(sql, idList, "id");
        return sql.toString();
    }

    public String updateByPromotionIdWithoutNull(AccountFrozenModel accountFrozenModel) {
        SQL sql = new SQL();
        sql.UPDATE("dspv2_t_account_frozen");
        if (null != accountFrozenModel.getFrozenAmount()) {
            sql.SET("frozen_amount=#{frozenAmount}");
        }
        if (null != accountFrozenModel.getFrozenDate()) {
            sql.SET("frozen_date=#{frozenDate}");
        }
        if (null != accountFrozenModel.getUpdateTime()) {
            sql.SET("update_time=#{updateTime}");
        }
        if (null != accountFrozenModel.getStatus()) {
            sql.SET("status=#{status}");
        }
        sql.WHERE("promotion_id=#{promotionId}");
        return sql.toString();
    }

}
