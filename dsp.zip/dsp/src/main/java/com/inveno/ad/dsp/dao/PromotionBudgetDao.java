package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.PromotionBudgetModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p>Title: {@link PromotionBudgetDao}</p>
 * <p>Description: 推广预算金额dao </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
@Mapper
public interface PromotionBudgetDao {

    /**
     * 插入审核预算
     * @param promotionBudgetModel 预算详情
     * @return 新纪录ID
     */
    @Insert(
            "INSERT INTO dspv2_t_promotion_budget(" +
                    "id, promotion_id, amount, operator, create_time, update_time, status" +
                    ")" +
                    "VALUES (" +
                    "#{id},#{promotionId},#{amount},#{operator},#{createTime},#{updateTime},#{status}" +
                    ")"
    )
    @Options(useGeneratedKeys = true)
    Integer insert(PromotionBudgetModel promotionBudgetModel);

    /**
     * 根据推广ID查询
     * @param promotionId 推广ID
     * @return 符合条件的记录
     */
    @Select(
            "SELECT id, promotion_id, amount, operator, create_time, update_time, status FROM dspv2_t_promotion_budget WHERE promotion_id=#{promotionId}"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "promotionId", column = "promotion_id"),
                    @Result(property = "amount", column = "amount"),
                    @Result(property = "operator", column = "operator"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "status", column = "status")
            }
    )
    List<PromotionBudgetModel> selectByPromotionId(Long promotionId);

    /**
     * 根据推广ID修改推广预算记录
     * @param promotionBudgetModel 修改条件
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_promotion_budget t SET t.operator = #{operator}," +
                    " t.status = #{status}," +
                    " t.update_time = #{updateTime} " +
                    " WHERE t.promotion_id = #{promotionId} "
    )
    Integer updateStatusByPromotionId(PromotionBudgetModel promotionBudgetModel);

    /**
     * 根据ID修改推广预算记录
     * @param promotionBudgetModel 修改条件
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_promotion_budget t SET t.operator = #{operator}," +
                    " t.status = #{status}," +
                    " t.update_time = #{updateTime} " +
                    " WHERE t.id = #{id} "
    )
    Integer updateStatusById(PromotionBudgetModel promotionBudgetModel);

}
