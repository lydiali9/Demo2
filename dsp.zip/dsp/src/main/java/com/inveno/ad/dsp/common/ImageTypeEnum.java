package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link ImageTypeEnum} </p>
 * <p>Description: 图片类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/19
 */
public enum ImageTypeEnum {

    /**
     * 小图
     */
    SMALL_IMAGE(1),
    /**
     * 大图
     */
    BIG_IMAGE(2),
    /**
     * 图组
     */
    IMAGE_GROUP(3);

    private int value;

    ImageTypeEnum(int value) {
        this.value = value;
    }

    public static boolean contains(int value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue() == value);
    }

    public int getValue() {
        return value;
    }
}
