package com.inveno.ad.dsp.validate;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public interface PageValidatorGroup {
}
