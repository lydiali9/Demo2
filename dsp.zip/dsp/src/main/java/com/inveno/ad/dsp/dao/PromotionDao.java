package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.model.PromotionModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p>Title: {@link PromotionDao}</p>
 * <p>Description: 推广DAO </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
@Mapper
public interface PromotionDao {

    /**
     * 根据定向包ID查询
     * @param id 推广ID
     * @return 符合条件的记录
     */
    @Select("SELECT id,app_id,orientation_id,parent_user_id,user_id," +
            " title,type,link_url,product,budget_type," +
            " budget_amount,deliver_type,deliver_start_time, deliver_end_time, deliver_time_type, buy_type,charge_mode,pay_amount_unit," +
            " operator,create_time,update_time,status " +
            " FROM dspv2_t_promotion t" +
            " WHERE t.orientation_id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "appId", column = "app_id"),
            @Result(property = "orientationId", column = "orientation_id"),
            @Result(property = "parentUserId", column = "parent_user_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "linkUrl", column = "link_url"),
            @Result(property = "product", column = "product"),
            @Result(property = "budgetType", column = "budget_type"),
            @Result(property = "budgetAmount", column = "budget_amount"),
            @Result(property = "deliverType", column = "deliver_type"),
            @Result(property = "deliverStartTime", column = "deliver_start_time"),
            @Result(property = "deliverEndTime", column = "deliver_end_time"),
            @Result(property = "deliverTimeType", column = "deliver_time_type"),
            @Result(property = "buyType", column = "buy_type"),
            @Result(property = "chargeMode", column = "charge_mode"),
            @Result(property = "payAmountUnit", column = "pay_amount_unit"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status")
    })
    PromotionModel selectByOrientationId(Integer id);

    /**
     * 根据推广ID查询
     * @param id 推广ID
     * @return 符合条件的记录
     */
    @Select("SELECT id,app_id,orientation_id,parent_user_id,user_id," +
            " title,type,link_url,product,budget_type," +
            " budget_amount,deliver_type,deliver_start_time, deliver_end_time, deliver_time_type, buy_type,charge_mode,pay_amount_unit," +
            " operator,create_time,update_time,status " +
            " FROM dspv2_t_promotion t" +
            " WHERE t.id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "appId", column = "app_id"),
            @Result(property = "orientationId", column = "orientation_id"),
            @Result(property = "parentUserId", column = "parent_user_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "linkUrl", column = "link_url"),
            @Result(property = "product", column = "product"),
            @Result(property = "budgetType", column = "budget_type"),
            @Result(property = "budgetAmount", column = "budget_amount"),
            @Result(property = "deliverType", column = "deliver_type"),
            @Result(property = "deliverStartTime", column = "deliver_start_time"),
            @Result(property = "deliverEndTime", column = "deliver_end_time"),
            @Result(property = "deliverTimeType", column = "deliver_time_type"),
            @Result(property = "buyType", column = "buy_type"),
            @Result(property = "chargeMode", column = "charge_mode"),
            @Result(property = "payAmountUnit", column = "pay_amount_unit"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status")
    })
    PromotionModel selectById(Long id);

    /**
     * 插入新的推广计划
     * @param promotionModel 推广计划详情
     * @return 新推广计划ID
     */
    @Insert(
            "INSERT INTO dspv2_t_promotion(" +
                    " app_id,orientation_id,parent_user_id,user_id," +
                    " title,type,link_url,product,budget_type," +
                    " budget_amount,deliver_type,deliver_start_time, deliver_end_time, deliver_time_type,  buy_type,charge_mode,pay_amount_unit," +
                    " operator,create_time,update_time,status) " +
                    " VALUES" +
                    "(" +
                    "#{appId},#{orientationId},#{parentUserId},#{userId},#{title}," +
                    "#{type},#{linkUrl},#{product},#{budgetType},#{budgetAmount}," +
                    "#{deliverType},#{deliverStartTime},#{deliverEndTime},#{deliverTimeType},#{buyType},#{chargeMode},#{payAmountUnit},#{operator}," +
                    "#{createTime},#{updateTime},#{status}" +
                    ")"
    )
    @Options(useGeneratedKeys = true)
    Integer insert(PromotionModel promotionModel);

    /**
     * 更新推广
     * @param promotionModel 推广修改详情
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_promotion SET" +
                    " app_id=#{appId}, orientation_id=#{orientationId}, user_id=#{userId}," +
                    " title=#{title}, type=#{type}, link_url=#{linkUrl}, product=#{product}," +
                    " budget_type=#{budgetType}, budget_amount=#{budgetAmount}, deliver_type=#{deliverType}," +
                    " deliver_start_time=#{deliverStartTime}, deliver_end_time=#{deliverEndTime},deliver_time_type=#{deliverTimeType}" +
                    " buy_type=#{buyType}, charge_mode=#{chargeMode}, pay_amount_unit=#{payAmountUnit}," +
                    " operator=#{operator}, update_time=#{updateTime}, status=#{status}" +
                    " WHERE id=#{id}"
    )
    Integer update(PromotionModel promotionModel);

    /**
     * 更新推广上下线状态
     * @param promotionModel 更新数据
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_promotion SET" +
                    " operator=#{operator}, update_time=#{updateTime}, status=#{status}" +
                    " WHERE id=#{id}"
    )
    Integer switchStatus(PromotionModel promotionModel);

    /**
     * 根据ID更新不为空的字段
     * @param promotionModel 待更新数据
     * @return 影响行数
     */
    @UpdateProvider(type = PromotionDaoSqlProvider.class, method = "updateByIdWithoutNull")
    Integer updateByIdWithoutNull(PromotionModel promotionModel);

    /**
     * 根据UID分页查询推广信息总数
     * @param pageModel 分页条件
     * @return 符合条件的推广数量
     */
    @SelectProvider(type = PromotionDaoSqlProvider.class, method = "pageQueryTotalCount")
    int pageQueryTotalCount(PageModel<PromotionModel> pageModel);

    /**
     * 根据UID分页查询推广列表
     * @param pageModel 分页条件
     * @return 符合条件的记录
     */
    @SelectProvider(type = PromotionDaoSqlProvider.class, method = "pageQuery")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "chargeMode", column = "charge_mode"),
            @Result(property = "payAmountUnit", column = "pay_amount_unit"),
            @Result(property = "budgetType", column = "budget_type"),
            @Result(property = "budgetAmount", column = "budget_amount"),
            @Result(property = "deliverStartTime", column = "deliver_start_time"),
            @Result(property = "deliverEndTime", column = "deliver_end_time"),
            @Result(property = "deliverTimeType", column = "deliver_time_type"),
            @Result(property = "status", column = "status"),
            @Result(property = "adCount", column = "ad_count"),
            @Result(property = "adReportDailyModel.pv", column = "pv"),
            @Result(property = "adReportDailyModel.click", column = "click"),
            @Result(property = "adReportDailyModel.ctr", column = "ctr"),
            @Result(property = "adReportDailyModel.ecpm", column = "ecpm"),
            @Result(property = "adReportDailyModel.ecpc", column = "ecpc"),
            @Result(property = "adReportDailyModel.totalCost", column = "total_cost")
    })
    List<PromotionModel> pageQuery(PageModel<PromotionModel> pageModel);

    /**
     * 根据推广ID查询
     * @param promotionModel 请求参数
     * @return 符合条件的记录
     */
    @Select("SELECT id,app_id,orientation_id,parent_user_id,user_id," +
            " title,type,link_url,product,budget_type," +
            " budget_amount,deliver_type,deliver_start_time, deliver_end_time, deliver_time_type, buy_type,charge_mode,pay_amount_unit," +
            " operator,create_time,update_time,status " +
            " FROM dspv2_t_promotion t" +
            " WHERE t.user_id = #{userId}" +
            " AND t.status != #{status}" +
            " AND t.deliver_end_time >= #{deliverEndTime}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "appId", column = "app_id"),
            @Result(property = "orientationId", column = "orientation_id"),
            @Result(property = "parentUserId", column = "parent_user_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "linkUrl", column = "link_url"),
            @Result(property = "product", column = "product"),
            @Result(property = "budgetType", column = "budget_type"),
            @Result(property = "budgetAmount", column = "budget_amount"),
            @Result(property = "deliverType", column = "deliver_type"),
            @Result(property = "deliverStartTime", column = "deliver_start_time"),
            @Result(property = "deliverEndTime", column = "deliver_end_time"),
            @Result(property = "deliverTimeType", column = "deliver_time_type"),
            @Result(property = "buyType", column = "buy_type"),
            @Result(property = "chargeMode", column = "charge_mode"),
            @Result(property = "payAmountUnit", column = "pay_amount_unit"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status")
    })
    List<PromotionModel> selectAvailablePromotionByUserId(PromotionModel promotionModel);

    /**
     * 根据推广ID查询
     * @param promotionModel 请求参数
     * @return 符合条件的记录
     */
    @Select("SELECT id,app_id,orientation_id,parent_user_id,user_id," +
            " title,type,link_url,product,budget_type," +
            " budget_amount,deliver_type,deliver_start_time, deliver_end_time, deliver_time_type, buy_type,charge_mode,pay_amount_unit," +
            " operator,create_time,update_time,status " +
            " FROM dspv2_t_promotion t" +
            " WHERE t.user_id = #{userId}" +
            " AND t.status != #{status}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "appId", column = "app_id"),
            @Result(property = "orientationId", column = "orientation_id"),
            @Result(property = "parentUserId", column = "parent_user_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "linkUrl", column = "link_url"),
            @Result(property = "product", column = "product"),
            @Result(property = "budgetType", column = "budget_type"),
            @Result(property = "budgetAmount", column = "budget_amount"),
            @Result(property = "deliverType", column = "deliver_type"),
            @Result(property = "deliverStartTime", column = "deliver_start_time"),
            @Result(property = "deliverEndTime", column = "deliver_end_time"),
            @Result(property = "deliverTimeType", column = "deliver_time_type"),
            @Result(property = "buyType", column = "buy_type"),
            @Result(property = "chargeMode", column = "charge_mode"),
            @Result(property = "payAmountUnit", column = "pay_amount_unit"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status")
    })
    List<PromotionModel> selectNotDiscardPromotionByUserId(PromotionModel promotionModel);

    /**
     * 根据推广ID查询
     * @param userId 用户ID
     * @return 符合条件的记录
     */
    @Select("SELECT id,app_id,orientation_id,parent_user_id,user_id," +
            " title,type,link_url,product,budget_type," +
            " budget_amount,deliver_type,deliver_start_time, deliver_end_time, deliver_time_type, buy_type,charge_mode,pay_amount_unit," +
            " operator,create_time,update_time,status " +
            " FROM dspv2_t_promotion t" +
            " WHERE t.user_id = #{userId}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "appId", column = "app_id"),
            @Result(property = "orientationId", column = "orientation_id"),
            @Result(property = "parentUserId", column = "parent_user_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "linkUrl", column = "link_url"),
            @Result(property = "product", column = "product"),
            @Result(property = "budgetType", column = "budget_type"),
            @Result(property = "budgetAmount", column = "budget_amount"),
            @Result(property = "deliverType", column = "deliver_type"),
            @Result(property = "deliverStartTime", column = "deliver_start_time"),
            @Result(property = "deliverEndTime", column = "deliver_end_time"),
            @Result(property = "deliverTimeType", column = "deliver_time_type"),
            @Result(property = "buyType", column = "buy_type"),
            @Result(property = "chargeMode", column = "charge_mode"),
            @Result(property = "payAmountUnit", column = "pay_amount_unit"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status")
    })
    List<PromotionModel> selectAllPromotionByUserId(Integer userId);

    /**
     * 查出最终开始时间、结束时间包含某个时间的推广
     * @param date
     * @return
     */
    @Select("SELECT id,app_id,orientation_id,parent_user_id,user_id, " +
            " title,type,link_url,product,budget_type, " +
            " budget_amount,deliver_type,deliver_start_time, deliver_end_time,deliver_time_type, buy_type,charge_mode,pay_amount_unit, " +
            " operator,create_time,update_time,status " +
            " FROM dspv2_t_promotion t " +
            " WHERE t.user_id = #{userId} " +
            " AND #{date} BETWEEN deliver_start_time AND deliver_end_time ")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "appId", column = "app_id"),
            @Result(property = "orientationId", column = "orientation_id"),
            @Result(property = "parentUserId", column = "parent_user_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "linkUrl", column = "link_url"),
            @Result(property = "product", column = "product"),
            @Result(property = "budgetType", column = "budget_type"),
            @Result(property = "budgetAmount", column = "budget_amount"),
            @Result(property = "deliverType", column = "deliver_type"),
            @Result(property = "deliverStartTime", column = "deliver_start_time"),
            @Result(property = "deliverEndTime", column = "deliver_end_time"),
            @Result(property = "deliverTimeType", column = "deliver_time_type"),
            @Result(property = "buyType", column = "buy_type"),
            @Result(property = "chargeMode", column = "charge_mode"),
            @Result(property = "payAmountUnit", column = "pay_amount_unit"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status")
    })
    List<PromotionModel> selectByUserIdAndDate(@Param("userId") Integer userId, @Param("date") String date);

}
