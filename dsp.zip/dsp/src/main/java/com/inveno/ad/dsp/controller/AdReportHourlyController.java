package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.AdReportSearchTypeEnum;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.AdReportHourlyService;
import com.inveno.ad.dsp.util.SysUtils;
import com.inveno.ad.dsp.vo.AdReportHourlyVo;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@RestController
public class AdReportHourlyController {

    @Autowired
    private AdReportHourlyService adReportHourlyService;

    @GetMapping("/adReportHourly")
    public VoContainer<List<AdReportHourlyVo>> query(AdReportHourlyVo adReportHourlyVo, HttpSession session) throws Exception{
        UserModel userModel = SysUtils.getUser(session);
        String type = adReportHourlyVo.getType();
        List<AdReportHourlyVo> adReportHourlyVoList = new ArrayList<>();
        if (AdReportSearchTypeEnum.PROMOTION.getValue().equals(type)){
            adReportHourlyVoList = adReportHourlyService.queryPromotion(adReportHourlyVo, userModel.getUserId());
        }else if (AdReportSearchTypeEnum.AD.getValue().equals(type)){
            adReportHourlyVoList = adReportHourlyService.queryAd(adReportHourlyVo, userModel.getUserId());
        }else if (AdReportSearchTypeEnum.USER.getValue().equals(type)){
            adReportHourlyVoList = adReportHourlyService.queryUser(adReportHourlyVo, userModel.getUserId());
        }
        return VoContainerHelper.createVoContainer(adReportHourlyVoList, RetCode.OK);
    }
}
