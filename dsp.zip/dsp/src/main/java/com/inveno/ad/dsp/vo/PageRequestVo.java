package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.validate.PageValidatorGroup;

import javax.validation.constraints.NotNull;

/**
 * <p>Title: {@link PageRequestVo} </p>
 * <p>Description: 分页请求vo对象 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public class PageRequestVo extends BaseVo {

    @NotNull(groups = PageValidatorGroup.class)
    private Integer currentPageNo;
    @NotNull(groups = PageValidatorGroup.class)
    private Integer eachPageCapacity;

    public Integer getCurrentPageNo() {
        return currentPageNo;
    }

    public void setCurrentPageNo(Integer currentPageNo) {
        this.currentPageNo = currentPageNo;
    }

    public Integer getEachPageCapacity() {
        return eachPageCapacity;
    }

    public void setEachPageCapacity(Integer eachPageCapacity) {
        this.eachPageCapacity = eachPageCapacity;
    }

}
