package com.inveno.ad.dsp.common;

public enum OnlineEnum {

    ONLINE("Y"),
    OFFLINE("N");

    private String value;

    OnlineEnum(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
