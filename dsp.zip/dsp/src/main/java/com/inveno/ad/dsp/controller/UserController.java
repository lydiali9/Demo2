package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.model.AdModel;
import com.inveno.ad.dsp.service.AdService;
import com.inveno.ad.dsp.service.UserService;
import com.inveno.ad.dsp.vo.*;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private AdService adService;

    @PostMapping("/login")
    public VoContainer<UserVo> login(@RequestBody LoginVo loginVo, HttpSession session) throws Exception {
        UserVo userVo = userService.login(loginVo, session);
        AdModel adModel = new AdModel();
        adModel.setUserId(userVo.getUserId());
        List<AdModel> adModelList = adService.list(adModel);
        userVo.setHasAd(CollectionUtils.isNotEmpty(adModelList));
        return VoContainerHelper.createVoContainer(userVo, RetCode.OK);
    }

    @PostMapping("/logout")
    public VoContainer<UserVo> logout(HttpServletRequest request) throws Exception {
        userService.logout(request);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @GetMapping("/userInfo")
    public VoContainer<UserVo> userInfo(HttpServletRequest request) throws Exception {
        UserVo userVo = userService.userInfo(request);
        return VoContainerHelper.createVoContainer(userVo, RetCode.OK);
    }

    @PostMapping("/register")
    public VoContainer<UserVo> register(RegisterVo registerVo) throws Exception {
        Integer userId = userService.register(registerVo);
        UserVo userVo = new UserVo();
        userVo.setUserId(userId);
        return VoContainerHelper.createVoContainer(userVo, RetCode.OK);
    }

    @PostMapping("/modifyPwd")
    public VoContainer<UserVo> modifyPwd(ModifyPwdVo modifyPwdVo, HttpSession session) throws Exception {
        userService.modifyPwd(modifyPwdVo, session);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @PostMapping("/resetPwd")
    public VoContainer<UserVo> resetPwd(ResetPwdVo resetPwdVo) throws Exception {
        userService.resetPwd(resetPwdVo);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

}
