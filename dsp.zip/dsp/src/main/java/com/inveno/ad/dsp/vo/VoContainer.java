package com.inveno.ad.dsp.vo;

/**
 * <p>Title: {@link VoContainer} </p>
 * <p>Description: vo容器类，返回固定格式的内容 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public class VoContainer<V> {

    private int code;
    private String message;
    private PageResponseVo page;
    private V data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public V getData() {
        return data;
    }

    public void setData(V data) {
        this.data = data;
    }

    public PageResponseVo getPage() {
        return page;
    }

    public void setPage(PageResponseVo page) {
        this.page = page;
    }
}
