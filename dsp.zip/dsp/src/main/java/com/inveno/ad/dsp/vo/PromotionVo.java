package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.common.PromotionBudgetTypeEnum;
import com.inveno.ad.dsp.common.PromotionChargeModeEnum;
import com.inveno.ad.dsp.common.PromotionTypeEnum;
import com.inveno.ad.dsp.validate.EnumValue;
import com.inveno.ad.dsp.validate.PageValidatorGroup;
import com.inveno.ad.dsp.validate.PostValidatorGroup;
import com.inveno.ad.dsp.validate.PutValidatorGroup;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * <p>Title: {@link PromotionVo}</p>
 * <p>Description: 推广VO对象 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
public class PromotionVo extends PageRequestVo {

    @NotNull(groups = PutValidatorGroup.class)
    private Long id;
    private Integer appId;
    private Integer orientationId;
    private Integer parentUserId;
    private Integer userId;
    private String title;
    @NotNull(groups = PostValidatorGroup.class)
    @EnumValue(clazz = PromotionTypeEnum.class, method = "contains", groups = PostValidatorGroup.class)
    private Integer type;
    private String linkUrl;
    @NotNull(groups = PostValidatorGroup.class)
    private String product;
    @NotNull(groups = PostValidatorGroup.class)
    @EnumValue(clazz = PromotionBudgetTypeEnum.class, method = "contains", groups = PostValidatorGroup.class)
    private Integer budgetType;
    @DecimalMin(value = "500", groups = PostValidatorGroup.class)
    private BigDecimal budgetAmount;
    private Integer deliverType;
    @NotNull(groups = PageValidatorGroup.class)
    private String deliverStartTime;
    @NotNull(groups = PageValidatorGroup.class)
    private String deliverEndTime;
    private Integer buyType;
    @NotNull(groups = PostValidatorGroup.class)
    @EnumValue(clazz = PromotionChargeModeEnum.class, method = "contains", groups = PostValidatorGroup.class)
    private Integer chargeMode;
    @DecimalMin(value = "0.01", groups = PostValidatorGroup.class)
    @DecimalMax(value = "9999.99", groups = PostValidatorGroup.class)
    private BigDecimal payAmountUnit;
    private Integer status;
    private OrientationVo orientation;
    @NotEmpty(groups = PostValidatorGroup.class)
    @Valid
    private List<PromotionOnlineTimeVo> promotionOnlineTimeList;
    private AdReportDailyVo statistic;
    private String keyword;
    /**
     * 查询的标识
     */
    private Integer category;

    /**
     * 查询时间范围的类型。(即根据 deliverTime 还是 createTime查询数据)
     */
    private Integer timeIntervalType;
    private Integer deliverTimeType;
    private Integer adCount;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAppId() {
        return appId;
    }

    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    public Integer getOrientationId() {
        return orientationId;
    }

    public void setOrientationId(Integer orientationId) {
        this.orientationId = orientationId;
    }

    public Integer getParentUserId() {
        return parentUserId;
    }

    public void setParentUserId(Integer parentUserId) {
        this.parentUserId = parentUserId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Integer getBudgetType() {
        return budgetType;
    }

    public void setBudgetType(Integer budgetType) {
        this.budgetType = budgetType;
    }

    public BigDecimal getBudgetAmount() {
        return budgetAmount;
    }

    public void setBudgetAmount(BigDecimal budgetAmount) {
        this.budgetAmount = budgetAmount;
    }

    public Integer getDeliverType() {
        return deliverType;
    }

    public void setDeliverType(Integer deliverType) {
        this.deliverType = deliverType;
    }

    public Integer getBuyType() {
        return buyType;
    }

    public void setBuyType(Integer buyType) {
        this.buyType = buyType;
    }

    public Integer getChargeMode() {
        return chargeMode;
    }

    public void setChargeMode(Integer chargeMode) {
        this.chargeMode = chargeMode;
    }

    public BigDecimal getPayAmountUnit() {
        return payAmountUnit;
    }

    public void setPayAmountUnit(BigDecimal payAmountUnit) {
        this.payAmountUnit = payAmountUnit;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public List<PromotionOnlineTimeVo> getPromotionOnlineTimeList() {
        return promotionOnlineTimeList;
    }

    public void setPromotionOnlineTimeList(List<PromotionOnlineTimeVo> promotionOnlineTimeList) {
        this.promotionOnlineTimeList = promotionOnlineTimeList;
    }

    public OrientationVo getOrientation() {
        return orientation;
    }

    public void setOrientation(OrientationVo orientation) {
        this.orientation = orientation;
    }

    public String getDeliverStartTime() {
        return deliverStartTime;
    }

    public void setDeliverStartTime(String deliverStartTime) {
        this.deliverStartTime = deliverStartTime;
    }

    public String getDeliverEndTime() {
        return deliverEndTime;
    }

    public void setDeliverEndTime(String deliverEndTime) {
        this.deliverEndTime = deliverEndTime;
    }

    public AdReportDailyVo getStatistic() {
        return statistic;
    }

    public void setStatistic(AdReportDailyVo statistic) {
        this.statistic = statistic;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Integer getTimeIntervalType() {
        return timeIntervalType;
    }

    public void setTimeIntervalType(Integer timeIntervalType) {
        this.timeIntervalType = timeIntervalType;
    }

    public Integer getDeliverTimeType() {
        return deliverTimeType;
    }

    public void setDeliverTimeType(Integer deliverTimeType) {
        this.deliverTimeType = deliverTimeType;
    }

    public Integer getAdCount() {
        return adCount;
    }

    public void setAdCount(Integer adCount) {
        this.adCount = adCount;
    }
}
