package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AccountModel;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

/**
 * <p>Title: {@link AccountDao} </p>
 * <p>Description: 账户DAO </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
@Mapper
public interface AccountDao {

    /**
     * 根据用户ID查询账户信息
     * @param userId 用户ID
     * @return 账户信息
     */
    @Select(
            "SELECT id, user_id, balance, status, version, update_time, create_time" +
                    " FROM dspv2_t_account t" +
                    " WHERE t.user_id = #{userId}"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "balance", column = "balance"),
                    @Result(property = "status", column = "status"),
                    @Result(property = "version", column = "version"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "createTime", column = "create_time")
            }
    )
    AccountModel selectByUserId(Integer userId);

    /**
     * 新增用户帐户
     * @param accountModel
     * @return
     */
    @Insert(
            "INSERT INTO dspv2_t_account(user_id, balance, status, version, update_time, create_time)" +
                    "VALUES(#{userId},#{balance},#{status},#{version},#{updateTime},#{createTime})"
    )
    @Options(useGeneratedKeys = true)
    Integer insert(AccountModel accountModel);


    /**
     * 更新用户记录版本
     * @param accountModel 用户ID
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_account SET version=version+1 WHERE user_id = #{userId} AND version = #{version}"
    )
    Integer incrVersionByUserId(AccountModel accountModel);

}
