package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.common.AccountFrozenStatusEnum;
import com.inveno.ad.dsp.common.PromotionChargeModeEnum;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.dao.*;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.*;
import com.inveno.ad.dsp.service.AccountService;
import com.inveno.ad.dsp.vo.AccountVo;
import com.inveno.ad.dsp.vo.AvailableBalanceVo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisCluster;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;


@Service
public class AccountServiceImpl implements AccountService {

    private static Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    @Autowired
    private AccountDao accountDao;
    @Autowired
    private AccountFrozenDao accountFrozenDao;
    @Autowired
    private AccountFlowReportDao accountFlowReportDao;
    @Autowired
    private AccountFlowDao accountFlowDao;
    @Autowired
    private PromotionDao promotionDao;
    @Autowired
    private JedisCluster jedisCluster;

    @Override
    public AccountVo info(Integer userId) throws Exception {
        AccountVo accountVo = new AccountVo();
        AccountModel accountModel = getAccount(userId);

        BeanUtils.copyProperties(accountModel, accountVo);
        BigDecimal balance = accountModel.getBalance();
        BigDecimal frozenAmount = getFrozenAmount(userId);
        BigDecimal availableBalance = balance.subtract(frozenAmount);     //可用余额
        BigDecimal consumptionToday = getConsumptionToday(userId);
        accountVo.setFrozenAmount(frozenAmount);
        accountVo.setAvailableBalance(availableBalance);
        accountVo.setConsumptionToday(consumptionToday);
        return accountVo;
    }

    @Override
    public BigDecimal getFrozenAmount(Integer userId) {
        BigDecimal frozenAmount = accountFrozenDao.selectSumByUserIdAndStatus(userId, AccountFrozenStatusEnum.FROZEN.getValue());
        return frozenAmount == null ? BigDecimal.ZERO : frozenAmount;
    }

    @Override
    public AvailableBalanceVo getAvailableBalance(Integer userId) throws Exception {
        AvailableBalanceVo availableBalanceVo = new AvailableBalanceVo();
        AccountModel accountModel = getAccount(userId);
        BeanUtils.copyProperties(accountModel, availableBalanceVo);

        BigDecimal balance = accountModel.getBalance();
        BigDecimal accountFrozen = this.getFrozenAmount(userId);
        availableBalanceVo.setAvailableBalance(balance.subtract(accountFrozen));

        return availableBalanceVo;
    }

    @Override
    public BigDecimal getConsumptionToday(Integer userId) {
        BigDecimal consumptionToday = BigDecimal.ZERO;
        String today = LocalDate.now().toString();
        List<PromotionModel> promotionModelList = promotionDao.selectByUserIdAndDate(userId, today);
        if (CollectionUtils.isNotEmpty(promotionModelList)){
            for (PromotionModel promotionModel : promotionModelList){
                BigDecimal itemConsumption = new BigDecimal(0);
                Long promotionId = promotionModel.getId();
                String key = "limit_" + today + "_" + promotionId;
                String strPv = jedisCluster.hget(key, "pv");
                String strClick = jedisCluster.hget(key, "click");
                Integer pv = 0;
                if (StringUtils.isNumeric(strPv)){
                    pv = Integer.valueOf(strPv);
                }
                Integer click = 0;
                if (StringUtils.isNumeric(strClick)){
                    click = Integer.valueOf(strClick);
                }
                BigDecimal payAmountUnit = promotionModel.getPayAmountUnit();
                Integer chargeMode = promotionModel.getChargeMode();
                if (chargeMode == PromotionChargeModeEnum.CPM.getValue()){
                    //CPM的消耗 = 单价 * pv / 1000
                    itemConsumption = (payAmountUnit.multiply(new BigDecimal(pv))).divide(new BigDecimal(1000),2, BigDecimal.ROUND_HALF_UP);
                }else if (chargeMode == PromotionChargeModeEnum.CPC.getValue()){
                    // CPC的消耗 = 单价 * click
                    itemConsumption = payAmountUnit.multiply(new BigDecimal(click));
                }
                consumptionToday = consumptionToday.add(itemConsumption);
                logger.info("Get ConsumptionToday|userId={}|promotionId={}|redisKey={}|payAmountUnit={}|chargeMode={}|pv={}|click={}"
                        , userId, promotionId, key, payAmountUnit, chargeMode, pv, click);
            }
        }
        return consumptionToday;
    }

    @Override
    public PageModel<AccountFlowReportModel> flowReportPageQuery(PageModel<AccountFlowReportModel> pageRequest) throws Exception {
        Integer totalCount = accountFlowReportDao.pageQueryTotalCountByUserId(pageRequest);
        List<AccountFlowReportModel> accountFlowReportModelList = accountFlowReportDao.pageQueryByUserId(pageRequest);
        pageRequest.setTotalCount(totalCount);
        pageRequest.setResponse(accountFlowReportModelList);
        return pageRequest;
    }

    @Override
    public PageModel<AccountFlowModel> flowPageQuery(PageModel<AccountFlowModel> pageRequest) throws Exception {
        Integer totalCount = accountFlowDao.pageQueryTotalCountByUserId(pageRequest);
        List<AccountFlowModel> accountFlowModelList = accountFlowDao.pageQueryByUserId(pageRequest);
        pageRequest.setTotalCount(totalCount);
        pageRequest.setResponse(accountFlowModelList);
        return pageRequest;
    }

    private AccountModel getAccount(Integer userId) {
        AccountModel accountModel = accountDao.selectByUserId(userId);
        if (accountModel == null){
            accountModel = new AccountModel();
            accountModel.setUserId(userId);
            accountModel.setBalance(BigDecimal.ZERO);
            accountModel.setStatus(0);
            accountModel.setVersion(0);
            accountModel.setUpdateTime(new Date());
            accountModel.setCreateTime(new Date());
            accountDao.insert(accountModel);
//            throw new DspException(RetCode.ERR_ACCOUNT_NOT_EXIST);
        }
        return  accountModel;
    }


}
