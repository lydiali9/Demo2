package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link PromotionBudgetTypeEnum} </p>
 * <p>Description: 预算类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public enum PromotionBudgetTypeEnum {

    /**
     * 日预算
     */
    DAILY(1),
    /**
     * 周预算
     */
    WEEKLY(2),
    /**
     * 月预算
     */
    MONTHLY(3);
    private int value;

    PromotionBudgetTypeEnum(int value) {
        this.value = value;
    }

    public static boolean contains(int value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue() == value);
    }

    public int getValue() {
        return value;
    }
}
