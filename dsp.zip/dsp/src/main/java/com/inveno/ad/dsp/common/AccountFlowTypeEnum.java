package com.inveno.ad.dsp.common;

public enum AccountFlowTypeEnum {

    //收支类型：收入
    INCOME(1),
    //收支类型：支出
    EXPEND(2);

    private Integer value;

    AccountFlowTypeEnum(Integer value){
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
