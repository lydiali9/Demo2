package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link StorageFolderEnum} </p>
 * <p>Description: 文件根目录枚举类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
public enum StorageFolderEnum {

    /**
     * 存储用户应用的folder
     */
    app,
    /**
     * 存储用户相关证书的folder
     */
    cert,
    /**
     * 图片
     */
    img

}
