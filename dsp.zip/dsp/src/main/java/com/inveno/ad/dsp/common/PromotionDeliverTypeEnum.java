package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link PromotionDeliverTypeEnum}</p>
 * <p>Description: 投放类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public enum PromotionDeliverTypeEnum {

    /**
     * 正常投放
     */
    NORMAL(1),
    /**
     * 加速投放
     */
    SPEED_UP(2);

    private int value;

    PromotionDeliverTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
