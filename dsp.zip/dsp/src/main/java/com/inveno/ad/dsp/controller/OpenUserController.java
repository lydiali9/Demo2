package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.model.OpenUserModel;
import com.inveno.ad.dsp.service.OpenUserService;
import com.inveno.ad.dsp.vo.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

@RestController
public class OpenUserController {

    @Autowired
    private OpenUserService openUserService;

    @PostMapping("/openUser")
    @ResponseBody
    public VoContainer<OpenUserVo> create(OpenUserVo openUserVo) throws Exception {
        OpenUserModel openUserModel = new OpenUserModel();
        BeanUtils.copyProperties(openUserVo, openUserModel);
        Integer id = openUserService.create(openUserModel);
        OpenUserVo returnOpenUserVo = new OpenUserVo();
        returnOpenUserVo.setOpenUserId(id);
        return VoContainerHelper.createVoContainer(returnOpenUserVo, RetCode.OK);
    }


    @PostMapping("/enterpriseUser")
    @ResponseBody
    public VoContainer<OpenUserVo> saveEnterpriseUser(EnterpriseUserVo enterpriseUserVo) throws Exception {
        Integer id = openUserService.saveEnterpriseUser(enterpriseUserVo);
        OpenUserVo returnOpenUserVo = new OpenUserVo();
        returnOpenUserVo.setOpenUserId(id);
        return VoContainerHelper.createVoContainer(returnOpenUserVo, RetCode.OK);
    }


    @PostMapping("/personalUser")
    @ResponseBody
    public VoContainer<OpenUserVo> savePersonalUserVo(PersonalUserVo personalUserVo) throws Exception {
        Integer id = openUserService.savePersonalUser(personalUserVo);
        OpenUserVo returnOpenUserVo = new OpenUserVo();
        returnOpenUserVo.setOpenUserId(id);
        return VoContainerHelper.createVoContainer(returnOpenUserVo, RetCode.OK);
    }

    @PutMapping("/openUser")
    @ResponseBody
    public VoContainer<OpenUserVo> update(OpenUserVo openUserVo) throws Exception {
        OpenUserModel openUserModel = new OpenUserModel();
        BeanUtils.copyProperties(openUserVo, openUserModel);
        openUserService.update(openUserModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }



}
