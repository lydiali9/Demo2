package com.inveno.ad.dsp.vo;


import java.util.List;

public class UserVo {

    private Integer userId;
    private String email;
    private String userName;
    private String role;
    private Boolean isParent;
    private Boolean hasAd;
    private List<MenuVo> menu;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Boolean getParent() {
        return isParent;
    }

    public void setParent(Boolean parent) {
        isParent = parent;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<MenuVo> getMenu() {
        return menu;
    }

    public void setMenu(List<MenuVo> menu) {
        this.menu = menu;
    }

    public Boolean getHasAd() {
        return hasAd;
    }

    public void setHasAd(Boolean hasAd) {
        this.hasAd = hasAd;
    }
}
