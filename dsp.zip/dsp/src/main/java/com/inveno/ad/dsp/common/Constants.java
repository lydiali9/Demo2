package com.inveno.ad.dsp.common;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public class Constants {

    public static final String SEPARATOR_WAVE_LINE = "~";
    public static final String SEPARATOR_SPACE = " ";
    public static final String SEPARATOR_COMMA = ",";
    public static final String SEPARATOR_HASHTAG = "#";
    public static final String SEPARATOR_VIRGULE = "/";
    public static final String SEPARATOR_VERTICAL_LINE = "|";
    public static final String SEPARATOR_VERTICAL_LINE_WITH_ESCAPE = "\\|";
    public static final String SEPARATOR_EQUAL = "=";
    public static final String SEPARATOR_COLON = ":";
    public static final String SEPARATOR_UNDERLINE = "_";
    public static final String SEPARATOR_AND= "&";
    public static final String SEPARATOR_QUESTION= "?";
    public static final String SEPARATOR_POINT= "\\.";
    public static final String SEPARATOR_POINT_WITH_OUT_ESCAPE= ".";
    public static final String SEPARATOR_BRACKETS_START= "(";
    public static final String SEPARATOR_BRACKETS_END= ")";
    public static final String SEPARATOR_SQUARE_BRACKETS_START= "[";
    public static final String SEPARATOR_SQUARE_BRACKETS_END= "]";
    public static final String SEPARATOR_SQUARE_QUOTATION= "\"";

    public static final String SESSION_KEY_USER_INFO = "userInfo";
    public static final String SESSION_KEY_LOGIN_COUNT = "loginCount";

    public static final String REDIS_KEY_VERIFICATION_CODE_PREFIX = "dsp_verification_code_";
    public static final String REDIS_KEY_FIND_PWD_CODE_PREFIX = "dsp_find_pwd_code_";

    public static final String PLAT_NAME = "DSP";

    public static final String KAPTCHA_SESSION_KEY = "KAPTCHA_SESSION_KEY";

}
