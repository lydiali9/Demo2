package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.AdReportSearchTypeEnum;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.AdReportDailyService;
import com.inveno.ad.dsp.util.SysUtils;
import com.inveno.ad.dsp.vo.AdReportDailyVo;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@RestController
public class AdReportDailyController {

    @Autowired
    private AdReportDailyService adReportDailyService;

    @GetMapping("/adReportDaily")
    public VoContainer<List<AdReportDailyVo>> query(AdReportDailyVo adReportDailyVo, HttpSession session) throws Exception{
        UserModel userModel = SysUtils.getUser(session);
        String type = adReportDailyVo.getType();
        List<AdReportDailyVo> adReportDailyVoList = new ArrayList<>();
        if (AdReportSearchTypeEnum.USER.getValue().equals(type)){
            adReportDailyVoList = adReportDailyService.queryUser(adReportDailyVo, userModel.getUserId());
        }else if (AdReportSearchTypeEnum.PROMOTION.getValue().equals(type)){
            adReportDailyVoList = adReportDailyService.queryPromotion(adReportDailyVo, userModel.getUserId());
        }else if (AdReportSearchTypeEnum.AD.getValue().equals(type)){
            adReportDailyVoList = adReportDailyService.queryAd(adReportDailyVo, userModel.getUserId());
        }
        return VoContainerHelper.createVoContainer(adReportDailyVoList, RetCode.OK);
    }
}
