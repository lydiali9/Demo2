package com.inveno.ad.dsp.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.inveno.ad.dsp.common.AppUrlTypeEnum;
import com.inveno.ad.dsp.common.PlatformEnum;
import com.inveno.ad.dsp.validate.DeleteValidatorGroup;
import com.inveno.ad.dsp.validate.EnumValue;
import com.inveno.ad.dsp.validate.PostValidatorGroup;
import com.inveno.ad.dsp.validate.PutValidatorGroup;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: {@link AppVo}</p>
 * <p>Description: 应用VO对象</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
public class AppVo extends PageRequestVo {

    @NotNull(groups = {PutValidatorGroup.class, DeleteValidatorGroup.class})
    private Integer id;
    @NotBlank(groups = {PostValidatorGroup.class, PutValidatorGroup.class})
    private String name;
    @NotNull(groups = {PostValidatorGroup.class, PutValidatorGroup.class})
    private String appType;
    @NotNull(groups = {PostValidatorGroup.class, PutValidatorGroup.class})
    @EnumValue(clazz = PlatformEnum.class, method = "contains", groups = PostValidatorGroup.class)
    private Integer os;
    private String appPackage;
    private Long packageSize;
    @NotNull(groups = {PostValidatorGroup.class})
    private String url;
    @NotNull(groups = {PostValidatorGroup.class})
    @EnumValue(clazz = AppUrlTypeEnum.class, method = "contains", groups = PostValidatorGroup.class)
    private Integer urlType;
    private Integer status;
    private Integer userId;
    private String version;
    private String startTime;
    private String endTime;
    private String description;
    private String folder;
    private String createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    public Integer getOs() {
        return os;
    }

    public void setOs(Integer os) {
        this.os = os;
    }

    @JSONField(name = "package")
    public String getAppPackage() {
        return appPackage;
    }

    @JSONField(name = "package")
    public void setAppPackage(String appPackage) {
        this.appPackage = appPackage;
    }

    public Long getPackageSize() {
        return packageSize;
    }

    public void setPackageSize(Long packageSize) {
        this.packageSize = packageSize;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getUrlType() {
        return urlType;
    }

    public void setUrlType(Integer urlType) {
        this.urlType = urlType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFolder() {
        return folder;
    }

    public void setFolder(String folder) {
        this.folder = folder;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
}
