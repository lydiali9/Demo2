package com.inveno.ad.dsp.filter;

import io.undertow.servlet.spec.HttpServletRequestImpl;
import io.undertow.servlet.spec.HttpServletResponseImpl;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import java.io.IOException;

/**
 * @author by sugang on 2018/1/5.
 */
@Component
public class CorsFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequestImpl httpServletRequestImpl = ((HttpServletRequestImpl) request);
		HttpServletResponseImpl httpServletResponseImpl = (HttpServletResponseImpl) response;
		httpServletResponseImpl.setHeader("Access-Control-Allow-Origin", httpServletRequestImpl.getHeader("Origin"));
		httpServletResponseImpl.setHeader("Access-Control-Allow-Credentials", "true");
		httpServletResponseImpl.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE, PUT");
		httpServletResponseImpl.setHeader("Access-Control-Max-Age", "3600");
		httpServletResponseImpl.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Connection, User-Agent, Cookie");
		filterChain.doFilter(request, response);
	}

	@Override
	public void destroy() {

	}

}
