package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.model.OpenUserModel;
import com.inveno.ad.dsp.vo.EnterpriseUserVo;
import com.inveno.ad.dsp.vo.PersonalUserVo;

public interface OpenUserService {
    Integer create(OpenUserModel openUserModel) throws Exception;

    Integer savePersonalUser(PersonalUserVo personalUserVo) throws Exception;

    Integer saveEnterpriseUser(EnterpriseUserVo enterpriseUserVo) throws Exception;

    Boolean update(OpenUserModel openUserModel) throws Exception;

    Integer saveBasePlatUser(Integer openUserId, Integer userId) throws Exception;
}
