package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link PromotionStatusEnum}</p>
 * <p>Description: 推广状态 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/5
 */
public enum PromotionStatusEnum {

    /**
     * 暂停
     */
    OFFLINE(0, "暂停"),
    /**
     * 启用
     */
    ONLINE(1, "启用"),
    /**
     * 废弃
     */
    DISCARD(2, "废弃");

    private int value;
    private String desc;

    PromotionStatusEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
