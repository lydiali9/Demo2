package com.inveno.ad.dsp.common;

public enum RoleEnum {
    PARENT("parent"),CHILD("child");
    String value;

    RoleEnum(String value){
        this.value = value;
    }
    public String getValue() {
        return value;
    }
}
