package com.inveno.ad.dsp.validate;

/**
 * <p>Title: {@link PostValidatorGroup} </p>
 * <p>Description: POST方法校验组，一般用于新建对象 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public interface PostValidatorGroup {



}
