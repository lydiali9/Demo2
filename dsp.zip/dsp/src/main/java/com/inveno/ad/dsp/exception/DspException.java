package com.inveno.ad.dsp.exception;

import com.inveno.ad.dsp.common.RetCode;

/**
 * <p>Title: {@link DspException} </p>
 * <p>Description: dsp异常类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public class DspException extends RuntimeException {

    private RetCode retCode;
    private int code;
    private Object[] args;

    public DspException(RetCode retCode) {
        super(retCode.getMessage());
        this.code = retCode.getCode();
    }

    public DspException(int code, String message) {
        super(message);
        this.code = code;
    }

    public DspException(RetCode retCode, Object... args) {
        super(retCode.getMessage(args));
        this.code = retCode.getCode();
        this.args = args;
    }

    public DspException(String message) {
        super(message);
    }

    public DspException(String message, Throwable cause) {
        super(message, cause);
    }

    public DspException(Throwable cause) {
        super(cause);
    }

    public DspException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public RetCode getRetCode() {
        return retCode;
    }

    public void setRetCode(RetCode retCode) {
        this.retCode = retCode;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Object[] getArgs() {
        return args;
    }

    public void setArgs(Object[] args) {
        this.args = args;
    }
}
