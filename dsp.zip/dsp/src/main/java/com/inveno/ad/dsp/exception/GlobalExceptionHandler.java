package com.inveno.ad.dsp.exception;

import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.i18n.DspLocale;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>Title: {@link GlobalExceptionHandler}</p>
 * <p>Description: 全局异常处理类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    @Autowired
    private MessageSource messageSource;

    @ResponseBody
    @ExceptionHandler(Exception.class)
    public VoContainer handle(HttpServletRequest request, Exception e) {
        int code;
        String message;
        try {
            if (e instanceof MethodArgumentNotValidException) {
                code = RetCode.ERR_PARAM.getCode();
                MethodArgumentNotValidException exp = (MethodArgumentNotValidException) e;
                String defaultMessage = exp.getBindingResult().getFieldError().getDefaultMessage();
                message = getMessage(defaultMessage);
                if (StringUtils.isBlank(defaultMessage)) {
                    String field = exp.getBindingResult().getFieldError().getField();
                    Object value = exp.getBindingResult().getFieldError().getRejectedValue();
                    message = RetCode.ERR_PARAM.getMessage(field, value);
                }
            } else if (e instanceof DspException) {
                DspException exception = (DspException) e;
                code = exception.getCode();
                message = getMessage(String.valueOf(exception.getCode()), exception.getArgs());
                if (StringUtils.isBlank(message)) {
                    message = exception.getMessage();
                }
            } else {
                code = RetCode.SERVICE_UNAVAILABLE.getCode();
                message = RetCode.SERVICE_UNAVAILABLE.getMessage();
            }
            logger.error(String.format("uri: %s, code=%d, message=%s, detail: %s",
                    request.getRequestURI(), code, message, e.getMessage()), e);
        } catch (Throwable t) {
            code = RetCode.SERVICE_UNAVAILABLE.getCode();
            message = RetCode.SERVICE_UNAVAILABLE.getMessage();
            logger.error(String.format("uri: %s, code=%d, message=%s, detail: %s",
                    request.getRequestURI(), code, message, t.getMessage()), e);
        }
        return VoContainerHelper.createVoContainer(code, message);
    }

    @ResponseBody
    @Order(Ordered.HIGHEST_PRECEDENCE)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public VoContainer handleValidateErr(HttpServletRequest request, MethodArgumentNotValidException e) {
        String defaultMessage = e.getBindingResult().getFieldError().getDefaultMessage();
        String message = getMessage(defaultMessage);
        if (StringUtils.isBlank(message)) {
            String field = e.getBindingResult().getFieldError().getField();
            Object value = e.getBindingResult().getFieldError().getRejectedValue();
            message = RetCode.ERR_PARAM.getMessage(field, value);
        }
        logger.error("uri: {}, code={}, message={}", request.getRequestURI(), RetCode.ERR_PARAM.getCode(), message);
        return VoContainerHelper.createVoContainer(RetCode.ERR_PARAM.getCode(), message);
    }

    private String getMessage(String code, Object... args) {
        String message = null;
        if (StringUtils.isNotBlank(code)) {
            try {
                message = messageSource.getMessage(code, args, DspLocale.ZH_CH_LOCALE.getLocale());
            } catch (Exception e1) {
                // ignore
            }
        }
        return message;
    }

}
