package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link AdStatusEnum}</p>
 * <p>Description: 广告状态 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/4
 */
public enum AdStatusEnum {

    /**
     * 待上线
     */
    INIT(0, "待上线"),
    /**
     * 上线
     */
    ONLINE(1, "上线"),
    /**
     * 下线
     */
    OFFLINE(2, "下线"),
    /**
     * 过期
     */
    EXPIRED(3, "过期"),
    /**
     * 废弃
     */
    DISCARD(4, "废弃");

    private int value;
    private String desc;

    AdStatusEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static AdStatusEnum parse(int value) {
        return Arrays.stream(values()).filter(e -> e.getValue() == value).findFirst().orElse(null);
    }

    public int getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }
}
