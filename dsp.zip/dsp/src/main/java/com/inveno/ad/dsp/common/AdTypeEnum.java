package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link AdTypeEnum} </p>
 * <p>Description: 广告类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/4
 */
public enum AdTypeEnum {

    /**
     * 普通广告
     */
    NORMAL(0),
    /**
     * c类广告
     */
    C(1);

    private int value;

    AdTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
