package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.model.ImageModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import javax.activation.UnsupportedDataTypeException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

/**
 * <p>Title: {@link ImageDaoSqlProvider}</p>
 * <p>Description: 图片DAO SQL 提供类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/18
 */
public class ImageDaoSqlProvider extends AbstractSqlProvider {

    @SuppressWarnings("unchecked")
    public String batchInsert(Map<Object, Object> map) {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO dspv2_t_image(");
        sql.append("image_id, img_server_url, url, user_id, width, height, format, ratio, " +
                "tag, is_template, template_id, title, create_time, update_time, status, type, big_image_type)");
        sql.append(" VALUES ");
        String pattern = "#'{'list[{0}].imageId'}', #'{'list[{0}].imgServerUrl'}', #'{'list[{0}].url'}', #'{'list[{0}].userId'}', #'{'list[{0}].width'}', #'{'list[{0}].height'}', " +
                " #'{'list[{0}].format'}',#'{'list[{0}].ratio'}',#'{'list[{0}].tag'}'," +
                " #'{'list[{0}].isTemplate'}',#'{'list[{0}].templateId'}',#'{'list[{0}].title'}'," +
                "#'{'list[{0}].createTime'}',#'{'list[{0}].updateTime'}',#'{'list[{0}].status'}'," +
                "#'{'list[{0}].type'}',#'{'list[{0}].bigImageType'}'";
        MessageFormat mf = new MessageFormat(pattern);
        List<ImageModel> imageModelList = (List<ImageModel>) map.get(PARAM_BATCH_LIST);
        append(sql, mf, imageModelList, Constants.SEPARATOR_COMMA);
        return sql.toString();
    }

    @SuppressWarnings("unchecked")
    public String selectByImageIdList(Map<String, Object> params) throws UnsupportedDataTypeException {
        SQL sql = new SQL();
        sql.SELECT("`image_id`", "img_server_url", " `url`", " `user_id`", "`width`", "`height`");
        sql.SELECT("`format`", " `ratio`", " `tag`", " `is_template`", " `template_id`", " `title`", "`create_time`", "`update_time`");
        sql.SELECT("`status`, type, big_image_type");
        sql.FROM("`dspv2_t_image`");
        List<Long> imageIdList = (List<Long>) params.get(PARAM_BATCH_LIST);
        appendORCondition(sql, imageIdList, "image_id");
        return sql.toString();
    }

    public String pageQueryTotalCount(PageModel<ImageModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(" SELECT ");
        sqlBuilder.append(" count(1) FROM ( ");
        sqlBuilder.append("SELECT ");
        sqlBuilder.append(" image.image_id ");
        sqlBuilder.append("FROM ");
        sqlBuilder.append(" dspv2_t_image image ");
        sqlBuilder.append(" WHERE image.user_id = #{request.userId} ");
        if (null != pageModel.getRequest().getIsTemplate()) {
            sqlBuilder.append(" AND image.is_template = #{request.isTemplate}");
        }
        if (null != pageModel.getRequest().getStartTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(image.create_time, '%Y-%m-%d') >= #{request.startTime} ");
        }
        if (null != pageModel.getRequest().getEndTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(image.create_time, '%Y-%m-%d') <= #{request.endTime} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND image.title like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getType()) {
            sqlBuilder.append(" AND image.type = #{request.type} ");
        }
        if (null != pageModel.getRequest().getBigImageType()) {
            sqlBuilder.append(" AND image.big_image_type = #{request.bigImageType} ");
        }
        sqlBuilder.append(" ORDER BY ");
        sqlBuilder.append(" image.create_time DESC) TMP ");
        return sqlBuilder.toString();
    }

    public String pageQuery(PageModel<ImageModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("SELECT ");
        sqlBuilder.append(" image_id, img_server_url, url, user_id, width, height, format, ratio, tag, is_template, template_id, title, create_time, update_time, status, type, big_image_type");
        sqlBuilder.append(" FROM ");
        sqlBuilder.append(" dspv2_t_image image ");
        sqlBuilder.append(" WHERE image.user_id = #{request.userId} ");
        if (null != pageModel.getRequest().getIsTemplate()) {
            sqlBuilder.append(" AND image.is_template = #{request.isTemplate}");
        }
        if (null != pageModel.getRequest().getStartTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(image.create_time, '%Y-%m-%d') >= #{request.startTime} ");
        }
        if (null != pageModel.getRequest().getEndTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(image.create_time, '%Y-%m-%d') <= #{request.endTime} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND image.title like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getType()) {
            sqlBuilder.append(" AND image.type = #{request.type} ");
        }
        if (null != pageModel.getRequest().getBigImageType()) {
            sqlBuilder.append(" AND image.big_image_type = #{request.bigImageType} ");
        }
        sqlBuilder.append(" ORDER BY image.create_time DESC ");
        sqlBuilder.append(" LIMIT #{offset},#{count} ");
        return sqlBuilder.toString();
    }

}
