package com.inveno.ad.dsp.service;

public interface EmailService {

    /**
     * 发送简单邮件
     * @param to
     * @param subject
     * @param content
     */
    void sendSimpleEmail(String to, String subject, String content) throws Exception;

    /**
     * 发送html格式邮件
     * @param to
     * @param subject
     * @param content
     */
    void sendHtmlEmail(String to, String subject, String content);

    String getMailTemplate(String type) throws Exception;

    void sendVerificationCode(String emailAddr) throws Exception;

    void sendFindPwdCode(String emailAddr) throws Exception;
}
