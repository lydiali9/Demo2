package com.inveno.ad.dsp.model;

import java.util.Date;
import java.util.List;

/**
 * <p>Title: {@link AdModel} </p>
 * <p>Description: 广告Model类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public class AdModel extends BaseModel {

    private Long adId;
    private Integer userId;
    private Integer operator;
    private Long promotionId;
    private String title;
    private Integer type;
    private String pvReportUrl;
    private String clickReportUrl;
    private String videoStartPlayReportUrl;
    private String videoEndPlayReportUrl;
    private Date createTime;
    private Date updateTime;
    private Integer status;
    private Integer version;
    private Integer transToStatus;
    private Integer matNum;
    private Integer reviewStatus;
    private String noPassReason;

    private List<AdMaterialModel> materialList;
    private PromotionModel promotion;
    private AdReportDailyModel adReportDailyModel;
    private String keyword;
    private String materialSource;

    /**
     * 查询时间范围的类型。(即根据 deliverTime 还是 createTime查询数据)
     */
    private Integer timeIntervalType;

    public Long getAdId() {
        return adId;
    }

    public void setAdId(Long adId) {
        this.adId = adId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getOperator() {
        return operator;
    }

    public void setOperator(Integer operator) {
        this.operator = operator;
    }

    public Long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(Long promotionId) {
        this.promotionId = promotionId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getPvReportUrl() {
        return pvReportUrl;
    }

    public void setPvReportUrl(String pvReportUrl) {
        this.pvReportUrl = pvReportUrl;
    }

    public String getClickReportUrl() {
        return clickReportUrl;
    }

    public void setClickReportUrl(String clickReportUrl) {
        this.clickReportUrl = clickReportUrl;
    }

    public String getVideoStartPlayReportUrl() {
        return videoStartPlayReportUrl;
    }

    public void setVideoStartPlayReportUrl(String videoStartPlayReportUrl) {
        this.videoStartPlayReportUrl = videoStartPlayReportUrl;
    }

    public String getVideoEndPlayReportUrl() {
        return videoEndPlayReportUrl;
    }

    public void setVideoEndPlayReportUrl(String videoEndPlayReportUrl) {
        this.videoEndPlayReportUrl = videoEndPlayReportUrl;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public List<AdMaterialModel> getMaterialList() {
        return materialList;
    }

    public void setMaterialList(List<AdMaterialModel> materialList) {
        this.materialList = materialList;
    }

    public PromotionModel getPromotion() {
        return promotion;
    }

    public void setPromotion(PromotionModel promotion) {
        this.promotion = promotion;
    }

    public AdReportDailyModel getAdReportDailyModel() {
        return adReportDailyModel;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public void setAdReportDailyModel(AdReportDailyModel adReportDailyModel) {
        this.adReportDailyModel = adReportDailyModel;
    }

    public Integer getTransToStatus() {
        return transToStatus;
    }

    public void setTransToStatus(Integer transToStatus) {
        this.transToStatus = transToStatus;
    }

    public Integer getMatNum() {
        return matNum;
    }

    public void setMatNum(Integer matNum) {
        this.matNum = matNum;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public Integer getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(Integer reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getNoPassReason() {
        return noPassReason;
    }

    public void setNoPassReason(String noPassReason) {
        this.noPassReason = noPassReason;
    }

    public String getMaterialSource() {
        return materialSource;
    }

    public void setMaterialSource(String materialSource) {
        this.materialSource = materialSource;
    }

    public Integer getTimeIntervalType() {
        return timeIntervalType;
    }

    public void setTimeIntervalType(Integer timeIntervalType) {
        this.timeIntervalType = timeIntervalType;
    }
}
