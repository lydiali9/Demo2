package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link PromotionChargeModeEnum}</p>
 * <p>Description: 推广付费模式 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public enum PromotionChargeModeEnum {

    /**
     * 按展示付费
     */
    CPM(1),
    /**
     * 按点击付费
     */
    CPC(2);

    private int value;

    PromotionChargeModeEnum(int value) {
        this.value = value;
    }

    public static boolean contains(int value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue() == value);
    }

    public int getValue() {
        return value;
    }
}
