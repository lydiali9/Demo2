package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.common.PromotionTypeEnum;
import com.inveno.ad.dsp.validate.*;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

/**
 * <p>Title: {@link AdVo}</p>
 * <p>Description: 广告VO对象 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public class AdVo extends PageRequestVo {

    @NotNull(groups = PutValidatorGroup.class)
    @DecimalMin(value = "0", groups = {PutValidatorGroup.class, GetValidatorGroup.class})
    private Long adId;
    private Integer userId;
    private Long promotionId;
    private String title;
    @EnumValue(clazz = PromotionTypeEnum.class, method = "contains", groups = PostValidatorGroup.class)
    private Integer type;
    private String pvReportUrl;
    private String clickReportUrl;
    private String videoStartPlayReportUrl;
    private String videoEndPlayReportUrl;
    private String createTime;
    private String updateTime;
    private Integer isOnline;
    private Integer status;
    private Integer version;
    private PromotionVo promotion;
    private AdReportDailyVo statistic;
    private Integer matNum;
    @Valid
    private AdMaterialInfoVo materialInfo;

    @NotNull(groups = PageValidatorGroup.class)
    private String deliverStartTime;
    @NotNull(groups = PageValidatorGroup.class)
    private String deliverEndTime;
    private Integer auditFailCount;
    private String keyword;
    private Integer reviewStatus;
    private String noPassReason;

    /**
     * 查询时间范围的类型。(即根据 deliverTime 还是 createTime查询数据)
     */
    private Integer timeIntervalType;

    public Long getAdId() {
        return adId;
    }

    public void setAdId(Long adId) {
        this.adId = adId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(Long promotionId) {
        this.promotionId = promotionId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getPvReportUrl() {
        return pvReportUrl;
    }

    public void setPvReportUrl(String pvReportUrl) {
        this.pvReportUrl = pvReportUrl;
    }

    public String getClickReportUrl() {
        return clickReportUrl;
    }

    public void setClickReportUrl(String clickReportUrl) {
        this.clickReportUrl = clickReportUrl;
    }

    public String getVideoStartPlayReportUrl() {
        return videoStartPlayReportUrl;
    }

    public void setVideoStartPlayReportUrl(String videoStartPlayReportUrl) {
        this.videoStartPlayReportUrl = videoStartPlayReportUrl;
    }

    public String getVideoEndPlayReportUrl() {
        return videoEndPlayReportUrl;
    }

    public void setVideoEndPlayReportUrl(String videoEndPlayReportUrl) {
        this.videoEndPlayReportUrl = videoEndPlayReportUrl;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(Integer isOnline) {
        this.isOnline = isOnline;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public PromotionVo getPromotion() {
        return promotion;
    }

    public void setPromotion(PromotionVo promotion) {
        this.promotion = promotion;
    }

    public AdReportDailyVo getStatistic() {
        return statistic;
    }

    public void setStatistic(AdReportDailyVo statistic) {
        this.statistic = statistic;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getDeliverStartTime() {
        return deliverStartTime;
    }

    public void setDeliverStartTime(String deliverStartTime) {
        this.deliverStartTime = deliverStartTime;
    }

    public String getDeliverEndTime() {
        return deliverEndTime;
    }

    public void setDeliverEndTime(String deliverEndTime) {
        this.deliverEndTime = deliverEndTime;
    }

    public Integer getMatNum() {
        return matNum;
    }

    public void setMatNum(Integer matNum) {
        this.matNum = matNum;
    }

    public AdMaterialInfoVo getMaterialInfo() {
        return materialInfo;
    }

    public void setMaterialInfo(AdMaterialInfoVo materialInfo) {
        this.materialInfo = materialInfo;
    }

    public Integer getAuditFailCount() {
        return auditFailCount;
    }

    public void setAuditFailCount(Integer auditFailCount) {
        this.auditFailCount = auditFailCount;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public Integer getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(Integer reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getNoPassReason() {
        return noPassReason;
    }

    public void setNoPassReason(String noPassReason) {
        this.noPassReason = noPassReason;
    }

    public Integer getTimeIntervalType() {
        return timeIntervalType;
    }

    public void setTimeIntervalType(Integer timeIntervalType) {
        this.timeIntervalType = timeIntervalType;
    }
}
