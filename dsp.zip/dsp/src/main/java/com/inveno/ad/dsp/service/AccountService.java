package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.model.AccountFlowModel;
import com.inveno.ad.dsp.model.AccountFlowReportModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.vo.AccountVo;
import com.inveno.ad.dsp.vo.AvailableBalanceVo;

import java.math.BigDecimal;

public interface AccountService {

    /**
     * 获取帐户信息
     * @param userId
     * @return
     * @throws Exception
     */
    AccountVo info(Integer userId) throws Exception;

    /**
     * 获取用户冻结金额
     * @param userId
     * @return
     * @throws Exception
     */
    BigDecimal getFrozenAmount(Integer userId) throws Exception;

    /**
     * 获取用户可用余额
     * @param userId
     * @return
     * @throws Exception
     */
    AvailableBalanceVo getAvailableBalance(Integer userId) throws Exception;

    /**
     * 获取用户今日消费
     * @param userId
     * @return
     * @throws Exception
     */
    BigDecimal getConsumptionToday(Integer userId) throws Exception;


    /**
     * 分页查询用户帐户天级流水报表
     * @return
     * @throws Exception
     */
    PageModel<AccountFlowReportModel> flowReportPageQuery(PageModel<AccountFlowReportModel> pageModel) throws Exception;


    /**
     * 分页查询用户帐户详细收支流水
     * @param pageModel
     * @return
     * @throws Exception
     */
    PageModel<AccountFlowModel> flowPageQuery(PageModel<AccountFlowModel> pageModel) throws Exception;
}
