package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link NetworkEnum}</p>
 * <p>Description: 网络</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public enum NetworkEnum {

    /**
     * 不限
     */
    UNLIMITED(0, "unlimited"),
    WIFI(1, "wifi"),
    TWO_G(2, "2g"),
    THREE_G(3, "3g"),
    FOUR_G(4, "4g"),
    FIVE_G(5, "5g");

    private int number;
    private String label;

    NetworkEnum(int number, String label) {
        this.number = number;
        this.label = label;
    }

    public int getNumber() {
        return number;
    }

    public String getLabel() {
        return label;
    }

    public static boolean contains(String label) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getLabel().equals(label));
    }

    public static boolean contains(int number) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getNumber() == number);
    }

    public static NetworkEnum parse(int number) {
        return Arrays.stream(values()).filter(e -> e.getNumber() == number).findFirst().orElse(null);
    }

    public static NetworkEnum parse(String label) {
        return Arrays.stream(values()).filter(e -> e.getLabel().equals(label)).findFirst().orElse(null);
    }

}
