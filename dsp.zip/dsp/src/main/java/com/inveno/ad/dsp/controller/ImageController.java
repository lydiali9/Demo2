package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.bean.ImageCropBean;
import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.conf.AppConfigProperties;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.ImageModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.ImageService;
import com.inveno.ad.dsp.util.ByteConverter;
import com.inveno.ad.dsp.util.DateUtils;
import com.inveno.ad.dsp.vo.ImageVo;
import com.inveno.ad.dsp.vo.PageResponseVo;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.StandardMultipartHttpServletRequest;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriUtils;

import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>Title: {@link ImageController}</p>
 * <p>Description: 图片controller类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
@RestController
public class ImageController {

    @Autowired
    private AppConfigProperties appConfigProperties;
    @Autowired
    private ImageService imageService;

    private static final String PARAM_FILES = "files";
    private static final String PARAM_TYPE = "type";
    private static final String PARAM_BIG_IMAGE_TYPE = "bigImageType";

    private static final String PARAM_IMAGE_CROP_W = "w";
    private static final String PARAM_IMAGE_CROP_H = "h";
    private static final String PARAM_IMAGE_CROP_X = "x";
    private static final String PARAM_IMAGE_CROP_Y = "y";

    @PostMapping("/image/upload")
    @ResponseBody
    public VoContainer upload(StandardMultipartHttpServletRequest request) throws Exception {
        MultipartFile file = request.getFile(PARAM_FILES);
        String type = request.getParameter(PARAM_TYPE);
        if (StringUtils.isBlank(type) || !StringUtils.isNumeric(type) || !ImageTypeEnum.contains(Integer.parseInt(type))) {
            throw new DspException(RetCode.ERR_PARAM, PARAM_TYPE, type);
        }
        String bigImageType = request.getParameter(PARAM_BIG_IMAGE_TYPE);
        if (ImageTypeEnum.BIG_IMAGE.getValue() == Integer.parseInt(type)
                && (StringUtils.isBlank(bigImageType) || !StringUtils.isNumeric(type) || !BigImageTypeEnum.contains(Integer.parseInt(bigImageType)))) {
            throw new DspException(RetCode.ERR_PARAM, PARAM_BIG_IMAGE_TYPE, bigImageType);
        }
        if (appConfigProperties.getImageMaxSize() < file.getSize()) {
            throw new DspException(RetCode.ERR_IMG_SIZE, ByteConverter.getPrintSize(appConfigProperties.getImageMaxSize()));
        }

        MediaType mediaType = MediaType.parseMediaType(file.getContentType());
        if (!mediaType.isCompatibleWith(MediaType.IMAGE_JPEG) && !mediaType.isCompatibleWith(MediaType.IMAGE_PNG)) {
            throw new DspException(RetCode.ERR_IMG_FORMAT);
        }
        UserModel userModel = (UserModel) request.getSession().getAttribute(Constants.SESSION_KEY_USER_INFO);
        if (null == userModel) {
            throw new DspException(RetCode.ERR_USER_NOT_LOGIN);
        }
        String folder = String.format("%d/%s/%s", userModel.getUserId(), StorageFolderEnum.img, LocalDate.now());
        ImageModel imageModel = new ImageModel();
        imageModel.setName(file.getOriginalFilename());
        imageModel.setFolder(folder);
        imageModel.setInputStream(file.getInputStream());
        imageModel.setType(Integer.parseInt(type));
        imageModel.setBigImageType(StringUtils.isBlank(bigImageType) ? null : Integer.parseInt(bigImageType));

        ImageCropBean imageCropBean = new ImageCropBean();
        String imageCropWidthStr = request.getParameter(PARAM_IMAGE_CROP_W);
        imageCropBean.setCropWidth(StringUtils.isBlank(imageCropWidthStr) ? null : (int) Math.round(Double.parseDouble(imageCropWidthStr)));
        String imageCropHeightStr = request.getParameter(PARAM_IMAGE_CROP_H);
        imageCropBean.setCropHeight(StringUtils.isBlank(imageCropHeightStr) ? null : (int) Math.round(Double.parseDouble(imageCropHeightStr)));
        String imageCropXStr = request.getParameter(PARAM_IMAGE_CROP_X);
        imageCropBean.setCropX(StringUtils.isBlank(imageCropXStr) ? null : (int) Math.round(Double.parseDouble(imageCropXStr)));
        String imageCropYStr = request.getParameter(PARAM_IMAGE_CROP_Y);
        imageCropBean.setCropY(StringUtils.isBlank(imageCropYStr) ? null : (int) Math.round(Double.parseDouble(imageCropYStr)));
        imageModel.setImageCropBean(imageCropBean);

        imageService.uploadAndCrop(imageModel, file.getBytes());
        String url = String.format("%s/%s/%s/%s",
                ServletUriComponentsBuilder.fromCurrentServletMapping().toUriString(),
                appConfigProperties.getFileRootLocation(),
                folder,
                UriUtils.encode(imageModel.getName(), Charset.defaultCharset()));
        imageModel.setUrl(url);
        ImageVo imageVo = new ImageVo();
        BeanUtils.copyProperties(imageModel, imageVo);
        return VoContainerHelper.createVoContainer(imageVo, RetCode.OK);
    }

    @PostMapping("/image/crop")
    @ResponseBody
    public VoContainer<ImageVo> crop(ImageVo imageVo) throws Exception {
        ImageModel imageModel = new ImageModel();
        BeanUtils.copyProperties(imageVo, imageModel);
        imageModel.setUserId(imageVo.getOperator());
        ImageModel cropImageModel = imageService.crop(imageModel);
        ImageVo cropImageVo = new ImageVo();
        BeanUtils.copyProperties(cropImageModel, cropImageVo);
        String url = String.format("%s/%s/%s/%s",
                ServletUriComponentsBuilder.fromCurrentServletMapping().toUriString(),
                appConfigProperties.getFileRootLocation(),
                cropImageVo.getFolder(),
                UriUtils.encode(cropImageVo.getName(), Charset.defaultCharset()));
        cropImageVo.setUrl(url);
        return VoContainerHelper.createVoContainer(cropImageVo, RetCode.OK);
    }

    @DeleteMapping("/image")
    @ResponseBody
    public VoContainer delete(ImageVo imageVo) throws Exception {
        ImageModel imageModel = new ImageModel();
        BeanUtils.copyProperties(imageVo, imageModel);
        imageService.delete(imageModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @PostMapping("/image")
    @ResponseBody
    public VoContainer<ImageVo> create(ImageVo imageVo) throws Exception {
        ImageModel imageModel = new ImageModel();
        BeanUtils.copyProperties(imageVo, imageModel);
        imageModel.setUserId(imageVo.getOperator());
        Long imageId = imageService.create(imageModel);
        ImageVo retImageVo = new ImageVo();
        retImageVo.setImageId(imageId);
        return VoContainerHelper.createVoContainer(retImageVo, RetCode.OK);
    }

    @GetMapping("/image")
    @ResponseBody
    public VoContainer<List<ImageVo>> pageQuery(ImageVo imageVo) throws Exception {
        ImageModel imageModel = new ImageModel();
        imageModel.setUserId(imageVo.getOperator());
        imageModel.setTitle(imageVo.getTitle());
        imageModel.setType(imageVo.getType());
        imageModel.setBigImageType(imageVo.getBigImageType());
        if (StringUtils.isNotBlank(imageVo.getStartTime())) {
            imageModel.setStartTime(DateUtils.parseDate(imageVo.getStartTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        }
        if (StringUtils.isNotBlank(imageVo.getEndTime())) {
            imageModel.setEndTime(DateUtils.parseDate(imageVo.getEndTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        }

        PageModel<ImageModel> pageModel = new PageModel<>();
        pageModel.setOffset((imageVo.getCurrentPageNo() - 1) * imageVo.getEachPageCapacity());
        pageModel.setCount(imageVo.getEachPageCapacity());
        pageModel.setRequest(imageModel);
        imageService.pageQuery(pageModel);

        List<ImageVo> imageVoList = null;
        if (CollectionUtils.isNotEmpty(pageModel.getResponse())) {
            imageVoList = new ArrayList<>(pageModel.getResponse().size());
            for (ImageModel retImageModel : pageModel.getResponse()) {
                ImageVo retImageVo = new ImageVo();
                BeanUtils.copyProperties(retImageModel, retImageVo);
                imageVoList.add(retImageVo);
            }
        }

        PageResponseVo pageResponseVo = new PageResponseVo();
        pageResponseVo.setCurrentPageNo(imageVo.getCurrentPageNo());
        pageResponseVo.setEachPageCapacity(imageVo.getEachPageCapacity());
        pageResponseVo.setTotalCount(pageModel.getTotalCount());
        return VoContainerHelper.createPageVoContainer(imageVoList, pageResponseVo, RetCode.OK);
    }

}
