package com.inveno.ad.dsp.common;

import java.util.Arrays;

public enum AdReportSearchTypeEnum {

    PROMOTION("promotion"),
    AD("ad"),
    USER("user");

    private String value;

    AdReportSearchTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean contains(String value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue().equals(value));
    }
}
