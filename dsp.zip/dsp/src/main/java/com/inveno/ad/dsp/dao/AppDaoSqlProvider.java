package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AppModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.commons.lang3.StringUtils;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/16
 */
public class AppDaoSqlProvider extends AbstractSqlProvider {

    public String pageQueryTotalCount(PageModel<AppModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(" SELECT ");
        sqlBuilder.append(" count(1) FROM ( ");
        sqlBuilder.append(" SELECT t.id FROM ");
        sqlBuilder.append(" dspv2_t_app t ");
        sqlBuilder.append(" WHERE ");
        sqlBuilder.append(" t.user_id = #{request.userId} ");
        if (StringUtils.isNotBlank(pageModel.getRequest().getName())) {
            sqlBuilder.append(" AND t.name like concat('%', #{request.name}, '%') ");
        }
        if (null != pageModel.getRequest().getStartTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') >= #{request.startTime} ");
        }
        if (null != pageModel.getRequest().getEndTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') <= #{request.endTime} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getAppType())) {
            sqlBuilder.append(" AND t.app_type = #{request.appType} ");
        }
        sqlBuilder.append(" GROUP BY ");
        sqlBuilder.append(" t.id) TMP ");
        return sqlBuilder.toString();
    }

    public String pageQuery(PageModel<AppModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("SELECT ");
        sqlBuilder.append(" id,  user_id,  name,  app_type,  os, ");
        sqlBuilder.append(" package,  package_size,  version,  description,  url, ");
        sqlBuilder.append(" url_type, folder, create_time,  update_time,  status ");
        sqlBuilder.append(" FROM dspv2_t_app t ");
        sqlBuilder.append(" WHERE t.user_id = #{request.userId} ");
        if (StringUtils.isNotBlank(pageModel.getRequest().getName())) {
            sqlBuilder.append(" AND t.name like concat('%', #{request.name}, '%') ");
        }
        if (null != pageModel.getRequest().getStartTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') >= #{request.startTime} ");
        }
        if (null != pageModel.getRequest().getEndTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') <= #{request.endTime} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getAppType())) {
            sqlBuilder.append(" AND t.app_type = #{request.appType} ");
        }
        sqlBuilder.append(" ORDER BY t.create_time DESC ");
        sqlBuilder.append(" LIMIT #{offset},#{count} ");
        return sqlBuilder.toString();
    }

}
