package com.inveno.ad.dsp.conf;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author sugang on 2017/10/17.
 * Reids 集群初始化类
 */
@Configuration
@EnableConfigurationProperties(RedisProperties.class)
public class RedisClusterInitializer {

    private static Logger logger = LoggerFactory.getLogger(RedisClusterInitializer.class);

    @Autowired
    private RedisProperties redisProperties;

    @Bean
    public JedisCluster jedisCluster(@Qualifier("jedisClusterPoolConfig") GenericObjectPoolConfig jedisClusterPoolConfig) {
        List<String> nodeStrList = redisProperties.getCluster().getNodes();
        if (CollectionUtils.isEmpty(nodeStrList)) {
            logger.error("<!>sys|Properties spring.redis.cluster.nodes error.");
            System.exit(-1);
        }
        logger.info("<#>sys|Redis nodes: {}", nodeStrList);
        Set<HostAndPort> nodes = new HashSet<>(nodeStrList.size());
        for (String hostAndPort : nodeStrList) {
            try {
                String[] hostAndPortArr = hostAndPort.split(":");
                if (hostAndPortArr.length != 2) {
                    continue;
                }
                nodes.add(new HostAndPort(hostAndPortArr[0], Integer.parseInt(hostAndPortArr[1])));
            } catch (Exception e) {
                logger.error("<!>sys|Redis node error.", e);
            }
        }
        if (CollectionUtils.isEmpty(nodes)) {
            logger.error("<!>sys|No redis nodes.");
            System.exit(-1);
        }
        return new JedisCluster(nodes, (int) redisProperties.getTimeout().toMillis(), redisProperties.getCluster().getMaxRedirects(), jedisClusterPoolConfig);
    }

    @Bean(name = "jedisClusterPoolConfig")
    public GenericObjectPoolConfig jedisClusterPoolConfig() {
        GenericObjectPoolConfig config = new GenericObjectPoolConfig();
        config.setMaxTotal(redisProperties.getJedis().getPool().getMaxActive());
        config.setMaxIdle(redisProperties.getJedis().getPool().getMaxIdle());
        config.setMinIdle(redisProperties.getJedis().getPool().getMinIdle());
        config.setMaxWaitMillis(redisProperties.getJedis().getPool().getMaxWait().toMillis());
        return config;
    }

}
