package com.inveno.ad.dsp.model;

import java.io.Serializable;

/**
 * <p>Title: {@link BaseModel} </p>
 * <p>Description: model基类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public class BaseModel implements Serializable {
}
