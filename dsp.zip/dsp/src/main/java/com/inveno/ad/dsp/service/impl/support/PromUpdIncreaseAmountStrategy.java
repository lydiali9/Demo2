package com.inveno.ad.dsp.service.impl.support;

import com.inveno.ad.dsp.model.PromotionModel;

/**
 * <p>Title: {@link PromUpdIncreaseAmountStrategy}</p>
 * <p>Description: 推广更新策略:金额变大，时间天数未变 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/30
 * 金额变大，时间天数未变
 *    a) 判断余额。
 *    b) 更新账户冻结表。
 *    c) 更新推广预算表。
 *    d) 更新推广上线时间表。
 */
public class PromUpdIncreaseAmountStrategy extends AbstractPromUpdStrategy {

    @Override
    public void update(PromotionModel updatePromotion, PromotionModel promotionInDB) throws Exception {
        // a) 判断余额。
        checkBalance(updatePromotion, promotionInDB);
        // b) 更新账户冻结表。
        updateAccountFrozenAmount(updatePromotion);
        // c) 更新推广预算表。
        updatePromotionBudget(updatePromotion, promotionInDB);
        // d) 更新推广上线时间表。
        updatePromotionOnlineTime(updatePromotion);
    }

}
