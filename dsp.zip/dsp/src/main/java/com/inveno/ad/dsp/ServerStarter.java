package com.inveno.ad.dsp;

import com.inveno.ad.dsp.conf.AppConfigProperties;
import com.inveno.ad.dsp.conf.EmailConfigProperties;
import com.inveno.ad.dsp.conf.ImageServerConfigProperties;
import com.inveno.ad.dsp.filter.AuthFilter;
import com.inveno.ad.dsp.filter.CorsFilter;
import com.inveno.ad.dsp.filter.QualifyAuthFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

/**
 * <p>Title: {@link ServerStarter}</p>
 * <p>Description: 程序入口类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
@SpringBootApplication
//@EnableAsync
@EnableConfigurationProperties({AppConfigProperties.class, EmailConfigProperties.class, ImageServerConfigProperties.class})
public class ServerStarter {

    public static void main(String[] args) {
        System.setProperty("Log4jContextSelector", "org.apache.logging.log4j.core.async.AsyncLoggerContextSelector");
        SpringApplication.run(ServerStarter.class, args);
    }

    @Bean
    @ConditionalOnBean(CorsFilter.class)
    public FilterRegistrationBean CorsFilterRegistrationBean(CorsFilter corsFilter) {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(corsFilter);
        filterRegistrationBean.addUrlPatterns("/*");
        filterRegistrationBean.setName("corsFilter");
        filterRegistrationBean.setOrder(1);
        return filterRegistrationBean;
    }

    @Bean
    @ConditionalOnBean(AuthFilter.class)
    public FilterRegistrationBean AuthFilterRegistrationBean(AuthFilter authFilter) {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(authFilter);
        filterRegistrationBean.addUrlPatterns("/*");
        filterRegistrationBean.setName("authFilter");
        filterRegistrationBean.setOrder(2);
        return filterRegistrationBean;
    }

    @Bean
    @ConditionalOnBean(QualifyAuthFilter.class)
    public FilterRegistrationBean QualifyAuthFilterRegistrationBean(QualifyAuthFilter qualifyAuthFilter) {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(qualifyAuthFilter);
        filterRegistrationBean.addUrlPatterns("/*");
        filterRegistrationBean.setName("qualifyAuthFilter");
        filterRegistrationBean.setOrder(3);
        return filterRegistrationBean;
    }

}
