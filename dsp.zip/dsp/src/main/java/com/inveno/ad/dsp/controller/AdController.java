package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.model.*;
import com.inveno.ad.dsp.service.AdService;
import com.inveno.ad.dsp.util.DateUtils;
import com.inveno.ad.dsp.vo.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <p>Title: {@link AdController}</p>
 * <p>Description: 广告Controller </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
@RestController
public class AdController {

    @Autowired
    private AdService adService;

    @PostMapping("/ad")
    public VoContainer<AdVo> create(AdVo adVo) throws Exception {
        AdModel adModel = voToModel(adVo);
        adModel.setUserId(adVo.getOperator());
        adService.create(adModel);
        AdVo retVo = new AdVo();
        retVo.setAdId(adModel.getAdId());
        return VoContainerHelper.createVoContainer(retVo, RetCode.OK);
    }

    @PutMapping("/ad")
    public VoContainer update(AdVo adVo) throws Exception {
        AdModel adModel = new AdModel();
        BeanUtils.copyProperties(adVo, adModel);
        AdMaterialInfoVo adMaterialInfoVo = adVo.getMaterialInfo();
        adModel.setMaterialList(adMaterialInfoVoToAdMaterialModel(adMaterialInfoVo));
        adModel.setUserId(adVo.getOperator());
        adService.update(adModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @GetMapping("/ad/id")
    @ResponseBody
    public VoContainer<AdVo> get(AdVo adVo) throws Exception {
        AdModel adModel = adService.queryById(adVo.getAdId());
        AdVo retAdVo = modelToVo(adModel);
        return VoContainerHelper.createVoContainer(retAdVo, RetCode.OK);
    }

    @GetMapping("/ad/list")
    @ResponseBody
    public VoContainer<List<AdVo>> list(AdVo adVo) throws Exception {
        AdModel adModel = voToModel(adVo);
        adModel.setUserId(adVo.getOperator());
        List<AdModel> retAdModelList = adService.list(adModel);
        List<AdVo> retAdVoList = voToModel(retAdModelList);
        return VoContainerHelper.createVoContainer(retAdVoList, RetCode.OK);
    }

    @GetMapping("/ad")
    @ResponseBody
    public VoContainer<List<AdVo>> pageQuery(AdVo adVo) throws Exception {
        PromotionModel promotionModel = new PromotionModel();
        promotionModel.setDeliverStartTime(DateUtils.parseDate(adVo.getDeliverStartTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        promotionModel.setDeliverEndTime(DateUtils.parseDate(adVo.getDeliverEndTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));

        AdModel adModel = new AdModel();
        adModel.setAdId(adVo.getAdId());
        adModel.setPromotionId(adVo.getPromotionId());
        adModel.setOperator(adVo.getOperator());
        adModel.setUserId(adVo.getOperator());
        adModel.setPromotion(promotionModel);
        adModel.setKeyword(adVo.getKeyword());
        adModel.setTimeIntervalType(adVo.getTimeIntervalType());
        adModel.setStatus(adVo.getStatus());
        adModel.setReviewStatus(adVo.getReviewStatus());

        PageModel<AdModel> pageModel = new PageModel<>();
        pageModel.setOffset((adVo.getCurrentPageNo() - 1) * adVo.getEachPageCapacity());
        pageModel.setCount(adVo.getEachPageCapacity());
        pageModel.setRequest(adModel);
        PageModel<AdModel> pageQueryResult = adService.pageQuery(pageModel);

        List<AdModel> retAdModelList = pageQueryResult.getResponse();
        List<AdVo> retAdVoList = voToModel(retAdModelList);
        PageResponseVo pageResponseVo = new PageResponseVo();
        pageResponseVo.setCurrentPageNo(adVo.getCurrentPageNo());
        pageResponseVo.setEachPageCapacity(adVo.getEachPageCapacity());
        pageResponseVo.setTotalCount(pageModel.getTotalCount());
        return VoContainerHelper.createPageVoContainer(retAdVoList, pageResponseVo, RetCode.OK);
    }

    @GetMapping("/ad/auditFail")
    @ResponseBody
    public VoContainer<AdVo> auditFailCount(AdVo adVo) throws Exception {
        Integer auditFailCount = adService.auditFailCount(adVo.getOperator());
        AdVo ret = new AdVo();
        ret.setAuditFailCount(auditFailCount);
        return VoContainerHelper.createVoContainer(ret, RetCode.OK);
    }


    @PutMapping("/ad/status")
    @ResponseBody
    public VoContainer switchStatus(AdVo adVo) throws Exception {
        AdModel adModel = new AdModel();
        adModel.setStatus(adVo.getStatus());
        adModel.setReviewStatus(adVo.getReviewStatus());
        adModel.setOperator(adVo.getOperator());
        adModel.setAdId(adVo.getAdId());
        adService.switchStatus(adModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    private List<AdVo> voToModel(List<AdModel> adModelList) {
        List<AdVo> retAdVoList = null;
        if (CollectionUtils.isNotEmpty(adModelList)) {
            retAdVoList = new ArrayList<>(adModelList.size());
            for (AdModel retAdModel : adModelList) {
                AdVo retAdVo = modelToVo(retAdModel);
                retAdVoList.add(retAdVo);
            }
        }
        return retAdVoList;
    }

    private AdModel voToModel(AdVo adVo) {
        AdModel adModel = new AdModel();
        BeanUtils.copyProperties(adVo, adModel);
        AdMaterialInfoVo adMaterialInfoVo = adVo.getMaterialInfo();
        adModel.setMaterialList(adMaterialInfoVoToAdMaterialModel(adMaterialInfoVo));
        return adModel;
    }

    private AdVo modelToVo(AdModel adModel) {
        AdVo adVo = null;
        if (null != adModel) {
            adVo = new AdVo();
            BeanUtils.copyProperties(adModel, adVo);
            if (null != adModel.getPromotion()) {
                PromotionVo promotionVo = new PromotionVo();
                promotionVo.setId(adModel.getPromotion().getId());
                promotionVo.setTitle(adModel.getPromotion().getTitle());
                promotionVo.setDeliverStartTime(DateFormatUtils.format(adModel.getPromotion().getDeliverStartTime(), DateUtils.FMT_yyyyMMddHHmmss_));
                promotionVo.setDeliverEndTime(DateFormatUtils.format(adModel.getPromotion().getDeliverEndTime(), DateUtils.FMT_yyyyMMddHHmmss_));
                adVo.setPromotion(promotionVo);
            }
            if (CollectionUtils.isNotEmpty(adModel.getMaterialList())) {
                List<AdMaterialVo> adMaterialVoList = new ArrayList<>(adModel.getMaterialList().size());
                AdMaterialInfoVo adMaterialInfoVo = new AdMaterialInfoVo();
                adMaterialInfoVo.setType(adModel.getMaterialList().get(0).getType());
                adMaterialInfoVo.setBigImageType(adModel.getMaterialList().get(0).getBigImageType());
                adMaterialInfoVo.setMaterialList(adMaterialVoList);
                adVo.setMaterialInfo(adMaterialInfoVo);
                for (AdMaterialModel adMaterialModel : adModel.getMaterialList()) {
                    AdMaterialVo adMaterialVo;
                    List<ImageVo> adMaterialImageVoList;
                    Optional<AdMaterialVo> adMaterialVoOptional = adMaterialVoList.stream()
                            .filter(e -> e.getImageGroupId().equals(adMaterialModel.getGroupId()))
                            .filter(e -> e.getType().equals(adMaterialModel.getType()))
                            .findFirst();
                    if (adMaterialVoOptional.isPresent()) {
                        adMaterialVo = adMaterialVoOptional.get();
                        adMaterialImageVoList = adMaterialVo.getImageList();
                    } else {
                        adMaterialVo = new AdMaterialVo();
                        BeanUtils.copyProperties(adMaterialModel, adMaterialVo);
                        adMaterialVo.setImageGroupId(adMaterialModel.getGroupId());
                        adMaterialVoList.add(adMaterialVo);
                        adMaterialImageVoList = new ArrayList<>();
                        adMaterialVo.setImageList(adMaterialImageVoList);
                    }
                    ImageModel adMaterialImageModel = adMaterialModel.getImageModel();
                    ImageVo imageVo = new ImageVo();
                    BeanUtils.copyProperties(adMaterialImageModel, imageVo);
                    //组图的三张图片有三条素材记录，因此在这里冗余一个字段到image里面，后期是否考虑组图的素材对应多个图片。
                    imageVo.setMaterialId(adMaterialModel.getId());
                    adMaterialImageVoList.add(imageVo);
                }
            }
            if (null != adModel.getAdReportDailyModel()) {
                AdReportDailyVo adReportDailyVo = new AdReportDailyVo();
                BeanUtils.copyProperties(adModel.getAdReportDailyModel(), adReportDailyVo);
                adVo.setStatistic(adReportDailyVo);
            }
        }
        return adVo;
    }

    private List<AdMaterialModel> adMaterialInfoVoToAdMaterialModel(AdMaterialInfoVo adMaterialInfoVo) {
        List<AdMaterialModel> adMaterialModelList = null;
        if (null != adMaterialInfoVo) {
            if (CollectionUtils.isNotEmpty(adMaterialInfoVo.getMaterialList())) {
                adMaterialModelList = new ArrayList<>(adMaterialInfoVo.getMaterialList().size());
                int groupId = 0;
                for (AdMaterialVo adMaterialVo : adMaterialInfoVo.getMaterialList()) {
                    groupId++;
                    for (ImageVo imageVo : adMaterialVo.getImageList()) {
                        ImageModel adMaterialImageModel = new ImageModel();
                        BeanUtils.copyProperties(imageVo, adMaterialImageModel);
                        AdMaterialModel adMaterialModel = new AdMaterialModel();
                        BeanUtils.copyProperties(adMaterialVo, adMaterialModel);
                        adMaterialModel.setImageModel(adMaterialImageModel);
                        adMaterialModel.setType(adMaterialInfoVo.getType());
                        adMaterialModel.setBigImageType(adMaterialInfoVo.getBigImageType());
                        adMaterialModel.setGroupId(groupId);
                        //组图的三张图片有三条素材记录，后期是否考虑组图的素材对应多个图片。
                        adMaterialModel.setId(imageVo.getMaterialId());
                        adMaterialModelList.add(adMaterialModel);
                    }
                }
            }
        }
        return adMaterialModelList;
    }

}
