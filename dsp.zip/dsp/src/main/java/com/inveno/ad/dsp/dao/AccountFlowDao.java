package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AccountFlowModel;
import com.inveno.ad.dsp.model.AccountFlowReportModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface AccountFlowDao {


    @Select(
            "SELECT " +
                " COUNT(1) " +
            " FROM dspv2_t_account_flow " +
            " WHERE user_id = #{request.userId} " +
            " AND create_time >= #{request.searchStartDate} " +
            " AND create_time <= #{request.searchEndDate} "
    )
    Integer pageQueryTotalCountByUserId(PageModel<AccountFlowModel> pageModel);


    @Select(
            " SELECT " +
                " id,user_id,amount,type,source,balance," +
                " status,operator,memo,update_time,create_time " +
            " FROM dspv2_t_account_flow " +
            " WHERE user_id = #{request.userId} " +
            " AND create_time >= #{request.searchStartDate} " +
            " AND create_time <= #{request.searchEndDate} " +
            " ORDER BY create_time DESC " +
            " LIMIT #{offset},#{count} "
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "amount", column = "amount"),
                    @Result(property = "type", column = "type"),
                    @Result(property = "source", column = "source"),
                    @Result(property = "balance", column = "balance"),
                    @Result(property = "status", column = "status"),
                    @Result(property = "operator", column = "operator"),
                    @Result(property = "memo", column = "memo"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "createTime", column = "create_time"),
            }
            )
    List<AccountFlowModel> pageQueryByUserId(PageModel<AccountFlowModel> pageModel);
}
