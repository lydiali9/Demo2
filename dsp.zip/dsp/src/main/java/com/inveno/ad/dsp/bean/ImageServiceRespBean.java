package com.inveno.ad.dsp.bean;

/**
 * <p>Title: {@link ImageServiceRespBean} </p>
 * <p>Description: 云图响应 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/11
 */
public class ImageServiceRespBean {

    private String srcUrl;
    private Integer width;
    private Integer height;
    private Long urlKey;
    private String url;

    public String getSrcUrl() {
        return srcUrl;
    }

    public void setSrcUrl(String srcUrl) {
        this.srcUrl = srcUrl;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Long getUrlKey() {
        return urlKey;
    }

    public void setUrlKey(Long urlKey) {
        this.urlKey = urlKey;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
