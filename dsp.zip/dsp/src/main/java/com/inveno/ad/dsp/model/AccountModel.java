package com.inveno.ad.dsp.model; /***********************************************************************
 * Module:  AccountModel.java
 * Author:  sugang
 * Purpose: Defines the Class AccountModel
 ***********************************************************************/

import java.math.BigDecimal;
import java.util.*;

/** 账户表
 * 
 * @pdOid fd7759f7-4c43-422e-b039-dd9ba9d345a9 */
public class AccountModel {
   private Integer id;
   private BigDecimal balance;
   private Date createTime;
   private Date updateTime;
   private Integer status;
   private Integer version;
   private Integer userId;

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public BigDecimal getBalance() {
      return balance;
   }

   public void setBalance(BigDecimal balance) {
      this.balance = balance;
   }

   public Date getCreateTime() {
      return createTime;
   }

   public void setCreateTime(Date createTime) {
      this.createTime = createTime;
   }

   public Date getUpdateTime() {
      return updateTime;
   }

   public void setUpdateTime(Date updateTime) {
      this.updateTime = updateTime;
   }

   public Integer getStatus() {
      return status;
   }

   public void setStatus(Integer status) {
      this.status = status;
   }

   public Integer getVersion() {
      return version;
   }

   public void setVersion(Integer version) {
      this.version = version;
   }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}