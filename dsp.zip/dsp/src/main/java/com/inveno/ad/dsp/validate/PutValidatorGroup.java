package com.inveno.ad.dsp.validate;

/**
 * <p>Title: {@link PutValidatorGroup} </p>
 * <p>Description: PUT方法校验组，用于更新操作 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public interface PutValidatorGroup {
}
