package com.inveno.ad.dsp.model; /***********************************************************************
 * Module:  AdHistoryModel.java
 * Author:  sugang
 * Purpose: Defines the Class AdHistoryModel
 ***********************************************************************/

import java.util.*;

/** 广告历史表，记录更新历史
 * 
 * @pdOid 9c795c2f-ae8c-418f-9766-79e7683ff540 */
public class AdHistoryModel {
   /** 广告ID
    * 
    * @pdOid 72b1839a-ac54-489d-b268-92a7ecb38c88 */
   private Long adId;
   /** @pdOid 5f1339af-c6e6-4678-a2ce-3022c34a77a5 */
   private Integer userId;
   /** 主键ID
    * 
    * @pdOid fdf67d31-bb48-4a88-bbce-71fd2c412c8f */
   private Integer promotionId;
   /** @pdOid 39e82801-20f8-447e-bff3-e6e4770d4abc */
   private Integer operator;
   /** operator-date-opition
    * 
    * @pdOid 3359dc17-899b-465d-ac27-6cb1337a2b5a */
   private String memo;
   /** @pdOid f3c0d6c5-cef4-42b9-92bb-781340d33b34 */
   private Date createTime;
   /** @pdOid fca1250b-449a-4ebb-bfa0-4f49dfd4122c */
   private Date updateTime;

   public Long getAdId() {
      return adId;
   }

   public void setAdId(Long adId) {
      this.adId = adId;
   }

   public Integer getUserId() {
      return userId;
   }

   public void setUserId(Integer userId) {
      this.userId = userId;
   }

   public Integer getPromotionId() {
      return promotionId;
   }

   public void setPromotionId(Integer promotionId) {
      this.promotionId = promotionId;
   }

   public Integer getOperator() {
      return operator;
   }

   public void setOperator(Integer operator) {
      this.operator = operator;
   }

   public String getMemo() {
      return memo;
   }

   public void setMemo(String memo) {
      this.memo = memo;
   }

   public Date getCreateTime() {
      return createTime;
   }

   public void setCreateTime(Date createTime) {
      this.createTime = createTime;
   }

   public Date getUpdateTime() {
      return updateTime;
   }

   public void setUpdateTime(Date updateTime) {
      this.updateTime = updateTime;
   }
}