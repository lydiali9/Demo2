package com.inveno.ad.dsp.conf;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.StorageService;
import com.inveno.ad.dsp.validate.*;
import com.inveno.ad.dsp.vo.BaseVo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.MethodParameter;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author by sugang on 2018/3/30.
 */
@Configuration
@ConditionalOnBean(StorageService.class)
public class AppWebMvcConfigurer implements WebMvcConfigurer {

    private static Logger logger = LoggerFactory.getLogger(AppWebMvcConfigurer.class);
    @Autowired
    private AppConfigProperties appConfigProperties;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        try {
            Resource resource = new UrlResource(Paths.get(appConfigProperties.getFileRootLocation()).toUri());
            logger.debug("resource is exist : {}", resource.exists());
            String fileUrl = String.format("file:%s", resource.getURL().getPath());
            logger.debug("fileUrl : {}", fileUrl);
            registry.addResourceHandler(String.format("/%s/**", appConfigProperties.getFileRootLocation())).addResourceLocations(fileUrl);
        } catch (Exception e) {
            logger.error("Add resource error.", e);
        }
    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        argumentResolvers.add(new HandlerMethodArgumentResolver() {
            @Override
            public boolean supportsParameter(MethodParameter methodParameter) {
                return true;
            }

            @Override
            @SuppressWarnings("unchecked")
            public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {
                long startTime = System.currentTimeMillis();
                Object req = methodParameter.getParameter().getType().newInstance();
                HttpServletRequest request = ((ServletWebRequest) nativeWebRequest).getRequest();
                logger.debug("<#>sys|content-type:{}", request.getContentType());
                if (MediaType.APPLICATION_JSON.toString().equalsIgnoreCase(request.getContentType())
                        || MediaType.APPLICATION_JSON_UTF8.toString().equalsIgnoreCase(request.getContentType())) {
                    // 处理json请求
                    String jsonParam = getRequestPostStr(request);
                    logger.debug("<#>sys|jsonParam={}", jsonParam);
                    req = JSON.parseObject(jsonParam, req.getClass());
                } else {
                    Method[] methods = req.getClass().getMethods();
                    if (ArrayUtils.isNotEmpty(methods)) {
                        for (Method method : methods) {
                            if (method.getName().contains("set")) {
                                String fieldName = method.getName().substring(method.getName().indexOf("set") + 3);
                                String parameterName = String.format("%s%s", String.valueOf(fieldName.charAt(0)).toLowerCase(), fieldName.substring(1));
                                JSONField jsonFieldAnnotation = method.getAnnotation(JSONField.class);
                                if (null != jsonFieldAnnotation && StringUtils.isNotBlank(jsonFieldAnnotation.name())) {
                                    parameterName = jsonFieldAnnotation.name();
                                }
                                String value = request.getParameter(parameterName);
                                logger.debug("<#>sys|{}={}", parameterName, value);
                                if (StringUtils.isNotBlank(value)) {
                                    Class<?>[] parameterType = method.getParameterTypes();
                                    if (ArrayUtils.isNotEmpty(parameterType) && parameterType.length == 1) {
                                        Object arg = value;
                                        if (parameterType[0].isAssignableFrom(int.class) || parameterType[0].isAssignableFrom(Integer.class)) {
                                            arg = Integer.parseInt(value);
                                        } else if (parameterType[0].isAssignableFrom(double.class) || parameterType[0].isAssignableFrom(Double.class)) {
                                            arg = Double.parseDouble(value);
                                        } else if (parameterType[0].isAssignableFrom(long.class) || parameterType[0].isAssignableFrom(Long.class)) {
                                            arg = Long.parseLong(value);
                                        }
                                        method.invoke(req, arg);
                                    }
                                }
                            }
                        }
                    }
                }
                validate(req, request, methodParameter);
                logger.debug("Parameter adapt duration: {}ms", System.currentTimeMillis() - startTime);
                if (req instanceof BaseVo) {
                    HttpSession session = request.getSession();
                    UserModel userModel = (UserModel) session.getAttribute(Constants.SESSION_KEY_USER_INFO);
                    if (null != userModel) {
                        ((BaseVo) req).setOperator(userModel.getUserId());
                    }
                }
                return req;
            }
        });
    }

    private static byte[] getRequestPostBytes(HttpServletRequest request) throws IOException {
        int contentLength = request.getContentLength();
        if (contentLength < 0) {
            return null;
        }
        byte[] buffer = new byte[contentLength];
        for (int i = 0; i < contentLength; ) {
            int readLen = request.getInputStream().read(buffer, i, contentLength - i);
            if (readLen == -1) {
                break;
            }
            i += readLen;
        }
        return buffer;
    }

    private static String getRequestPostStr(HttpServletRequest request) throws IOException {
        byte[] buffer = getRequestPostBytes(request);
        String charEncoding = request.getCharacterEncoding();
        if (charEncoding == null) {
            charEncoding = StandardCharsets.UTF_8.displayName();
        }
        if (null != buffer) {
            return new String(buffer, charEncoding);
        }
        return null;
    }

    private void validate(Object req, HttpServletRequest request, MethodParameter methodParameter) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> violations;
        List<Class<?>> validateGroupClazz = getValidateGroup(request, methodParameter);
        if (null != validateGroupClazz) {
            violations = validator.validate(req, validateGroupClazz.toArray(new Class<?>[0]));
        } else {
            violations = validator.validate(req);
        }
        if (CollectionUtils.isNotEmpty(violations)) {
            ConstraintViolation<Object> err = violations.iterator().next();
            throw new DspException(RetCode.ERR_PARAM, err.getPropertyPath(), err.getInvalidValue());
        }
    }

    private List<Class<?>> getValidateGroup(HttpServletRequest request, MethodParameter methodParameter) {
        if (HttpMethod.POST.toString().equals(request.getMethod())) {
            return Collections.singletonList(PostValidatorGroup.class);
        } else if (HttpMethod.DELETE.toString().equals(request.getMethod())) {
            return Collections.singletonList(DeleteValidatorGroup.class);
        } else if (HttpMethod.PUT.toString().equals(request.getMethod())) {
            return Collections.singletonList(PutValidatorGroup.class);
        } else if (HttpMethod.GET.toString().equals(request.getMethod())) {
            if (methodParameter.hasParameterAnnotation(Pageable.class)) {
                return Arrays.asList(PageValidatorGroup.class, GetValidatorGroup.class);
            } else {
                return Collections.singletonList(GetValidatorGroup.class);
            }
        } else {
            return null;
        }
    }

}
