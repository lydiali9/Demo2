package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.common.AreaTypeEnum;
import com.inveno.ad.dsp.dao.AreaDao;
import com.inveno.ad.dsp.model.AreaModel;
import com.inveno.ad.dsp.service.AreaService;
import com.inveno.ad.dsp.vo.AreaVo;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AreaServiceImpl implements AreaService {

    @Autowired
    private AreaDao areaDao;

    @Override
    public AreaVo getArea() throws Exception {
        AreaVo areaVo = new AreaVo();
        List<AreaModel> areaModelList = areaDao.getAllArea();

        if (CollectionUtils.isNotEmpty(areaModelList)){
            HashMap<Integer, AreaVo.Province> provinceMapping = new HashMap<>();
            List<AreaVo.Province.City> cityList = new ArrayList<>();

            for (AreaModel area : areaModelList){
                Integer areaType = area.getAreaType();
                if (AreaTypeEnum.PROVINCE.getValue().equals(areaType)){
                    //省
                    AreaVo.Province province = AreaVo.createProvince();
                    province.setCapital(area.getCapital());
                    province.setId(area.getId());
                    province.setProvince(area.getName());
                    provinceMapping.put(area.getId(), province);
                } else if (AreaTypeEnum.CITY.getValue().equals(areaType)){
                    //市
                    AreaVo.Province.City city = AreaVo.Province.createCity();
                    city.setId(area.getId());
                    city.setCity(area.getName());
                    city.setParentId(area.getParentId());
                    cityList.add(city);
                }
            }
            if (CollectionUtils.isNotEmpty(cityList)){
                for (AreaVo.Province.City city : cityList){
                    Integer parentId = city.getParentId();
                    if (provinceMapping.containsKey(parentId)){
                        AreaVo.Province province = provinceMapping.get(parentId);
                        province.addCity(city);
                    }
                }
            }

            for (Map.Entry<Integer, AreaVo.Province> entry : provinceMapping.entrySet()){
                areaVo.addProvince(entry.getValue());
            }
        }
        return areaVo;
    }
}
