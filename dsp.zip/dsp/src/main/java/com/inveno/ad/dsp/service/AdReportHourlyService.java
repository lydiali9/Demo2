package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.vo.AdReportHourlyVo;

import java.util.List;

public interface AdReportHourlyService {

    List<AdReportHourlyVo> queryPromotion(AdReportHourlyVo adReportHourlyVo, Integer userId);

    List<AdReportHourlyVo> queryAd(AdReportHourlyVo adReportHourlyVo, Integer userId);

    List<AdReportHourlyVo> queryUser(AdReportHourlyVo adReportHourlyVo, Integer userId);

}
