package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.StorageFolderEnum;
import com.inveno.ad.dsp.service.StorageService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.stream.Collectors;

/**
 * <p>Title: {@link FileUploadController}</p>
 * <p>Description: 用于文件上传 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/7
 */
@Controller
public class FileUploadController {

    private StorageService storageServiceImpl;

    @Autowired
    public FileUploadController(StorageService storageServiceImpl) {
        this.storageServiceImpl = storageServiceImpl;
    }

    @GetMapping("/upload")
    public String listUploadedFiles(Model model) {
        model.addAttribute("files", storageServiceImpl.loadAll().map(
                path -> String.format("%s/files/%s",
                        ServletUriComponentsBuilder.fromCurrentServletMapping().toUriString(),
                        path.toFile().toString().replaceAll("\\\\", "/")))
                .collect(Collectors.toList()));
        return "upload";
    }

    @GetMapping(value = "/files/{folder:[0-9]+}/{fileName:.+}")
    @ResponseBody
    public ResponseEntity<Resource> serveFile(@PathVariable("folder") String folder, @PathVariable("fileName") String fileName) {
        String absFileName;
        if (StringUtils.isNotBlank(folder)) {
            absFileName = String.format("%s/%s", folder, fileName);
        } else {
            absFileName = fileName;
        }
        Resource file = storageServiceImpl.loadAsResource(absFileName);
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
    }

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file,
                                   RedirectAttributes redirectAttributes) {
        storageServiceImpl.store(file, StorageFolderEnum.app.name());
        redirectAttributes.addFlashAttribute("message",
                "You successfully uploaded " + file.getOriginalFilename() + "!");
        return "redirect:/upload";
    }

}
