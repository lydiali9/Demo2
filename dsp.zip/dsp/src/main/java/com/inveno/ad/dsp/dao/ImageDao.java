package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.ImageModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p>Title: {@link ImageDao} </p>
 * <p>Description: 图片DAO类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/18
 */
@Mapper
public interface ImageDao {

    /**
     * 插入素材图片
     * @param imageModel 新图片详情
     * @return 影响行数
     */
    @Insert(
            "INSERT INTO dspv2_t_image" +
                    "(" +
                    "img_server_url, url, user_id, width, height, format, ratio, tag, is_template, template_id, title, " +
                    "create_time, update_time, status, type, big_image_type" +
                    ")" +
                    "VALUES " +
                    "(" +
                    "#{imgServerUrl}, #{url}, #{userId}, #{width}, #{height}, " +
                    "#{format},#{ratio},#{tag}, #{isTemplate},#{templateId}," +
                    "#{title},#{createTime},#{updateTime},#{status},#{type}," +
                    "#{bigImageType}" +
                    ")"
    )
    @Options(useGeneratedKeys = true, keyProperty = "imageId")
    Integer insert(ImageModel imageModel);

    /**
     * 批量插入图片数据
     * @param imageModelList 新数据
     * @return 影响行数
     */
    @InsertProvider(type = ImageDaoSqlProvider.class, method = "batchInsert")
    @Options(useGeneratedKeys = true, keyProperty = "imageId")
    Integer batchInsert(List<ImageModel> imageModelList);

    /**
     * 根据图片ID查询
     * @param imageIdList 图片ID
     * @return 满足条件的记录
     */
    @SelectProvider(type = ImageDaoSqlProvider.class, method = "selectByImageIdList")
    @Results({
            @Result(property = "imageId", column = "image_id"),
            @Result(property = "imgServerUrl", column = "img_server_url"),
            @Result(property = "url", column = "url"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "width", column = "width"),
            @Result(property = "height", column = "height"),
            @Result(property = "format", column = "format"),
            @Result(property = "ratio", column = "ratio"),
            @Result(property = "tag", column = "tag"),
            @Result(property = "isTemplate", column = "is_template"),
            @Result(property = "templateId", column = "template_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "type", column = "type"),
            @Result(property = "bigImageType", column = "big_image_type")
    })
    List<ImageModel> selectByImageIdList(List<Long> imageIdList);

    /**
     * 根据UID分页查询图片模板总数
     * @param pageModel 分页条件
     * @return 符合条件的图片数量
     */
    @SelectProvider(type = ImageDaoSqlProvider.class, method = "pageQueryTotalCount")
    int pageQueryTotalCount(PageModel<ImageModel> pageModel);

    /**
     * 根据UID分页查询图片模板列表
     * @param pageModel 分页条件
     * @return 符合条件的记录
     */
    @SelectProvider(type = ImageDaoSqlProvider.class, method = "pageQuery")
    @Results({
            @Result(property = "imageId", column = "image_id"),
            @Result(property = "imgServerUrl", column = "img_server_url"),
            @Result(property = "url", column = "url"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "width", column = "width"),
            @Result(property = "height", column = "height"),
            @Result(property = "format", column = "format"),
            @Result(property = "ratio", column = "ratio"),
            @Result(property = "tag", column = "tag"),
            @Result(property = "isTemplate", column = "is_template"),
            @Result(property = "templateId", column = "template_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "type", column = "type"),
            @Result(property = "bigImageType", column = "big_image_type")
    })
    List<ImageModel> pageQuery(PageModel<ImageModel> pageModel);

}
