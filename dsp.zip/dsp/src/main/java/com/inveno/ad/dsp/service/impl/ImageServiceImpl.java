package com.inveno.ad.dsp.service.impl;

import com.alibaba.fastjson.JSON;
import com.inveno.ad.dsp.bean.ImageCropBean;
import com.inveno.ad.dsp.bean.ImageServiceRespBean;
import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.conf.AppConfigProperties;
import com.inveno.ad.dsp.dao.ImageDao;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.ImageModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.service.ImageService;
import com.inveno.ad.dsp.service.ImageSyncService;
import com.inveno.ad.dsp.service.StorageService;
import net.coobird.thumbnailator.ThumbnailParameter;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.name.Rename;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * <p>Title: {@link ImageServiceImpl}</p>
 * <p>Description: 图片service实现类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/18
 */
@Service
public class ImageServiceImpl implements ImageService {

    private static Logger logger = LoggerFactory.getLogger(ImageServiceImpl.class);

    @Autowired
    private StorageService storageService;
    @Autowired
    private ImageDao imageDao;
    @Autowired
    private ImageSyncService imageSyncService;
    @Autowired
    private AppConfigProperties appConfigProperties;

    @Override
    public void uploadImage(ImageModel imageModel) throws Exception {
        storageService.store(imageModel.getInputStream(),
                imageModel.getFolder(),
                imageModel.getName());
        String resourcePath = String.format("%s/%s", imageModel.getFolder(), imageModel.getName());
        Resource resource = storageService.loadAsResource(resourcePath);
        parseImage(imageModel, resource);
        try {
            sizeCheck(imageModel);
        } catch (Exception e) {
            storageService.delete(resourcePath);
            throw e;
        }
    }

    @Override
    public ImageModel crop(ImageModel imageModel) throws Exception {
        ImageModel cropImageModel = new ImageModel();
        String resourcePath = String.format("%s/%s", imageModel.getFolder(), imageModel.getName());
        Resource resource = storageService.loadAsResource(resourcePath);
        String cropFolder = String.format("%d/%s/%s", imageModel.getUserId(), StorageFolderEnum.img, LocalDate.now());
        Resource cropFolderResource = storageService.loadAsResource(cropFolder);
        String cropImageName = String.format("%s-%d×%d-%d%s",
                imageModel.getName().substring(0, imageModel.getName().lastIndexOf(Constants.SEPARATOR_POINT_WITH_OUT_ESCAPE)),
                imageModel.getWidth(),
                imageModel.getHeight(),
                System.currentTimeMillis(),
                imageModel.getName().substring(imageModel.getName().lastIndexOf(Constants.SEPARATOR_POINT_WITH_OUT_ESCAPE))
        );
        Thumbnails.of(resource.getFile(), resource.getFile())
                .forceSize(imageModel.getWidth(), imageModel.getHeight())
                .toFiles(cropFolderResource.getFile(), new Rename() {
                    @Override
                    public String apply(String s, ThumbnailParameter thumbnailParameter) {
                        return cropImageName;
                    }
                });
        cropImageModel.setFolder(cropFolder);
        cropImageModel.setName(cropImageName);
        cropImageModel.setWidth(imageModel.getWidth());
        cropImageModel.setHeight(imageModel.getHeight());
        cropImageModel.setFormat(imageModel.getFormat());
        cropImageModel.setRatio(BigDecimal.valueOf(imageModel.getWidth()).divide(BigDecimal.valueOf(imageModel.getHeight()), 2, BigDecimal.ROUND_HALF_UP).doubleValue());
        return cropImageModel;
    }

    @Override
    public void pageQuery(PageModel<ImageModel> pageModel) {
        pageModel.getRequest().setIsTemplate(BoolEnum.YES.getValue());
        int totalCount = imageDao.pageQueryTotalCount(pageModel);
        pageModel.setTotalCount(totalCount);
        if (totalCount > 0) {
            List<ImageModel> adModelList = imageDao.pageQuery(pageModel);
            pageModel.setResponse(adModelList);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long create(ImageModel imageModel) throws Exception {
        try {
            ImageServiceRespBean imageServiceRespBean = imageSyncService.upload(imageModel.getUrl());
            imageModel.setIsTemplate(BoolEnum.YES.getValue());
            imageModel.setStatus(0);
            imageModel.setCreateTime(new Date());
            imageModel.setImgServerUrl(imageServiceRespBean.getUrl());
            imageDao.insert(imageModel);
            return imageModel.getImageId();
        } catch (Exception e) {
            String absFilePath = String.format("%s/%s", imageModel.getFolder(), imageModel.getName());
            storageService.delete(absFilePath);
            throw e;
        }
    }

    /**
     * 1、原图内部的截取，则取原图XY轴的RGB填充。
     * 2、如果X、Y轴有超出，则按照指定RGB填充。
     * @param imageModel 裁剪图片详情
     */
    @Override
    public ImageModel uploadAndCrop(ImageModel imageModel, byte[] data) throws Exception {
        logger.debug("parameters : {}", JSON.toJSONString(imageModel));
        // 1、保存原始图片
        String uniqueSerialNum = DigestUtils.md5Hex(data);
        String format = imageModel.getName().substring(imageModel.getName().lastIndexOf(Constants.SEPARATOR_POINT_WITH_OUT_ESCAPE) + 1);
        String uniqueImageName = String.format("%s.%s", uniqueSerialNum, format);
        String absoluteName = String.format("%s/%s", imageModel.getFolder(), uniqueImageName);
        boolean isExist = storageService.exist(absoluteName);
        logger.debug("file is existed = {}", isExist);
        if (!isExist) {
            try (InputStream inputStream = new ByteArrayInputStream(data)) {
                storageService.store(inputStream, imageModel.getFolder(), uniqueImageName);
            }
        }

        ImageCropBean imageCropBean = imageModel.getImageCropBean();
        Resource resource = storageService.loadAsResource(absoluteName);
        BufferedImage bufferedImage;
        try (InputStream resourceInputStream = resource.getInputStream()) {
            bufferedImage = ImageIO.read(resourceInputStream);
            imageModel.setFormat(format);
            imageModel.setAbsoluteName(resource.getURL().getPath());
            imageModel.setName(uniqueImageName);
            imageModel.setWidth(bufferedImage.getWidth());
            imageModel.setHeight(bufferedImage.getHeight());
        }
        if (null == imageCropBean
                || null == imageCropBean.getCropHeight()
                || null == imageCropBean.getCropWidth()
                || null == imageCropBean.getCropX()
                || null == imageCropBean.getCropY()) {
            logger.info("no need crop.");
            double ratio = BigDecimal.valueOf(bufferedImage.getWidth()).divide(BigDecimal.valueOf(bufferedImage.getHeight()), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
            imageModel.setRatio(ratio);
        } else {
            int srcImageWidth = imageModel.getWidth();
            int srcImageHeight = imageModel.getHeight();

            // 需要截取
            // 1、x轴大于0，左边要截取原图。
            //    startX = x;
            //    1.1) 如果x + width < srcImageWidth, endX = x + width;
            //    1.2) 如果x + width >= srcImageWidth, endX = srcImageWidth;
            // 2、y轴大于0，上边需要截取原图。
            //    startY = y;
            //    2.1) 如果y + height < srcImageHeight, endY = y + height;
            //    2.2) 如果y + height >= srcImageHeight, endY = srcImageHeight;
            // 3、x轴小于0。
            //    startX = 0;
            //    3.1) 如果x + width < srcImageWidth, endX = x + width。
            //    3.2) 如果x + width > srcImageWidth，endX = srcImageWidth，不需要截图。
            // 4、y轴小于0。
            //    startY = 0;
            //    4.1) 如果y + height < srcImageHeight, endY = y + height;
            //    4.2) 如果y + height > srcImageHeight, endY = srcImageHeight，不需要截图。
            boolean isNeedCrop = (imageCropBean.getCropX() > 0 || (imageCropBean.getCropX() <= 0 && (imageCropBean.getCropX() + imageCropBean.getCropWidth() < srcImageWidth)))
                    || (imageCropBean.getCropY() > 0 || (imageCropBean.getCropY() <= 0 && (imageCropBean.getCropY() + imageCropBean.getCropHeight() < srcImageHeight)));
            BufferedImage cropBufferedImage = null;
            if (isNeedCrop) {
                int startX = 0;
                int endX = srcImageWidth;
                int startY = 0;
                int endY = srcImageHeight;
                if (imageCropBean.getCropX() > 0) {
                    startX = imageCropBean.getCropX();
                    if (imageCropBean.getCropX() + imageCropBean.getCropWidth() < srcImageWidth) {
                        endX = imageCropBean.getCropX() + imageCropBean.getCropWidth();
                    } else {
                        endX = srcImageWidth;
                    }
                } else {
                    if (imageCropBean.getCropX() + imageCropBean.getCropWidth() < srcImageWidth) {
                        endX = imageCropBean.getCropX() + imageCropBean.getCropWidth();
                    }
                }
                if (imageCropBean.getCropY() > 0) {
                    startY = imageCropBean.getCropY();
                    if (imageCropBean.getCropY() + imageCropBean.getCropHeight() < srcImageHeight) {
                        endY = imageCropBean.getCropY() + imageCropBean.getCropHeight();
                    } else {
                        endY = srcImageHeight;
                    }
                } else {
                    if (imageCropBean.getCropY() + imageCropBean.getCropHeight() < srcImageHeight) {
                        endY = imageCropBean.getCropY() + imageCropBean.getCropHeight();
                    }
                }
                cropBufferedImage = new BufferedImage(endX - startX, endY - startY, BufferedImage.TYPE_INT_BGR);
                for (int x = startX; x < endX; x++) {
                    for (int y = startY; y < endY; y++) {
                        int rgb = bufferedImage.getRGB(x, y);
                        cropBufferedImage.setRGB(x - startX, y - startY, rgb);
                    }
                }
            }

            // 需要填充
            // 1、x轴大于等于0。
            //    1.1) 如果x + width > srcImageWidth, fillPointX = 0;
            //    1.2) 如果x + width <= srcImageWidth, 不需要填充;
            // 2、y轴大于等于0。
            //    2.1) 如果y + height > srcImageHeight, fillPointY = 0;
            //    2.2) 如果y + height <= srcImageHeight, 不需要填充;
            // 3、x轴小于0。
            //    fillPointX = |x|;
            // 4、y轴小于0。
            //    fillPointX = |y|;
            boolean isNeedFill = ((imageCropBean.getCropX() >= 0 && (imageCropBean.getCropX() + imageCropBean.getCropWidth() > srcImageWidth))
                    || (imageCropBean.getCropY() >= 0 && (imageCropBean.getCropY() + imageCropBean.getCropHeight()) > srcImageHeight))
                    || imageCropBean.getCropX() < 0 || imageCropBean.getCropY() < 0;
            BufferedImage fillBufferedImage = null;
            int fillPointX = imageCropBean.getCropX() < 0 ? 0 - imageCropBean.getCropX() : 0;
            int fillPointY = imageCropBean.getCropY() < 0 ? 0 - imageCropBean.getCropY() : 0;
            if (isNeedFill) {
                fillBufferedImage = new BufferedImage(imageCropBean.getCropWidth(), imageCropBean.getCropHeight(), BufferedImage.TYPE_INT_BGR);
                Graphics2D graphics2D = (Graphics2D) fillBufferedImage.getGraphics();
                graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                graphics2D.setColor(Color.white);
                graphics2D.fillRect(0, 0, imageCropBean.getCropWidth(), imageCropBean.getCropHeight());
                graphics2D.dispose();
            }
            Resource cropFolderResource = storageService.loadAsResource(imageModel.getFolder());
            if (null != cropBufferedImage && null == fillBufferedImage) {
                // 截取
                logger.debug("crop");
                try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
                    ImageIO.write(cropBufferedImage, format, os);
                    try (InputStream is = new ByteArrayInputStream(os.toByteArray())) {
                        final String imageTempName = String.format("%s-temp.%s", uniqueSerialNum, imageModel.getFormat());
                        String imageTempPath = String.format("%s/%s", imageModel.getFolder(), imageTempName);
                        storageService.store(is, imageTempPath);
                        renameWithMd5sum(imageModel, cropFolderResource, imageTempName);
                    }
                }
            } else if (null == cropBufferedImage && null != fillBufferedImage) {
                // 填充
                logger.debug("fill");
                String watermarkImageName = watermark(imageModel, fillBufferedImage, fillPointX, fillPointY, bufferedImage, uniqueSerialNum, cropFolderResource);
                renameWithMd5sum(imageModel, cropFolderResource, watermarkImageName);
            } else if (null != cropBufferedImage) {
                // 截取并填充
                logger.debug("crop and fill");
                try (ByteArrayOutputStream cropImageOs = new ByteArrayOutputStream()) {
                    ImageIO.write(cropBufferedImage, format, cropImageOs);
                    String cropImageName = String.format("%s/%s-crop.%s",
                            imageModel.getFolder(),
                            uniqueSerialNum,
                            imageModel.getFormat());
                    try (InputStream is = new ByteArrayInputStream(cropImageOs.toByteArray())) {
                        storageService.store(is, cropImageName);
                        String watermarkImageName = watermark(imageModel, fillBufferedImage, fillPointX, fillPointY, cropBufferedImage, uniqueSerialNum, cropFolderResource);
                        renameWithMd5sum(imageModel, cropFolderResource, watermarkImageName);
                    } finally {
                        storageService.delete(cropImageName);
                    }
                }
            }
            double ratio = BigDecimal.valueOf(imageCropBean.getCropWidth()).divide(BigDecimal.valueOf(imageCropBean.getCropHeight()), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
            imageModel.setWidth(imageCropBean.getCropWidth());
            imageModel.setHeight(imageCropBean.getCropHeight());
            imageModel.setRatio(ratio);
        }
        try {
            sizeCheck(imageModel);
        } catch (Exception e) {
            storageService.delete(absoluteName);
            throw e;
        }
        return imageModel;
    }

    @Override
    public void delete(ImageModel imageModel) throws Exception {
        storageService.delete(imageModel.getAbsoluteName());
    }

    private void parseImage(ImageModel imageModel, Resource resource) throws IOException {
        try (InputStream inputStream = resource.getInputStream()) {
            BufferedImage bufferedImage = ImageIO.read(inputStream);
            double ratio = BigDecimal.valueOf(bufferedImage.getWidth()).divide(BigDecimal.valueOf(bufferedImage.getHeight()), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
            imageModel.setWidth(bufferedImage.getWidth());
            imageModel.setHeight(bufferedImage.getHeight());
            imageModel.setFormat(imageModel.getName().substring(imageModel.getName().lastIndexOf(".") + 1));
            imageModel.setRatio(ratio);
            imageModel.setAbsoluteName(resource.getURL().getPath());
        }
    }

    private void sizeCheck(ImageModel imageModel) {
        if (appConfigProperties.isImageCheckOpen()) {
            logger.debug("check image info: {}", JSON.toJSONString(imageModel));
            if (imageModel.getType() == ImageTypeEnum.SMALL_IMAGE.getValue()) {
                if (imageModel.getRatio() < appConfigProperties.getSmallImageRatio() - appConfigProperties.getRatioTolerance()
                        || imageModel.getRatio() > appConfigProperties.getSmallImageRatio() + appConfigProperties.getRatioTolerance()) {
                    throw new DspException(RetCode.ERR_IMG_SMALL_RATIO, appConfigProperties.getSmallImageRatio(), appConfigProperties.getRatioTolerance());
                } else {
                    imageModel.setRatio(appConfigProperties.getSmallImageRatio());
                }
                if (imageModel.getWidth() < appConfigProperties.getSmallImageMinWidth()) {
                    throw new DspException(RetCode.ERR_IMG_SMALL_MIN_WIDTH, appConfigProperties.getSmallImageMinWidth());
                }
                if (imageModel.getHeight() < appConfigProperties.getSmallImageMinHeight()) {
                    throw new DspException(RetCode.ERR_IMG_SMALL_MIN_HEIGHT, appConfigProperties.getSmallImageMinHeight());
                }
            } else if (imageModel.getType() == ImageTypeEnum.BIG_IMAGE.getValue()) {
                if (BigImageTypeEnum.BANNER.getValue() == imageModel.getBigImageType()) {
                    if (imageModel.getRatio() < appConfigProperties.getBannerImageRatio() - appConfigProperties.getRatioTolerance()
                            || imageModel.getRatio() > appConfigProperties.getBannerImageRatio() + appConfigProperties.getRatioTolerance()) {
                        throw new DspException(RetCode.ERR_IMG_BANNER_RATIO, appConfigProperties.getBannerImageRatio(), appConfigProperties.getRatioTolerance());
                    } else {
                        imageModel.setRatio(appConfigProperties.getBannerImageRatio());
                    }
                    if (imageModel.getHeight() < appConfigProperties.getBannerImageMinHeight()) {
                        throw new DspException(RetCode.ERR_IMG_BANNER_MIN_HEIGHT, appConfigProperties.getBannerImageMinHeight());
                    }
                    if (imageModel.getWidth() < appConfigProperties.getBannerImageMinWidth()) {
                        throw new DspException(RetCode.ERR_IMG_BANNER_MIN_WIDTH, appConfigProperties.getBannerImageMinWidth());
                    }
                } else if (BigImageTypeEnum.HORIZONTAL.getValue() == imageModel.getBigImageType()) {
                    if (imageModel.getRatio() < appConfigProperties.getHorizontalImageRatio() - appConfigProperties.getRatioTolerance()
                            || imageModel.getRatio() > appConfigProperties.getHorizontalImageRatio() + appConfigProperties.getRatioTolerance()) {
                        throw new DspException(RetCode.ERR_IMG_HORIZONTAL_RATIO, appConfigProperties.getHorizontalImageRatio(), appConfigProperties.getRatioTolerance());
                    } else {
                        imageModel.setRatio(appConfigProperties.getHorizontalImageRatio());
                    }
                    if (imageModel.getHeight() < appConfigProperties.getHorizontalImageMinHeight()) {
                        throw new DspException(RetCode.ERR_IMG_HORIZONTAL_MIN_HEIGHT, appConfigProperties.getHorizontalImageMinHeight());
                    }
                    if (imageModel.getWidth() < appConfigProperties.getHorizontalImageMinWidth()) {
                        throw new DspException(RetCode.ERR_IMG_HORIZONTAL_MIN_WIDTH, appConfigProperties.getHorizontalImageMinWidth());
                    }
                } else if (BigImageTypeEnum.VERTICAL.getValue() == imageModel.getBigImageType()) {
                    if (imageModel.getRatio() < appConfigProperties.getVerticalImageRatio() - appConfigProperties.getRatioTolerance()
                            || imageModel.getRatio() > appConfigProperties.getVerticalImageRatio() + appConfigProperties.getRatioTolerance()) {
                        throw new DspException(RetCode.ERR_IMG_VERTICAL_RATIO, appConfigProperties.getVerticalImageRatio(), appConfigProperties.getRatioTolerance());
                    } else {
                        imageModel.setRatio(appConfigProperties.getVerticalImageRatio());
                    }
                    if (imageModel.getHeight() < appConfigProperties.getVerticalImageMinHeight()) {
                        throw new DspException(RetCode.ERR_IMG_VERTICAL_MIN_HEIGHT, appConfigProperties.getVerticalImageMinHeight());
                    }
                    if (imageModel.getWidth() < appConfigProperties.getVerticalImageMinWidth()) {
                        throw new DspException(RetCode.ERR_IMG_VERTICAL_MIN_WIDTH, appConfigProperties.getVerticalImageMinWidth());
                    }
                }
            } else if (imageModel.getType() == ImageTypeEnum.IMAGE_GROUP.getValue()) {
                if (imageModel.getRatio() < appConfigProperties.getSmallImageRatio() - appConfigProperties.getRatioTolerance()
                        || imageModel.getRatio() > appConfigProperties.getSmallImageRatio() + appConfigProperties.getRatioTolerance()) {
                    throw new DspException(RetCode.ERR_IMG_GROUP_MIN_WIDTH, appConfigProperties.getSmallImageRatio(), appConfigProperties.getRatioTolerance());
                } else {
                    imageModel.setRatio(appConfigProperties.getSmallImageRatio());
                }
                if (imageModel.getWidth() < appConfigProperties.getSmallImageMinWidth()) {
                    throw new DspException(RetCode.ERR_IMG_GROUP_MIN_HEIGHT, appConfigProperties.getSmallImageMinWidth());
                }
                if (imageModel.getHeight() < appConfigProperties.getSmallImageMinHeight()) {
                    throw new DspException(RetCode.ERR_IMG_GROUP_RATIO, appConfigProperties.getSmallImageMinHeight());
                }
            }
        }
    }

    private String watermark(ImageModel imageModel,
                             BufferedImage backgroundBufferedImage,
                             int watermarkStartPointX,
                             int watermarkStartPointY,
                             BufferedImage watermarkBufferedImage,
                             String uniqueSerialNum,
                             Resource folderResource) throws Exception {
        String backgroundImageName = String.format("%s/%s-background.%s",
                imageModel.getFolder(),
                uniqueSerialNum,
                imageModel.getFormat());
        // 加水印并保存到临时文件
        final String watermarkImageName = String.format("%s-temp.%s", uniqueSerialNum, imageModel.getFormat());
        try (ByteArrayOutputStream fillImageOs = new ByteArrayOutputStream()) {
            ImageIO.write(backgroundBufferedImage, imageModel.getFormat(), fillImageOs);
            try (InputStream is = new ByteArrayInputStream(fillImageOs.toByteArray())) {
                storageService.store(is, backgroundImageName);
                Resource fillImageResource = storageService.loadAsResource(backgroundImageName);
                Thumbnails.of(fillImageResource.getFile())
                        .size(imageModel.getImageCropBean().getCropWidth(), imageModel.getImageCropBean().getCropHeight())
                        .watermark((enclosingWidth, enclosingHeight, width, height, insetLeft, insetRight, insetTop, insetBottom) -> new Point(watermarkStartPointX, watermarkStartPointY), watermarkBufferedImage, 1f)
                        .toFiles(folderResource.getFile(), new Rename() {
                            @Override
                            public String apply(String s, ThumbnailParameter thumbnailParameter) {
                                return watermarkImageName;
                            }
                        });
                // 根据md5值重命名
            } finally {
                storageService.delete(backgroundImageName);
            }
        }
        return watermarkImageName;
    }

    private void renameWithMd5sum(ImageModel imageModel, Resource folderResource, String srcName) throws Exception {
        // 根据md5值重命名
        String srcPath = String.format("%s/%s", folderResource.getFile(), srcName);
        Resource imageTempResource = storageService.loadAsResource(srcPath);
        String cropUniqueSerialNum;
        try (InputStream imageTempInputStream = imageTempResource.getInputStream()) {
            cropUniqueSerialNum = DigestUtils.md5Hex(imageTempInputStream);
        }
        String cropImageName = String.format("%s/%s.%s", folderResource.getFile(), cropUniqueSerialNum, imageModel.getFormat());
        if (!storageService.exist(cropImageName)) {
            storageService.move(srcPath, cropImageName);
        }
        imageModel.setAbsoluteName(cropImageName);
        imageModel.setName(String.format("%s.%s", cropUniqueSerialNum, imageModel.getFormat()));
        storageService.delete(srcPath);
    }

}
