package com.inveno.ad.dsp.vo;

import com.alibaba.fastjson.annotation.JSONField;

import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;

public class AreaVo extends BaseVo {

    private List<Province> provinces;

    public static Province createProvince() {
        return new Province();
    }

    public void addProvince(Integer id, String provinceName, String capital){

    }

    public void addProvince(Province province) {
        if (this.provinces == null) {
            this.provinces = new ArrayList<>();
        }
        this.provinces.add(province);
    }


    public static class Province extends BaseVo {
        private Integer id;
        private String province;
        private String capital;
        private List<City> cities;

        Province() {

        }

        Province(Integer id, String province){
            this(id, province, null);
        }

        Province(Integer id, String province, String capital){
            this(id, province, capital, null);
        }

        Province(Integer id, String province, String capital, List<City> cities){
            this.id = id;
            this.province = province;
            this.capital = capital;
            this.cities = cities;
        }

        public static City createCity() {
            return new City();
        }

        public void addCity(Integer id, String cityName){
            City city = new City(id, cityName);
            this.addCity(city);
        }

        public void addCity(City city) {
            if (this.cities == null) {
                this.cities = new ArrayList<>();
            }
            this.cities.add(city);
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getProvince() {
            return province;
        }

        public void setProvince(String province) {
            this.province = province;
        }

        public String getCapital() {
            return capital;
        }

        public void setCapital(String capital) {
            this.capital = capital;
        }

        public List<City> getCities() {
            return cities;
        }

        public void setCities(List<City> cities) {
            this.cities = cities;
        }

        public static class City extends BaseVo {
            private String city;
            private Integer id;

            @JSONField(serialize = false)
            private Integer parentId;

            City(){

            }

            City(Integer id, String city) {
                this(id, city, null);
            }

            City(Integer id, String city, Integer parentId){
                this.id = id;
                this.city = city;
                this.parentId = parentId;
            }

            public String getCity() {
                return city;
            }

            public void setCity(String city) {
                this.city = city;
            }

            public Integer getId() {
                return id;
            }

            public void setId(Integer id) {
                this.id = id;
            }

            public Integer getParentId() {
                return parentId;
            }

            public void setParentId(Integer parentId) {
                this.parentId = parentId;
            }
        }
    }

    public List<Province> getProvinces() {
        return provinces;
    }

    public void setProvinces(List<Province> provinces) {
        this.provinces = provinces;
    }
}
