package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.vo.AreaVo;

public interface AreaService {

    AreaVo getArea() throws Exception;
}
