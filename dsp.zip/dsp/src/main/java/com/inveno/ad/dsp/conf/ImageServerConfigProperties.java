package com.inveno.ad.dsp.conf;

import com.inveno.ad.dsp.common.ImgQualityEnum;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p>Title: {@link ImageServerConfigProperties} </p>
 * <p>Description: 云图服务器配置项 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/10
 */
@ConfigurationProperties(
        "app.image"
)
public class ImageServerConfigProperties {

    private String host;
    private int port;
    private int timeout;
    private int initialBufferCapacity;
    private int maxLength;
    private String domain;
    private String quality;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getInitialBufferCapacity() {
        return initialBufferCapacity;
    }

    public void setInitialBufferCapacity(int initialBufferCapacity) {
        this.initialBufferCapacity = initialBufferCapacity;
    }

    public int getMaxLength() {
        return maxLength;
    }

    public void setMaxLength(int maxLength) {
        this.maxLength = maxLength;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }
}
