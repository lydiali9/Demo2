package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.UserModel;
import org.apache.ibatis.annotations.*;

public interface UserDao {

    @Select(
            " SELECT user_id,username,password,realname,position,telephone,email, " +
                    " userIp,lastIp,online,state,memo,create_time,last_upd_time, " +
                    " user_sys,type,firm_id,open_close,parent_id,is_propagate " +
                    "FROM t_user " +
                    "WHERE user_id=#{userId} " +
                    "LIMIT 1"
    )
    @Results(
            {
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "username", column = "username"),
                    @Result(property = "password", column = "password"),
                    @Result(property = "realname", column = "realname"),
                    @Result(property = "position", column = "position"),
                    @Result(property = "telephone", column = "telephone"),
                    @Result(property = "email", column = "email"),
                    @Result(property = "userIp", column = "userIp"),
                    @Result(property = "lastIp", column = "lastIp"),
                    @Result(property = "online", column = "online"),
                    @Result(property = "state", column = "state"),
                    @Result(property = "memo", column = "memo"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "lastUpdTime", column = "last_upd_time"),
                    @Result(property = "userSys", column = "user_sys"),
                    @Result(property = "type", column = "type"),
                    @Result(property = "firmId", column = "firm_id"),
                    @Result(property = "openClose", column = "open_close"),
                    @Result(property = "parentId", column = "parent_id"),
                    @Result(property = "isPropagate", column = "is_propagate"),
            }
    )
    UserModel findByUserId(Integer userId);

    @Select(
            " SELECT user_id,username,password,realname,position,telephone,email, " +
                    " userIp,lastIp,online,state,memo,create_time,last_upd_time, " +
                    " user_sys,type,firm_id,open_close,parent_id,is_propagate " +
                    "FROM t_user " +
                    "WHERE username=#{username} " +
                    "LIMIT 1"
    )
    @Results(
            {
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "username", column = "username"),
                    @Result(property = "password", column = "password"),
                    @Result(property = "realname", column = "realname"),
                    @Result(property = "position", column = "position"),
                    @Result(property = "telephone", column = "telephone"),
                    @Result(property = "email", column = "email"),
                    @Result(property = "userIp", column = "userIp"),
                    @Result(property = "lastIp", column = "lastIp"),
                    @Result(property = "online", column = "online"),
                    @Result(property = "state", column = "state"),
                    @Result(property = "memo", column = "memo"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "lastUpdTime", column = "last_upd_time"),
                    @Result(property = "userSys", column = "user_sys"),
                    @Result(property = "type", column = "type"),
                    @Result(property = "firmId", column = "firm_id"),
                    @Result(property = "openClose", column = "open_close"),
                    @Result(property = "parentId", column = "parent_id"),
                    @Result(property = "isPropagate", column = "is_propagate"),
            }
    )
    UserModel findByUsername(String username);

    @Select(
            " SELECT user_id,username,password,realname,position,telephone,email, " +
                    " userIp,lastIp,online,state,memo,create_time,last_upd_time, " +
                    " user_sys,type,firm_id,open_close,parent_id,is_propagate " +
                    "FROM t_user " +
                    "WHERE email=#{email} " +
                    "LIMIT 1"
    )
    @Results(
            {
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "username", column = "username"),
                    @Result(property = "password", column = "password"),
                    @Result(property = "realname", column = "realname"),
                    @Result(property = "position", column = "position"),
                    @Result(property = "telephone", column = "telephone"),
                    @Result(property = "email", column = "email"),
                    @Result(property = "userIp", column = "userIp"),
                    @Result(property = "lastIp", column = "lastIp"),
                    @Result(property = "online", column = "online"),
                    @Result(property = "state", column = "state"),
                    @Result(property = "memo", column = "memo"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "lastUpdTime", column = "last_upd_time"),
                    @Result(property = "userSys", column = "user_sys"),
                    @Result(property = "type", column = "type"),
                    @Result(property = "firmId", column = "firm_id"),
                    @Result(property = "openClose", column = "open_close"),
                    @Result(property = "parentId", column = "parent_id"),
                    @Result(property = "isPropagate", column = "is_propagate"),
            }
    )
    UserModel findByEmail(String email);



    /**
     * 新增系统用户
     * @param UserModel 用户信息
     * @return 新增用户id
     */
    @Insert(
            "INSERT INTO t_user(" +
                    " username, password, realname, position, telephone, email," +
                    " userIp, lastIp, online, state, memo, create_time, last_upd_time," +
                    " user_sys, type, firm_id, open_close, parent_id, is_propagate " +
                    ") " +
                    "VALUES(" +
                    "#{username}, #{password}, #{realname}, #{position}, #{telephone}, #{email}," +
                    "#{userIp}, #{lastIp}, #{online}, #{state},#{memo}, #{createTime}, #{lastUpdTime}," +
                    "#{userSys}, #{type}, #{firmId}, #{openClose}, #{parentId}, #{isPropagate}" +
                    ")"
    )
    @Options(useGeneratedKeys = true, keyColumn = "user_id", keyProperty = "userId")
    Integer insert(UserModel UserModel);

    @Update(
            "UPDATE t_user SET password=#{password} WHERE user_id = #{userId}"
    )
    Integer updatePwdByUserId(@Param("userId") Integer userId, @Param("password") String password);
}













