package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.BasePlatUserModel;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;

public interface BasePlatUserDao {

    @Insert(
            "INSERT INTO t_base_plat_user(" +
                    "user_id, plat_user_id, plat_id " +
                    " )" +
                    "VALUES(" +
                    "#{userId}, #{platUserId}, #{platId} " +
                    ")"
    )
    @Options(useGeneratedKeys = true)
    Integer saveBasePlatUser(BasePlatUserModel basePlatUserModel);
}
