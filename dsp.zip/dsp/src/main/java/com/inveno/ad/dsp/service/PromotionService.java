package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.model.PromotionModel;

import java.util.List;

/**
 * <p>Title: {@link PromotionService}</p>
 * <p>Description: 推广service类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
public interface PromotionService {

    /**
     * 创建推广计划
     * @param promotionModel 推广计划参数
     * @return 新生成推广计划D
     * @throws Exception 异常抛出
     */
    Long create(PromotionModel promotionModel) throws Exception;

    /**
     * 删除推广计划
     * @param id 推广计划ID
     * @return 是否删除成功
     * @throws Exception 异常处理
     */
    boolean delete(Integer id) throws Exception;

    /**
     * 更新推广计划
     * @param promotionModel 新的推广计划内容
     * @return 是否成功
     * @throws Exception 异常抛出
     */
    boolean update(PromotionModel promotionModel) throws Exception;

    /**
     * 分页查询推广计划
     * @param pageRequest 请求
     * @return 响应信息
     * @throws Exception 异常抛出
     */
    PageModel<PromotionModel> pageQuery(PageModel<PromotionModel> pageRequest) throws Exception;

    /**
     * 查询推广列表
     * @param promotionModel 查询条件
     * @return 响应信息
     * @throws Exception 异常抛出
     */
    List<PromotionModel> list(PromotionModel promotionModel) throws Exception;

    /**
     * 根据ID查询推广详情
     * @param id 推广ID
     * @return 推广详情
     * @throws Exception 异常抛出
     */
    PromotionModel getById(Long id) throws Exception;

    /**
     * 切换状态
     * @param promotionModel 推广ID，状态
     * @throws Exception 异常抛出
     */
    void switchPromotionStatus(PromotionModel promotionModel) throws Exception;

}
