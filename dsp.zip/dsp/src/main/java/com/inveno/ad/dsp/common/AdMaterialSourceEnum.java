package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link AdMaterialSourceEnum}</p>
 * <p>Description: 素材来源 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/4
 */
public enum AdMaterialSourceEnum {

    /**
     * 广告主
     */
    ADM("adm");

    private String value;

    AdMaterialSourceEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
