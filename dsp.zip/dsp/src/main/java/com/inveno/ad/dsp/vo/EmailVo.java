package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.validate.PostValidatorGroup;

import javax.validation.constraints.NotNull;

public class EmailVo extends BaseVo{

    @NotNull(groups = PostValidatorGroup.class)
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
