package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.model.AppModel;
import com.inveno.ad.dsp.model.PageModel;

import java.util.List;

/**
 * <p>Title: {@link AppService}</p>
 * <p>Description: 应用service类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
public interface AppService {

    /**
     * 应用上传
     * @param appModel 参数
     * @throws Exception 异常抛出
     */
    void upload(AppModel appModel) throws Exception;

    /**
     * 查询应用
     * @param appModel 查询条件
     * @return 满足条件的应用
     */
    List<AppModel> query(AppModel appModel);

    /**
     * 创建应用
     * @param appModel 新应用各个字段名
     * @return 新应用ID
     * @throws Exception 异常抛出
     */
    Integer create(AppModel appModel) throws Exception;

    /**
     * 应用后台上传
     * @param appModel 参数
     * @return 返回文件相对路径
     * @throws Exception 异常抛出
     */
    AppModel bgUpload(AppModel appModel) throws Exception;

    /**
     * 分页查询应用
     * @param pageRequest 请求
     * @return 响应信息
     * @throws Exception 异常抛出
     */
    PageModel<AppModel> pageQuery(PageModel<AppModel> pageRequest) throws Exception;

    /**
     * 删除应用
     * @param appModel 应用信息
     * @return 是否删除成功
     * @throws Exception 异常抛出
     */
    boolean delete(AppModel appModel) throws Exception;

    /**
     * 修改应用
     * @param appModel 更新后应用详情
     * @return 是否更新成功
     * @throws Exception 异常抛出
     */
    boolean update(AppModel appModel) throws Exception;

}
