package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.OrientationModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p>Title: {@link OrientationDao} </p>
 * <p>Description: dspv2_t_orientation处理sql </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
@Mapper
public interface OrientationDao {

    /**
     * 新增定向包
     * @param orientationModel 定向包详细信息
     * @return 新增定向包id
     */
    @Insert(
            "INSERT INTO dspv2_t_orientation(" +
                    "user_id, title, sex, age, platform," +
                    "network, network_operator, area, phone_brand, is_template," +
                    "operator, create_time, update_time, status" +
                    ")" +
                    "VALUES(" +
                    "#{userId},#{title},#{sex},#{age},#{platform}," +
                    "#{network},#{networkOperator},#{area},#{phoneBrand},#{isTemplate}," +
                    "#{operator},#{createTime},#{updateTime},#{status}" +
                    ")"
    )
    @Options(useGeneratedKeys = true)
    Integer insert(OrientationModel orientationModel);

    /**
     * 删除定向包
     * @param id 定向包ID
     * @return 影响行数
     */
    @Delete("DELETE FROM dspv2_t_orientation WHERE id = #{id}")
    Integer deleteById(Integer id);

    /**
     * 根据定向包ID修改内容
     * @param orientationModel 修改后的内容
     * @return 影响行数
     */
    @UpdateProvider(type = OrientationDaoSqlProvider.class, method = "updateById")
    Integer updateById(OrientationModel orientationModel);

    /**
     * 根据UID分页查询定向包信息总数
     * @param pageModel 分页条件
     * @return 符合条件的定向包数量
     */
    @SelectProvider(type = OrientationDaoSqlProvider.class, method = "pageQueryTotalCount")
    Integer pageQueryTotalCount(PageModel<OrientationModel> pageModel);

    /**
     * 根据UID分页查询定向包列表
     * @param pageModel 分页条件
     * @return 符合条件的定向包列表
     */
    @SelectProvider(type = OrientationDaoSqlProvider.class, method = "pageQuery")
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "title", column = "title"),
                    @Result(property = "sex", column = "sex"),
                    @Result(property = "age", column = "age"),
                    @Result(property = "platform", column = "platform"),
                    @Result(property = "network", column = "network"),
                    @Result(property = "networkOperator", column = "network_operator"),
                    @Result(property = "area", column = "area"),
                    @Result(property = "phoneBrand", column = "phone_brand"),
                    @Result(property = "isTemplate", column = "is_template"),
                    @Result(property = "operator", column = "operator"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "status", column = "status")
            }
    )
    List<OrientationModel> pageQuery(PageModel<OrientationModel> pageModel);

    /**
     * 根据ID查询
     * @param id 定向包ID
     * @return 定向包
     */
    @Select(
            "SELECT " +
                    " id, user_id, title, sex, age, platform," +
                    " network, network_operator, area, phone_brand, is_template, " +
                    " operator, create_time, update_time, status " +
                    " FROM dspv2_t_orientation t" +
                    " WHERE t.id = #{id}"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "title", column = "title"),
                    @Result(property = "sex", column = "sex"),
                    @Result(property = "age", column = "age"),
                    @Result(property = "platform", column = "platform"),
                    @Result(property = "network", column = "network"),
                    @Result(property = "networkOperator", column = "network_operator"),
                    @Result(property = "area", column = "area"),
                    @Result(property = "phoneBrand", column = "phone_brand"),
                    @Result(property = "isTemplate", column = "is_template"),
                    @Result(property = "operator", column = "operator"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "status", column = "status")
            }
    )
    OrientationModel selectById(Integer id);

    /**
     * 根据用户ID查询
     * @param userId 用户ID
     * @return 定向包列表
     */
    @Select(
            "SELECT " +
                    " id, user_id, title, sex, age, platform," +
                    " network, network_operator, area, phone_brand, is_template, " +
                    " operator, create_time, update_time, status " +
                    " FROM dspv2_t_orientation t" +
                    " WHERE t.user_id = #{userId} AND is_template=1"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "title", column = "title"),
                    @Result(property = "sex", column = "sex"),
                    @Result(property = "age", column = "age"),
                    @Result(property = "platform", column = "platform"),
                    @Result(property = "network", column = "network"),
                    @Result(property = "networkOperator", column = "network_operator"),
                    @Result(property = "area", column = "area"),
                    @Result(property = "phoneBrand", column = "phone_brand"),
                    @Result(property = "isTemplate", column = "is_template"),
                    @Result(property = "operator", column = "operator"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "status", column = "status")
            }
    )
    List<OrientationModel> selectOrientationTemplateByUserId(Integer userId);

}
