package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.validate.PostValidatorGroup;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

public class PersonalUserVo extends BaseVo {
    //联系人名称
    @NotNull(groups = PostValidatorGroup.class)
    private String contactName;
    //身份证号码
    @NotNull(groups = PostValidatorGroup.class)
    private String certifNo;
    //身份证图片地址
    @NotNull(groups = PostValidatorGroup.class)
    private String certifObversePath;
    //手机号码
    @NotNull(groups = PostValidatorGroup.class)
    private String telNo;
    //邮箱
    @Email(groups = PostValidatorGroup.class)
    private String email;
    //联系地址
    @NotNull(groups = PostValidatorGroup.class)
    private String addrDetail;
    //公司名称
    private String compName;
    //行业类型id
    @NotNull(groups = PostValidatorGroup.class)
    private String businessType;

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getCertifNo() {
        return certifNo;
    }

    public void setCertifNo(String certifNo) {
        this.certifNo = certifNo;
    }

    public String getCertifObversePath() {
        return certifObversePath;
    }

    public void setCertifObversePath(String certifObversePath) {
        this.certifObversePath = certifObversePath;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddrDetail() {
        return addrDetail;
    }

    public void setAddrDetail(String addrDetail) {
        this.addrDetail = addrDetail;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }
}
