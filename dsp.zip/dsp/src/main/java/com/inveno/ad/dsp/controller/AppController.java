package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.conf.AppConfigProperties;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.AppModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.AppService;
import com.inveno.ad.dsp.util.DateUtils;
import com.inveno.ad.dsp.vo.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.StandardMultipartHttpServletRequest;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriUtils;

import javax.servlet.http.HttpSession;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>Title: {@link AppController} </p>
 * <p>Description: 应用控制类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
@RestController
public class AppController {

    @Autowired
    private AppService appService;
    @Autowired
    private AppConfigProperties appConfigProperties;
    private static final String PARAM_NAME = "name";
    private static final String PARAM_FILE = "file";

    @PostMapping("/app/upload")
    @ResponseBody
    public VoContainer<AppVo> upload(StandardMultipartHttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();
        MultipartFile file = request.getFile(PARAM_FILE);
        if (appConfigProperties.getAppMaxSize() < file.getSize()) {
            throw new DspException(RetCode.ERR_APP_SIZE);
        }

        UserModel userModel = (UserModel) session.getAttribute(Constants.SESSION_KEY_USER_INFO);
        String folder = String.format("%d/%s/%s", userModel.getUserId(), StorageFolderEnum.app, LocalDate.now());
        AppModel appModel = new AppModel();
        appModel.setPackageSize(file.getSize());
        appModel.setFolder(folder);
        appModel.setRelativePath(String.format("%s/%s", folder, file.getOriginalFilename()));
        appModel.setName(file.getOriginalFilename());
        appModel.setInputStream(file.getInputStream());
        if (file.getOriginalFilename().endsWith(AppTypeEnum.apk.getSuffix())) {
            appModel.setOs(PlatformEnum.ANDROID.getLabel());
        } else if (file.getOriginalFilename().endsWith(AppTypeEnum.ipa.getSuffix())) {
            appModel.setOs(PlatformEnum.IOS.getLabel());
        } else {
            throw new DspException(RetCode.ERR_APP_TYPE);
        }
        appService.upload(appModel);
        String url = String.format("%s/%s/%s/%s",
                ServletUriComponentsBuilder.fromCurrentServletMapping().toUriString(),
                appConfigProperties.getFileRootLocation(),
                folder,
                UriUtils.encode(appModel.getAlias(), Charset.defaultCharset()));
        appModel.setUrl(url);
        AppVo appVo = new AppVo();
        BeanUtils.copyProperties(appModel, appVo);
        return VoContainerHelper.createVoContainer(appVo, RetCode.OK);
    }

    @PostMapping("/app")
    @ResponseBody
    public VoContainer create(AppVo appVo) throws Exception {
        AppModel appModel = voToModel(appVo);
        appModel.setUserId(appVo.getOperator());
        Integer id = appService.create(appModel);
        AppVo ret = new AppVo();
        ret.setId(id);
        return VoContainerHelper.createVoContainer(ret, RetCode.OK);
    }

    @PutMapping("/app")
    @ResponseBody
    public VoContainer update(AppVo appVo) throws Exception {
        AppModel appModel = voToModel(appVo);
        appService.update(appModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @DeleteMapping("/app")
    @ResponseBody
    public VoContainer<OrientationVo> delete(AppVo appVo) throws Exception {
        AppModel appModel = new AppModel();
        appModel.setUserId(appVo.getOperator());
        BeanUtils.copyProperties(appVo, appModel);
        appService.delete(appModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @GetMapping("/app/list")
    @ResponseBody
    public VoContainer<List<AppVo>> get(AppVo appVo) {
        List<AppVo> appVoList = null;
        AppModel paramAppModel = new AppModel();
        paramAppModel.setUserId(appVo.getOperator());
        List<AppModel> retAppModelList = appService.query(paramAppModel);
        if (CollectionUtils.isNotEmpty(retAppModelList)) {
            appVoList = new ArrayList<>(retAppModelList.size());
            for (AppModel retAppModel : retAppModelList) {
                AppVo retAppVo = modelToVo(retAppModel);
                appVoList.add(retAppVo);
            }
        }
        return VoContainerHelper.createVoContainer(appVoList, RetCode.OK);
    }

    @GetMapping("/app")
    @ResponseBody
    public VoContainer<List<AppVo>> pageQuery(AppVo appVo) throws Exception {
        AppModel appModel = new AppModel();
        appModel.setStartTime(DateUtils.parseDate(appVo.getStartTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        appModel.setEndTime(DateUtils.parseDate(appVo.getEndTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        appModel.setName(appVo.getName());
        appModel.setAppType(appVo.getAppType());
        appModel.setUserId(appVo.getOperator());

        PageModel<AppModel> pageModel = new PageModel<>();
        pageModel.setOffset((appVo.getCurrentPageNo() - 1) * appVo.getEachPageCapacity());
        pageModel.setCount(appVo.getEachPageCapacity());
        pageModel.setRequest(appModel);
        PageModel<AppModel> pageQueryResult = appService.pageQuery(pageModel);

        List<AppVo> appVoList = null;
        if (CollectionUtils.isNotEmpty(pageQueryResult.getResponse())) {
            appVoList = new ArrayList<>(pageQueryResult.getResponse().size());
            for (AppModel retAppModel : pageQueryResult.getResponse()) {
                AppVo retAppVo = modelToVo(retAppModel);
                appVoList.add(retAppVo);
            }
        }
        PageResponseVo pageResponseVo = new PageResponseVo();
        pageResponseVo.setCurrentPageNo(appVo.getCurrentPageNo());
        pageResponseVo.setEachPageCapacity(appVo.getEachPageCapacity());
        pageResponseVo.setTotalCount(pageModel.getTotalCount());
        return VoContainerHelper.createPageVoContainer(appVoList, pageResponseVo, RetCode.OK);
    }

    private AppVo modelToVo(AppModel appModel) {
        AppVo appVo = null;
        if (null != appModel) {
            appVo = new AppVo();
            BeanUtils.copyProperties(appModel, appVo);
            appVo.setOs(PlatformEnum.parse(appModel.getOs()).getNumber());
            appVo.setCreateTime(DateFormatUtils.format(appModel.getCreateTime(), DateUtils.FMT_yyyyMMddHHmmss_));
        }
        return appVo;
    }

    private AppModel voToModel(AppVo appVo) {
        AppModel appModel = null;
        if (null != appVo) {
            appModel = new AppModel();
            BeanUtils.copyProperties(appVo, appModel);
            appModel.setOs(PlatformEnum.parse(appVo.getOs()).getLabel());
        }
        return appModel;
    }

}
