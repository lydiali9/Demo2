package com.inveno.ad.dsp.conf;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

/**
 * <p>Title: {@link AppConfigProperties} </p>
 * <p>Description: 系统应用属性 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
@ConfigurationProperties(
        "app.config"
)
public class AppConfigProperties {

    private String fileRootLocation;
    private List<String> urlWhiteList;
    private List<String> ipWhiteList;
    private Long appMaxSize;
    private Long imageMaxSize;
    private Double smallImageRatio;
    private Integer smallImageMinWidth;
    private Integer smallImageMinHeight;
    private Double bannerImageRatio;
    private Integer bannerImageMinWidth;
    private Integer bannerImageMinHeight;
    private Double horizontalImageRatio;
    private Integer horizontalImageMinWidth;
    private Integer horizontalImageMinHeight;
    private Double verticalImageRatio;
    private Integer verticalImageMinWidth;
    private Integer verticalImageMinHeight;
    private Double ratioTolerance = 0d;
    private boolean imageCheckOpen;

    public String getFileRootLocation() {
        return fileRootLocation;
    }

    public void setFileRootLocation(String fileRootLocation) {
        this.fileRootLocation = fileRootLocation;
    }

    public List<String> getUrlWhiteList() {
        return urlWhiteList;
    }

    public void setUrlWhiteList(List<String> urlWhiteList) {
        this.urlWhiteList = urlWhiteList;
    }

    public Long getAppMaxSize() {
        return appMaxSize;
    }

    public void setAppMaxSize(Long appMaxSize) {
        this.appMaxSize = appMaxSize;
    }

    public Long getImageMaxSize() {
        return imageMaxSize;
    }

    public void setImageMaxSize(Long imageMaxSize) {
        this.imageMaxSize = imageMaxSize;
    }

    public List<String> getIpWhiteList() {
        return ipWhiteList;
    }

    public void setIpWhiteList(List<String> ipWhiteList) {
        this.ipWhiteList = ipWhiteList;
    }

    public Double getSmallImageRatio() {
        return smallImageRatio;
    }

    public void setSmallImageRatio(Double smallImageRatio) {
        this.smallImageRatio = smallImageRatio;
    }

    public Integer getSmallImageMinWidth() {
        return smallImageMinWidth;
    }

    public void setSmallImageMinWidth(Integer smallImageMinWidth) {
        this.smallImageMinWidth = smallImageMinWidth;
    }

    public Integer getSmallImageMinHeight() {
        return smallImageMinHeight;
    }

    public void setSmallImageMinHeight(Integer smallImageMinHeight) {
        this.smallImageMinHeight = smallImageMinHeight;
    }

    public Double getBannerImageRatio() {
        return bannerImageRatio;
    }

    public void setBannerImageRatio(Double bannerImageRatio) {
        this.bannerImageRatio = bannerImageRatio;
    }

    public Integer getBannerImageMinWidth() {
        return bannerImageMinWidth;
    }

    public void setBannerImageMinWidth(Integer bannerImageMinWidth) {
        this.bannerImageMinWidth = bannerImageMinWidth;
    }

    public Integer getBannerImageMinHeight() {
        return bannerImageMinHeight;
    }

    public void setBannerImageMinHeight(Integer bannerImageMinHeight) {
        this.bannerImageMinHeight = bannerImageMinHeight;
    }

    public Double getHorizontalImageRatio() {
        return horizontalImageRatio;
    }

    public void setHorizontalImageRatio(Double horizontalImageRatio) {
        this.horizontalImageRatio = horizontalImageRatio;
    }

    public Integer getHorizontalImageMinWidth() {
        return horizontalImageMinWidth;
    }

    public void setHorizontalImageMinWidth(Integer horizontalImageMinWidth) {
        this.horizontalImageMinWidth = horizontalImageMinWidth;
    }

    public Integer getHorizontalImageMinHeight() {
        return horizontalImageMinHeight;
    }

    public void setHorizontalImageMinHeight(Integer horizontalImageMinHeight) {
        this.horizontalImageMinHeight = horizontalImageMinHeight;
    }

    public Double getVerticalImageRatio() {
        return verticalImageRatio;
    }

    public void setVerticalImageRatio(Double verticalImageRatio) {
        this.verticalImageRatio = verticalImageRatio;
    }

    public Integer getVerticalImageMinWidth() {
        return verticalImageMinWidth;
    }

    public void setVerticalImageMinWidth(Integer verticalImageMinWidth) {
        this.verticalImageMinWidth = verticalImageMinWidth;
    }

    public Integer getVerticalImageMinHeight() {
        return verticalImageMinHeight;
    }

    public void setVerticalImageMinHeight(Integer verticalImageMinHeight) {
        this.verticalImageMinHeight = verticalImageMinHeight;
    }

    public boolean isImageCheckOpen() {
        return imageCheckOpen;
    }

    public void setImageCheckOpen(boolean imageCheckOpen) {
        this.imageCheckOpen = imageCheckOpen;
    }

    public Double getRatioTolerance() {
        return ratioTolerance;
    }

    public void setRatioTolerance(Double ratioTolerance) {
        this.ratioTolerance = ratioTolerance;
    }
}
