package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AccountFrozenModel;
import org.apache.ibatis.annotations.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static com.inveno.ad.dsp.dao.AbstractSqlProvider.PARAM_BATCH_LIST;

/**
 * <p>Title: {@link AccountFrozenDao}</p>
 * <p>Description: 账户冻结金额DAO </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
@Mapper
public interface AccountFrozenDao {

    String PARAM_UPDATE_TIME = "updateTime";
    String PARAM_STATUS = "status";

    /**
     * 新增冻结金额
     * @param accountFrozenModel 冻结详情
     * @return 新增记录ID
     */
    @Insert(
            "INSERT INTO dspv2_t_account_frozen(id, user_id, frozen_amount, promotion_id, update_time, create_time, status)" +
                    "VALUES(#{id},#{userId},#{frozenAmount},#{promotionId},#{updateTime},#{createTime},#{status})"
    )
    @Options(useGeneratedKeys = true)
    Integer insert(AccountFrozenModel accountFrozenModel);

    /**
     * 根据用户ID查询账户冻结金额
     * @param accountFrozenModel 参数
     * @return 账户冻结金额信息
     */
    @Select(
            "SELECT id, user_id, frozen_amount, frozen_date, promotion_id, update_time, create_time, status" +
                    " FROM dspv2_t_account_frozen t" +
                    " WHERE t.user_id = #{userId}" +
                    " AND t.status=#{status}"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "frozenAmount", column = "frozen_amount"),
                    @Result(property = "frozenDate", column = "frozen_date"),
                    @Result(property = "promotionId", column = "promotion_id"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "status", column = "status")
            }
    )
    List<AccountFrozenModel> selectFrozenRecordByUserId(AccountFrozenModel accountFrozenModel);

    /**
     * 批量插入冻结金额
     * @param accountFrozenModelList 插入参数
     * @return 影响行数
     */
    @InsertProvider(type = AccountFrozenDaoSqlProvider.class, method = "batchInsert")
    @Options(useGeneratedKeys = true)
    Integer batchInsert(@Param(PARAM_BATCH_LIST) List<AccountFrozenModel> accountFrozenModelList);

    /**
     * 根据ID批量删除
     * @param idList id
     * @return 影响行数
     */
    @DeleteProvider(type = AccountFrozenDaoSqlProvider.class, method = "batchDelete")
    Integer batchDelete(List<Integer> idList);

    /**
     * 批量更新状态
     * @param params 参数
     * @return 影响行数
     */
    @UpdateProvider(type = AccountFrozenDaoSqlProvider.class, method = "batchUpdateStatus")
    Integer batchUpdateStatus(Map<String, Object> params);

    @Select(
            " SELECT SUM(frozen_amount) FROM dspv2_t_account_frozen WHERE user_id=#{userId} AND status=#{status}"
    )
    @ResultType(BigDecimal.class)
    BigDecimal selectSumByUserIdAndStatus(@Param("userId") Integer userId, @Param("status") Integer status);

    /**
     * 根据推广ID更新
     * @param accountFrozenModel 待更新数据
     * @return 影响行数
     */
    @UpdateProvider(type = AccountFrozenDaoSqlProvider.class, method = "updateByPromotionIdWithoutNull")
    Integer updateByPromotionIdWithoutNull(AccountFrozenModel accountFrozenModel);
}
