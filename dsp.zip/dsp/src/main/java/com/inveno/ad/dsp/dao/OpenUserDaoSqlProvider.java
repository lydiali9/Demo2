package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.OpenUserModel;
import org.apache.ibatis.jdbc.SQL;

public class OpenUserDaoSqlProvider {

    public String updateByOpenUserId(OpenUserModel openUserModel) {
        SQL sql = new SQL();
        sql.UPDATE("t_dsp_open_user");
        sql.SET("comp_name = #{compName}");
        sql.SET("business_license = #{businessLicense}");
        sql.SET("qualifications = #{qualifications}");
        sql.SET("business_type = #{businessType}");
        sql.SET("org_no = #{orgNo}");
        sql.SET("certif_obverse_pic = #{certifObversePic}");
        sql.SET("certif_reverse_pic = #{certifReversePic}");
        sql.SET("province = #{province}");
        sql.SET("city = #{city}");
        sql.SET("contact_name = #{contactName}");
        sql.SET("email = #{email}");
        sql.SET("addr_detail = #{addrDetail}");
        sql.SET("tel_no = #{telNo}");
        sql.SET("fixed_line_tel = #{fixedLineTel}");
        sql.SET("qq = #{qq}");
        sql.SET("comp_url = #{compUrl}");
        sql.SET("user_type = #{userType}");
        sql.SET("certif_no = #{certifNo}");
        sql.SET("update_time = #{updateTime}");
        sql.WHERE("user_id = #{openUserId}");
        return sql.toString();
    }
}
