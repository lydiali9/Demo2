package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link AccountFrozenStatusEnum}</p>
 * <p>Description: 账户冻结金额表状态 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/2
 */
public enum AccountFrozenStatusEnum {

    /**
     * 冻结状态
     */
    FROZEN(0),
    /**
     * 已结算
     */
    SETTLEMENT(1),
    /**
     * 已删除
     */
    DELETE(2);

    private int value;

    AccountFrozenStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
