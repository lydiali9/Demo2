package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.common.OpenUserStatusEnum;
import com.inveno.ad.dsp.dao.BasePlatUserDao;
import com.inveno.ad.dsp.dao.OpenUserDao;
import com.inveno.ad.dsp.model.BasePlatUserModel;
import com.inveno.ad.dsp.model.OpenUserModel;
import com.inveno.ad.dsp.service.OpenUserService;
import com.inveno.ad.dsp.vo.EnterpriseUserVo;
import com.inveno.ad.dsp.vo.PersonalUserVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class OpenUserServiceImpl implements OpenUserService {

    public static Logger logger = LoggerFactory.getLogger(OpenUserServiceImpl.class);

    @Autowired
    private OpenUserDao openUserDao;

    @Autowired
    private BasePlatUserDao basePlatUserDao;

    @Override
    public Integer create(OpenUserModel openUserModel) throws Exception {
        Date date = new Date();
        openUserModel.setCreateTime(date);
        openUserModel.setStatus(OpenUserStatusEnum.CHECKING.getValue());
        openUserDao.insert(openUserModel);
        logger.info("save openUser -> openUserId={}", openUserModel.getOpenUserId());
        return openUserModel.getOpenUserId();
    }

    @Override
    public Integer savePersonalUser(PersonalUserVo personalUserVo) throws Exception {
        Date date = new Date();
        OpenUserModel openUserModel = new OpenUserModel();
        BeanUtils.copyProperties(personalUserVo, openUserModel);

        //保存身份证图片的路径,设置图片的id
        openUserModel.setCertifObversePic("");
        openUserModel.setStatus(OpenUserStatusEnum.CHECKING.getValue());
        openUserModel.setUpdateTime(date);
        openUserModel.setCreateTime(date);
        openUserDao.insert(openUserModel);
        Integer openUserId = openUserModel.getOpenUserId();
        Integer userId = personalUserVo.getOperator();
        saveBasePlatUser(openUserId, userId);

        return openUserId;
    }

    @Override
    public Integer saveEnterpriseUser(EnterpriseUserVo enterpriseUserVo) throws Exception {
        Date date = new Date();
        OpenUserModel openUserModel = new OpenUserModel();
        BeanUtils.copyProperties(enterpriseUserVo, openUserModel);

        //保存营业执照图片的路径,设置图片的id
        openUserModel.setBusinessLicense("");
        openUserModel.setStatus(OpenUserStatusEnum.CHECKING.getValue());
        openUserModel.setUpdateTime(date);
        openUserModel.setCreateTime(date);
        openUserDao.insert(openUserModel);
        Integer openUserId = openUserModel.getOpenUserId();
        Integer userId = enterpriseUserVo.getOperator();
        saveBasePlatUser(openUserId, userId);

        return openUserId;
    }

    @Override
    public Boolean update(OpenUserModel openUserModel) throws Exception {
        Date date = new Date();
        openUserModel.setUpdateTime(date);
        openUserDao.updateByOpenUserId(openUserModel);
        return true;
    }

    @Override
    public Integer saveBasePlatUser(Integer openUserId, Integer userId) throws Exception {
        BasePlatUserModel basePlatUserModel = new BasePlatUserModel();
        basePlatUserModel.setPlatUserId(openUserId);
        basePlatUserModel.setUserId(userId);
        basePlatUserModel.setPlatId(Constants.PLAT_NAME);
        basePlatUserDao.saveBasePlatUser(basePlatUserModel);
        return basePlatUserModel.getId();
    }

}
