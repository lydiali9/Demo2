package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.model.PromotionOnlineTimeModel;
import org.apache.ibatis.jdbc.SQL;

import javax.activation.UnsupportedDataTypeException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

/**
 * <p>Title: {@link PromotionOnlineTimeDaoSqlProvider}</p>
 * <p>Description: PromotionOnlineTimeDao sql 提供类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public class PromotionOnlineTimeDaoSqlProvider extends AbstractSqlProvider {


    @SuppressWarnings("unchecked")
    public String batchInsert(Map<Object, Object> map) {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO `dspv2_t_promotion_online_time`(");
        sql.append("`promotion_id`,`start_time`,`end_time`,`create_time`,`status`)");
        sql.append(" VALUES ");
        String pattern = " #'{'list[{0}].promotionId'}', #'{'list[{0}].startTime'}', #'{'list[{0}].endTime'}', " +
                " #'{'list[{0}].createTime'}',#'{'list[{0}].status'}'";
        MessageFormat mf = new MessageFormat(pattern);
        List<PromotionOnlineTimeModel> promotionOnlineTimeModelList = (List<PromotionOnlineTimeModel>) map.get(PARAM_BATCH_LIST);
        append(sql, mf, promotionOnlineTimeModelList, Constants.SEPARATOR_COMMA);
        return sql.toString();
    }

    @SuppressWarnings("unchecked")
    public String batchDelete(Map<Object, Object> params) throws UnsupportedDataTypeException {
        SQL sql = new SQL();
        sql.DELETE_FROM("`dspv2_t_promotion_online_time`");
        List<Integer> idList = (List<Integer>) params.get(PARAM_BATCH_LIST);
        appendORCondition(sql, idList, "id");
        return sql.toString();
    }

}
