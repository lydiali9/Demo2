package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link PromotionBudgetStatusEnum} </p>
 * <p>Description: 推广预算状态 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public enum PromotionBudgetStatusEnum {

    VALID(0),
    INVALID(1);
    private int value;

    PromotionBudgetStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
