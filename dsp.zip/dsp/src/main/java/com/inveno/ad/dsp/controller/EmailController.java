package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.common.SendEmailEnum;
import com.inveno.ad.dsp.service.EmailService;
import com.inveno.ad.dsp.vo.EmailVo;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.JedisCluster;


@RestController
public class EmailController {
    @Autowired
    private EmailService emailService;



    @PostMapping("/email/{type}/send")
    public VoContainer<EmailVo> send(@RequestBody EmailVo emailVo, @PathVariable String type) throws Exception {
        String sendEmailAddr = emailVo.getEmail();
        if (SendEmailEnum.SEND_VERIFICATION_CODE_EMAIL.getValue().equals(type)){
            emailService.sendVerificationCode(sendEmailAddr);
        } else if (SendEmailEnum.SEND_FIND_PWD_EMAIL.getValue().equals(type)){
            emailService.sendFindPwdCode(sendEmailAddr);
        }
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }
}
