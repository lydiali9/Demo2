package com.inveno.ad.dsp.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.nio.file.CopyOption;
import java.nio.file.Path;
import java.util.stream.Stream;

/**
 * <p>Title: {@link StorageService}</p>
 * <p>Description: 用于文件存储 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/7
 */
public interface StorageService {

    /**
     * 新建文件夹
     * @param dirs 文件夹路径
     */
    void createDirectories(String dirs);

    /**
     * 存储文件
     * @param file 文件
     * @param folder 相对根目录的路径
     * @param copyOptions 存储选项，{@see CopyOption}
     */
    void store(MultipartFile file, String folder, CopyOption... copyOptions);

    /**
     * 存储文件，如果文件所属包不存在，则不会保存成功。
     * @param inputStream 文件流
     * @param relativePath 文件存储相对路径
     * @param copyOptions 存储选项，{@see CopyOption}
     */
    void store(InputStream inputStream, String relativePath, CopyOption... copyOptions);

    /**
     * 存储文件
     * @param inputStream 文件流
     * @param folder 文件夹
     * @param name 文件名称
     * @param copyOptions 存储选项，{@see CopyOption}
     */
    void store(InputStream inputStream, String folder, String name, CopyOption... copyOptions);

    /**
     * 加载所有文件路径
     * @return 文件路径流
     */
    Stream<Path> loadAll();

    /**
     * 加载单个文件路径
     * @param filename 文件名
     * @return 文件路径
     */
    Path load(String filename);

    /**
     * 读取文件为Resource
     * @param filename 文件名z
     * @return Resource对象
     */
    Resource loadAsResource(String filename);

    /**
     * 删除所有文件
     * @throws Exception 异常抛出
     */
    void deleteAll() throws Exception;

    /**
     * 删除文件/文件夹
     * @param file 文件/文件夹相对路径
     * @throws Exception 异常
     */
    void delete(String file) throws Exception;

    /**
     * 文件是否存在
     * @param path 文件路径
     * @return 是否存在
     * @throws Exception 异常抛出
     */
    boolean exist(String path) throws Exception;

    /**
     * 重命名
     * @param srcFiePath 源文件路径
     * @param targetFilePath 重命名路径
     * @return 是否成功
     * @throws Exception 异常抛出
     */
    Path move(String srcFiePath, String targetFilePath) throws Exception;

}
