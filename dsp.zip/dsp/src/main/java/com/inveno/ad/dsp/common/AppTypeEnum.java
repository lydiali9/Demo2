package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link AppTypeEnum} </p>
 * <p>Description: 应用类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public enum AppTypeEnum {

    /**
     * apk
     */
    apk(1, ".apk"),
    /**
     * ipa
     */
    ipa(2, ".ipa");

    private int value;
    private String suffix;

    AppTypeEnum(int value, String suffix) {
        this.value = value;
        this.suffix = suffix;
    }

    public String getSuffix() {
        return suffix;
    }

    public int getValue() {
        return value;
    }
}
