package com.inveno.ad.dsp.vo;

import javax.validation.Valid;
import java.util.List;

/**
 * <p>Title: {@link AdMaterialInfoVo} </p>
 * <p>Description: 素材info </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/11
 */
public class AdMaterialInfoVo {

    private Integer type;
    private Integer bigImageType;
    @Valid
    private List<AdMaterialVo> materialList;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getBigImageType() {
        return bigImageType;
    }

    public void setBigImageType(Integer bigImageType) {
        this.bigImageType = bigImageType;
    }

    public List<AdMaterialVo> getMaterialList() {
        return materialList;
    }

    public void setMaterialList(List<AdMaterialVo> materialList) {
        this.materialList = materialList;
    }
}
