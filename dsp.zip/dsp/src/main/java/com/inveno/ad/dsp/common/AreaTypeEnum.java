package com.inveno.ad.dsp.common;

public enum AreaTypeEnum {
    COUNTRY(1),
    PROVINCE(2),
    CITY(3);

    private Integer value;

    AreaTypeEnum(Integer value){
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
