package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link AgeEnum} </p>
 * <p>Description: 年龄区间枚举 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public enum AgeEnum {

    /**
     * 不限
     */
    UNLIMITED(0, "unlimited"),
    /**
     * 0~18
     */
    P_LT_18(1, "0~18"),
    P_18_TO_23(2, "18~23"),
    P_24_TO_30(3, "24~30"),
    P_31_TO_40(4, "31~40"),
    P_41_TO_49(5, "41~50"),
    P_GT_50(6, "50~100");

    int number;
    String label;

    AgeEnum(int number, String label) {
        this.number = number;
        this.label = label;
    }

    public static boolean contains(String label) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getLabel().equals(label));
    }

    public static boolean contains(int number) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getNumber() == number);
    }

    public static AgeEnum parse(int number) {
        return Arrays.stream(values()).filter(e -> e.getNumber() == number).findFirst().orElse(null);
    }

    public static AgeEnum parse(String label) {
        return Arrays.stream(values()).filter(e -> e.getLabel().equals(label)).findFirst().orElse(null);
    }

    public int getNumber() {
        return number;
    }

    public String getLabel() {
        return label;
    }
}
