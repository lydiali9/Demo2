package com.inveno.ad.dsp.model; /***********************************************************************
 * Module:  PromotionOnlineTimeModel.java
 * Author:  sugang
 * Purpose: Defines the Class PromotionOnlineTimeModel
 ***********************************************************************/

import java.io.Serializable;
import java.util.Date;

/** @pdOid d6a1419b-250e-4d64-90b3-aec1182e516b */
public class PromotionOnlineTimeModel implements Serializable {
    private Integer id;
    private Long promotionId;
    private Date startTime;
    private Date endTime;
    private Date createTime;
    private Integer status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(Long promotionId) {
        this.promotionId = promotionId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}