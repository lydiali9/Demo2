package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.model.BaseModel;

import java.util.Date;

public class OpenUserVo extends BaseVo {

    private Integer openUserId;
    //公司名称
    private String compName;
    //营业执照
    private String businessLicense;
    //行业资质
    private String qualifications;
    //所属行业
    private String businessType;
    private String compUrl;
    //组织代码
    private String orgNo;
    //身份证正面照
    private String certifObversePic;
    //身份证反面照
    private String certifReversePic;
    //所在省
    private String province;
    //所在市
    private String city;
    //联系人姓名
    private String contactName;
    //电子邮箱
    private String email;
    //详细地址
    private String addrDetail;
    //联系电话
    private String telNo;
    //固定电话
    private String fixedLineTel;
    //qq号码
    private String qq;
    //审核状态
    private String status;
    //审核不通过原因
    private String noPassReason;
    //营业执照
    private String businessLicensePath;
    //行业资质
    private String qualificationsPath;
    //用户类型，1-企业 2-个人
    private String userType;
    //身份证号码
    private String certifNo;
    private String businessTypeName;
    //创建时间
    private Date createTime;
    //修改时间
    private Date updateTime;

    public Integer getOpenUserId() {
        return openUserId;
    }

    public void setOpenUserId(Integer openUserId) {
        this.openUserId = openUserId;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getBusinessLicense() {
        return businessLicense;
    }

    public void setBusinessLicense(String businessLicense) {
        this.businessLicense = businessLicense;
    }

    public String getQualifications() {
        return qualifications;
    }

    public void setQualifications(String qualifications) {
        this.qualifications = qualifications;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getCompUrl() {
        return compUrl;
    }

    public void setCompUrl(String compUrl) {
        this.compUrl = compUrl;
    }

    public String getOrgNo() {
        return orgNo;
    }

    public void setOrgNo(String orgNo) {
        this.orgNo = orgNo;
    }

    public String getCertifObversePic() {
        return certifObversePic;
    }

    public void setCertifObversePic(String certifObversePic) {
        this.certifObversePic = certifObversePic;
    }

    public String getCertifReversePic() {
        return certifReversePic;
    }

    public void setCertifReversePic(String certifReversePic) {
        this.certifReversePic = certifReversePic;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddrDetail() {
        return addrDetail;
    }

    public void setAddrDetail(String addrDetail) {
        this.addrDetail = addrDetail;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getFixedLineTel() {
        return fixedLineTel;
    }

    public void setFixedLineTel(String fixedLineTel) {
        this.fixedLineTel = fixedLineTel;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNoPassReason() {
        return noPassReason;
    }

    public void setNoPassReason(String noPassReason) {
        this.noPassReason = noPassReason;
    }

    public String getBusinessLicensePath() {
        return businessLicensePath;
    }

    public void setBusinessLicensePath(String businessLicensePath) {
        this.businessLicensePath = businessLicensePath;
    }

    public String getQualificationsPath() {
        return qualificationsPath;
    }

    public void setQualificationsPath(String qualificationsPath) {
        this.qualificationsPath = qualificationsPath;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getCertifNo() {
        return certifNo;
    }

    public void setCertifNo(String certifNo) {
        this.certifNo = certifNo;
    }

    public String getBusinessTypeName() {
        return businessTypeName;
    }

    public void setBusinessTypeName(String businessTypeName) {
        this.businessTypeName = businessTypeName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
