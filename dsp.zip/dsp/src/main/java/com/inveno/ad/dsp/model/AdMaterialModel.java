package com.inveno.ad.dsp.model; /***********************************************************************
 * Module:  AdMaterialModel.java
 * Author:  sugang
 * Purpose: Defines the Class AdMaterialModel
 ***********************************************************************/

import java.util.Date;

/** 广告素材
 *
 * @pdOid be84677a-6a3b-4cce-a806-33e3f7a2e90c */
public class AdMaterialModel {

    private Long id;
    private Integer type;
    private String title;
    private Integer bigImageType;
    private Integer groupId;
    private Long adId;
    private Long imageId;
    private String source;
    private Integer operator;
    private Date createTime;
    private Date updateTime;
    private Integer status;
    private ImageModel imageModel;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getBigImageType() {
        return bigImageType;
    }

    public void setBigImageType(Integer bigImageType) {
        this.bigImageType = bigImageType;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public Long getAdId() {
        return adId;
    }

    public void setAdId(Long adId) {
        this.adId = adId;
    }

    public Long getImageId() {
        return imageId;
    }

    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Integer getOperator() {
        return operator;
    }

    public void setOperator(Integer operator) {
        this.operator = operator;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public ImageModel getImageModel() {
        return imageModel;
    }

    public void setImageModel(ImageModel imageModel) {
        this.imageModel = imageModel;
    }
}