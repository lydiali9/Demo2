package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AccountFlowReportModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface AccountFlowReportDao {


    @Select(
            "SELECT " +
                " COUNT(1) " +
            " FROM dspv2_t_account_flow_report " +
            " WHERE user_id = #{request.userId} " +
            " AND date >= #{request.searchStartDate} " +
            " AND date <= #{request.searchEndDate} "
    )
    Integer pageQueryTotalCountByUserId(PageModel<AccountFlowReportModel> pageModel);


    @Select(
            " SELECT " +
                " id,date,user_id,recharge_amount,return_amount,consumption_amount,frozen_amount," +
                " balance,available_balance,create_time " +
            " FROM dspv2_t_account_flow_report " +
            " WHERE user_id = #{request.userId} " +
            " AND date >= #{request.searchStartDate} " +
            " AND date <= #{request.searchEndDate} " +
            " ORDER BY date DESC " +
            " LIMIT #{offset},#{count} "
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "date", column = "date"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "rechargeAmount", column = "recharge_amount"),
                    @Result(property = "returnAmount", column = "return_amount"),
                    @Result(property = "consumptionAmount", column = "consumption_amount"),
                    @Result(property = "frozenAmount", column = "frozen_amount"),
                    @Result(property = "balance", column = "balance"),
                    @Result(property = "availableBalance", column = "available_balance"),
                    @Result(property = "createTime", column = "create_time"),
            }
            )
    List<AccountFlowReportModel> pageQueryByUserId(PageModel<AccountFlowReportModel> pageModel);
}
