package com.inveno.ad.dsp.common;

public enum  OpenUserStatusEnum {

    NORMAL("1"),
    CHECKING("2"),
    NO_PASS("3");

    private String value;

    OpenUserStatusEnum(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
