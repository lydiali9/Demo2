package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link AdReviewStatusEnum}</p>
 * <p>Description: 广告审核状态 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/18
 */
public enum AdReviewStatusEnum {

    /**
     * 待审核
     */
    PENDING(0),
    /**
     * 审核通过
     */
    PASS(1),
    /**
     * 审核不通过
     */
    NOT_PASS(2),
    /**
     * 强制下线
     */
    FORCE_OFFLINE(3);
    private int value;

    AdReviewStatusEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
