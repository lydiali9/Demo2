package com.inveno.ad.dsp.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.dao.UserDao;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.UserService;
import com.inveno.ad.dsp.util.SysUtils;
import com.inveno.ad.dsp.vo.*;
import com.inveno.util.MD5Utils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisCluster;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;


@Service
public class UserServiceImpl implements UserService {

    private static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserDao userDao;
    @Autowired
    private JedisCluster jedisCluster;

    @Override
    public UserVo login(LoginVo loginVo, HttpSession session) throws DspException {

        String username = loginVo.getUsername();
        String password = loginVo.getPassword();

        Integer loginCount = (Integer) session.getAttribute(Constants.SESSION_KEY_LOGIN_COUNT);
        if (loginCount != null) {
            if (loginCount > 3) {
                //登陆超过3次，需要验证码
                String checkCode = loginVo.getCheckCode();
                String kaptchaText = (String) session.getAttribute(Constants.KAPTCHA_SESSION_KEY);
                if (StringUtils.isEmpty(checkCode) || StringUtils.isEmpty(kaptchaText) || !checkCode.equals(kaptchaText)){
                    throw new DspException(RetCode.ERR_CHECK_CODE);
                }
            } else {
                session.setAttribute(Constants.SESSION_KEY_LOGIN_COUNT, loginCount + 1);
            }
        } else {
            session.setAttribute(Constants.SESSION_KEY_LOGIN_COUNT, 1);
        }

        UserModel userModel = userDao.findByUsername(username);
        if (userModel == null){
            throw new DspException(RetCode.ERR_LOGIN);
        }
        String thisPassword = userModel.getPassword();
        if (!thisPassword.equals(MD5Utils.getResult(password))){
            throw new DspException(RetCode.ERR_LOGIN);
        }
        int openClose = userModel.getOpenClose();
        if(openClose == OpenCloseEnum.CLOSE.getValue()){
            throw new DspException(RetCode.ERR_STATUS_CONFLICT);
        }

        //保存至session
        session.setAttribute(Constants.SESSION_KEY_USER_INFO, userModel);
        //登陆成功，重置次数为0
        session.setAttribute(Constants.SESSION_KEY_LOGIN_COUNT, 0);

        UserVo userVo = new UserVo();
        userVo.setUserId(userModel.getUserId());
        userVo.setUserName(userModel.getUsername());
        userVo.setParent(userModel.getParentId() == 0);
        userVo.setRole(userModel.getParentId() == 0 ? RoleEnum.PARENT.getValue() : RoleEnum.CHILD.getValue());
        userVo.setMenu(getMenu(userModel.getParentId() == 0 ? RoleEnum.PARENT.getValue() : RoleEnum.CHILD.getValue()));
        return userVo;
    }

    @Override
    public void logout(HttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();
        if (session == null){
            throw new DspException(RetCode.ERR_STATUS_CONFLICT);
        }
        session.removeAttribute(Constants.SESSION_KEY_USER_INFO);
    }

    @Override
    public UserVo userInfo(HttpServletRequest request) throws Exception {
        HttpSession session = request.getSession();
        UserModel userModel = SysUtils.getUser(session);
//        UserModel userModel = (UserModel) session.getAttribute(Constants.SESSION_KEY_USER_INFO);
//        if (userModel == null){
//            throw new DspException(RetCode.ERR_STATUS_CONFLICT.getCode(), "10005");
//        }
        UserVo userVo = new UserVo();
        userVo.setUserId(userModel.getUserId());
        userVo.setUserName(userModel.getUsername());
        return userVo;
    }

    @Override
    public Integer register(RegisterVo registerVo) throws Exception {
        String email = registerVo.getEmail();
        String verificationCodeKey = Constants.REDIS_KEY_VERIFICATION_CODE_PREFIX + registerVo.getEmail() ;
        String verificationCode = jedisCluster.get(verificationCodeKey);
        if (verificationCode == null || !verificationCode.equals(registerVo.getVerificationCode())){
            throw new DspException(RetCode.ERR_VERIFICATION_CODE);
        }

        UserModel userModel = userDao.findByEmail(email);
        if (userModel != null){
            throw new DspException(RetCode.ERR_EMAIL_EXIST);
        }

        userModel = new UserModel();
        userModel.setEmail(email);
        userModel.setUsername(email);
        userModel.setPassword(MD5Utils.getResult(registerVo.getPassword()));
        userModel.setState("2");
        userModel.setOnline(OnlineEnum.ONLINE.getValue());
        userModel.setParentId(0);
        userModel.setOpenClose(OpenCloseEnum.OPEN.getValue());//默认可以登录
        userModel.setCreateTime(new Date());
        //这几个不知道干嘛的
        userModel.setType(0);
        userModel.setFirmId(0);
        userModel.setUserSys("");
        userModel.setIsPropagate("1");
        userDao.insert(userModel);
        jedisCluster.del(verificationCodeKey);
        return userModel.getUserId();
    }

    @Override
    public void resetPwd(ResetPwdVo resetPwdVo) throws Exception {
        String email = resetPwdVo.getEmail();
        String findPwdCodeKey = Constants.REDIS_KEY_FIND_PWD_CODE_PREFIX + resetPwdVo.getEmail() ;
        String findPwdCode = jedisCluster.get(findPwdCodeKey);
        if (findPwdCode == null || !findPwdCode.equals(resetPwdVo.getFindPwdCode())){
            throw new DspException(RetCode.ERR_VERIFICATION_CODE);
        }
        UserModel userModel = userDao.findByEmail(email);
        if (userModel == null){
            throw new DspException(RetCode.ERR_EMAIL_NOT_EXIST);
        }
        String password = MD5Utils.getResult(resetPwdVo.getNewPwd());
        userDao.updatePwdByUserId(userModel.getUserId(), password);
        jedisCluster.del(findPwdCodeKey);       //每个验证码只用一次
    }

    @Override
    public void modifyPwd(ModifyPwdVo modifyPwdVo, HttpSession session) throws Exception {
        UserModel userModel = SysUtils.getUser(session);
        UserModel user = userDao.findByUserId(userModel.getUserId());
        if (user == null){
            throw new DspException(RetCode.ERR_USER_NOT_EXIST);
        }
        String oldPwd = MD5Utils.getResult(modifyPwdVo.getOldPwd());
        if (!oldPwd.equals(user.getPassword())){
            throw new DspException(RetCode.ERR_AD_STATUS);
        }
        String newPwd = MD5Utils.getResult(modifyPwdVo.getNewPwd());
        userDao.updatePwdByUserId(user.getUserId(), newPwd);
    }


    private List<MenuVo> getMenu(String role) {
        List<MenuVo> menuList = null;
        try {
            String fileName = "navigation/navigation-" + role + ".json";
            ClassPathResource classPathResource = new ClassPathResource(fileName);
            if (!classPathResource.exists()) {
                throw new RuntimeException(fileName + " not exist!");
            }
            String content = FileUtils.readFileToString(classPathResource.getFile(), "UTF-8");
            if (StringUtils.isNotBlank(content)) {
                menuList = JSONObject.parseArray(content, MenuVo.class);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return menuList;
    }

}
