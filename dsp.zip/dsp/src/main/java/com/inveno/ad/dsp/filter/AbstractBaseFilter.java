package com.inveno.ad.dsp.filter;

import com.alibaba.fastjson.JSONObject;
import com.inveno.ad.dsp.conf.AppConfigProperties;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public abstract class AbstractBaseFilter {
    private static final String INTRANET_IP_PREFIX = "192.168.";

    @Autowired
    private AppConfigProperties appConfigProperties;


    protected Boolean isNoCheckIp(String ip) {
        if (ip.startsWith(INTRANET_IP_PREFIX)) {
            // 内网网段全部放开。
            return true;
        }
        return CollectionUtils.isNotEmpty(appConfigProperties.getIpWhiteList()) && appConfigProperties.getIpWhiteList().contains(ip);
    }

    protected Boolean isNoCheckUrl(String path) {
        return CollectionUtils.isNotEmpty(appConfigProperties.getUrlWhiteList()) && appConfigProperties.getUrlWhiteList().contains(path);
    }

    protected void returnNoAuthMsg(Logger logger, HttpServletResponse response, int code, String msg) {
        VoContainer voContainer = VoContainerHelper.createVoContainer(code, msg);
        response.setContentType("application/json;charset=utf-8");
        PrintWriter out;
        try {
            out = response.getWriter();
            out.print(JSONObject.toJSONString(voContainer));
            out.flush();
            out.close();
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }
    }

}
