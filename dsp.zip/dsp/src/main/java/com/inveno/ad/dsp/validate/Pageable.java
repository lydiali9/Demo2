package com.inveno.ad.dsp.validate;

import java.lang.annotation.*;

/**
 * <p>Title: {@link Pageable}</p>
 * <p>Description: 用于辨别参数是否属于PageValidatorGroup </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/6
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Pageable {
}
