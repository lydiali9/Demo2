package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link PromotionTypeEnum} </p>
 * <p>Description: 推广类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public enum PromotionTypeEnum {

    /**
     * 链接
     */
    LINK(1),
    /**
     * 应用
     */
    APP(2);

    private int value;

    PromotionTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static boolean contains(int value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue() == value);
    }

}
