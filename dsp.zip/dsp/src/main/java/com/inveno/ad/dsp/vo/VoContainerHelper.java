package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.common.RetCode;

/**
 * <p>Title: {@link VoContainerHelper}</p>
 * <p>Description: vo容器工具类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public class VoContainerHelper {

    public static <T> VoContainer<T> createVoContainer(T data, int code, String message) {
        return createPageVoContainer(data, null, code, message);
    }

    public static <T> VoContainer<T> createVoContainer(T data, RetCode retCode) {
        return createVoContainer(data, retCode.getCode(), retCode.getMessage());
    }

    public static <T> VoContainer<T> createVoContainer(RetCode retCode) {
        return createVoContainer(null, retCode.getCode(), retCode.getMessage());
    }

    public static <T> VoContainer<T> createVoContainer(int code, String message) {
        return createVoContainer(null, code, message);
    }

    public static <T> VoContainer<T> createPageVoContainer(T data, PageResponseVo pageResponseVo, int code, String message) {
        VoContainer<T> voContainer = new VoContainer<>();
        voContainer.setData(data);
        voContainer.setCode(code);
        voContainer.setMessage(message);
        voContainer.setPage(pageResponseVo);
        return voContainer;
    }

    public static <T> VoContainer<T> createPageVoContainer(T data, PageResponseVo pageResponseVo, RetCode retCode) {
        return createPageVoContainer(data, pageResponseVo, retCode.getCode(), retCode.getMessage());
    }
}
