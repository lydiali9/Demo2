package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link ImgQualityEnum} </p>
 * <p>Description: 云图质量 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/11
 */
public enum ImgQualityEnum {

    high,
    mid,
    low;

    public static boolean contains(String name) {
        return Arrays.stream(values()).anyMatch(e -> e.name().equals(name));
    }

}
