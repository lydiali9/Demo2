package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.vo.AdReportDailyVo;

import java.util.List;

public interface AdReportDailyService {

    List<AdReportDailyVo> queryPromotion(AdReportDailyVo adReportDailyVo, Integer userId);

    List<AdReportDailyVo> queryAd(AdReportDailyVo adReportDailyVo, Integer userId);

    List<AdReportDailyVo> queryUser(AdReportDailyVo adReportDailyVo, Integer userId);
}
