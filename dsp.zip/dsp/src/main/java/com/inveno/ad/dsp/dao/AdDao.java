package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AdModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p>Title:{@link AdDao} </p>
 * <p>Description: 广告DAO类</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
@Mapper
public interface AdDao {

    /**
     * 插入广告
     * @param adModel 新广告信息
     * @return 影响行数
     */
    @Insert(
            "INSERT INTO dspv2_t_ad(" +
                    "ad_id, user_id, operator, promotion_id, title, " +
                    "type, pv_report_url, click_report_url, video_start_play_report_url, video_end_play_report_url, " +
                    "create_time, update_time, status, version, review_status, no_pass_reason" +
                    ")" +
                    "VALUES(" +
                    "#{adId}, #{userId}, #{operator}, #{promotionId}, #{title}, " +
                    "#{type}, #{pvReportUrl}, #{clickReportUrl}, #{videoStartPlayReportUrl}, #{videoEndPlayReportUrl}, " +
                    "#{createTime}, #{updateTime}, #{status}, #{version}, #{reviewStatus}, #{noPassReason}" +
                    ")"
    )
    Integer insert(AdModel adModel);

    /**
     * 根据UID分页查询广告信息总数
     * @param pageModel 分页条件
     * @return 符合条件的广告数量
     */
    @SelectProvider(type = AdDaoSqlProvider.class, method = "pageQueryTotalCount")
    int pageQueryTotalCount(PageModel<AdModel> pageModel);

    /**
     * 根据ID查询广告
     * @param adId 广告ID
     * @return 符合条件的广告详情
     */
    @Select(
            "SELECT ad_id, user_id, operator, promotion_id, title, " +
                    " type, pv_report_url, click_report_url, video_start_play_report_url, video_end_play_report_url, " +
                    " create_time, update_time, status, version, review_status, no_pass_reason" +
                    " FROM dspv2_t_ad" +
                    " WHERE ad_id = #{adId}"
    )
    @Results({
            @Result(property = "adId", column = "ad_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "promotionId", column = "promotion_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "pvReportUrl", column = "pv_report_url"),
            @Result(property = "clickReportUrl", column = "click_report_url"),
            @Result(property = "videoStartPlayReportUrl", column = "video_start_play_report_url"),
            @Result(property = "videoEndPlayReportUrl", column = "video_end_play_report_url"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status"),
            @Result(property = "version", column = "version"),
            @Result(property = "reviewStatus", column = "review_status"),
            @Result(property = "noPassReason", column = "no_pass_reason")

    })
    AdModel selectById(Long adId);

    /**
     * 根据UID分页查询广告列表
     * @param pageModel 分页条件
     * @return 符合条件的记录
     */
    @SelectProvider(type = AdDaoSqlProvider.class, method = "pageQuery")
    @Results({
            @Result(property = "adId", column = "ad_id"),
            @Result(property = "matNum", column = "mat_num"),
            @Result(property = "status", column = "status"),
            @Result(property = "version", column = "version"),
            @Result(property = "type", column = "type"),
            @Result(property = "title", column = "title"),
            @Result(property = "user_id", column = "userId"),
            @Result(property = "promotionId", column = "promotion_id"),
            @Result(property = "promotion.id", column = "promotion_id"),
            @Result(property = "promotion.title", column = "prom_title"),
            @Result(property = "promotion.deliverStartTime", column = "deliver_start_time"),
            @Result(property = "promotion.deliverEndTime", column = "deliver_end_time"),
            @Result(property = "adReportDailyModel.pv", column = "pv"),
            @Result(property = "adReportDailyModel.click", column = "click"),
            @Result(property = "adReportDailyModel.ctr", column = "ctr"),
            @Result(property = "adReportDailyModel.ecpm", column = "ecpm"),
            @Result(property = "adReportDailyModel.ecpc", column = "ecpc"),
            @Result(property = "adReportDailyModel.totalCost", column = "total_cost"),
            @Result(property = "mat_num", column = "matNum"),
            @Result(property = "reviewStatus", column = "review_status"),
            @Result(property = "noPassReason", column = "no_pass_reason")
    })
    List<AdModel> pageQuery(PageModel<AdModel> pageModel);

    /**
     * 根据推广ID更新广告状态
     * @param adModel 更新信息
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_ad SET " +
                    " status=#{status}, " +
                    " update_time=#{updateTime}," +
                    " version=version+1, " +
                    " operator=#{operator}" +
                    " WHERE promotion_id=#{promotionId} " +
                    " AND status=#{status}"
    )
    Integer updateStatusByPromotionId(AdModel adModel);

    /**
     * 根据推广ID更新广告状态
     * @param adModel 更新信息
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_ad SET " +
                    " update_time=#{updateTime}, " +
                    " version=version+1, " +
                    " operator=#{operator}" +
                    " WHERE promotion_id=#{promotionId} "
    )
    Integer switchStatus(AdModel adModel);

    /**
     * 根据广告ID更新广告状态
     * @param adModel 更新信息
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_ad SET " +
                    " status=#{status}, " +
                    " update_time=#{updateTime}, " +
                    " version=version+1, " +
                    " operator=#{operator}" +
                    " WHERE ad_id=#{adId} " +
                    " AND version=#{version}"
    )
    Integer updateStatusById(AdModel adModel);

    /**
     * 根据ID更新
     * @param adModel 更新信息
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_ad SET" +
                    " user_id=#{userId}," +
                    " operator=#{operator}," +
                    " promotion_id=#{promotionId}," +
                    " title=#{title}," +
                    " type=#{type}," +
                    " pv_report_url=#{pvReportUrl}," +
                    " click_report_url=#{clickReportUrl}," +
                    " video_start_play_report_url=#{videoStartPlayReportUrl}," +
                    " video_end_play_report_url=#{videoEndPlayReportUrl}," +
                    " update_time=#{updateTime}," +
                    " version=version+1, " +
                    " status=#{status}" +
                    " WHERE ad_id=#{adId} " +
                    " AND version=#{version}"
    )
    Integer updateById(AdModel adModel);

    /**
     * 查询审核未通过数量
     * @param adModel 用户ID，状态信息
     * @return 未审核通过数量
     */
    @Select(
            "SELECT count(1) FROM dspv2_t_ad t WHERE t.user_id = #{userId} AND t.review_status = #{reviewStatus}"
    )
    Integer auditFailCount(AdModel adModel);

    /**
     * 根据ID更新不为空的字段
     * @param adModel 待更新数据
     * @return 影响行数
     */
    @UpdateProvider(type = AdDaoSqlProvider.class, method = "updateByIdWithoutNull")
    Integer updateByIdWithoutNull(AdModel adModel);

    /**
     * 根据推广ID更新不为空的字段
     * @param adModel 待更新数据
     * @return 影响行数
     */
    @UpdateProvider(type = AdDaoSqlProvider.class, method = "updateByPromotionIdWithoutNull")
    Integer updateByPromotionIdWithoutNull(AdModel adModel);

    /**
     * 根据推广ID查询广告
     * @param promotionId 推广ID
     * @return 广告列表
     */
    @Select(
            "SELECT ad_id, user_id, operator, promotion_id, title, " +
                    " type, pv_report_url, click_report_url, video_start_play_report_url, video_end_play_report_url, " +
                    " create_time, update_time, status, version, review_status, no_pass_reason" +
                    " FROM dspv2_t_ad" +
                    " WHERE promotion_id = #{promotionId}"
    )
    @Results({
            @Result(property = "adId", column = "ad_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "promotionId", column = "promotion_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "pvReportUrl", column = "pv_report_url"),
            @Result(property = "clickReportUrl", column = "click_report_url"),
            @Result(property = "videoStartPlayReportUrl", column = "video_start_play_report_url"),
            @Result(property = "videoEndPlayReportUrl", column = "video_end_play_report_url"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status"),
            @Result(property = "version", column = "version"),
            @Result(property = "reviewStatus", column = "review_status"),
            @Result(property = "noPassReason", column = "no_pass_reason")

    })
    List<AdModel> selectByPromotionId(Long promotionId);

    /**
     * 切换推广下所有广告为下线状态。
     * @param adModel 推广ID, 状态
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_ad SET status=#{status}, operator=#{operator}, update_time=#{updateTime}" +
                    " WHERE promotion_id = #{promotionId}" +
                    " AND (status = 0 OR status = 1)"
    )
    Integer switchToOfflineByPromotionId(AdModel adModel);

    /**
     * 切换推广下所有广告位上线状态
     * @param adModel 推广ID，状态
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_ad SET status=#{status}, operator=#{operator}, update_time=#{updateTime}" +
                    " WHERE promotion_id = #{promotionId}" +
                    " AND (status = 0 OR status = 2)"
    )
    Integer switchToOnlineByPromotionId(AdModel adModel);

    /**
     * 查询用户所有的广告
     * @param adModel 用户ID
     * @return 符合条件的记录
     */
    @Results({
            @Result(property = "adId", column = "ad_id"),
            @Result(property = "userId", column = "user_id"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "promotionId", column = "promotion_id"),
            @Result(property = "title", column = "title"),
            @Result(property = "type", column = "type"),
            @Result(property = "pvReportUrl", column = "pv_report_url"),
            @Result(property = "clickReportUrl", column = "click_report_url"),
            @Result(property = "videoStartPlayReportUrl", column = "video_start_play_report_url"),
            @Result(property = "videoEndPlayReportUrl", column = "video_end_play_report_url"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status"),
            @Result(property = "version", column = "version"),
            @Result(property = "reviewStatus", column = "review_status"),
            @Result(property = "noPassReason", column = "no_pass_reason")

    })
    @SelectProvider(type = AdDaoSqlProvider.class, method = "list")
    List<AdModel> list(AdModel adModel);

}
