package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.common.SendEmailEnum;
import com.inveno.ad.dsp.conf.EmailConfigProperties;
import com.inveno.ad.dsp.dao.UserDao;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.EmailService;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisCluster;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@Service
public class EmailServiceImpl implements EmailService {

    public static Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    @Autowired
    private EmailConfigProperties emailConfigProperties;
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private JedisCluster jedisCluster;
    @Autowired
    private UserDao userDao;

    @Override
    public void sendSimpleEmail(String to, String subject, String content) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(emailConfigProperties.getAddr());
        message.setTo(to);
        message.setSubject(subject);
        message.setText(content);
        try {
            javaMailSender.send(message);
            logger.info("send simple email success. sendAddr={}", to);
        } catch (Exception e) {
            logger.error("send simple email error", e);
        }
    }

    @Override
    public void sendHtmlEmail(String to, String subject, String content) {
        MimeMessage message = javaMailSender.createMimeMessage();
        try {
            String nick = javax.mail.internet.MimeUtility.encodeText(emailConfigProperties.getNick());
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(emailConfigProperties.getAddr());
            helper.setFrom(new InternetAddress(emailConfigProperties.getAddr(), nick));
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content, true);
            javaMailSender.send(message);
            logger.info("send html email success. sendAddr={}", to);
        } catch (Exception e) {
            logger.error("send html email error", e);
        }
    }

    @Override
    public String getMailTemplate(String type) {
        if (!SendEmailEnum.contains(type)){
            throw new RuntimeException("send mail type not exist!");
        }
        String content = "";
        try {
            String fileName = "emailTemplate/";
            if (SendEmailEnum.SEND_VERIFICATION_CODE_EMAIL.getValue().equals(type)){
                fileName += "registerCodeEmail.txt";
            }else if (SendEmailEnum.SEND_FIND_PWD_EMAIL.getValue().equals(type)){
                fileName += "findPwdEmail.txt";
            }
            ClassPathResource classPathResource = new ClassPathResource(fileName);
            if (!classPathResource.exists()) {
                throw new RuntimeException(fileName + " not exist!");
            }
            content = FileUtils.readFileToString(classPathResource.getFile(), "UTF-8");
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return content;
    }

    @Override
    public void sendVerificationCode(String emailAddr) throws Exception {
        String verificationCode = String.valueOf(Math.round((Math.random() * 9 + 1) * 100000));
        String key = Constants.REDIS_KEY_VERIFICATION_CODE_PREFIX + emailAddr;
        jedisCluster.setex(key, 5 * 60, verificationCode);
        String content = getMailTemplate(SendEmailEnum.SEND_VERIFICATION_CODE_EMAIL.getValue()).replaceAll("registerCode", verificationCode);
        sendHtmlEmail(emailAddr, "DSP平台注册验证码", content);
    }

    @Override
    public void sendFindPwdCode(String emailAddr) throws Exception {
        UserModel userModel = userDao.findByEmail(emailAddr);
        if (userModel == null){
            throw new DspException(RetCode.ERR_EMAIL_NOT_EXIST);
        }

        String findPwdCode = String.valueOf(Math.round((Math.random() * 9 + 1) * 100000));
        String key = Constants.REDIS_KEY_FIND_PWD_CODE_PREFIX + emailAddr;
        jedisCluster.setex(key, 5 * 60, findPwdCode);
        String content = getMailTemplate(SendEmailEnum.SEND_FIND_PWD_EMAIL.getValue()).replaceAll("findPwdCode", findPwdCode);
        sendHtmlEmail(emailAddr, "DSP平台密码找回验证码", content);
    }
}
