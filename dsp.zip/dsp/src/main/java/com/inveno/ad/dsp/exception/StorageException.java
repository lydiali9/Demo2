package com.inveno.ad.dsp.exception;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
public class StorageException extends RuntimeException {
    public StorageException() {
    }

    public StorageException(String message) {
        super(message);
    }

    public StorageException(String message, Throwable cause) {
        super(message, cause);
    }

    public StorageException(Throwable cause) {
        super(cause);
    }

    public StorageException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
