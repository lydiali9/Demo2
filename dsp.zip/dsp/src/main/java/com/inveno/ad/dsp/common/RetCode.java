package com.inveno.ad.dsp.common;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.http.HttpStatus;

import java.text.MessageFormat;

/**
 * <p>Title: {@link RetCode}</p>
 * <p>Description: 返回信息 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public enum RetCode {

    /**
     * 成功返回码
     */
    OK(HttpStatus.OK.value(), HttpStatus.OK.getReasonPhrase()),
    /**
     * 服务错误
     */
    SERVICE_UNAVAILABLE(HttpStatus.SERVICE_UNAVAILABLE.value(), HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase()),
    /**
     * 参数错误
     */
    ERR_PARAM(HttpStatus.BAD_REQUEST.value(), "Invalid parameter[{0}={1}]."),
    /**
     * 用户登录错误
     */
    ERR_LOGIN_ERR(HttpStatus.FORBIDDEN.value(), "User not exist or password error."),
    /**
     * token过期
     */
    ERR_INVALID_TOKEN(HttpStatus.FORBIDDEN.value(), "Invalid token."),
    /**
     * 无权访问
     */
    ERR_FORBIDDEN(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase()),
    /**
     * 无权访问
     */
    ERR_STATUS_CONFLICT(HttpStatus.CONFLICT.value(), "Status[{0}] conflict."),
    /**
     * 重定向
     */
    REDIRECTION(HttpStatus.NOT_MODIFIED.value(), "Redirection."),

    ERR_LOGIN(10001, "User not exist or password error."),
    ERR_ACCOUNT_INSUFFICIENT_BALANCE(10002, "Unopened account"),
    /**
     * 用户未登录
     */
    ERR_USER_NOT_LOGIN(10003, "User not login"),
    /**
     * 验证码错误
     */
    ERR_VERIFICATION_CODE(10004, "Verification code error"),
    /**
     * 注册邮箱已存在
     */
    ERR_EMAIL_EXIST(10005, "Email exist"),
    /**
     * 登录验证码错误
     */
    ERR_CHECK_CODE(10006, "Check code error"),
    /**
     * 邮箱不存在
     */
    ERR_EMAIL_NOT_EXIST(10007, "Email not exist"),
    /**
     * 用户不存在
     */
    ERR_USER_NOT_EXIST(10008, "User not exist"),
    /**
     * 密码错误
     */
    ERR_OLD_PWD(10009, "Old password error"),
    /**
     * 帐户不存在
     */
    ERR_ACCOUNT_NOT_EXIST(10010, "Account not exist"),


    ERR_PROMOTION_INSUFFICIENT_BALANCE(20001, "Insufficient Balance"),
    ERR_PROMOTION_INFORMATION_CHANGED(20002, "User information changed"),
    ERR_PROMOTION_STATUS(20003, "Promotion status error."),
    ERR_PROMOTION_LINK_URL_APP_CANNOT_EDIT(20004, "Link url/app can't be edited."),
    ERR_PROMOTION_DISCARD_FAIL(20005, "Discard promotion fail. reason: {0}."),


    ERR_AD_STATUS(30001, "Ad status error."),
    ERR_AD_MESSAGE_CHANGED(30002, "Ad changed."),
    ERR_AD_PROMOTION_OFFLINE(30003, "Promotion offline."),

    /**
     * 图片太大
     */
    ERR_IMG_SIZE(40001, "Image size error."),

    ERR_IMG_SMALL_MIN_WIDTH(40002, "Small image min width error."),
    ERR_IMG_SMALL_MIN_HEIGHT(40003, "Small image min height error."),
    ERR_IMG_SMALL_RATIO(40004, "Small image ratio error."),

    ERR_IMG_BANNER_MIN_WIDTH(40005, "Banner min width error."),
    ERR_IMG_BANNER_MIN_HEIGHT(40006, "Banner min height error."),
    ERR_IMG_BANNER_RATIO(40007, "Banner ratio error."),

    ERR_IMG_HORIZONTAL_MIN_WIDTH(40008, "Horizontal image min width error."),
    ERR_IMG_HORIZONTAL_MIN_HEIGHT(40009, "Horizontal image min height error."),
    ERR_IMG_HORIZONTAL_RATIO(40010, "Horizontal image ratio error."),

    ERR_IMG_VERTICAL_MIN_WIDTH(40011, "Vertical image min width error."),
    ERR_IMG_VERTICAL_MIN_HEIGHT(40012, "Vertical image min height error."),
    ERR_IMG_VERTICAL_RATIO(40013, "Vertical image ratio error."),

    ERR_IMG_GROUP_MIN_WIDTH(40014, "Group image min width error."),
    ERR_IMG_GROUP_MIN_HEIGHT(40015, "Group image min height error."),
    ERR_IMG_GROUP_RATIO(40016, "Group image ratio error."),
    /**
     * 图片格式错误
     */
    ERR_IMG_FORMAT(40017, "Image format error."),

    ERR_APP_SIZE(50001, "App size is greater than max limit."),
    /**
     * 应用错误
     */
    ERR_APP_TYPE(50002, "App is not supported."),

    ERR_APP(50003, "App error");
    private int code;
    private String message;

    RetCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getMessage(Object... args) {
        if (ArrayUtils.isEmpty(args)) {
            return getMessage();
        }
        return MessageFormat.format(message, args);
    }
}
