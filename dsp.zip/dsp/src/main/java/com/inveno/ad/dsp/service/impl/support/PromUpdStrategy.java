package com.inveno.ad.dsp.service.impl.support;

import com.inveno.ad.dsp.model.PromotionModel;

/**
 * <p>Title: {@link PromUpdStrategy} </p>
 * <p>Description: 推广更新策略 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/30
 * 1、金额变大，时间天数未变
 *    a) 判断余额。
 *    b) 更新账户冻结表。
 *    c) 更新推广预算表。
 *    d) 更新推广上线时间表。
 * 2、金额变小，时间天数未变
 *    a) 当日金额取最大值，因此不变更，当日之后的冻结记录全部更新至最小值。
 *    b) 更新推广预算表。
 *    c) 更新上线时间表。
 * 3、时间增加，金额未变
 *    a) 判断余额。
 *    b) 新增冻结表记录。
 *    c) 更新推广预算表记录。
 *    d) 更新推广上线时间表。
 * 4、时间减少，金额未变
 *    a) 删除冻结表记录。
 *    d) 更新推广上线时间表。
 * 5、金额变大，时间增加
 *    a) 判断余额。
 *    b) 更新账户冻结表。
 *    c) 更新推广预算表。
 *    d) 更新推广上线时间表。
 * 6、金额变大，时间减少
 *    a) 判断余额。
 *    b) 更新账户冻结表。
 *    c) 更新推广预算表。
 *    d) 更新推广上线时间表。
 * 7、金额变小，时间增加
 *    a) 判断余额。
 *    b) 更新账户冻结表。
 *    c) 更新推广预算表。
 *    d) 更新推广上线时间表。
 * 8、金额变小，时间减少
 *    a) 更新账户冻结表。
 *    b) 更新推广预算表。
 *    c) 更新推广上线时间表。
 */
public interface PromUpdStrategy {

    /**
     * 更新策略
     * @param updatePromotionModel 待更新数据
     * @param promotionModelInDB 数据库中记录
     * @throws Exception 异常抛出
     */
    void update(PromotionModel updatePromotionModel, PromotionModel promotionModelInDB) throws Exception;

}
