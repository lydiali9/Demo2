package com.inveno.ad.dsp.model; /***********************************************************************
 * Module:  AccountFrozenModel.java
 * Author:  sugang
 * Purpose: Defines the Class AccountFrozenModel
 ***********************************************************************/

import java.math.BigDecimal;
import java.util.*;

/** 账户冻结表
 * 
 * @pdOid 1e1a121e-2562-4f96-aeb5-25769ad3c590 */
public class AccountFrozenModel {
   /** 账户id
    * 
    * @pdOid 3148d22d-96c8-4a6e-858f-6791bb7ea69c */
   private Integer id;
   /** @pdOid 87ceeee9-d338-4a55-b532-1ef96270b849 */
   private Integer userId;
   /** 账户冻结金额
    * 
    * @pdOid fd810cbb-0fca-4e8c-9a13-a36c568970af */
   private BigDecimal frozenAmount;
   /** @pdOid 80867f51-6b2c-4e13-9eac-379de398ad28 */
   private Date frozenDate;
   /** @pdOid 7e8e1e90-e11d-472c-91c1-7fd30f2e7b94 */
   private Long promotionId;
   /** @pdOid 950ce2f7-83d9-4a7d-87c7-edc678a01559 */
   private Date createTime;
   /** @pdOid 128b6ead-343e-4b07-8e2e-51d65a95de34 */
   private Date updateTime;
   /** @pdOid 71bbcafe-3d37-4fe7-a23e-295593fcb8c6 */
   private Integer status;

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public Integer getUserId() {
      return userId;
   }

   public void setUserId(Integer userId) {
      this.userId = userId;
   }

   public BigDecimal getFrozenAmount() {
      return frozenAmount;
   }

   public void setFrozenAmount(BigDecimal frozenAmount) {
      this.frozenAmount = frozenAmount;
   }

   public Date getFrozenDate() {
      return frozenDate;
   }

   public void setFrozenDate(Date frozenDate) {
      this.frozenDate = frozenDate;
   }

   public Long getPromotionId() {
      return promotionId;
   }

   public void setPromotionId(Long promotionId) {
      this.promotionId = promotionId;
   }

   public Date getCreateTime() {
      return createTime;
   }

   public void setCreateTime(Date createTime) {
      this.createTime = createTime;
   }

   public Date getUpdateTime() {
      return updateTime;
   }

   public void setUpdateTime(Date updateTime) {
      this.updateTime = updateTime;
   }

   public Integer getStatus() {
      return status;
   }

   public void setStatus(Integer status) {
      this.status = status;
   }
}