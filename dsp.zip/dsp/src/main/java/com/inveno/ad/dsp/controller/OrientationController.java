package com.inveno.ad.dsp.controller;

import com.alibaba.fastjson.JSONArray;
import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.model.OrientationModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.service.OrientationService;
import com.inveno.ad.dsp.util.DateUtils;
import com.inveno.ad.dsp.vo.OrientationVo;
import com.inveno.ad.dsp.vo.PageResponseVo;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>Title: {@link OrientationController} </p>
 * <p>Description: 定向包controller </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
@RestController
public class OrientationController {

    @Autowired
    private OrientationService orientationService;

    @PostMapping("/orientation")
    @ResponseBody
    public VoContainer<OrientationVo> create(OrientationVo orientationVo) throws Exception {
        OrientationModel orientationModel = voToModel(orientationVo);
        orientationModel.setUserId(orientationVo.getOperator());
        Integer id = orientationService.create(orientationModel);
        OrientationVo result = new OrientationVo();
        result.setId(id);
        return VoContainerHelper.createVoContainer(result, RetCode.OK);
    }

    @GetMapping("/orientation/id")
    @ResponseBody
    public VoContainer<OrientationVo> get(OrientationVo orientationVo) throws Exception {
        OrientationModel orientationModel = orientationService.get(orientationVo.getId());
        OrientationVo ret = modelToVo(orientationModel);
        return VoContainerHelper.createVoContainer(ret, RetCode.OK);
    }

    @DeleteMapping("/orientation")
    @ResponseBody
    public VoContainer<OrientationVo> delete(OrientationVo orientationVo) throws Exception {
        orientationService.delete(orientationVo.getId());
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @PutMapping("/orientation")
    @ResponseBody
    public VoContainer<OrientationVo> update(OrientationVo orientationVo) throws Exception {
        OrientationModel orientationModel = voToModel(orientationVo);
        orientationService.update(orientationModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @GetMapping("/orientation")
    @ResponseBody
    public VoContainer<List<OrientationVo>> pageQuery(OrientationVo orientationVo) throws Exception {
        OrientationModel paramOrientationModel = new OrientationModel();
        paramOrientationModel.setUserId(orientationVo.getOperator());
        paramOrientationModel.setStartTime(DateUtils.parseDate(orientationVo.getStartTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        paramOrientationModel.setEndTime(DateUtils.parseDate(orientationVo.getEndTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        paramOrientationModel.setTitle(orientationVo.getTitle());
        paramOrientationModel.setKeyword(orientationVo.getKeyword());

        PageModel<OrientationModel> pageModel = new PageModel<>();
        pageModel.setOffset((orientationVo.getCurrentPageNo() - 1) * orientationVo.getEachPageCapacity());
        pageModel.setCount(orientationVo.getEachPageCapacity());
        pageModel.setRequest(paramOrientationModel);
        pageModel = orientationService.pageQuery(pageModel);

        List<OrientationModel> orientationModelList = pageModel.getResponse();
        List<OrientationVo> orientationVoList = modelToVo(orientationModelList);

        PageResponseVo pageResponseVo = new PageResponseVo();
        pageResponseVo.setCurrentPageNo(orientationVo.getCurrentPageNo());
        pageResponseVo.setEachPageCapacity(orientationVo.getEachPageCapacity());
        pageResponseVo.setTotalCount(pageModel.getTotalCount());
        return VoContainerHelper.createPageVoContainer(orientationVoList, pageResponseVo, RetCode.OK);
    }

    @GetMapping("/orientation/list")
    @ResponseBody
    public VoContainer<List<OrientationVo>> templateList(OrientationVo orientationVo) throws Exception {
        OrientationModel paramOrientationModel = new OrientationModel();
        paramOrientationModel.setUserId(orientationVo.getOperator());
        List<OrientationModel> orientationModelList = orientationService.templateList(paramOrientationModel);
        List<OrientationVo> orientationVoList = modelToVo(orientationModelList);
        return VoContainerHelper.createVoContainer(orientationVoList, RetCode.OK);
    }

    private List<OrientationVo> modelToVo(List<OrientationModel> orientationModelList) {
        List<OrientationVo> orientationVoList = null;
        if (CollectionUtils.isNotEmpty(orientationModelList)) {
            orientationVoList = new ArrayList<>(orientationModelList.size());
            for (OrientationModel orientationModel : orientationModelList) {
                OrientationVo ret = modelToVo(orientationModel);
                orientationVoList.add(ret);
            }
        }
        return orientationVoList;
    }

    private OrientationVo modelToVo(OrientationModel orientationModel) {
        OrientationVo orientationVo = null;
        if (null != orientationModel) {
            orientationVo = new OrientationVo();
            BeanUtils.copyProperties(orientationModel, orientationVo, "age", "platform", "network", "networkOperator");

            JSONArray ageNumberJSONArray = new JSONArray();
            if (StringUtils.isNotBlank(orientationModel.getAge())) {
                JSONArray ageLabelJSONArray = JSONArray.parseArray(orientationModel.getAge());
                if (!ageLabelJSONArray.isEmpty()) {
                    ageLabelJSONArray.toJavaList(String.class).stream()
                            .map(AgeEnum::parse)
                            .filter(e -> AgeEnum.UNLIMITED.getNumber() != e.getNumber())
                            .map(AgeEnum::getNumber)
                            .forEach(ageNumberJSONArray::add);
                }
            }
            if (ageNumberJSONArray.isEmpty()) {
                ageNumberJSONArray.add(AgeEnum.UNLIMITED.getNumber());
            }
            orientationVo.setAge(ageNumberJSONArray.toJSONString());

//            JSONArray platformNumberJSONArray = new JSONArray();
//            if (StringUtils.isNotBlank(orientationModel.getPlatform())) {
//                JSONArray platformLabelJSONArray = JSONArray.parseArray(orientationModel.getPlatform());
//                if (!platformLabelJSONArray.isEmpty()) {
//                    platformLabelJSONArray.toJavaList(String.class).stream()
//                            .map(PlatformEnum::parse)
//                            .filter(e -> PlatformEnum.UNLIMITED.getNumber() != e.getNumber())
//                            .map(PlatformEnum::getNumber)
//                            .forEach(platformNumberJSONArray::add);
//                }
//            }
//            if (platformNumberJSONArray.isEmpty()) {
//                platformNumberJSONArray.add(PlatformEnum.UNLIMITED.getNumber());
//            }
//            orientationVo.setPlatform(platformNumberJSONArray.toJSONString());
            if (StringUtils.isNotBlank(orientationModel.getPlatform())) {
                orientationVo.setPlatform(String.valueOf(PlatformEnum.parse(orientationModel.getPlatform()).getNumber()));
            } else {
                orientationVo.setPlatform(String.valueOf(PlatformEnum.UNLIMITED.getNumber()));
            }

            JSONArray networkNumberJSONArray = new JSONArray();
            if (StringUtils.isNotBlank(orientationModel.getNetwork())) {
                JSONArray networkLabelJSONArray = JSONArray.parseArray(orientationModel.getNetwork());
                if (!networkLabelJSONArray.isEmpty()) {
                    networkLabelJSONArray.toJavaList(String.class).stream()
                            .map(NetworkEnum::parse)
                            .filter(e -> 0 != e.getNumber())
                            .map(NetworkEnum::getNumber)
                            .forEach(networkNumberJSONArray::add);
                }
            }
            if (networkNumberJSONArray.isEmpty()) {
                networkNumberJSONArray.add(NetworkEnum.UNLIMITED.getNumber());
            }
            orientationVo.setNetwork(networkNumberJSONArray.toJSONString());

            JSONArray networkOperatorNumberJSONArray = new JSONArray();
            if (StringUtils.isNotBlank(orientationModel.getNetworkOperator())) {
                JSONArray networkOperatorLabelJSONArray = JSONArray.parseArray(orientationModel.getNetworkOperator());
                if (!networkOperatorLabelJSONArray.isEmpty()) {
                    networkOperatorLabelJSONArray.toJavaList(String.class).stream()
                            .map(NetworkOperatorEnum::parse)
                            .filter(e -> NetworkOperatorEnum.UNLIMITED.getNumber() != e.getNumber())
                            .map(NetworkOperatorEnum::getNumber)
                            .forEach(networkOperatorNumberJSONArray::add);
                }
            }
            if (networkOperatorNumberJSONArray.isEmpty()) {
                networkOperatorNumberJSONArray.add(NetworkOperatorEnum.UNLIMITED.getNumber());
            }
            orientationVo.setNetworkOperator(networkOperatorNumberJSONArray.toJSONString());

            orientationVo.setCreateTime(DateFormatUtils.format(orientationModel.getCreateTime(), DateUtils.FMT_yyyyMMddHHmmss_));
        }
        return orientationVo;
    }


    private OrientationModel voToModel(OrientationVo orientationVo) {
        OrientationModel orientationModel = new OrientationModel();
        BeanUtils.copyProperties(orientationVo, orientationModel, "age", "platform", "network", "networkOperator");
        JSONArray ageNumberJSONArray = JSONArray.parseArray(orientationVo.getAge());
        JSONArray ageLabelJSONArray = new JSONArray();
        ageNumberJSONArray.toJavaList(Integer.class).stream()
                .map(AgeEnum::parse)
                .filter(e -> AgeEnum.UNLIMITED.getNumber() != e.getNumber())
                .map(AgeEnum::getLabel)
                .forEach(ageLabelJSONArray::add);
        if (!ageLabelJSONArray.isEmpty()) {
            orientationModel.setAge(ageLabelJSONArray.toJSONString());
        }

//        JSONArray platformNumberJSONArray = JSONArray.parseArray(orientationVo.getPlatform());
//        JSONArray platformLabelJSONArray = new JSONArray();
//        platformNumberJSONArray.toJavaList(Integer.class).stream()
//                .map(PlatformEnum::parse)
//                .filter(e -> PlatformEnum.UNLIMITED.getNumber() != e.getNumber())
//                .map(PlatformEnum::getLabel)
//                .forEach(platformLabelJSONArray::add);
//        if (!platformLabelJSONArray.isEmpty()) {
//            orientationModel.setPlatform(platformLabelJSONArray.toJSONString());
//        }
        if (StringUtils.isNotBlank(orientationVo.getPlatform())) {
            PlatformEnum platformEnum = PlatformEnum.parse(Integer.parseInt(orientationVo.getPlatform()));
            if (null != platformEnum && PlatformEnum.UNLIMITED != platformEnum) {
                orientationModel.setPlatform(platformEnum.getLabel());
            }
        }

        JSONArray networkNumberJSONArray = JSONArray.parseArray(orientationVo.getNetwork());
        JSONArray networkLabelJSONArray = new JSONArray();
        networkNumberJSONArray.toJavaList(Integer.class).stream()
                .map(NetworkEnum::parse)
                .filter(e -> NetworkOperatorEnum.UNLIMITED.getNumber() != e.getNumber())
                .map(NetworkEnum::getLabel)
                .forEach(networkLabelJSONArray::add);
        if (!networkLabelJSONArray.isEmpty()) {
            orientationModel.setNetwork(networkLabelJSONArray.toJSONString());
        }

        JSONArray networkOperatorNumberJSONArray = JSONArray.parseArray(orientationVo.getNetworkOperator());
        JSONArray networkOperatorLabelJSONArray = new JSONArray();
        networkOperatorNumberJSONArray.toJavaList(Integer.class).stream().map(NetworkOperatorEnum::parse).filter(e -> 0 != e.getNumber()).map(NetworkOperatorEnum::getLabel).forEach(networkOperatorLabelJSONArray::add);
        if (!networkOperatorLabelJSONArray.isEmpty()) {
            orientationModel.setNetworkOperator(networkOperatorLabelJSONArray.toJSONString());
        }

        return orientationModel;
    }

}
