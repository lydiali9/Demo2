package com.inveno.ad.dsp.util;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
public class DateUtils extends org.apache.commons.lang3.time.DateUtils {

    public static final String FMT_yyyyMMddHHmmss_ = "yyyy-MM-dd HH:mm:ss";
    public static final String FMT_yyyyMMdd = "yyyy-MM-dd";

    public static int getDay(Date date) {
        Calendar startCalender = Calendar.getInstance();
        startCalender.setTime(date);
        return startCalender.get(Calendar.DAY_OF_YEAR);
    }

    public static String getStringDate(Date date) {
        if (date == null) return null;

        SimpleDateFormat format = new SimpleDateFormat(FMT_yyyyMMdd);
        return format.format(date);
    }

    public static String getStringDateTime(Date date) {
        if (date == null) return null;

        SimpleDateFormat format = new SimpleDateFormat(FMT_yyyyMMddHHmmss_);
        return format.format(date);
    }

    public static Date strToDateTime(String strDate) {
        SimpleDateFormat formatter = new SimpleDateFormat(FMT_yyyyMMddHHmmss_);
        ParsePosition pos = new ParsePosition(0);
        return formatter.parse(strDate, pos);
    }
}
