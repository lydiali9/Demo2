package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link BigImageTypeEnum} </p>
 * <p>Description: 大图类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/11
 */
public enum BigImageTypeEnum {

    BANNER(1),
    HORIZONTAL(2),
    VERTICAL(3);

    private int value;

    BigImageTypeEnum(int value) {
        this.value = value;
    }

    public static boolean contains(int value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue() == value);
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
