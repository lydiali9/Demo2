package com.inveno.ad.dsp.common;

public enum SearchTimeIntervalType {

    SEARCH_CREATE_TIME(1),
    SEARCH_DELIVER_TIME(2);

    private Integer value;

    SearchTimeIntervalType(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
