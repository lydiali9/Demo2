package com.inveno.ad.dsp.common;

public enum OpenCloseEnum {
    OPEN(1),
    CLOSE(0);

    int value;

    OpenCloseEnum(int value){
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
