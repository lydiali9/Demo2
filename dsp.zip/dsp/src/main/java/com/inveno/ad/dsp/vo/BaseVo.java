package com.inveno.ad.dsp.vo;

import java.io.Serializable;

/**
 * <p>Title: {@link BaseVo} </p>
 * <p>Description: vo基类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public class BaseVo implements Serializable {

    private Integer operator;

    public Integer getOperator() {
        return operator;
    }

    public void setOperator(Integer operator) {
        this.operator = operator;
    }
}
