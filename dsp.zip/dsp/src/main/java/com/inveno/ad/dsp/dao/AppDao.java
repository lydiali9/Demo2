package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AppModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p>Title: {@link AppDao}</p>
 * <p>Description: 应用dao类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
@Mapper
public interface AppDao {

    /**
     * 插入应用
     * @param appModel 应用具体信息
     * @return 新增应用ID
     */
    @Insert(
            "INSERT INTO dspv2_t_app(" +
                    "user_id,name,app_type,os,package,package_size,url,description,url_type,create_time,update_time,status,version,folder" +
                    ")" +
                    "VALUES" +
                    "(" +
                    "#{userId},#{name},#{appType},#{os},#{appPackage}," +
                    "#{packageSize},#{url},#{description},#{urlType},#{createTime},#{updateTime}," +
                    "#{status}, #{version}, #{folder}" +
                    ")"
    )
    @Options(useGeneratedKeys = true)
    Integer insert(AppModel appModel);

    /**
     * 根据用户ID查询应用
     * @param userId 用户ID
     * @return 用户的应用列表
     */
    @Select(
            "SELECT id,user_id,name,app_type,os,package,package_size,url,url_type,create_time,update_time,status,version, description, folder " +
                    " FROM dspv2_t_app t " +
                    " WHERE t.user_id = #{userId}"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "name", column = "name"),
                    @Result(property = "appType", column = "app_type"),
                    @Result(property = "os", column = "os"),
                    @Result(property = "appPackage", column = "package"),
                    @Result(property = "packageSize", column = "package_size"),
                    @Result(property = "url", column = "url"),
                    @Result(property = "urlType", column = "url_type"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "status", column = "status"),
                    @Result(property = "version", column = "version"),
                    @Result(property = "description", column = "description"),
                    @Result(property = "folder", column = "folder")
            }
    )
    List<AppModel> selectByUserId(Integer userId);

    /**
     * 根据ID查询应用
     * @param id ID
     * @return 用户的应用列表
     */
    @Select(
            "SELECT id,user_id,name,app_type,os,package,package_size,url,url_type,create_time,update_time,status, version, description, folder " +
                    " FROM dspv2_t_app t " +
                    " WHERE t.id = #{id}"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "name", column = "name"),
                    @Result(property = "appType", column = "app_type"),
                    @Result(property = "os", column = "os"),
                    @Result(property = "appPackage", column = "package"),
                    @Result(property = "packageSize", column = "package_size"),
                    @Result(property = "url", column = "url"),
                    @Result(property = "urlType", column = "url_type"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "status", column = "status"),
                    @Result(property = "version", column = "version"),
                    @Result(property = "description", column = "description"),
                    @Result(property = "folder", column = "folder")
            }
    )
    AppModel selectById(Integer id);

    /**
     * 分页查询APP信息总数
     * @param pageModel 分页条件
     * @return 符合条件的定向包数量
     */
    @SelectProvider(type = AppDaoSqlProvider.class, method = "pageQueryTotalCount")
    Integer pageQueryTotalCount(PageModel<AppModel> pageModel);

    /**
     * 分页查询APP列表
     * @param pageModel 分页条件
     * @return 符合条件的定向包列表
     */
    @SelectProvider(type = AppDaoSqlProvider.class, method = "pageQuery")
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "name", column = "name"),
                    @Result(property = "appType", column = "app_type"),
                    @Result(property = "os", column = "os"),
                    @Result(property = "appPackage", column = "package"),
                    @Result(property = "packageSize", column = "package_size"),
                    @Result(property = "url", column = "url"),
                    @Result(property = "urlType", column = "url_type"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "status", column = "status"),
                    @Result(property = "version", column = "version"),
                    @Result(property = "description", column = "description"),
                    @Result(property = "folder", column = "folder")
            }
    )
    List<AppModel> pageQuery(PageModel<AppModel> pageModel);

    /**
     * 根据ID删除应用
     * @param id 应用ID
     * @return 影响行数
     */
    @Delete("DELETE FROM dspv2_t_app where id = #{id}")
    Integer delete(int id);

    /**
     * 更新应用
     * @param appModel 更新详情
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_app t SET " +
                    "name = #{name}," +
                    "app_type = #{appType}," +
                    "os = #{os}," +
                    "package = #{appPackage}," +
                    "package_size = #{packageSize}," +
                    "version = #{version}," +
                    "description = #{description}," +
                    "url = #{url}," +
                    "url_type = #{urlType}," +
                    "folder = #{folder}," +
                    "update_time = #{updateTime}" +
                    " WHERE id = #{id}"
    )
    Integer updateById(AppModel appModel);

}
