package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.dao.AdReportHourlyDao;
import com.inveno.ad.dsp.model.AdReportHourlyModel;
import com.inveno.ad.dsp.service.AdReportHourlyService;
import com.inveno.ad.dsp.vo.AdReportHourlyVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdReportHourlyServiceImpl implements AdReportHourlyService {

    @Autowired
    private AdReportHourlyDao adReportHourlyDao;

    @Override
    public List<AdReportHourlyVo> queryPromotion(AdReportHourlyVo adReportHourlyVo, Integer userId) {
        List<AdReportHourlyVo> adReportHourlyVoList = new ArrayList<>();
        AdReportHourlyModel adReportHourlyModel = new AdReportHourlyModel();
        BeanUtils.copyProperties(adReportHourlyVo, adReportHourlyModel);
        adReportHourlyModel.setUserId(userId);
        List<AdReportHourlyModel> adReportHourlyModelList = adReportHourlyDao.selectPromotionData(adReportHourlyModel);

        for (AdReportHourlyModel reportHourlyModel : adReportHourlyModelList){
            AdReportHourlyVo reportHourlyVo = new AdReportHourlyVo();
            BeanUtils.copyProperties(reportHourlyModel, reportHourlyVo);
            adReportHourlyVoList.add(reportHourlyVo);
        }

        return adReportHourlyVoList;
    }

    @Override
    public List<AdReportHourlyVo> queryAd(AdReportHourlyVo adReportHourlyVo, Integer userId) {
        List<AdReportHourlyVo> adReportHourlyVoList = new ArrayList<>();
        AdReportHourlyModel adReportHourlyModel = new AdReportHourlyModel();
        BeanUtils.copyProperties(adReportHourlyVo, adReportHourlyModel);
        adReportHourlyModel.setUserId(userId);
        List<AdReportHourlyModel> adReportHourlyModelList = adReportHourlyDao.selectAdData(adReportHourlyModel);

        for (AdReportHourlyModel reportHourlyModel : adReportHourlyModelList){
            AdReportHourlyVo reportHourlyVo = new AdReportHourlyVo();
            BeanUtils.copyProperties(reportHourlyModel, reportHourlyVo);
            adReportHourlyVoList.add(reportHourlyVo);
        }

        return adReportHourlyVoList;
    }

    @Override
    public List<AdReportHourlyVo> queryUser(AdReportHourlyVo adReportHourlyVo, Integer userId) {
        List<AdReportHourlyVo> adReportHourlyVoList = new ArrayList<>();
        AdReportHourlyModel adReportHourlyModel = new AdReportHourlyModel();
        BeanUtils.copyProperties(adReportHourlyVo, adReportHourlyModel);
        adReportHourlyModel.setUserId(userId);
        List<AdReportHourlyModel> adReportHourlyModelList = adReportHourlyDao.selectUserData(adReportHourlyModel);

        for (AdReportHourlyModel reportHourlyModel : adReportHourlyModelList){
            AdReportHourlyVo reportHourlyVo = new AdReportHourlyVo();
            BeanUtils.copyProperties(reportHourlyModel, reportHourlyVo);
            adReportHourlyVoList.add(reportHourlyVo);
        }

        return adReportHourlyVoList;
    }
}
