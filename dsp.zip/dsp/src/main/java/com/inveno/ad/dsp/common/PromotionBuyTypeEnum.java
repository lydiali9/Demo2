package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link PromotionBuyTypeEnum}</p>
 * <p>Description: 推广购买方式 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public enum PromotionBuyTypeEnum {

    /**
     * 竞争购买
     */
    BIDDING(1),
    /**
     * 私有化采买
     */
    PRIV(2);

    private int value;

    PromotionBuyTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
