package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.bean.ImageServiceRespBean;
import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.common.ImgQualityEnum;
import com.inveno.ad.dsp.conf.ImageServerConfigProperties;
import com.inveno.ad.dsp.exception.ImageServerException;
import com.inveno.ad.dsp.service.ImageSyncService;
import com.inveno.ad.imagecloud.ImageAddReq;
import com.inveno.ad.imagecloud.ImageAddResp;
import com.inveno.ad.imagecloud.ImageTransport;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TFastFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * 图片同步服务<br>
 * 向ImageTransport同步图片
 *
 * @author sugang
 */
@Component
public class ImageSyncServiceImpl implements ImageSyncService {

    private static Logger logger = LoggerFactory.getLogger(OpenUserServiceImpl.class);

    @Autowired
    private ImageServerConfigProperties imageServerConfigProperties;

    //    @Async
    @Override
    @Transactional(propagation = Propagation.MANDATORY, rollbackFor = Exception.class)
    public ImageServiceRespBean upload(String imgUrl) throws Exception {
        TSocket socket = new TSocket(imageServerConfigProperties.getHost(), imageServerConfigProperties.getPort(), imageServerConfigProperties.getTimeout());
        socket.open();
        try (TFastFramedTransport transport = new TFastFramedTransport(socket, imageServerConfigProperties.getInitialBufferCapacity(), imageServerConfigProperties.getMaxLength())) {
            TProtocol protocol = new TBinaryProtocol(transport);
            ImageTransport.Client client = new ImageTransport.Client(protocol);
            ImageAddReq img = new ImageAddReq();
            img.setUrl(imgUrl);
            ImageAddResp imageAddResp = client.addoneimgv2(img);
            logger.debug("img server response: {}", imageAddResp.toString());
            if (imageAddResp.getStatus() != 0) {
                throw new ImageServerException("Upload image error.");
            }
            return buildImgRespBean(imageAddResp, imgUrl);
        } catch (Exception e) {
            logger.error("upload image error.", e);
            throw e;
        }
    }

    /**
     * 云图没有提供批量上传的接口
     * @param imgUrlList 本地图片url
     * @return 云图响应结果集
     * @throws Exception 异常抛出
     */
    @Override
    @Transactional(propagation = Propagation.MANDATORY, rollbackFor = Exception.class)
    public List<ImageServiceRespBean> upload(List<String> imgUrlList) throws Exception {
        List<ImageServiceRespBean> imageServiceRespBeanList = null;
        if (CollectionUtils.isNotEmpty(imgUrlList)) {
            imageServiceRespBeanList = new ArrayList<>(imgUrlList.size());
            TSocket socket = new TSocket(imageServerConfigProperties.getHost(), imageServerConfigProperties.getPort(), imageServerConfigProperties.getTimeout());
            socket.open();
            try (TFastFramedTransport transport = new TFastFramedTransport(socket, imageServerConfigProperties.getInitialBufferCapacity(), imageServerConfigProperties.getMaxLength())) {
                TProtocol protocol = new TBinaryProtocol(transport);
                ImageTransport.Client client = new ImageTransport.Client(protocol);
                for (String imgUrl : imgUrlList) {
                    ImageAddReq img = new ImageAddReq();
                    img.setUrl(imgUrl);
                    ImageAddResp imageAddResp = client.addoneimgv2(img);
                    logger.debug("img server response: {}", imageAddResp.toString());
                    if (imageAddResp.getStatus() != 0) {
                        throw new ImageServerException("Upload image error.");
                    }
                    imageServiceRespBeanList.add(buildImgRespBean(imageAddResp, imgUrl));
                }
            } catch (Exception e) {
                logger.error("upload image error.", e);
                throw e;
            }
        }
        return imageServiceRespBeanList;
    }

    private ImageServiceRespBean buildImgRespBean(ImageAddResp imageAddResp, String srcUrl) {
        ImageServiceRespBean imageServiceRespBean = new ImageServiceRespBean();
        imageServiceRespBean.setSrcUrl(srcUrl);
        imageServiceRespBean.setHeight(imageAddResp.getHeigh());
        imageServiceRespBean.setWidth(imageAddResp.getWidth());
        imageServiceRespBean.setUrlKey(imageAddResp.getUrlkey());
        imageServiceRespBean.setUrl(buildUrl(imageAddResp));
        return imageServiceRespBean;
    }

    private String buildUrl(ImageAddResp imageAddResp) {
        StringBuilder urlBuilder = new StringBuilder(imageServerConfigProperties.getDomain());
        urlBuilder.append(Constants.SEPARATOR_QUESTION);
        if (StringUtils.isNotBlank(imageServerConfigProperties.getQuality())
                && ImgQualityEnum.contains(imageServerConfigProperties.getQuality())) {
            urlBuilder.append("quality");
            urlBuilder.append(Constants.SEPARATOR_EQUAL);
            urlBuilder.append(imageServerConfigProperties.getQuality());
            urlBuilder.append(Constants.SEPARATOR_AND);
        }
        urlBuilder.append("id");
        urlBuilder.append(Constants.SEPARATOR_EQUAL);
        urlBuilder.append(imageAddResp.getUrlkey());
        return urlBuilder.toString();
    }

}
