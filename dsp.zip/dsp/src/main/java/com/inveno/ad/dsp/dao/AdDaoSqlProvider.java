package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.common.SearchTimeIntervalType;
import com.inveno.ad.dsp.model.AdModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.util.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.jdbc.SQL;

/**
 * <p>Title: {@link AdDaoSqlProvider}</p>
 * <p>Description: 广告DAO SQL提供类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/4
 */
public class AdDaoSqlProvider extends AbstractSqlProvider {

    public String pageQueryTotalCount(PageModel<AdModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(" SELECT ");
        sqlBuilder.append(" count(1) FROM ( ");
        sqlBuilder.append("SELECT ");
        sqlBuilder.append(" ad.ad_id ");
        sqlBuilder.append("FROM ");
        sqlBuilder.append(" dspv2_t_ad ad ");
        sqlBuilder.append(" LEFT JOIN dspv2_t_promotion prom ON ad.promotion_id = prom.id ");
        sqlBuilder.append(" LEFT JOIN dspv2_t_ad_report_daily ard ON ad.ad_id = ard.ad_id ");
        sqlBuilder.append(" WHERE ad.user_id = #{request.userId} ");

        if (SearchTimeIntervalType.SEARCH_CREATE_TIME.getValue().equals(pageModel.getRequest().getTimeIntervalType())) {
            // 此处先借用deliverStartTime、deliverEndTime这两个属性,本来应该新增两个用来搜索createTime的属性的
            String startCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getPromotion().getDeliverStartTime()) + " 00:00:00";
            String endCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getPromotion().getDeliverEndTime()) + " 23:59:59";
            pageModel.getRequest().getPromotion().setDeliverStartTime(DateUtils.strToDateTime(startCreateTimeStr));
            pageModel.getRequest().getPromotion().setDeliverEndTime(DateUtils.strToDateTime(endCreateTimeStr));
            sqlBuilder.append(" AND DATE_FORMAT(ad.create_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(ad.create_time, '%Y-%m-%d')<= #{request.promotion.deliverEndTime}");
        } else {
            sqlBuilder.append(" AND ((DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d')<= #{request.promotion.deliverEndTime})");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.promotion.deliverEndTime}) ");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.promotion.deliverEndTime})) ");
        }

        if (null != pageModel.getRequest().getPromotionId()) {
            sqlBuilder.append(" AND prom.id = #{request.promotionId} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND prom.title like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getAdId()) {
            sqlBuilder.append(" AND ad.ad_id = #{request.adId} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getKeyword())) {
            sqlBuilder.append(" AND (prom.title like concat('%', #{request.keyword}, '%') OR  ad.ad_id like concat('%', #{request.keyword}, '%'))");
        }
        if (null != pageModel.getRequest().getStatus()) {
            sqlBuilder.append(" AND ad.status = #{request.status} ");
        }
        if (null != pageModel.getRequest().getReviewStatus()) {
            sqlBuilder.append(" AND ad.review_status = #{request.reviewStatus} ");
        }
        sqlBuilder.append("GROUP BY ");
        sqlBuilder.append(" ad.ad_id) TMP ");
        return sqlBuilder.toString();
    }

    public String pageQuery(PageModel<AdModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("SELECT ");
        sqlBuilder.append(" ad.ad_id, ");
        sqlBuilder.append(" (SELECT count(1) FROM dspv2_t_ad_material am WHERE am.ad_id = ad.ad_id AND source = #{request.materialSource}) AS mat_num, ");
        sqlBuilder.append(" ad.status, ");
        sqlBuilder.append(" ad.version, ");
        sqlBuilder.append(" ad.promotion_id, ");
        sqlBuilder.append(" ad.type, ");
        sqlBuilder.append(" ad.version, ");
        sqlBuilder.append(" ad.title, ");
        sqlBuilder.append(" ad.user_id, ");
        sqlBuilder.append(" ad.review_status, ");
        sqlBuilder.append(" ad.no_pass_reason, ");
        sqlBuilder.append(" prom.title prom_title, ");
        sqlBuilder.append(" prom.deliver_start_time, ");
        sqlBuilder.append(" prom.deliver_end_time, ");
        sqlBuilder.append(" SUM(ard.pv) pv, ");
        sqlBuilder.append(" SUM(ard.click) click, ");
        sqlBuilder.append(" convert(SUM(ard.click) / SUM(ard.pv) * 100, decimal(10,2)) ctr, ");
        sqlBuilder.append(" convert(SUM(ard.total_cost) / SUM(ard.pv) * 1000, decimal(10,2)) ecpm, ");
        sqlBuilder.append(" convert(SUM(ard.total_cost) / SUM(ard.click), decimal(10,2)) ecpc,  ");
        sqlBuilder.append(" SUM(ard.total_cost) total_cost ");
        sqlBuilder.append("FROM ");
        sqlBuilder.append(" dspv2_t_ad ad ");
        sqlBuilder.append(" LEFT JOIN dspv2_t_promotion prom ON ad.promotion_id = prom.id ");
        sqlBuilder.append(" LEFT JOIN dspv2_t_ad_report_daily ard ON ad.ad_id = ard.ad_id ");
        sqlBuilder.append(" WHERE ad.user_id = #{request.userId} ");

        if (SearchTimeIntervalType.SEARCH_CREATE_TIME.getValue().equals(pageModel.getRequest().getTimeIntervalType())) {
            // 此处先借用deliverStartTime、deliverEndTime这两个属性,本来应该新增两个用来搜索createTime的属性的
            String startCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getPromotion().getDeliverStartTime()) + " 00:00:00";
            String endCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getPromotion().getDeliverEndTime()) + " 23:59:59";
            pageModel.getRequest().getPromotion().setDeliverStartTime(DateUtils.strToDateTime(startCreateTimeStr));
            pageModel.getRequest().getPromotion().setDeliverEndTime(DateUtils.strToDateTime(endCreateTimeStr));
            sqlBuilder.append(" AND DATE_FORMAT(ad.create_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(ad.create_time, '%Y-%m-%d')<= #{request.promotion.deliverEndTime} ");
        } else {
            sqlBuilder.append(" AND ((DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d')<= #{request.promotion.deliverEndTime})");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.promotion.deliverEndTime}) ");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.promotion.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.promotion.deliverEndTime})) ");
        }

//        sqlBuilder.append(" AND ((prom.deliver_start_time >= #{request.promotion.deliverStartTime} AND prom.deliver_start_time<= #{request.promotion.deliverEndTime})");
//        sqlBuilder.append(" OR (prom.deliver_end_time >= #{request.promotion.deliverStartTime} AND prom.deliver_end_time <= #{request.promotion.deliverEndTime}) ");
//        sqlBuilder.append(" OR (prom.deliver_start_time >= #{request.promotion.deliverStartTime} AND prom.deliver_end_time <= #{request.promotion.deliverEndTime})) ");
        if (null != pageModel.getRequest().getPromotionId()) {
            sqlBuilder.append(" AND prom.id = #{request.promotionId} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND prom.title like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getAdId()) {
            sqlBuilder.append(" AND ad.ad_id = #{request.adId} ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getKeyword())) {
            sqlBuilder.append(" AND (prom.title like concat('%', #{request.keyword}, '%') OR  ad.ad_id like concat('%', #{request.keyword}, '%'))");
        }
        if (null != pageModel.getRequest().getStatus()) {
            sqlBuilder.append(" AND ad.status = #{request.status} ");
        }
        if (null != pageModel.getRequest().getReviewStatus()) {
            sqlBuilder.append(" AND ad.review_status = #{request.reviewStatus} ");
        }
        sqlBuilder.append("GROUP BY ");
        sqlBuilder.append(" ad.ad_id");
        sqlBuilder.append(" ORDER BY ad.create_time DESC ");
        sqlBuilder.append(" LIMIT #{offset},#{count} ");
        return sqlBuilder.toString();
    }

    public String updateByIdWithoutNull(AdModel adModel) {
        SQL sql = new SQL();
        sql.UPDATE("dspv2_t_ad");
        if (null != adModel.getOperator()) {
            sql.SET("operator=#{operator}");
        }
        if (StringUtils.isNotBlank(adModel.getTitle())) {
            sql.SET("title=#{title}");
        }
        if (null != adModel.getType()) {
            sql.SET("type=#{type}");
        }
        if (StringUtils.isNotBlank(adModel.getPvReportUrl())) {
            sql.SET("pv_report_url=#{pvReportUrl}");
        }
        if (StringUtils.isNotBlank(adModel.getClickReportUrl())) {
            sql.SET("click_report_url=#{clickReportUrl}");
        }
        if (StringUtils.isNotBlank(adModel.getVideoStartPlayReportUrl())) {
            sql.SET("video_start_play_report_url=#{videoStartPlayReportUrl}");
        }
        if (StringUtils.isNotBlank(adModel.getVideoEndPlayReportUrl())) {
            sql.SET("video_end_play_report_url=#{videoEndPlayReportUrl}");
        }
        if (null != adModel.getUpdateTime()) {
            sql.SET("update_time=#{updateTime}");
        }
        if (null != adModel.getStatus()) {
            sql.SET("status=#{status}");
        }
        if (null != adModel.getReviewStatus()) {
            sql.SET("review_status=#{reviewStatus}");
        }
        if (StringUtils.isNotBlank(adModel.getNoPassReason())) {
            sql.SET("no_pass_reason=#{notPassReason}");
        }
        sql.WHERE("ad_id=#{adId}");
        return sql.toString();
    }

    public String updateByPromotionIdWithoutNull(AdModel adModel) {
        SQL sql = new SQL();
        sql.UPDATE("dspv2_t_ad");
        if (null != adModel.getOperator()) {
            sql.SET("operator=#{operator}");
        }
        if (StringUtils.isNotBlank(adModel.getTitle())) {
            sql.SET("title=#{title}");
        }
        if (null != adModel.getType()) {
            sql.SET("type=#{type}");
        }
        if (StringUtils.isNotBlank(adModel.getPvReportUrl())) {
            sql.SET("pv_report_url=#{pvReportUrl}");
        }
        if (StringUtils.isNotBlank(adModel.getClickReportUrl())) {
            sql.SET("click_report_url=#{clickReportUrl}");
        }
        if (StringUtils.isNotBlank(adModel.getVideoStartPlayReportUrl())) {
            sql.SET("video_start_play_report_url=#{videoStartPlayReportUrl}");
        }
        if (StringUtils.isNotBlank(adModel.getVideoEndPlayReportUrl())) {
            sql.SET("video_end_play_report_url=#{videoEndPlayReportUrl}");
        }
        if (null != adModel.getUpdateTime()) {
            sql.SET("update_time=#{updateTime}");
        }
        if (null != adModel.getStatus()) {
            sql.SET("status=#{status}");
        }
        if (null != adModel.getReviewStatus()) {
            sql.SET("review_status=#{reviewStatus}");
        }
        if (StringUtils.isNotBlank(adModel.getNoPassReason())) {
            sql.SET("no_pass_reason=#{notPassReason}");
        }
        sql.WHERE("promotion_id=#{promotionId}");
        return sql.toString();
    }

    public String list(AdModel adModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("SELECT ad_id, user_id, operator, promotion_id, title, ");
        sqlBuilder.append(" type, pv_report_url, click_report_url, video_start_play_report_url, video_end_play_report_url, ");
        sqlBuilder.append(" create_time, update_time, status, version, review_status, no_pass_reason");
        sqlBuilder.append(" FROM dspv2_t_ad");
        sqlBuilder.append(" WHERE user_id = #{userId}");
        if (null != adModel.getPromotionId()) {
            sqlBuilder.append(" AND promotion_id = #{promotionId}");
        }
        return sqlBuilder.toString();
    }

}
