package com.inveno.ad.dsp.model;

/**
 * <p>Title: {@link AdMaterialRelModel}</p>
 * <p>Description: 广告素材关联关系表model </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/17
 */
public class AdMaterialRelModel extends BaseModel {

    private Integer id;
    private Long adId;
    private Long materialId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getAdId() {
        return adId;
    }

    public void setAdId(Long adId) {
        this.adId = adId;
    }

    public Long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }
}
