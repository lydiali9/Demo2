package com.inveno.ad.dsp.service.impl;

import com.alibaba.fastjson.JSON;
import com.inveno.ad.adid.AdIdGenerator;
import com.inveno.ad.dsp.bean.ImageServiceRespBean;
import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.dao.AdDao;
import com.inveno.ad.dsp.dao.AdMaterialDao;
import com.inveno.ad.dsp.dao.ImageDao;
import com.inveno.ad.dsp.dao.PromotionDao;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.*;
import com.inveno.ad.dsp.service.AdService;
import com.inveno.ad.dsp.service.ImageSyncService;
import com.inveno.ad.dsp.service.StorageService;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>Title: {@link AdServiceImpl} </p>
 * <p>Description: 广告Service实现类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
@Service
public class AdServiceImpl implements AdService {

    private static Logger logger = LoggerFactory.getLogger(AdServiceImpl.class);

    @Autowired
    private StorageService storageService;
    @Autowired
    private PromotionDao promotionDao;
    @Autowired
    private AdDao adDao;
    @Autowired
    private AdMaterialDao adMaterialDao;
    @Autowired
    private ImageSyncService imageSyncService;
    @Autowired
    private ImageDao imageDao;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void create(AdModel adModel) throws Exception {
        try {
            Date date = new Date();
            PromotionModel promotionModel = promotionDao.selectById(adModel.getPromotionId());
            if (null == promotionModel) {
                throw new DspException(RetCode.ERR_PARAM, "promotionId", adModel.getPromotionId());
            }
            // 1、插入广告表。
            Long adId = AdIdGenerator.genADId4DSPV2();
            AdMaterialTypeEnum adMaterialTypeEnum = AdMaterialTypeEnum.parse(adModel.getMaterialList().get(0).getType());
            String title = String.format("%s-%s-%d", promotionModel.getTitle(), adMaterialTypeEnum.getDesc(), adId);
            adModel.setAdId(adId);
            adModel.setTitle(title);
            adModel.setStatus(AdStatusEnum.INIT.getValue());
            adModel.setType(AdTypeEnum.NORMAL.getValue());
            adModel.setReviewStatus(AdReviewStatusEnum.PENDING.getValue());
            adModel.setCreateTime(date);
            adModel.setVersion(0);
            logger.debug("adId:{}", adId);
            adDao.insert(adModel);

            // 2、插入图片表。
            List<AdMaterialModel> materialList = adModel.getMaterialList();
            List<ImageModel> imageModelList = materialList.stream()
                    .map(AdMaterialModel::getImageModel).filter(e -> e.getImageId() == null)
                    .collect(Collectors.toList());
            insertAndUploadImage(imageModelList, adModel.getOperator(), date);

            // 3、插入素材表。
            for (AdMaterialModel adMaterialModel : materialList) {
                adMaterialModel.setAdId(adId);
                adMaterialModel.setImageId(adMaterialModel.getImageModel().getImageId());
                adMaterialModel.setOperator(adModel.getOperator());
                adMaterialModel.setSource(AdMaterialSourceEnum.ADM.getValue());
                adMaterialModel.setStatus(0);
                adMaterialModel.setCreateTime(date);
            }
            adMaterialDao.batchInsert(materialList);
            logger.debug("adMaterialId:{}", materialList.stream().map(AdMaterialModel::getId).collect(Collectors.toList()));
        } catch (Exception e) {
            // 是否需要删除图片
            logger.error("create ad error.", e);
            throw e;
        }
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public void update(AdModel updateAdModel) throws Exception {
        try {
            //1) 校验广告状态，如果为上线状态或者不为审核通过状态不允许修改。
            logger.debug("ad model: {}", updateAdModel);
            AdModel adInDb = adDao.selectById(updateAdModel.getAdId());
            if (AdStatusEnum.DISCARD.getValue() == adInDb.getStatus() || AdStatusEnum.EXPIRED.getValue() == adInDb.getStatus()) {
                AdStatusEnum adStatusInDb = AdStatusEnum.parse(adInDb.getStatus());
                AdStatusEnum requestAdStatus = AdStatusEnum.parse(updateAdModel.getStatus());
                throw new DspException(RetCode.ERR_AD_STATUS, adStatusInDb.getDesc(), requestAdStatus.getDesc());
            }
            //2) 更新图片素材。
            AdMaterialModel adMaterialModelParams = new AdMaterialModel();
            adMaterialModelParams.setAdId(updateAdModel.getAdId());
            adMaterialModelParams.setSource(AdMaterialSourceEnum.ADM.getValue());
            List<AdMaterialModel> adMaterialInDbList = adMaterialDao.selectByAdId(adMaterialModelParams);
            List<AdMaterialModel> requestMaterialList = updateAdModel.getMaterialList();

            Date date = new Date();
            //数据库
            List<Long> materialIdInDbList = adMaterialInDbList.stream().map(AdMaterialModel::getId).collect(Collectors.toList());
            List<AdMaterialModel> newMaterialList = requestMaterialList.stream().filter(e -> null == e.getId()).collect(Collectors.toList());
            List<AdMaterialModel> updateMaterialList = requestMaterialList.stream()
                    .filter(e -> null != e.getId() && materialIdInDbList.contains(e.getId()))
                    .collect(Collectors.toList());
            List<Long> requestMaterialIdList = requestMaterialList.stream().map(AdMaterialModel::getId).collect(Collectors.toList());
            List<Long> deleteMaterialIdList = materialIdInDbList.stream().filter(e -> !requestMaterialIdList.contains(e)).collect(Collectors.toList());

            // 2.1) 新增记录
            if (CollectionUtils.isNotEmpty(newMaterialList)) {
                logger.debug("new material list: {}", JSON.toJSONString(newMaterialList));
                List<ImageModel> newImageList = newMaterialList.stream()
                        .map(AdMaterialModel::getImageModel)
                        .filter(e -> null == e.getImageId())
                        .collect(Collectors.toList());
                insertAndUploadImage(newImageList, updateAdModel.getOperator(), date);
                logger.debug("new image list: {}", JSON.toJSONString(newImageList));
                for (AdMaterialModel adMaterialModel : newMaterialList) {
                    adMaterialModel.setAdId(updateAdModel.getAdId());
                    adMaterialModel.setImageId(adMaterialModel.getImageModel().getImageId());
                    adMaterialModel.setOperator(updateAdModel.getOperator());
                    adMaterialModel.setSource(AdMaterialSourceEnum.ADM.getValue());
                    adMaterialModel.setStatus(0);
                    adMaterialModel.setUpdateTime(date);
                }
                adMaterialDao.batchInsert(newMaterialList);
            }

            // 2.2) 修改记录。
            if (CollectionUtils.isNotEmpty(updateMaterialList)) {
                logger.debug("update material: {}", JSON.toJSONString(updateMaterialList));
                List<ImageModel> newImageList = updateMaterialList.stream()
                        .map(AdMaterialModel::getImageModel)
                        .filter(e -> null == e.getImageId())
                        .collect(Collectors.toList());
                insertAndUploadImage(newImageList, updateAdModel.getOperator(), date);
                logger.debug("new image list: {}", JSON.toJSONString(newImageList));
                for (AdMaterialModel adMaterialModel : updateMaterialList) {
                    adMaterialModel.setImageId(adMaterialModel.getImageModel().getImageId());
                    adMaterialModel.setUpdateTime(date);
                    adMaterialModel.setOperator(updateAdModel.getOperator());
                    adMaterialDao.updateByIdWithoutNull(adMaterialModel);
                }
            }

            // 2.3) 删除记录
            if (CollectionUtils.isNotEmpty(deleteMaterialIdList)) {
                logger.info("delete material: {}", JSON.toJSONString(updateMaterialList));
                adMaterialDao.batchDelete(deleteMaterialIdList);
            }
            // 3) 更新广告表
            updateAdModel.setUpdateTime(date);
            updateAdModel.setReviewStatus(AdReviewStatusEnum.PENDING.getValue());
            Integer rows = adDao.updateByIdWithoutNull(updateAdModel);
            if (rows != 1) {
                throw new DspException(RetCode.ERR_AD_MESSAGE_CHANGED);
            }
        } catch (Exception e) {
            // 是否需要删除图片
            logger.error("update ad error.", e);
            throw e;
        }
    }

    @Override
    public AdModel queryById(Long id) {
        AdModel adModel = adDao.selectById(id);
        if (null == adModel) {
            return null;
        }
        PromotionModel promotionModel = promotionDao.selectById(adModel.getPromotionId());
        adModel.setPromotion(promotionModel);
        AdMaterialModel adMaterialModel = new AdMaterialModel();
        adMaterialModel.setAdId(id);
        adMaterialModel.setSource(AdMaterialSourceEnum.ADM.getValue());
        List<AdMaterialModel> adMaterialModelList = adMaterialDao.selectByAdId(adMaterialModel);
        adModel.setMaterialList(adMaterialModelList);
        List<ImageModel> imageModelList = imageDao.selectByImageIdList(adMaterialModelList.stream().map(AdMaterialModel::getImageId).collect(Collectors.toList()));
        adMaterialModelList.forEach(e -> e.setImageModel(imageModelList.stream().filter(image -> image.getImageId().equals(e.getImageId())).findFirst().orElse(null)));
        return adModel;
    }

    @Override
    public PageModel<AdModel> pageQuery(PageModel<AdModel> pageRequest) {
        int totalCount = adDao.pageQueryTotalCount(pageRequest);
        pageRequest.setTotalCount(totalCount);
        pageRequest.getRequest().setMaterialSource(AdMaterialSourceEnum.ADM.getValue());
        if (totalCount > 0) {
            List<AdModel> adModelList = adDao.pageQuery(pageRequest);
            pageRequest.setResponse(adModelList);
        }
        return pageRequest;
    }

    @Override
    public Integer auditFailCount(Integer id) {
        AdModel adModel = new AdModel();
        adModel.setUserId(id);
        adModel.setReviewStatus(AdReviewStatusEnum.NOT_PASS.getValue());
        return adDao.auditFailCount(adModel);
    }

    @Override
    public void switchStatus(AdModel adModel) {
        AdModel adModelInDb = adDao.selectById(adModel.getAdId());
        PromotionModel promotionModel = promotionDao.selectById(adModelInDb.getPromotionId());
        // 一、广告状态切换。
        //1.1、切换至上线状态。
        adModel.setUpdateTime(new Date());
        AdStatusEnum adStatusInDb = AdStatusEnum.parse(adModelInDb.getStatus());
        AdStatusEnum requestAdStatus = AdStatusEnum.parse(adModel.getStatus());
        if (null != adModel.getStatus() && adModel.getStatus() == AdStatusEnum.ONLINE.getValue()) {
            if (PromotionStatusEnum.OFFLINE.getValue() == promotionModel.getStatus()) {
                // 推广为下线状态，广告不能修改至上线状态
                throw new DspException(RetCode.ERR_AD_PROMOTION_OFFLINE);
            }
            if (adModelInDb.getReviewStatus() != AdReviewStatusEnum.PASS.getValue()
                    && adModelInDb.getStatus() != AdStatusEnum.OFFLINE.getValue()
                    && adModelInDb.getStatus() != AdStatusEnum.INIT.getValue()) {
                // 只有当审核状态为“审核通过”，广告状态为“下线”或者“初始化”时才能切换至“上线”状态。
                throw new DspException(RetCode.ERR_AD_STATUS, adStatusInDb.getDesc(), requestAdStatus.getDesc());
            }
        }
        //1.2、切换至下线状态。
        if (null != adModel.getStatus() && adModel.getStatus() == AdStatusEnum.OFFLINE.getValue()) {
            if (adModelInDb.getStatus() != AdStatusEnum.INIT.getValue()
                    && adModelInDb.getStatus() != AdStatusEnum.ONLINE.getValue()) {
                // 只有当广告为“初始化”或者“上线”状态时才能切换至“下线”状态。
                throw new DspException(RetCode.ERR_AD_STATUS, adStatusInDb.getDesc(), requestAdStatus.getDesc());
            }
        }
        //1.3、切换至过期状态。
//        if (adModel.getStatus() == AdStatusEnum.EXPIRED.getValue()) {
        // 任何状态均可以切换至“过期”状态。
//        }
        //1.4、切换至废除状态。
//        if (adModel.getStatus() == AdStatusEnum.DISCARD.getValue()) {
        // 任何状态均可以切换至“废除”状态。
//        }

        // 二、广告审核状态切换。
        //2.1、切换至待审核状态。
//        if (adModel.getReviewStatus() == AdReviewStatusEnum.PENDING.getValue()) {
        // 任何状态均可以切换至“待审核”状态。
//        }
        //2.2、切换至审核通过状态。
        if (null != adModel.getReviewStatus() && adModel.getReviewStatus() == AdReviewStatusEnum.PASS.getValue()) {
            // 只有“待审核”才能切换至“审核通过”状态。
            if (adModelInDb.getReviewStatus() != AdReviewStatusEnum.PENDING.getValue()) {
                throw new DspException(RetCode.ERR_AD_STATUS, adStatusInDb.getDesc(), requestAdStatus.getDesc());
            }
        }
        //2.3、切换至审核不通过状态。
        if (null != adModel.getReviewStatus() && adModel.getReviewStatus() == AdReviewStatusEnum.NOT_PASS.getValue()) {
            // 只有“待审核”才能切换至“审核不通过”状态。
            if (adModelInDb.getReviewStatus() != AdReviewStatusEnum.PENDING.getValue()) {
                throw new DspException(RetCode.ERR_AD_STATUS, adStatusInDb.getDesc(), requestAdStatus.getDesc());
            }
        }
        adDao.updateByIdWithoutNull(adModel);
    }

    @Override
    public List<AdModel> list(AdModel adModel) {
        return adDao.list(adModel);
    }

    private void insertAndUploadImage(List<ImageModel> imageModelList, Integer operator, Date createTime) throws Exception {
        if (CollectionUtils.isNotEmpty(imageModelList)) {
            // 上传云图
            List<String> urlList = imageModelList.stream().map(ImageModel::getUrl).collect(Collectors.toList());
            List<ImageServiceRespBean> imageAddRespList = imageSyncService.upload(urlList);
            for (ImageModel imageModel : imageModelList) {
                imageModel.setUserId(operator);
                imageModel.setCreateTime(createTime);
                imageModel.setStatus(0);
                imageModel.setImgServerUrl(imageAddRespList.stream().filter(e -> e.getSrcUrl().equals(imageModel.getUrl())).findFirst().get().getUrl());
            }
            imageDao.batchInsert(imageModelList);
            logger.debug("imageId:{}", imageModelList.stream().map(ImageModel::getImageId).collect(Collectors.toList()));
        }
    }

}
