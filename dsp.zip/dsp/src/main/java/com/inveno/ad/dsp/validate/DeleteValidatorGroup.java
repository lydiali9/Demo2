package com.inveno.ad.dsp.validate;

/**
 * <p>Title: {@link DeleteValidatorGroup} </p>
 * <p>Description: DELETE方法校验组 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public interface DeleteValidatorGroup {
}
