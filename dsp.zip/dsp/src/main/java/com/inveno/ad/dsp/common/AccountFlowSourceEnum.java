package com.inveno.ad.dsp.common;

public enum AccountFlowSourceEnum {

    //收支来源:充值
    RECHARGE(1),
    //赠送(返货)
    RETURN(2),
    //广告消耗
    AD_CONSUMPTION(3);

    private Integer value;

    AccountFlowSourceEnum(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
