package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.bean.ImageServiceRespBean;

import java.util.List;

/**
 * 云图service类
 * @author sugang
 */
public interface ImageSyncService {

    /**
     * 上传图片到云图
     * @param imgUrl 本地图片url
     * @return 云图响应
     * @throws Exception 异常抛出
     */
    ImageServiceRespBean upload(String imgUrl) throws Exception;

    /**
     * 上传图片到云图
     * @param imgUrlList 本地图片url
     * @return 云图响应结果集
     * @throws Exception 异常抛出
     */
    List<ImageServiceRespBean> upload(List<String> imgUrlList) throws Exception;

}
