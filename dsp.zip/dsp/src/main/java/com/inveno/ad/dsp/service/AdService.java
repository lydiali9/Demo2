package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.model.AdModel;
import com.inveno.ad.dsp.model.PageModel;

import java.util.List;

/**
 * <p>Title: {@link AdService} </p>
 * <p>Description: 广告Service类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public interface AdService {

    /**
     * 创建广告
     * @param adModel 广告详细数据
     * @throws Exception 异常抛出
     */
    void create(AdModel adModel) throws Exception;

    /**
     * 修改广告
     * @param adModel 广告详细数据
     * @throws Exception 异常抛出
     */
    void update(AdModel adModel) throws Exception;

    /**
     * 根据ID查询广告详情
     * @param id 广告ID
     * @return 符合条件的广告
     * @throws Exception 异常抛出
     */
    AdModel queryById(Long id) throws Exception;

    /**
     * 分页查询广告
     * @param pageRequest 请求
     * @return 响应信息
     * @throws Exception 异常抛出
     */
    PageModel<AdModel> pageQuery(PageModel<AdModel> pageRequest) throws Exception;

    /**
     * 查询用户审核未通过数量
     * @param id 广告ID
     * @return 符合条件的广告
     * @throws Exception 异常抛出
     */
    Integer auditFailCount(Integer id) throws Exception;

    /**
     * 切换广告状态
     * @param adModel 广告详情
     * @throws Exception 异常抛出
     */
    void switchStatus(AdModel adModel) throws Exception;

    /**
     * 列举用户创建的所有的广告
     * @param adModel 请求
     * @return 响应信息
     * @throws Exception 异常抛出
     */
    List<AdModel> list(AdModel adModel) throws Exception;

}
