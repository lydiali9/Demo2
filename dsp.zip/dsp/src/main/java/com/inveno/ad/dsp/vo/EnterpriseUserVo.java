package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.validate.PostValidatorGroup;

import javax.validation.constraints.NotNull;

public class EnterpriseUserVo extends BaseVo {

    //公司名称
    @NotNull(groups = PostValidatorGroup.class)
    private String compName;
    //公司网站
    @NotNull(groups = PostValidatorGroup.class)
    private String compUrl;
    //行业类型id
    @NotNull(groups = PostValidatorGroup.class)
    private Integer businessType;
    //营业执照图片地址
    @NotNull(groups = PostValidatorGroup.class)
    private String businessLicensePath;
    //组织机构代码
    @NotNull(groups = PostValidatorGroup.class)
    private String orgNo;
    //公司地址
    @NotNull(groups = PostValidatorGroup.class)
    private String addrDetail;
    //固定电话
    @NotNull(groups = PostValidatorGroup.class)
    private String fixedLineTel;
    //联系人
    @NotNull(groups = PostValidatorGroup.class)
    private String contactName;
    //手机号码
    @NotNull(groups = PostValidatorGroup.class)
    private String telNo;
    //邮箱
    @NotNull(groups = PostValidatorGroup.class)
    private String email;
    //QQ
    private String qq;

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getCompUrl() {
        return compUrl;
    }

    public void setCompUrl(String compUrl) {
        this.compUrl = compUrl;
    }

    public Integer getBusinessType() {
        return businessType;
    }

    public void setBusinessType(Integer businessType) {
        this.businessType = businessType;
    }

    public String getBusinessLicensePath() {
        return businessLicensePath;
    }

    public void setBusinessLicensePath(String businessLicensePath) {
        this.businessLicensePath = businessLicensePath;
    }

    public String getOrgNo() {
        return orgNo;
    }

    public void setOrgNo(String orgNo) {
        this.orgNo = orgNo;
    }

    public String getAddrDetail() {
        return addrDetail;
    }

    public void setAddrDetail(String addrDetail) {
        this.addrDetail = addrDetail;
    }

    public String getFixedLineTel() {
        return fixedLineTel;
    }

    public void setFixedLineTel(String fixedLineTel) {
        this.fixedLineTel = fixedLineTel;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }
}
