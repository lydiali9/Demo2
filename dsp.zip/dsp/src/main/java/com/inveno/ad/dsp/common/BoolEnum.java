package com.inveno.ad.dsp.common;

/**
 * <p>Title: {@link BoolEnum}</p>
 * <p>Description: bool值 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public enum BoolEnum {

    NO(0),
    YES(1);

    private int value;

    BoolEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
