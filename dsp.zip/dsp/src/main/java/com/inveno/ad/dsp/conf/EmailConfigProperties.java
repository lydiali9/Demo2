package com.inveno.ad.dsp.conf;


import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(
        "app.email"
)
public class EmailConfigProperties {

    private String addr;
    private String nick;


    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }
}
