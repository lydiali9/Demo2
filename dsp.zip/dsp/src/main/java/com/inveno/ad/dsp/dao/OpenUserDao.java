package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.OpenUserModel;
import org.apache.ibatis.annotations.*;

public interface OpenUserDao {

    @Select(" SELECT " +
            "   openUser.user_id,openUser.comp_name,openUser.business_license,openUser.qualifications,openUser.business_type,openUser.org_no,openUser.certif_obverse_pic,openUser.certif_reverse_pic,openUser.province,openUser.city,openUser.contact_name,openUser.email,openUser.addr_detail,openUser.tel_no,openUser.fixed_line_tel,openUser.qq,openUser.no_pass_reason,openUser.status,openUser.create_time,openUser.update_time,openUser.comp_url,openUser.user_type,openUser.certif_no " +
            " FROM t_dsp_open_user openUser " +
            " LEFT JOIN t_base_plat_user platUser ON platUser.plat_id = 'DSP' AND platUser.plat_user_id = openUser.user_id " +
            " WHERE platUser.user_id = #{userId}")

    @Results(
            {
                    @Result(property = "openUserId", column = "user_id"),
                    @Result(property = "compName", column = "comp_name"),
                    @Result(property = "businessLicense", column = "business_license"),
                    @Result(property = "qualifications", column = "qualifications"),
                    @Result(property = "businessType", column = "business_type"),
                    @Result(property = "orgNo", column = "org_no"),
                    @Result(property = "certifObversePic", column = "certif_obverse_pic"),
                    @Result(property = "certifReversePic", column = "certif_reverse_pic"),
                    @Result(property = "province", column = "province"),
                    @Result(property = "city", column = "city"),
                    @Result(property = "contactName", column = "contact_name"),
                    @Result(property = "email", column = "email"),
                    @Result(property = "addrDetail", column = "addr_detail"),
                    @Result(property = "telNo", column = "tel_no"),
                    @Result(property = "fixedLineTel", column = "fixed_line_tel"),
                    @Result(property = "qq", column = "qq"),
                    @Result(property = "noPassReason", column = "no_pass_reason"),
                    @Result(property = "status", column = "status"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "updateTime", column = "update_time"),
                    @Result(property = "compUrl", column = "comp_url"),
                    @Result(property = "userType", column = "user_type"),
                    @Result(property = "certifNo", column = "certif_no"),
            }
    )
    OpenUserModel findOpenUserByUserId(Integer userId);


    /**
     * 新增平台用户
     * @param openUserModel 用户信息
     * @return 新增用户id
     */
    @Insert(
            "INSERT INTO t_dsp_open_user(" +
                    "user_id, comp_name, business_license, qualifications, business_type, org_no," +
                    "certif_obverse_pic, certif_reverse_pic, province,city, contact_name, email," +
                    "addr_detail, tel_no, fixed_line_tel, qq, no_pass_reason, status," +
                    "create_time, update_time, comp_url, user_type, certif_no" +
                    ")" +
                    "VALUES(" +
                    "#{openUserId}, #{compName}, #{businessLicense}, #{qualifications}, #{businessType}, #{orgNo}," +
                    "#{certifObversePic}, #{certifReversePic}, #{province}, #{city}, #{contactName}, #{email}," +
                    "#{addrDetail}, #{telNo}, #{fixedLineTel}, #{qq}, #{noPassReason}, #{status}," +
                    "#{createTime}, #{updateTime}, #{compUrl}, #{userType}, #{certifNo}" +
                    ")"
    )
    @Options(useGeneratedKeys = true)
    Integer insert(OpenUserModel openUserModel);

    @UpdateProvider(type = OpenUserDaoSqlProvider.class, method = "updateByOpenUserId")
    Boolean updateByOpenUserId(OpenUserModel openUserModel);

}

