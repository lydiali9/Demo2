package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.service.AreaService;
import com.inveno.ad.dsp.vo.AreaVo;
import com.inveno.ad.dsp.vo.VoContainer;
import com.inveno.ad.dsp.vo.VoContainerHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AreaController {

    @Autowired
    private AreaService areaService;

    @GetMapping("/area")
    public VoContainer<AreaVo> get() throws Exception{
        AreaVo areaVo = areaService.getArea();
        return VoContainerHelper.createVoContainer(areaVo, RetCode.OK);
    }
}
