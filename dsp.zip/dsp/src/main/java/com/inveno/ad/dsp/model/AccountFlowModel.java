package com.inveno.ad.dsp.model; /***********************************************************************
 * Module:  AccountFlowModel.java
 * Author:  sugang
 * Purpose: Defines the Class AccountFlowModel
 ***********************************************************************/

import java.math.BigDecimal;
import java.util.*;

/**
 * 账户流水表
 */
public class AccountFlowModel {
   private Integer id;
   private Integer userId;
   //金额
   private BigDecimal amount;
   //收入类型:1=收入,2=支出
   private Integer type;
   //余额
   private BigDecimal balance;
   //这笔收支的来源:1=充值,2=赠送,3=广告消耗
   private Integer source;
   private byte status;
   //操作人,-1:代表系统操作
   private Integer operator;
   private String memo;
   private String updateTime;
   private String createTime;

   private String searchStartDate;
   private String searchEndDate;

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   public Integer getUserId() {
      return userId;
   }

   public void setUserId(Integer userId) {
      this.userId = userId;
   }

   public BigDecimal getAmount() {
      return amount;
   }

   public void setAmount(BigDecimal amount) {
      this.amount = amount;
   }

   public Integer getType() {
      return type;
   }

   public void setType(Integer type) {
      this.type = type;
   }

   public BigDecimal getBalance() {
      return balance;
   }

   public void setBalance(BigDecimal balance) {
      this.balance = balance;
   }

   public Integer getSource() {
      return source;
   }

   public void setSource(Integer source) {
      this.source = source;
   }

   public byte getStatus() {
      return status;
   }

   public void setStatus(byte status) {
      this.status = status;
   }

   public Integer getOperator() {
      return operator;
   }

   public void setOperator(Integer operator) {
      this.operator = operator;
   }

   public String getMemo() {
      return memo;
   }

   public void setMemo(String memo) {
      this.memo = memo;
   }

   public String getUpdateTime() {
      return updateTime;
   }

   public void setUpdateTime(String updateTime) {
      this.updateTime = updateTime;
   }

   public String getCreateTime() {
      return createTime;
   }

   public void setCreateTime(String createTime) {
      this.createTime = createTime;
   }

   public String getSearchStartDate() {
      return searchStartDate;
   }

   public void setSearchStartDate(String searchStartDate) {
      this.searchStartDate = searchStartDate;
   }

   public String getSearchEndDate() {
      return searchEndDate;
   }

   public void setSearchEndDate(String searchEndDate) {
      this.searchEndDate = searchEndDate;
   }
}