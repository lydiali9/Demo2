package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.common.AdReportSearchTypeEnum;
import com.inveno.ad.dsp.validate.EnumValue;
import com.inveno.ad.dsp.validate.GetValidatorGroup;
import com.inveno.ad.dsp.validate.PageValidatorGroup;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * <p>Title: {@link AdReportDailyVo}</p>
 * <p>Description: 日统计报表</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public class AdReportDailyVo extends BaseVo {

    private String date;
    private Long promotionId;
    private String promotionTitle;
    private Long adId;
    private String adTitle;
    private Integer pv;
    private Integer click;
    private Double ctr;
    private Double ecpm;
    private Double ecpc;
    private Double totalCost;

    @NotNull(groups = GetValidatorGroup.class)
    private String searchStartDate;
    @NotNull(groups = GetValidatorGroup.class)
    private String searchEndDate;
    @NotNull(groups = GetValidatorGroup.class)
    @EnumValue(clazz = AdReportSearchTypeEnum.class, method = "contains", groups = GetValidatorGroup.class)
    private String type;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Long getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(Long promotionId) {
        this.promotionId = promotionId;
    }

    public String getPromotionTitle() {
        return promotionTitle;
    }

    public void setPromotionTitle(String promotionTitle) {
        this.promotionTitle = promotionTitle;
    }

    public Long getAdId() {
        return adId;
    }

    public void setAdId(Long adId) {
        this.adId = adId;
    }

    public String getAdTitle() {
        return adTitle;
    }

    public void setAdTitle(String adTitle) {
        this.adTitle = adTitle;
    }

    public Integer getPv() {
        return pv;
    }

    public void setPv(Integer pv) {
        this.pv = pv;
    }

    public Integer getClick() {
        return click;
    }

    public void setClick(Integer click) {
        this.click = click;
    }

    public Double getCtr() {
        return ctr;
    }

    public void setCtr(Double ctr) {
        this.ctr = ctr;
    }

    public Double getEcpm() {
        return ecpm;
    }

    public void setEcpm(Double ecpm) {
        this.ecpm = ecpm;
    }

    public Double getEcpc() {
        return ecpc;
    }

    public void setEcpc(Double ecpc) {
        this.ecpc = ecpc;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }

    public String getSearchStartDate() {
        return searchStartDate;
    }

    public void setSearchStartDate(String searchStartDate) {
        this.searchStartDate = searchStartDate;
    }

    public String getSearchEndDate() {
        return searchEndDate;
    }

    public void setSearchEndDate(String searchEndDate) {
        this.searchEndDate = searchEndDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
