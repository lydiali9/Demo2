package com.inveno.ad.dsp.controller;

import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.model.AccountFlowModel;
import com.inveno.ad.dsp.model.AccountFlowReportModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.model.UserModel;
import com.inveno.ad.dsp.service.AccountService;
import com.inveno.ad.dsp.util.DateUtils;
import com.inveno.ad.dsp.util.SysUtils;
import com.inveno.ad.dsp.vo.*;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@RestController
public class AccountController {

    @Autowired
    private AccountService accountService;

    @GetMapping("/account")
    public VoContainer<AccountVo> get(HttpSession session) throws Exception{
        UserModel userModel = SysUtils.getUser(session);
        Integer userId = userModel.getUserId();
        AccountVo accountVo = accountService.info(userId);
        return VoContainerHelper.createVoContainer(accountVo, RetCode.OK);
    }

    @GetMapping("/availableBalance")
    public VoContainer<AvailableBalanceVo> getAvailableBalance(HttpSession session) throws Exception {
        UserModel userModel = SysUtils.getUser(session);
        Integer userId = userModel.getUserId();
        AvailableBalanceVo availableBalanceVo = accountService.getAvailableBalance(userId);
        return VoContainerHelper.createVoContainer(availableBalanceVo, RetCode.OK);
    }

    @GetMapping("/accountFlow")
    public VoContainer<List<AccountFlowVo>> flowPageQuery(AccountFlowVo accountFlowVo) throws Exception {
        AccountFlowModel accountFlowModel = new AccountFlowModel();
        accountFlowModel.setUserId(accountFlowVo.getOperator());
        accountFlowModel.setSearchStartDate(accountFlowVo.getSearchStartDate());
        accountFlowModel.setSearchEndDate(accountFlowVo.getSearchEndDate());

        PageModel<AccountFlowModel> pageModel = new PageModel<>();
        pageModel.setOffset((accountFlowVo.getCurrentPageNo() - 1) * accountFlowVo.getEachPageCapacity());
        pageModel.setCount(accountFlowVo.getEachPageCapacity());
        pageModel.setRequest(accountFlowModel);

        PageModel<AccountFlowModel> queryResult = accountService.flowPageQuery(pageModel);
        List<AccountFlowModel> accountFlowModelList = queryResult.getResponse();
        List<AccountFlowVo> accountFlowVoList = null;
        if (CollectionUtils.isNotEmpty(accountFlowModelList)) {
            accountFlowVoList = new ArrayList<>(accountFlowModelList.size());
            for (AccountFlowModel retAccountFlowModel : accountFlowModelList) {
                AccountFlowVo retAccountFlowVo = new AccountFlowVo();
                BeanUtils.copyProperties(retAccountFlowModel, retAccountFlowVo);
                accountFlowVoList.add(retAccountFlowVo);
            }
        }
        PageResponseVo pageResponseVo = new PageResponseVo();
        pageResponseVo.setCurrentPageNo(accountFlowVo.getCurrentPageNo());
        pageResponseVo.setEachPageCapacity(accountFlowVo.getEachPageCapacity());
        pageResponseVo.setTotalCount(queryResult.getTotalCount());
        return VoContainerHelper.createPageVoContainer(accountFlowVoList, pageResponseVo, RetCode.OK);
    }

    @GetMapping("/accountFlowReport")
    public VoContainer<List<AccountFlowReportVo>> flowReportPageQuery(AccountFlowReportVo accountFlowReportVo) throws Exception {
        AccountFlowReportModel accountFlowReportModel = new AccountFlowReportModel();
        accountFlowReportModel.setUserId(accountFlowReportVo.getOperator());
        accountFlowReportModel.setSearchStartDate(accountFlowReportVo.getSearchStartDate());
        accountFlowReportModel.setSearchEndDate(accountFlowReportVo.getSearchEndDate());

        PageModel<AccountFlowReportModel> pageModel = new PageModel<>();
        pageModel.setOffset((accountFlowReportVo.getCurrentPageNo() - 1) * accountFlowReportVo.getEachPageCapacity());
        pageModel.setCount(accountFlowReportVo.getEachPageCapacity());
        pageModel.setRequest(accountFlowReportModel);

        PageModel<AccountFlowReportModel> queryResult = accountService.flowReportPageQuery(pageModel);
        List<AccountFlowReportModel> accountFlowReportModelList = queryResult.getResponse();
        List<AccountFlowReportVo> accountFlowReportVoList = null;
        if (CollectionUtils.isNotEmpty(accountFlowReportModelList)) {
            accountFlowReportVoList = new ArrayList<>(accountFlowReportModelList.size());
            for (AccountFlowReportModel retAccountFlowReportModel : accountFlowReportModelList) {
                AccountFlowReportVo retAccountFlowReportVo = new AccountFlowReportVo();
                BeanUtils.copyProperties(retAccountFlowReportModel, retAccountFlowReportVo);
                retAccountFlowReportVo.setDate(new SimpleDateFormat(DateUtils.FMT_yyyyMMdd).format(retAccountFlowReportModel.getDate()));
                accountFlowReportVoList.add(retAccountFlowReportVo);
            }
        }
        PageResponseVo pageResponseVo = new PageResponseVo();
        pageResponseVo.setCurrentPageNo(accountFlowReportVo.getCurrentPageNo());
        pageResponseVo.setEachPageCapacity(accountFlowReportVo.getEachPageCapacity());
        pageResponseVo.setTotalCount(queryResult.getTotalCount());
        return VoContainerHelper.createPageVoContainer(accountFlowReportVoList, pageResponseVo, RetCode.OK);
    }

}
