package com.inveno.ad.dsp.util;

import com.dd.plist.*;
import com.inveno.ad.dsp.model.AppModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public class IpaParser {

    private static Logger logger = LoggerFactory.getLogger(IpaParser.class);

    private static final String VERSION = "CFBundleShortVersionString";
    private static final String PACKAGE = "CFBundleIdentifier";
    private static final String CF_BUNDLE_SIGNATURE = "CFBundleSignature";

    public static AppModel parse(InputStream is) {
        AppModel appModel = null;
        try {
            ZipInputStream zipIns = new ZipInputStream(is);
            ZipEntry ze;
            InputStream infoIs = null;
            while ((ze = zipIns.getNextEntry()) != null) {
                if (!ze.isDirectory()) {
                    String name = ze.getName();
                    if (name.contains("Info.plist")) {
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        //int read = 0;
                        int chunk = 0;
                        byte[] data = new byte[256];
                        while (-1 != (chunk = zipIns.read(data))) {
                            //read += data.length;
                            byteArrayOutputStream.write(data, 0, chunk);
                        }
                        infoIs = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                        break;
                    }
                }
            }
            if (null != infoIs) {
                NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(infoIs);
                String[] keyArray = rootDict.allKeys();
                appModel = new AppModel();
                for (String key : keyArray) {
                    NSObject value = rootDict.objectForKey(key);
                    if (CF_BUNDLE_SIGNATURE.equals(key)) {
                        continue;
                    }
                    if (value.getClass().equals(NSString.class) || value.getClass().equals(NSNumber.class)) {
                        if (VERSION.equals(key)) {
                            appModel.setVersion(value.toString());
                        } else if (PACKAGE.equals(key)) {
                            appModel.setAppPackage(value.toString());
                        }
                    }
                }
                zipIns.close();
            }
        } catch (Exception e) {
            logger.error("Parse IPA error.", e);
        }
        return appModel;
    }

}
