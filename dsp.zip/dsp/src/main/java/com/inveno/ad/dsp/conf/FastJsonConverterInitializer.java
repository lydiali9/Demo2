package com.inveno.ad.dsp.conf;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.inveno.ad.dsp.util.DateUtils;
import com.inveno.ad.dsp.vo.VoContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author by sugang on 2018/3/28.
 */
@Configuration
@ConditionalOnClass({FastJsonHttpMessageConverter.class})
@ConditionalOnProperty(name = "app.conf.json-type", havingValue = "fastjson", matchIfMissing = true)
public class FastJsonConverterInitializer {

    private static Logger logger = LoggerFactory.getLogger(FastJsonConverterInitializer.class);

    @Bean
    public HttpMessageConverters fastJsonHttpMessageConverters() {
        logger.info("<#>sys|Init FastJson converter.");
        FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
        FastJsonConfig fastJsonConfig = new FastJsonConfig();
        fastJsonConfig.setSerializerFeatures(SerializerFeature.DisableCircularReferenceDetect);
        fastJsonConfig.setSerializeFilters(new LongValueFilter());
        fastConverter.setFastJsonConfig(fastJsonConfig);
        return new HttpMessageConverters(fastConverter);
    }

    /**
     * 1、兼容前端不能解析long值
     * 2、兼容前端data为空的逻辑判断
     */
    private class LongValueFilter implements ValueFilter {
        @Override
        public Object process(Object object, String name, Object value) {
            if (value instanceof Long) {
                return String.valueOf(value);
            }
            if (object.getClass() == VoContainer.class && name.equals("data") && value == null) {
                return "";
            }
            return value;
        }
    }

}
