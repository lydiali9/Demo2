package com.inveno.ad.dsp.service.impl.support;

import com.inveno.ad.dsp.common.AccountFrozenStatusEnum;
import com.inveno.ad.dsp.common.PromotionBudgetStatusEnum;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.dao.*;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.*;
import com.inveno.ad.dsp.util.DateUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/30
 */
abstract public class AbstractPromUpdStrategy implements PromUpdStrategy {

    @Autowired
    protected AccountDao accountDao;
    @Autowired
    protected AccountFrozenDao accountFrozenDao;
    @Autowired
    protected PromotionDao promotionDao;
    @Autowired
    protected PromotionBudgetDao promotionBudgetDao;
    @Autowired
    protected PromotionOnlineTimeDao promotionOnlineTimeDao;

    protected void checkBalance(PromotionModel updatePromotionModel, PromotionModel promotionInDb) {
        AccountModel accountModel = accountDao.selectByUserId(updatePromotionModel.getUserId());
        AccountFrozenModel param = new AccountFrozenModel();
        param.setUserId(updatePromotionModel.getUserId());
        param.setStatus(AccountFrozenStatusEnum.FROZEN.getValue());
//        List<AccountFrozenModel> existAccountFrozenList = accountFrozenDao.selectFrozenRecordByUserId(param);
//        // 1.1) 非当前推广冻结金额总和。
//        double notCurrentPromotionTotalFrozenAmount = existAccountFrozenList.stream()
//                .filter(e -> !e.getPromotionId().equals(updatePromotionModel.getId()))
//                .mapToDouble(AccountFrozenModel::getFrozenAmount)
//                .sum();
//        // 1.2) 当前推广，今天之前的冻结金额总和。
//        LocalDate today = LocalDate.now();
//        double currentPromotionTotalFrozenAmount = existAccountFrozenList.stream()
//                .filter(e -> today.isAfter(e.getFrozenDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
//                .filter(e -> e.getPromotionId().equals(updatePromotionModel.getId()))
//                .mapToDouble(AccountFrozenModel::getFrozenAmount)
//                .sum();
//        // 1.3) 当前推广修改后需要新增冻结金额总和，取修改前后金额的较大的一个值。
//        List<PromotionOnlineTimeModel> promotionOnlineTimeList = updatePromotionModel.getPromotionOnlineTimeList();
//        double updatedAmount = promotionOnlineTimeList.stream()
//                .filter(e -> !today.isAfter(e.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
//                .filter(e -> e.getPromotionId().equals(updatePromotionModel.getId()))
//                .count() * Math.max(updatePromotionModel.getBudgetAmount(), promotionInDb.getBudgetAmount());
//        if (accountModel.getBalance() < notCurrentPromotionTotalFrozenAmount + currentPromotionTotalFrozenAmount + updatedAmount) {
//            throw new DspException(RetCode.ERR_PROMOTION_INSUFFICIENT_BALANCE);
//        }
    }

    /**
     * 新增大于等于今天的新冻结流水记录
     * @param updatePromotion 新纪录
     * @throws ParseException 日期解析异常
     */
    protected void addGteTodayAccountFrozenRecord(PromotionModel updatePromotion) throws ParseException {
        LocalDate today = LocalDate.now();
        List<AccountFrozenModel> accountFrozenModelList = new ArrayList<>();
        List<PromotionOnlineTimeModel> promotionOnlineTimeList = updatePromotion.getPromotionOnlineTimeList();
        for (PromotionOnlineTimeModel promotionOnlineTimeModel : promotionOnlineTimeList) {
            if (!today.isAfter(promotionOnlineTimeModel.getStartTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate())) {
                AccountFrozenModel accountFrozenModel = new AccountFrozenModel();
                accountFrozenModel.setPromotionId(updatePromotion.getId());
                accountFrozenModel.setCreateTime(new Date());
                accountFrozenModel.setFrozenAmount(updatePromotion.getBudgetAmount());
                accountFrozenModel.setFrozenDate(DateUtils.parseDate(DateFormatUtils.format(promotionOnlineTimeModel.getStartTime(), DateUtils.FMT_yyyyMMdd), DateUtils.FMT_yyyyMMdd));
                accountFrozenModel.setStatus(0);
                accountFrozenModel.setUserId(updatePromotion.getUserId());
                accountFrozenModelList.add(accountFrozenModel);
            }
        }
        accountFrozenDao.batchInsert(accountFrozenModelList);
    }

    /**
     * 删除大于等于今天的当前推广的冻结金额记录
     * @param updatePromotion 待更新记录
     */
    protected void deleteGteTodayAccountFrozenRecord(PromotionModel updatePromotion) {
        LocalDate today = LocalDate.now();
        AccountFrozenModel param = new AccountFrozenModel();
        param.setUserId(updatePromotion.getUserId());
        param.setStatus(AccountFrozenStatusEnum.FROZEN.getValue());
        List<AccountFrozenModel> existAccountFrozenList = accountFrozenDao.selectFrozenRecordByUserId(param);
        List<Integer> needDeleteIdList = existAccountFrozenList.stream()
                .filter(e -> !today.isAfter(e.getFrozenDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()))
                .filter(e -> e.getPromotionId().equals(updatePromotion.getId()))
                .map(AccountFrozenModel::getId)
                .collect(Collectors.toList());
        accountFrozenDao.batchDelete(needDeleteIdList);
    }

    protected void updateAccountFrozenAmount(PromotionModel updatePromotion) throws ParseException {
        deleteGteTodayAccountFrozenRecord(updatePromotion);
        addGteTodayAccountFrozenRecord(updatePromotion);
    }

    protected void updatePromotionBudget(PromotionModel updatePromotion, PromotionModel promotionInDB) {
        if (!promotionInDB.getBudgetAmount().equals(updatePromotion.getBudgetAmount())) {
            PromotionBudgetModel updateExistPromotionBudgetModel = new PromotionBudgetModel();
            updateExistPromotionBudgetModel.setPromotionId(updatePromotion.getId());
            updateExistPromotionBudgetModel.setStatus(PromotionBudgetStatusEnum.INVALID.getValue());
            promotionBudgetDao.updateStatusById(updateExistPromotionBudgetModel);
            PromotionBudgetModel promotionBudgetModel = new PromotionBudgetModel();
            promotionBudgetModel.setCreateTime(new Date());
            promotionBudgetModel.setAmount(updatePromotion.getBudgetAmount());
            promotionBudgetModel.setOperator(updatePromotion.getOperator());
            promotionBudgetModel.setPromotionId(updatePromotion.getId());
            promotionBudgetModel.setStatus(PromotionBudgetStatusEnum.VALID.getValue());
            promotionBudgetDao.insert(promotionBudgetModel);
        }
    }

    protected void updatePromotionOnlineTime(PromotionModel updatePromotion) {
        promotionOnlineTimeDao.deleteByPromotionId(updatePromotion.getId());
        for (PromotionOnlineTimeModel promotionOnlineTimeModel : updatePromotion.getPromotionOnlineTimeList()) {
            promotionOnlineTimeModel.setPromotionId(updatePromotion.getId());
            promotionOnlineTimeModel.setCreateTime(new Date());
            promotionOnlineTimeModel.setStatus(0);
        }
        promotionOnlineTimeDao.batchInsert(updatePromotion.getPromotionOnlineTimeList());
    }

}
