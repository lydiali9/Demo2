package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AreaModel;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface AreaDao {

    @Select(" SELECT id, parent_id, name, capital, area_type " +
            " FROM t_world_area ")
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "parentId", column = "parent_id"),
                    @Result(property = "name", column = "name"),
                    @Result(property = "capital", column = "capital"),
                    @Result(property = "areaType", column = "area_type")
            }
    )
    List<AreaModel> getAllArea();
}
