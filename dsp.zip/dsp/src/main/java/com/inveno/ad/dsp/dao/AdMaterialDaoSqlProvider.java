package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.model.AdMaterialModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import javax.activation.UnsupportedDataTypeException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

/**
 * <p>Title: {@link AdMaterialDaoSqlProvider}</p>
 * <p>Description: 广告素材表SQL提供类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/4
 */
public class AdMaterialDaoSqlProvider extends AbstractSqlProvider {

    @SuppressWarnings("unchecked")
    public String batchInsert(Map<Object, Object> map) {
        StringBuilder sql = new StringBuilder();
        sql.append("INSERT INTO dspv2_t_ad_material(");
        sql.append("type, title, big_image_type, image_group_id, ad_id, image_id, source, operator, create_time, update_time, status)");
        sql.append(" VALUES ");
        String pattern = "#'{'list[{0}].type'}', #'{'list[{0}].title'}', #'{'list[{0}].bigImageType'}', " +
                " #'{'list[{0}].groupId'}', #'{'list[{0}].adId'}',#'{'list[{0}].imageId'}', " +
                " #'{'list[{0}].source'}',#'{'list[{0}].operator'}',#'{'list[{0}].createTime'}', " +
                " #'{'list[{0}].updateTime'}',#'{'list[{0}].status'}'";
        MessageFormat mf = new MessageFormat(pattern);
        List<AdMaterialModel> adMaterialModelList = (List<AdMaterialModel>) map.get(PARAM_BATCH_LIST);
        append(sql, mf, adMaterialModelList, Constants.SEPARATOR_COMMA);
        return sql.toString();
    }

    @SuppressWarnings("unchecked")
    public String batchDelete(Map<String, Object> params) throws UnsupportedDataTypeException {
        SQL sql = new SQL();
        sql.DELETE_FROM("dspv2_t_ad_material");
        List<Long> idList = (List<Long>) params.get(PARAM_BATCH_LIST);
        appendORCondition(sql, idList, "id");
        return sql.toString();
    }

    public String updateByIdWithoutNull(AdMaterialModel adMaterialModel) {
        SQL sql = new SQL();
        sql.UPDATE("dspv2_t_ad_material");
        if (null != adMaterialModel.getType()) {
            sql.SET("type=#{type}");
        }
        if (StringUtils.isNotBlank(adMaterialModel.getTitle())) {
            sql.SET("title=#{title}");
        }
        if (null != adMaterialModel.getBigImageType()) {
            sql.SET("big_image_type=#{bigImageType}");
        }
        if (null != adMaterialModel.getGroupId()) {
            sql.SET("image_group_id=#{groupId}");
        }
        if (null != adMaterialModel.getImageId()) {
            sql.SET("image_id=#{imageId}");
        }
        if (StringUtils.isNotBlank(adMaterialModel.getSource())) {
            sql.SET("source=#{source}");
        }
        if (null != adMaterialModel.getOperator()) {
            sql.SET("operator=#{operator}");
        }
        if (null != adMaterialModel.getUpdateTime()) {
            sql.SET("update_time=#{updateTime}");
        }
        if (null != adMaterialModel.getStatus()) {
            sql.SET("status=#{status}");
        }
        sql.WHERE("id=#{id}");
        return sql.toString();
    }

}
