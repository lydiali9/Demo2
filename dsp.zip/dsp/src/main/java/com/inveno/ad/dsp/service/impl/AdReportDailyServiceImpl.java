package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.dao.AdReportDailyDao;
import com.inveno.ad.dsp.model.AdReportDailyModel;
import com.inveno.ad.dsp.service.AdReportDailyService;
import com.inveno.ad.dsp.vo.AdReportDailyVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdReportDailyServiceImpl implements AdReportDailyService {

    @Autowired
    private AdReportDailyDao adReportDailyDao;

    @Override
    public List<AdReportDailyVo> queryPromotion(AdReportDailyVo adReportDailyVo, Integer userId) {
        List<AdReportDailyVo> adReportDailyVoList = new ArrayList<>();
        AdReportDailyModel adReportDailyModel = new AdReportDailyModel();
        BeanUtils.copyProperties(adReportDailyVo, adReportDailyModel);
        adReportDailyModel.setUserId(userId);
        List<AdReportDailyModel> adReportDailyModelList = adReportDailyDao.selectPromotionData(adReportDailyModel);

        for (AdReportDailyModel reportDailyModel : adReportDailyModelList){
            AdReportDailyVo reportDailyVo = new AdReportDailyVo();
            BeanUtils.copyProperties(reportDailyModel, reportDailyVo);
            adReportDailyVoList.add(reportDailyVo);
        }

        return adReportDailyVoList;
    }

    @Override
    public List<AdReportDailyVo> queryAd(AdReportDailyVo adReportDailyVo, Integer userId) {
        List<AdReportDailyVo> adReportDailyVoList = new ArrayList<>();
        AdReportDailyModel adReportDailyModel = new AdReportDailyModel();
        BeanUtils.copyProperties(adReportDailyVo, adReportDailyModel);
        adReportDailyModel.setUserId(userId);
        List<AdReportDailyModel> adReportDailyModelList = adReportDailyDao.selectAdData(adReportDailyModel);

        for (AdReportDailyModel reportDailyModel : adReportDailyModelList){
            AdReportDailyVo reportDailyVo = new AdReportDailyVo();
            BeanUtils.copyProperties(reportDailyModel, reportDailyVo);
            adReportDailyVoList.add(reportDailyVo);
        }

        return adReportDailyVoList;
    }

    @Override
    public List<AdReportDailyVo> queryUser(AdReportDailyVo adReportDailyVo, Integer userId) {
        List<AdReportDailyVo> adReportDailyVoList = new ArrayList<>();
        AdReportDailyModel adReportDailyModel = new AdReportDailyModel();
        BeanUtils.copyProperties(adReportDailyVo, adReportDailyModel);
        adReportDailyModel.setUserId(userId);
        List<AdReportDailyModel> adReportDailyModelList = adReportDailyDao.selectUserData(adReportDailyModel);

        for (AdReportDailyModel reportDailyModel : adReportDailyModelList){
            AdReportDailyVo reportDailyVo = new AdReportDailyVo();
            BeanUtils.copyProperties(reportDailyModel, reportDailyVo);
            adReportDailyVoList.add(reportDailyVo);
        }

        return adReportDailyVoList;
    }
}
