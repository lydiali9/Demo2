package com.inveno.ad.dsp.service.impl.support;

import com.inveno.ad.dsp.model.PromotionModel;

/**
 * <p>Title: {@link PromUpdReduceTimeStrategy} </p>
 * <p>Description: 推广更新策略:时间减少，金额未变</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/30
 * 时间减少，金额未变
 *    a) 删除冻结表记录。
 *    b) 更新推广上线时间表。
 */
public class PromUpdReduceTimeStrategy extends AbstractPromUpdStrategy {

    @Override
    public void update(PromotionModel updatePromotionModel, PromotionModel promotionModelInDB) throws Exception {
        // a) 删除冻结表记录。
        deleteGteTodayAccountFrozenRecord(updatePromotionModel);
        // b) 更新推广上线时间表。
        deleteGteTodayAccountFrozenRecord(updatePromotionModel);
    }

}
