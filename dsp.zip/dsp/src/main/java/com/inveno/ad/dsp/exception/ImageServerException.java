package com.inveno.ad.dsp.exception;

/**
 * <p>Title: {@link ImageServerException} </p>
 * <p>Description: 云图服务异常类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/8/1
 */
public class ImageServerException extends RuntimeException {
    public ImageServerException() {
    }

    public ImageServerException(String message) {
        super(message);
    }

    public ImageServerException(String message, Throwable cause) {
        super(message, cause);
    }

    public ImageServerException(Throwable cause) {
        super(cause);
    }

    public ImageServerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
