package com.inveno.ad.dsp.service.impl.support;

import com.inveno.ad.dsp.model.PromotionModel;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/30
 * 金额变小，时间增加
 *    a) 判断余额。
 *    b) 更新账户冻结表。
 *    c) 更新推广预算表。
 *    d) 更新推广上线时间表。
 */
public class PromUpdReduceAmoutIncreaseTimeStrategy extends AbstractPromUpdStrategy {
    @Override
    public void update(PromotionModel updatePromotionModel, PromotionModel promotionModelInDB) throws Exception {
        // a) 判断余额。
        checkBalance(updatePromotionModel, promotionModelInDB);
        // b) 更新账户冻结表。
        updateAccountFrozenAmount(updatePromotionModel);
        // c) 更新推广预算表。
        updatePromotionBudget(updatePromotionModel, promotionModelInDB);
        // d) 更新推广上线时间表。
        updatePromotionOnlineTime(updatePromotionModel);
    }
}
