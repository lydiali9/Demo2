package com.inveno.ad.dsp.common;

public enum AdReportDailyStatusEnum {

    NORMAL(1),
    DISCARD(2);

    private Integer value;

    AdReportDailyStatusEnum(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
