package com.inveno.ad.dsp.conf;

import com.zaxxer.hikari.HikariConfig;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author by sugang on 2018/3/28.
 */
@ConfigurationProperties("spring.datasource.hikari")
public class HikariDatabaseProperties extends HikariConfig {
}
