package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.OrientationModel;
import com.inveno.ad.dsp.model.PageModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.jdbc.SQL;

/**
 * <p>Title: {@link OrientationDaoSqlProvider} </p>
 * <p>Description: 定向包动态sql提供类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public class OrientationDaoSqlProvider {

    public String updateById(OrientationModel orientationModel) {
        SQL sql = new SQL();
        sql.UPDATE("dspv2_t_orientation");
        sql.SET("title = #{title}");
        sql.SET("sex = #{sex}");
        sql.SET("age = #{age}");
        sql.SET("platform = #{platform}");
        sql.SET("network = #{network}");
        sql.SET("network_operator = #{networkOperator}");
        sql.SET("area = #{area}");
        sql.SET("phone_brand = #{phoneBrand}");
        sql.SET("is_template = #{isTemplate}");
        sql.SET("operator = #{operator}");
        sql.SET("update_time = #{updateTime}");
        sql.SET("status = #{status}");
        sql.WHERE("id = #{id}");
        return sql.toString();
    }

    public String pageQueryTotalCount(PageModel<OrientationModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(" SELECT ");
        sqlBuilder.append(" count(1) FROM ( ");
        sqlBuilder.append(" SELECT t.id FROM ");
        sqlBuilder.append(" dspv2_t_orientation t ");
        sqlBuilder.append(" WHERE ");
        sqlBuilder.append(" t.user_id = #{request.userId} AND t.is_template=1 ");
        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND t.title like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getStartTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') >= #{request.startTime} ");
        }
        if (null != pageModel.getRequest().getEndTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') <= #{request.endTime} ");
        }
        if (null != pageModel.getRequest().getTitle()) {
            sqlBuilder.append(" AND t.ad_id like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getKeyword()) {
            sqlBuilder.append(" AND t.title like concat('%', #{request.keyword}, '%')");
        }
        sqlBuilder.append(" GROUP BY ");
        sqlBuilder.append(" t.id) TMP ");
        return sqlBuilder.toString();
    }

    public String pageQuery(PageModel<OrientationModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("SELECT ");
        sqlBuilder.append(" id, user_id, title, sex, age, platform, ");
        sqlBuilder.append(" network, network_operator, area, phone_brand, is_template, ");
        sqlBuilder.append(" operator, create_time, update_time, status ");
        sqlBuilder.append(" FROM dspv2_t_orientation t ");
        sqlBuilder.append(" WHERE t.user_id = #{request.userId} ");
        sqlBuilder.append(" AND t.is_template=1");
        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND t.title like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getStartTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') >= #{request.startTime} ");
        }
        if (null != pageModel.getRequest().getEndTime()) {
            sqlBuilder.append(" AND DATE_FORMAT(t.create_time,'%Y-%m-%d') <= #{request.endTime} ");
        }
        if (null != pageModel.getRequest().getTitle()) {
            sqlBuilder.append(" AND t.ad_id like concat('%', #{request.title}, '%') ");
        }
        if (null != pageModel.getRequest().getKeyword()) {
            sqlBuilder.append(" AND t.title like concat('%', #{request.keyword}, '%')");
        }
        sqlBuilder.append(" ORDER BY t.create_time DESC ");
        sqlBuilder.append(" LIMIT #{offset},#{count} ");
        return sqlBuilder.toString();
    }

}
