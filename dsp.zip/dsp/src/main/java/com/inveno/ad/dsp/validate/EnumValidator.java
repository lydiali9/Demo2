package com.inveno.ad.dsp.validate;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>Title: {@code EnumValidator}</p>
 * <p>Description: 枚举校验器 </p>
 * <p>Company: www.inveno.com</p>
 *
 * @author sugang
 * @date 2018/5/11
 */
public class EnumValidator implements ConstraintValidator<EnumValue, Object> {

    private Class<? extends Enum<?>> enumClass;
    private String enumMethod;
    private Map<Class<? extends Enum<?>>, Method> enumValidatorMethodCache = new HashMap<>();

    @Override
    public void initialize(EnumValue enumValue) {
        enumMethod = enumValue.method();
        enumClass = enumValue.clazz();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null) {
            return Boolean.TRUE;
        }
        if (enumClass == null || enumMethod == null) {
            return Boolean.TRUE;
        }
        Class<?> valueClazz = value.getClass();
        try {
            Method method = enumValidatorMethodCache.get(enumClass);
            if (null == method) {
                try {
                    if (List.class.isAssignableFrom(valueClazz)) {
                        method = enumClass.getMethod(enumMethod, List.class);
                    } else if (Set.class.isAssignableFrom(valueClazz)) {
                        method = enumClass.getMethod(enumMethod, Set.class);
                    } else {
                        method = enumClass.getMethod(enumMethod, valueClazz);
                    }
                } catch (NoSuchMethodException e) {
                    method = enumClass.getMethod(enumMethod, getBoxMappingClazz(valueClazz));
                }
                enumValidatorMethodCache.put(enumClass, method);
            }
            if (!Modifier.isStatic(method.getModifiers())) {
                throw new RuntimeException(String.format("%s method is not static method in the %s class", enumMethod, enumClass));
            }

            if (!Boolean.TYPE.equals(method.getReturnType()) && !Boolean.class.equals(method.getReturnType())) {
                throw new RuntimeException(String.format("%s method return is not boolean type in the %s class", enumMethod, enumClass));
            }

            Boolean result = (Boolean) method.invoke(null, value);
            return result == null ? false : result;
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException | SecurityException e) {
            throw new RuntimeException(String.format("This %s(%s) method does not exist in the %s", enumMethod, valueClazz, enumClass), e);
        }
    }

    private Class<?> getBoxMappingClazz(Class<?> boxClazz) {
        if (boxClazz == Integer.class) {
            return int.class;
        } else if (boxClazz == Double.class) {
            return double.class;
        } else if (boxClazz == Long.class) {
            return long.class;
        } else if (boxClazz == Float.class) {
            return float.class;
        } else if (boxClazz == Boolean.class) {
            return boolean.class;
        }
        return null;
    }

}