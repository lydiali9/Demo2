package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.conf.AppConfigProperties;
import com.inveno.ad.dsp.dao.AppDao;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.AppModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.service.AppService;
import com.inveno.ad.dsp.service.StorageService;
import com.inveno.ad.dsp.util.ApkParser;
import com.inveno.ad.dsp.util.IpaParser;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Clock;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

/**
 * <p>Title: {@link AppServiceImpl}</p>
 * <p>Description: 应用service实现类</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
@Service
public class AppServiceImpl implements AppService {

    private static Logger logger = LoggerFactory.getLogger(AppServiceImpl.class);

    @Autowired
    private AppDao appDao;
    @Autowired
    private StorageService storageService;
    @Autowired
    private AppConfigProperties appConfigProperties;

    @Override
    public void upload(AppModel appModel) throws Exception {
        try {
            storageService.store(appModel.getInputStream(), appModel.getFolder(), appModel.getName());
            parseApp(appModel);
            rename(appModel);
        } catch (Exception e) {
            String absFilePath = String.format("%s/%s", appModel.getFolder(), appModel.getName());
            storageService.delete(absFilePath);
            throw e;
        }
    }

    @Override
    public List<AppModel> query(AppModel appModel) {
        return appDao.selectByUserId(appModel.getUserId());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Integer create(AppModel appModel) throws Exception {
        try {
            if (AppUrlTypeEnum.THIRD.getValue() == appModel.getUrlType()) {
                downloadAndParseThirdApp(appModel);
            }
            Date date = new Date();
            appModel.setCreateTime(date);
            appModel.setStatus(0);
            return appDao.insert(appModel);
        } catch (Exception e) {
            String absFilePath = String.format("%s/%s", appModel.getFolder(), appModel.getName());
            storageService.delete(absFilePath);
            throw e;
        }
    }

    @Override
    public AppModel bgUpload(AppModel appModel) throws IOException {
        AppModel retAppModel = new AppModel();
        String url = appModel.getUrl();
        Mono<ClientResponse> resp = WebClient.create(url).get().accept(MediaType.APPLICATION_OCTET_STREAM).exchange().timeout(Duration.of(3, ChronoUnit.MINUTES));
        ClientResponse response = resp.block();
        ClientResponse.Headers headers = response.headers();
        if (headers.contentLength().isPresent()) {
            long contentLength = headers.contentLength().getAsLong();
            if (appConfigProperties.getAppMaxSize() < contentLength) {
                throw new DspException(RetCode.ERR_PARAM, "File greater than " + appConfigProperties.getAppMaxSize());
            }
            retAppModel.setPackageSize(contentLength);
        } else {
            throw new DspException(RetCode.ERR_PARAM, "Invalid download url.");
        }

        String fileName;
        if (appModel.getOs().equals(PlatformEnum.ANDROID.getLabel())) {
            fileName = String.format("%s-%d%s", appModel.getName(), Clock.systemDefaultZone().millis(), AppTypeEnum.apk.getSuffix());
        } else if (appModel.getOs().equals(PlatformEnum.IOS.getLabel())) {
            fileName = String.format("%s-%d%s", appModel.getName(), Clock.systemDefaultZone().millis(), AppTypeEnum.ipa.getSuffix());
        } else {
            fileName = appModel.getUrl().substring(appModel.getUrl().lastIndexOf(Constants.SEPARATOR_VIRGULE) + 1);
        }

        String folder = String.format("%d/%s/%s", appModel.getUserId(), StorageFolderEnum.app, LocalDate.now());
        Resource resource = response.bodyToMono(Resource.class).block();
        storageService.store(resource.getInputStream(), folder, fileName, StandardCopyOption.REPLACE_EXISTING);
        String filePath = String.format("%s/%s", folder, fileName);
        retAppModel.setFolder(filePath);
        retAppModel.setRelativePath(filePath);
        retAppModel.setOs(appModel.getOs());
        return retAppModel;
    }

    @Override
    public PageModel<AppModel> pageQuery(PageModel<AppModel> pageRequest) {
        int totalCount = appDao.pageQueryTotalCount(pageRequest);
        pageRequest.setTotalCount(totalCount);
        if (totalCount > 0) {
            List<AppModel> adModelList = appDao.pageQuery(pageRequest);
            pageRequest.setResponse(adModelList);
        }
        return pageRequest;
    }

    @Override
    public boolean delete(AppModel appModel) throws Exception {
        AppModel appInDb = appDao.selectById(appModel.getId());
        if (null == appInDb) {
            return true;
        } else {
            String userFolder = String.format("%s/%s/", appConfigProperties.getFileRootLocation(), StorageFolderEnum.app);
            if (StringUtils.isNotBlank(appInDb.getFolder())
                    && appInDb.getFolder().startsWith(userFolder)
                    && (appInDb.getFolder().endsWith(AppTypeEnum.apk.getSuffix())
                    || appInDb.getFolder().endsWith(AppTypeEnum.ipa.getSuffix()))) {
                storageService.delete(appInDb.getFolder());
            } else {
                logger.warn("file path[{}] error.", appInDb.getFolder());
            }
            appDao.delete(appInDb.getId());
            return true;
        }
    }

    @Override
    public boolean update(AppModel appModel) throws Exception {
        AppModel appModelInDb = appDao.selectById(appModel.getId());
        if (!appModelInDb.getUrl().equals(appModel.getUrl()) && AppUrlTypeEnum.THIRD.getValue() == appModel.getUrlType()) {
            try {
                downloadAndParseThirdApp(appModel);
            } catch (Exception e) {
                storageService.delete(String.format("%s/%s", appModel.getFolder(), appModel.getName()));
            }
        }
        appModel.setUpdateTime(new Date());
        appDao.updateById(appModel);
        return true;
    }

    private void downloadAndParseThirdApp(AppModel appModel) throws Exception {
        AppModel thirdAppModel = bgUpload(appModel);
        parseApp(thirdAppModel);
        appModel.setPackageSize(thirdAppModel.getPackageSize());
        appModel.setFolder(thirdAppModel.getFolder());
        appModel.setAppPackage(thirdAppModel.getAppPackage());
        appModel.setVersion(thirdAppModel.getVersion());
    }

    private void parseApp(AppModel appModel) throws Exception {
        if (appModel.getOs().equals(PlatformEnum.ANDROID.getLabel())) {
            Path path = storageService.load(appModel.getRelativePath());
            AppModel apk = ApkParser.parse(path.toFile());
            if (apk.getAppPackage() == null || apk.getVersion() == null) {
                throw new DspException(RetCode.ERR_APP);
            }
            appModel.setAppPackage(apk.getAppPackage());
            appModel.setVersion(apk.getVersion());
        } else if (appModel.getOs().equals(PlatformEnum.IOS.getLabel())) {
            Resource resource = storageService.loadAsResource(appModel.getRelativePath());
            AppModel ipa = IpaParser.parse(resource.getInputStream());
            appModel.setAppPackage(ipa.getAppPackage());
            appModel.setVersion(ipa.getVersion());
        } else {
            throw new DspException(RetCode.ERR_APP_TYPE);
        }
    }

    private void rename(AppModel appModel) throws Exception {
        int pointIndex = appModel.getName().lastIndexOf(Constants.SEPARATOR_POINT_WITH_OUT_ESCAPE);
        String originName = appModel.getName().substring(0, pointIndex);
        String suffix = appModel.getName().substring(pointIndex + 1);
        String alias = String.format("%s-%d.%s", originName, Clock.systemDefaultZone().millis(), suffix);
        String newPath = String.format("%s/%s", appModel.getFolder(), alias);
        if (!storageService.exist(newPath)) {
            storageService.move(appModel.getRelativePath(), newPath);
        }
        storageService.delete(appModel.getRelativePath());
        appModel.setFolder(newPath);
        appModel.setAlias(alias);
    }

}
