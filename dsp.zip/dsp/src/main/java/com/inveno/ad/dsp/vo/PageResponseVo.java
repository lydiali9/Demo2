package com.inveno.ad.dsp.vo;

/**
 * <p>Title: {@link PageResponseVo}</p>
 * <p>Description: 分页响应VO对象</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
public class PageResponseVo extends BaseVo {

    private Integer currentPageNo;
    private Integer eachPageCapacity;
    private Integer totalCount;

    public Integer getCurrentPageNo() {
        return currentPageNo;
    }

    public void setCurrentPageNo(Integer currentPageNo) {
        this.currentPageNo = currentPageNo;
    }

    public Integer getEachPageCapacity() {
        return eachPageCapacity;
    }

    public void setEachPageCapacity(Integer eachPageCapacity) {
        this.eachPageCapacity = eachPageCapacity;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }
}
