package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link AppUrlTypeEnum}</p>
 * <p>Description: 应用上传URL类型 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/17
 */
public enum AppUrlTypeEnum {

    /**
     * inveno地址
     */
    INVENO(1),
    /**
     * 第三方下载地址
     */
    THIRD(2);

    private int value;

    AppUrlTypeEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static boolean contains(int value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue() == value);
    }
}
