package com.inveno.ad.dsp.filter;


import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.model.UserModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Component
public class AuthFilter extends AbstractBaseFilter implements Filter {

    private static Logger logger = LoggerFactory.getLogger(AuthFilter.class);


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        final HttpServletRequest request = (HttpServletRequest) servletRequest;
        final HttpServletResponse response = (HttpServletResponse) servletResponse;

        String ip = request.getRemoteAddr();
        logger.debug("uri : {}, ip : {}", request.getRequestURI(), ip);
        if (isNoCheckIp(ip)) {
            logger.debug("ip is in white list ");
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }
        String path = request.getServletPath();
        if (isNoCheckUrl(path)) {
            logger.debug("path is in white list ");
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }
        HttpSession session = request.getSession();
        UserModel userModel = (UserModel) session.getAttribute(Constants.SESSION_KEY_USER_INFO);
        if (userModel == null) {
            returnNoAuthMsg(logger, response, RetCode.ERR_STATUS_CONFLICT.getCode(), "非常抱歉，您还未登陆或当前会话已经结束，请刷新当前页面，重新登陆！");
            return;
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }


}
