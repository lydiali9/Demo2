package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.util.DateUtils;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <p>Title: {@link PromotionOnlineTimeVo} </p>
 * <p>Description: 推广上线时间vo </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
public class PromotionOnlineTimeVo extends BaseVo {

    private Integer id;
    @DateTimeFormat(pattern = DateUtils.FMT_yyyyMMddHHmmss_)
    private String startTime;
    @DateTimeFormat(pattern = DateUtils.FMT_yyyyMMddHHmmss_)
    private String endTime;
    private String createTime;
    private String status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
