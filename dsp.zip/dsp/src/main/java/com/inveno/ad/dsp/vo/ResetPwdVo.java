package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.validate.PostValidatorGroup;

import javax.validation.constraints.NotNull;

public class ResetPwdVo extends BaseVo {

    @NotNull(groups = PostValidatorGroup.class)
    private String email;
    @NotNull(groups = PostValidatorGroup.class)
    private String findPwdCode;
    @NotNull(groups = PostValidatorGroup.class)
    private String newPwd;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFindPwdCode() {
        return findPwdCode;
    }

    public void setFindPwdCode(String findPwdCode) {
        this.findPwdCode = findPwdCode;
    }

    public String getNewPwd() {
        return newPwd;
    }

    public void setNewPwd(String newPwd) {
        this.newPwd = newPwd;
    }
}
