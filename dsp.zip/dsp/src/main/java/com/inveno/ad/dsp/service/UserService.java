package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.vo.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public interface UserService {
    UserVo login(LoginVo loginVo, HttpSession session) throws Exception;

    void logout(HttpServletRequest request) throws Exception;

    UserVo userInfo(HttpServletRequest request) throws Exception;

    Integer register(RegisterVo registerVo) throws Exception;

    void resetPwd(ResetPwdVo resetPwdVo) throws Exception;

    void modifyPwd(ModifyPwdVo modifyPwdVo, HttpSession session) throws Exception;
}
