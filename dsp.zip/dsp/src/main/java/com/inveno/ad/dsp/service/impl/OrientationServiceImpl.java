package com.inveno.ad.dsp.service.impl;

import com.inveno.ad.dsp.dao.OrientationDao;
import com.inveno.ad.dsp.dao.PromotionDao;
import com.inveno.ad.dsp.model.OrientationModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.service.OrientationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * <p>Title: {@link OrientationServiceImpl}</p>
 * <p>Description: 定向包服务实现类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
@Service
public class OrientationServiceImpl implements OrientationService {

    private static Logger logger = LoggerFactory.getLogger(OrientationServiceImpl.class);

    @Autowired
    private OrientationDao orientationDao;
    @Autowired
    private PromotionDao promotionDao;

    @Override
    public Integer create(OrientationModel orientationModel) throws Exception {
        Date date = new Date();
        orientationModel.setCreateTime(date);
        orientationModel.setStatus(0);
        orientationDao.insert(orientationModel);
        logger.info("orientation_id={}", orientationModel.getId());
        return orientationModel.getId();
    }

    @Override
    public boolean delete(Integer id) {
        orientationDao.deleteById(id);
        return true;
    }

    @Override
    public boolean update(OrientationModel orientationModel) {
        orientationModel.setUpdateTime(new Date());
        orientationDao.updateById(orientationModel);
        return true;
    }

    @Override
    public OrientationModel get(Integer id) {
        return orientationDao.selectById(id);
    }

    @Override
    public PageModel<OrientationModel> pageQuery(PageModel<OrientationModel> pageRequest) {
        int totalCount = orientationDao.pageQueryTotalCount(pageRequest);
        if (totalCount > 0) {
            List<OrientationModel> orientationModelList = orientationDao.pageQuery(pageRequest);
            pageRequest.setTotalCount(totalCount);
            pageRequest.setResponse(orientationModelList);
        }
        return pageRequest;
    }

    @Override
    public List<OrientationModel> templateList(OrientationModel orientationModel) {
        return orientationDao.selectOrientationTemplateByUserId(orientationModel.getUserId());
    }
}
