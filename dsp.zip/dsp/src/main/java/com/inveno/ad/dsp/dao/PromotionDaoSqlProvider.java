package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.common.SearchTimeIntervalType;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.model.PromotionModel;
import com.inveno.ad.dsp.util.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.jdbc.SQL;

/**
 * <p>Title: {@link PromotionDaoSqlProvider} </p>
 * <p>Description: 推广DAO sql提供类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public class PromotionDaoSqlProvider extends AbstractSqlProvider {

    public String pageQueryTotalCount(PageModel<PromotionModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append(" SELECT ");
        sqlBuilder.append(" count(1) FROM ( ");
        sqlBuilder.append(" SELECT prom.id FROM ");
        sqlBuilder.append(" dspv2_t_promotion prom ");
        sqlBuilder.append(" LEFT JOIN dspv2_t_ad_report_daily ard ON (prom.id = ard.promotion_id) ");
        sqlBuilder.append(" WHERE ");
        sqlBuilder.append(" prom.user_id = #{request.userId} ");

        if (SearchTimeIntervalType.SEARCH_CREATE_TIME.getValue().equals(pageModel.getRequest().getTimeIntervalType())) {
            // 此处先借用deliverStartTime、deliverEndTime这两个属性,本来应该新增两个用来搜索createTime的属性的
            String startCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getDeliverStartTime()) + " 00:00:00";
            String endCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getDeliverEndTime()) + " 23:59:59";
            pageModel.getRequest().setDeliverStartTime(DateUtils.strToDateTime(startCreateTimeStr));
            pageModel.getRequest().setDeliverEndTime(DateUtils.strToDateTime(endCreateTimeStr));
            sqlBuilder.append(" AND DATE_FORMAT(prom.create_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.create_time, '%Y-%m-%d')<= #{request.deliverEndTime}");
        } else {
            sqlBuilder.append(" AND ((DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d')<= #{request.deliverEndTime})");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.deliverEndTime}) ");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.deliverEndTime})) ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND prom.title like concat('%', #{request.title}, '%') ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getKeyword())) {
            sqlBuilder.append(" AND (prom.title like concat('%', #{request.keyword}, '%') OR  prom.id like concat('%', #{request.keyword}, '%'))");
        }
        if (null != pageModel.getRequest().getStatus()) {
            sqlBuilder.append(" AND prom.status = #{request.status}");
        }
        sqlBuilder.append(" GROUP BY ");
        sqlBuilder.append(" prom.id) TMP ");
        return sqlBuilder.toString();
    }

    public String pageQuery(PageModel<PromotionModel> pageModel) {
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder.append("SELECT ");
        sqlBuilder.append(" prom.user_id, ");
        sqlBuilder.append(" prom.title, ");
        sqlBuilder.append(" prom.charge_mode, ");
        sqlBuilder.append(" prom.pay_amount_unit, ");
        sqlBuilder.append(" prom.budget_type, ");
        sqlBuilder.append(" prom.budget_amount, ");
        sqlBuilder.append(" prom.deliver_start_time, ");
        sqlBuilder.append(" prom.deliver_end_time, ");
        sqlBuilder.append(" prom.status, ");
        sqlBuilder.append(" prom.id, ");
        sqlBuilder.append(" SUM(ard.pv) pv, ");
        sqlBuilder.append(" SUM(ard.click) click, ");
        sqlBuilder.append(" convert(SUM(ard.click) / SUM(ard.pv) * 100, decimal(10,2)) ctr, ");
        sqlBuilder.append(" convert(SUM(ard.total_cost) / SUM(ard.pv) * 1000 ,decimal(10,2)) ecpm, ");
        sqlBuilder.append(" convert(SUM(ard.total_cost) / SUM(ard.click), decimal(10,2)) ecpc, ");
        sqlBuilder.append(" SUM(ard.total_cost) total_cost, ");
        sqlBuilder.append(" (SELECT count(1) FROM dspv2_t_ad ad WHERE ad.promotion_id = prom.id) as ad_count ");
        sqlBuilder.append("FROM ");
        sqlBuilder.append(" dspv2_t_promotion prom ");
        sqlBuilder.append("LEFT JOIN dspv2_t_ad_report_daily ard ON (prom.id = ard.promotion_id) ");
        sqlBuilder.append("WHERE ");
        sqlBuilder.append(" prom.user_id = #{request.userId} ");

        if (SearchTimeIntervalType.SEARCH_CREATE_TIME.getValue().equals(pageModel.getRequest().getTimeIntervalType())) {
            // 此处先借用deliverStartTime、deliverEndTime这两个属性,本来应该新增两个用来搜索createTime的属性的
            String startCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getDeliverStartTime()) + " 00:00:00";
            String endCreateTimeStr = DateUtils.getStringDate(pageModel.getRequest().getDeliverEndTime()) + " 23:59:59";
            pageModel.getRequest().setDeliverStartTime(DateUtils.strToDateTime(startCreateTimeStr));
            pageModel.getRequest().setDeliverEndTime(DateUtils.strToDateTime(endCreateTimeStr));
            sqlBuilder.append(" AND DATE_FORMAT(prom.create_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.create_time, '%Y-%m-%d')<= #{request.deliverEndTime} ");
        } else {
            sqlBuilder.append(" AND ((DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d')<= #{request.deliverEndTime})");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.deliverEndTime}) ");
            sqlBuilder.append(" OR (DATE_FORMAT(prom.deliver_start_time, '%Y-%m-%d') >= #{request.deliverStartTime} AND DATE_FORMAT(prom.deliver_end_time, '%Y-%m-%d') <= #{request.deliverEndTime})) ");
        }

        if (StringUtils.isNotBlank(pageModel.getRequest().getTitle())) {
            sqlBuilder.append(" AND prom.title like concat('%', #{request.title}, '%') ");
        }
        if (StringUtils.isNotBlank(pageModel.getRequest().getKeyword())) {
            sqlBuilder.append(" AND (prom.title like concat('%', #{request.keyword}, '%') OR  prom.id like concat('%', #{request.keyword}, '%'))");
        }
        if (null != pageModel.getRequest().getStatus()) {
            sqlBuilder.append(" AND prom.status = #{request.status}");
        }
        sqlBuilder.append("GROUP BY ");
        sqlBuilder.append(" prom.id");
        sqlBuilder.append(" ORDER BY prom.create_time DESC");
        sqlBuilder.append(" LIMIT #{offset},#{count} ");
        return sqlBuilder.toString();
    }

    public String updateByIdWithoutNull(PromotionModel promotionModel) {
        SQL sql = new SQL();
        sql.UPDATE("dspv2_t_promotion");
        if (null != promotionModel.getAppId()) {
            sql.SET("app_id=#{appId}");
        }
        if (null != promotionModel.getOrientationId()) {
            sql.SET("orientation_id=#{orientationId}");
        }
        if (null != promotionModel.getParentUserId()) {
            sql.SET("parent_user_id=#{parentUserId}");
        }
        if (null != promotionModel.getUserId()) {
            sql.SET("user_id=#{userId}");
        }
        if (StringUtils.isNotBlank(promotionModel.getTitle())) {
            sql.SET("title=#{title}");
        }
        if (null != promotionModel.getType()) {
            sql.SET("type=#{type}");
        }
        if (StringUtils.isNotBlank(promotionModel.getLinkUrl())) {
            sql.SET("link_url=#{linkUrl}");
        }
        if (StringUtils.isNotBlank(promotionModel.getProduct())) {
            sql.SET("product=#{product}");
        }
        if (null != promotionModel.getBudgetType()) {
            sql.SET("budget_type=#{budgetType}");
        }
        if (null != promotionModel.getBudgetAmount()) {
            sql.SET("budget_amount=#{budgetAmount}");
        }
        if (null != promotionModel.getDeliverType()) {
            sql.SET("deliver_type=#{deliverType}");
        }
        if (null != promotionModel.getDeliverStartTime()) {
            sql.SET("deliver_start_time=#{deliverStartTime}");
        }
        if (null != promotionModel.getDeliverEndTime()) {
            sql.SET("deliver_end_time=#{deliverEndTime}");
        }
        if (null != promotionModel.getBuyType()) {
            sql.SET("buy_type=#{buyType}");
        }
        if (null != promotionModel.getChargeMode()) {
            sql.SET("charge_mode=#{chargeMode}");
        }
        if (null != promotionModel.getPayAmountUnit()) {
            sql.SET("pay_amount_unit=#{payAmountUnit}");
        }
        if (null != promotionModel.getOperator()) {
            sql.SET("operator=#{operator}");
        }
        if (null != promotionModel.getStatus()) {
            sql.SET("status=#{status}");
        }
        if (null != promotionModel.getDeliverTimeType()) {
            sql.SET("deliver_time_type=#{deliverTimeType}");
        }
        sql.WHERE("id=#{id}");
        return sql.toString();
    }

}
