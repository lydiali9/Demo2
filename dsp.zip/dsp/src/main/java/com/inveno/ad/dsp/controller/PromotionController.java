package com.inveno.ad.dsp.controller;

import com.alibaba.fastjson.JSONArray;
import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.OrientationModel;
import com.inveno.ad.dsp.model.PageModel;
import com.inveno.ad.dsp.model.PromotionModel;
import com.inveno.ad.dsp.model.PromotionOnlineTimeModel;
import com.inveno.ad.dsp.service.PromotionService;
import com.inveno.ad.dsp.util.DateUtils;
import com.inveno.ad.dsp.vo.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>Title: {@link PromotionController}</p>
 * <p>Description: 推广控制器类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
@RestController
public class PromotionController {

    @Autowired
    private PromotionService promotionService;

    @PostMapping("/promotion")
    @ResponseBody
    public VoContainer<PromotionVo> create(PromotionVo promotionVo) throws Exception {
        PromotionModel promotionModel = voToModel(promotionVo);
        promotionModel.setUserId(promotionVo.getOperator());
        promotionService.create(promotionModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @PutMapping("/promotion")
    @ResponseBody
    public VoContainer<PromotionVo> update(PromotionVo promotionVo) throws Exception {
        PromotionModel promotionModel = voToModel(promotionVo);
        promotionModel.setUserId(promotionVo.getOperator());
        promotionService.update(promotionModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @GetMapping("/promotion/id")
    @ResponseBody
    public VoContainer<PromotionVo> get(PromotionVo promotionVo) throws Exception {
        PromotionModel promotionModel = promotionService.getById(promotionVo.getId());
        PromotionVo retPromotionVo = modelToVo(promotionModel);
        return VoContainerHelper.createVoContainer(retPromotionVo, RetCode.OK);
    }

    @PutMapping("/promotion/status")
    @ResponseBody
    public VoContainer switchPromotionStatus(PromotionVo promotionVo) throws Exception {
        PromotionModel promotionModel = voToModel(promotionVo);
        promotionService.switchPromotionStatus(promotionModel);
        return VoContainerHelper.createVoContainer(RetCode.OK);
    }

    @GetMapping("/promotion/list")
    @ResponseBody
    public VoContainer<List<PromotionVo>> list(PromotionVo promotionVo) throws Exception {
        PromotionModel promotionModel = new PromotionModel();
        promotionModel.setUserId(promotionVo.getOperator());
        promotionModel.setCategory(null == promotionVo.getCategory() ? 0 : promotionVo.getCategory());
        List<PromotionModel> retPromotionModelList = promotionService.list(promotionModel);
        List<PromotionVo> retPromotionVoList = modelListToVoList(retPromotionModelList);
        return VoContainerHelper.createVoContainer(retPromotionVoList, RetCode.OK);
    }

    @GetMapping("/promotion")
    @ResponseBody
    public VoContainer<List<PromotionVo>> pageQuery(PromotionVo promotionVo) throws Exception {
        PromotionModel promotionModel = new PromotionModel();
        promotionModel.setUserId(promotionVo.getOperator());
        // 分页查询
        promotionModel.setDeliverStartTime(DateUtils.parseDate(promotionVo.getDeliverStartTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        promotionModel.setDeliverEndTime(DateUtils.parseDate(promotionVo.getDeliverEndTime(), DateUtils.FMT_yyyyMMddHHmmss_, DateUtils.FMT_yyyyMMdd));
        promotionModel.setTitle(promotionVo.getTitle());
        promotionModel.setKeyword(promotionVo.getKeyword());
        promotionModel.setTimeIntervalType(promotionVo.getTimeIntervalType());
        promotionModel.setStatus(promotionVo.getStatus());

        PageModel<PromotionModel> pageModel = new PageModel<>();
        pageModel.setOffset((promotionVo.getCurrentPageNo() - 1) * promotionVo.getEachPageCapacity());
        pageModel.setCount(promotionVo.getEachPageCapacity());
        pageModel.setRequest(promotionModel);
        PageModel<PromotionModel> pageQueryResult = promotionService.pageQuery(pageModel);

        List<PromotionModel> retPromotionModelList = pageQueryResult.getResponse();
        List<PromotionVo> retPromotionVoList = modelListToVoList(retPromotionModelList);
        PageResponseVo pageResponseVo = new PageResponseVo();
        pageResponseVo.setCurrentPageNo(promotionVo.getCurrentPageNo());
        pageResponseVo.setEachPageCapacity(promotionVo.getEachPageCapacity());
        pageResponseVo.setTotalCount(pageModel.getTotalCount());
        return VoContainerHelper.createPageVoContainer(retPromotionVoList, pageResponseVo, RetCode.OK);
    }

    private PromotionModel voToModel(PromotionVo promotionVo) throws ParseException {
        PromotionModel promotionModel = new PromotionModel();
        BeanUtils.copyProperties(promotionVo, promotionModel);
        if (null != promotionVo.getOrientation()) {
            OrientationModel orientationModel = new OrientationModel();
            promotionModel.setOrientation(orientationModel);
            BeanUtils.copyProperties(promotionVo.getOrientation(), orientationModel, "age", "platform", "network", "networkOperator");
            if (StringUtils.isNotBlank(promotionVo.getOrientation().getAge())) {
                try {
                    JSONArray ageNumberJSONArray = JSONArray.parseArray(promotionVo.getOrientation().getAge());
                    if (!ageNumberJSONArray.isEmpty()) {
                        JSONArray ageLabelJSONArray = new JSONArray();
                        ageNumberJSONArray.toJavaList(Integer.class).stream()
                                .map(AgeEnum::parse)
                                .filter(e -> AgeEnum.UNLIMITED.getNumber() != e.getNumber())
                                .map(AgeEnum::getLabel)
                                .forEach(ageLabelJSONArray::add);
                        if (!ageLabelJSONArray.isEmpty()) {
                            orientationModel.setAge(ageLabelJSONArray.toJSONString());
                        }
                    }
                } catch (Exception e) {
                    throw new DspException(RetCode.ERR_PARAM, "age", promotionVo.getOrientation().getAge());
                }
            }

            if (StringUtils.isNotBlank(promotionVo.getOrientation().getPlatform())) {
                try {
                    PlatformEnum platformEnum = PlatformEnum.parse(Integer.parseInt(promotionVo.getOrientation().getPlatform()));
                    if (null != platformEnum && PlatformEnum.UNLIMITED != platformEnum) {
                        orientationModel.setPlatform(platformEnum.getLabel());
                    }
                } catch (Exception e) {
                    throw new DspException(RetCode.ERR_PARAM, "platform", promotionVo.getOrientation().getPlatform());
                }
            }

            if (StringUtils.isNotBlank(promotionVo.getOrientation().getNetwork())) {
                try {
                    JSONArray networkNumberJSONArray = JSONArray.parseArray(promotionVo.getOrientation().getNetwork());
                    if (!networkNumberJSONArray.isEmpty()) {
                        JSONArray networkLabelJSONArray = new JSONArray();
                        networkNumberJSONArray.toJavaList(Integer.class).stream()
                                .map(NetworkEnum::parse)
                                .filter(e -> NetworkEnum.UNLIMITED.getNumber() != e.getNumber())
                                .map(NetworkEnum::getLabel)
                                .forEach(networkLabelJSONArray::add);
                        if (!networkLabelJSONArray.isEmpty()) {
                            orientationModel.setNetwork(networkLabelJSONArray.toJSONString());
                        }
                    }
                } catch (Exception e) {
                    throw new DspException(RetCode.ERR_PARAM, "network", promotionVo.getOrientation().getNetwork());
                }
            }

            if (StringUtils.isNotBlank(promotionVo.getOrientation().getNetworkOperator())) {
                try {
                    JSONArray networkOperatorNumberJSONArray = JSONArray.parseArray(promotionVo.getOrientation().getNetworkOperator());
                    if (!networkOperatorNumberJSONArray.isEmpty()) {
                        JSONArray networkOperatorLabelJSONArray = new JSONArray();
                        networkOperatorNumberJSONArray.toJavaList(Integer.class).stream()
                                .map(NetworkOperatorEnum::parse)
                                .filter(e -> NetworkOperatorEnum.UNLIMITED.getNumber() != e.getNumber())
                                .map(NetworkOperatorEnum::getLabel)
                                .forEach(networkOperatorLabelJSONArray::add);
                        if (!networkOperatorLabelJSONArray.isEmpty()) {
                            orientationModel.setNetworkOperator(networkOperatorLabelJSONArray.toJSONString());
                        }
                    }
                } catch (Exception e) {
                    throw new DspException(RetCode.ERR_PARAM, "networkOperator", promotionVo.getOrientation().getNetworkOperator());
                }
            }
        }
        List<PromotionOnlineTimeVo> promotionOnlineTimeList = promotionVo.getPromotionOnlineTimeList();
        if (CollectionUtils.isNotEmpty(promotionOnlineTimeList)) {
            List<PromotionOnlineTimeModel> promotionOnlineTimeModelList = new ArrayList<>(promotionOnlineTimeList.size());
            promotionModel.setPromotionOnlineTimeList(promotionOnlineTimeModelList);
            for (PromotionOnlineTimeVo promotionOnlineTimeVo : promotionOnlineTimeList) {
                PromotionOnlineTimeModel promotionOnlineTimeModel = new PromotionOnlineTimeModel();
                promotionOnlineTimeModel.setStartTime(DateUtils.parseDate(promotionOnlineTimeVo.getStartTime(), DateUtils.FMT_yyyyMMddHHmmss_));
                promotionOnlineTimeModel.setEndTime(DateUtils.parseDate(promotionOnlineTimeVo.getEndTime(), DateUtils.FMT_yyyyMMddHHmmss_));
                promotionOnlineTimeModelList.add(promotionOnlineTimeModel);
            }
            // 前端插件时间需要减1秒。
            promotionOnlineTimeModelList.forEach(e -> e.setEndTime(Date.from(e.getEndTime().toInstant().plusSeconds(-1L))));
        }
        return promotionModel;
    }

    private PromotionVo modelToVo(PromotionModel promotionModel) {
        PromotionVo promotionVo = new PromotionVo();
        BeanUtils.copyProperties(promotionModel, promotionVo);
        if (null != promotionModel.getDeliverStartTime()) {
            promotionVo.setDeliverStartTime(DateFormatUtils.format(promotionModel.getDeliverStartTime(), DateUtils.FMT_yyyyMMddHHmmss_));
        }
        if (null != promotionModel.getDeliverEndTime()) {
            promotionVo.setDeliverEndTime(DateFormatUtils.format(promotionModel.getDeliverEndTime(), DateUtils.FMT_yyyyMMddHHmmss_));
        }
        if (null != promotionModel.getOrientation()) {
            OrientationVo orientationVo = new OrientationVo();
            BeanUtils.copyProperties(promotionModel.getOrientation(), orientationVo, "age", "platform", "network", "networkOperator");
            JSONArray ageNumberJSONArray = new JSONArray();
            if (StringUtils.isNotBlank(promotionModel.getOrientation().getAge())) {
                JSONArray ageLabelJSONArray = JSONArray.parseArray(promotionModel.getOrientation().getAge());
                if (!ageLabelJSONArray.isEmpty()) {
                    ageLabelJSONArray.toJavaList(String.class).stream().map(AgeEnum::parse).filter(e -> 0 != e.getNumber()).map(AgeEnum::getNumber).forEach(ageNumberJSONArray::add);
                }
            }
            if (ageNumberJSONArray.isEmpty()) {
                ageNumberJSONArray.add(AgeEnum.UNLIMITED.getNumber());
            }
            orientationVo.setAge(ageNumberJSONArray.toJSONString());

            if (StringUtils.isNotBlank(promotionModel.getOrientation().getPlatform())) {
                orientationVo.setPlatform(String.valueOf(PlatformEnum.parse(promotionModel.getOrientation().getPlatform()).getNumber()));
            } else {
                orientationVo.setPlatform(String.valueOf(PlatformEnum.UNLIMITED.getNumber()));
            }

            JSONArray networkNumberJSONArray = new JSONArray();
            if (StringUtils.isNotBlank(promotionModel.getOrientation().getNetwork())) {
                JSONArray networkLabelJSONArray = JSONArray.parseArray(promotionModel.getOrientation().getNetwork());
                if (!networkLabelJSONArray.isEmpty()) {
                    networkLabelJSONArray.toJavaList(String.class).stream().map(NetworkEnum::parse).filter(e -> 0 != e.getNumber()).map(NetworkEnum::getNumber).forEach(networkNumberJSONArray::add);
                }
            }
            if (networkNumberJSONArray.isEmpty()) {
                networkNumberJSONArray.add(NetworkEnum.UNLIMITED.getNumber());
            }
            orientationVo.setNetwork(networkNumberJSONArray.toJSONString());

            JSONArray networkOperatorNumberJSONArray = new JSONArray();
            if (StringUtils.isNotBlank(promotionModel.getOrientation().getNetworkOperator())) {
                JSONArray networkOperatorLabelJSONArray = JSONArray.parseArray(promotionModel.getOrientation().getNetworkOperator());
                if (!networkOperatorLabelJSONArray.isEmpty()) {
                    networkOperatorLabelJSONArray.toJavaList(String.class).stream().map(NetworkOperatorEnum::parse).filter(e -> 0 != e.getNumber()).map(NetworkOperatorEnum::getNumber).forEach(networkOperatorNumberJSONArray::add);
                }
            }
            if (networkOperatorNumberJSONArray.isEmpty()) {
                networkOperatorNumberJSONArray.add(NetworkOperatorEnum.UNLIMITED.getNumber());
            }
            orientationVo.setNetworkOperator(networkOperatorNumberJSONArray.toJSONString());

            promotionVo.setOrientation(orientationVo);
        }
        if (null != promotionModel.getAdReportDailyModel()) {
            AdReportDailyVo adReportDailyVo = new AdReportDailyVo();
            promotionVo.setStatistic(adReportDailyVo);
            BeanUtils.copyProperties(promotionModel.getAdReportDailyModel(), adReportDailyVo);
        }
        if (CollectionUtils.isNotEmpty(promotionModel.getPromotionOnlineTimeList())) {
            List<PromotionOnlineTimeVo> promotionOnlineTimeList = new ArrayList<>(promotionModel.getPromotionOnlineTimeList().size());
            // 返回给前端时间加秒。
            promotionModel.getPromotionOnlineTimeList().forEach(e -> e.setEndTime(Date.from(e.getEndTime().toInstant().plusSeconds(1L))));
            for (PromotionOnlineTimeModel promotionOnlineTimeModel : promotionModel.getPromotionOnlineTimeList()) {
                PromotionOnlineTimeVo promotionOnlineTimeVo = new PromotionOnlineTimeVo();
                promotionOnlineTimeVo.setStartTime(DateFormatUtils.format(promotionOnlineTimeModel.getStartTime(), DateUtils.FMT_yyyyMMddHHmmss_));
                promotionOnlineTimeVo.setEndTime(DateFormatUtils.format(promotionOnlineTimeModel.getEndTime(), DateUtils.FMT_yyyyMMddHHmmss_));
                promotionOnlineTimeList.add(promotionOnlineTimeVo);
            }
            promotionVo.setPromotionOnlineTimeList(promotionOnlineTimeList);
        }
        return promotionVo;
    }

    private List<PromotionVo> modelListToVoList(List<PromotionModel> promotionModelList) {
        List<PromotionVo> promotionVoList = null;
        if (CollectionUtils.isNotEmpty(promotionModelList)) {
            promotionVoList = new ArrayList<>(promotionModelList.size());
            for (PromotionModel retPromotionModel : promotionModelList) {
                PromotionVo retPromotionVo = modelToVo(retPromotionModel);
                promotionVoList.add(retPromotionVo);
            }
        }
        return promotionVoList;
    }

}
