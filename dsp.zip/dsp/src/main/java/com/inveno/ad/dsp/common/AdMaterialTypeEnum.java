package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link AdMaterialTypeEnum} </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/4
 */
public enum AdMaterialTypeEnum {

    /**
     * 未知
     */
    UNKNOWN(0, "未知"),
    /**
     * 小图
     */
    SMALL_IMG(1, "小图"),
    /**
     * 大图
     */
    BIG_IMG(2, "大图"),
    /**
     * 图组
     */
    IMG_GROUP(3, "图组"),
    /**
     * 视频
     */
    VIDEO(4, "视频");

    private int value;
    private String desc;

    AdMaterialTypeEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static AdMaterialTypeEnum parse(int value) {
        return Arrays.stream(values()).filter(e -> e.getValue() == value).findFirst().orElse(UNKNOWN);
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
