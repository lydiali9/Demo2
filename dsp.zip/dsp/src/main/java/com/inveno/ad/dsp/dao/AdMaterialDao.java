package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AdMaterialModel;
import com.inveno.ad.dsp.model.AdModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * <p>Title: {@link AdMaterialDao} </p>
 * <p>Description: 广告素材DAO对象 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/4
 */
@Mapper
public interface AdMaterialDao {

    /**
     * 插入广告素材
     * @param adMaterialModel 广告素材对象
     * @return 影响行数
     */
    @Insert(
            "INSERT INTO dspv2_t_ad_material(" +
                    "type, title, big_image_type, image_group_id, ad_id, image_id, source, operator, create_time, update_time, status" +
                    ")" +
                    "VALUES(" +
                    "#{type}, #{title}, #{bigImageType}, #{groupId}, #{adId}, #{imageId}, #{source}, #{operator}, #{createTime}, #{updateTime}, #{status}" +
                    ")"
    )
    Integer insert(AdMaterialModel adMaterialModel);

    /**
     * 批量插入素材数据
     * @param adMaterialModelList 新数据
     * @return 影响行数
     */
    @InsertProvider(type = AdMaterialDaoSqlProvider.class, method = "batchInsert")
    @Options(useGeneratedKeys = true)
    Integer batchInsert(List<AdMaterialModel> adMaterialModelList);

    /**
     * 根据广告ID查询广告素材
     * @param adMaterialModel 查询参数: 广告ID, 素材来源
     * @return 广告素材列表
     */
    @Select(
            "SELECT mat.id, mat.type, mat.title, mat.big_image_type, mat.image_group_id, mat.ad_id, mat.image_id, mat.source, mat.operator, mat.create_time, mat.update_time, mat.status" +
                    " FROM dspv2_t_ad_material mat" +
                    " WHERE mat.ad_id = #{adId}" +
                    " AND source = #{source}" +
                    " ORDER BY mat.image_group_id, mat.id"
    )
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "type", column = "type"),
            @Result(property = "title", column = "title"),
            @Result(property = "bigImageType", column = "big_image_type"),
            @Result(property = "groupId", column = "image_group_id"),
            @Result(property = "adId", column = "ad_id"),
            @Result(property = "imageId", column = "image_id"),
            @Result(property = "source", column = "source"),
            @Result(property = "operator", column = "operator"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time"),
            @Result(property = "status", column = "status")
    })
    List<AdMaterialModel> selectByAdId(AdMaterialModel adMaterialModel);

    /**
     * 更新素材
     * @param adMaterialModel 更新详细Model
     * @return 影响行数
     */
    @Update(
            "UPDATE dspv2_t_ad_material SET" +
                    " type=#{type}," +
                    " title=#{title}," +
                    " big_image_type=#{bigImageType}," +
                    " image_group_id=#{groupId}," +
                    " image_id=#{imageId}," +
                    " source=#{source}," +
                    " operator=#{operator}," +
                    " update_time=#{updateTime}" +
                    " WHERE id=#{id}"
    )
    Integer updateById(AdMaterialModel adMaterialModel);

    /**
     * 根据ID更新不为空的字段
     * @param adMaterialModel 待更新数据
     * @return 影响行数
     */
    @UpdateProvider(type = AdMaterialDaoSqlProvider.class, method = "updateByIdWithoutNull")
    Integer updateByIdWithoutNull(AdMaterialModel adMaterialModel);

    /**
     * 根据ID批量删除记录
     * @param idList ID
     * @return 影响行数
     */
    @DeleteProvider(type = AdMaterialDaoSqlProvider.class, method = "batchDelete")
    Integer batchDelete(List<Long> idList);


}
