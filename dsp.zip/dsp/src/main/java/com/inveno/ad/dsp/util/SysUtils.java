package com.inveno.ad.dsp.util;

import com.inveno.ad.dsp.common.Constants;
import com.inveno.ad.dsp.common.RetCode;
import com.inveno.ad.dsp.exception.DspException;
import com.inveno.ad.dsp.model.UserModel;

import javax.servlet.http.HttpSession;

public class SysUtils {

    public static UserModel getUser(HttpSession session){
        UserModel userModel = (UserModel) session.getAttribute(Constants.SESSION_KEY_USER_INFO);
        if (userModel == null){
            throw new DspException(RetCode.ERR_USER_NOT_LOGIN);
        }
        return userModel;
    }
}
