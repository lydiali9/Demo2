package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AdReportDailyModel;
import org.apache.commons.lang3.StringUtils;

public class AdReportDailyDaoSqlProvider extends AbstractSqlProvider {

    public String selectPromotionData(AdReportDailyModel adReportDailyModel) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(" DATE_FORMAT(date,'%Y-%m-%d') date,user_id,promotion_id,promotion_title, ");
        stringBuilder.append(" SUM(impression) impression,SUM(request) request,SUM(pv) pv,SUM(click) click, ");
        stringBuilder.append(" ROUND((SUM(click)/SUM(pv)) * 100, 2) ctr, ");
        stringBuilder.append(" ROUND(SUM(total_cost) / SUM(click), 2) ecpc, ");
        stringBuilder.append(" ROUND(SUM(total_cost) / SUM(pv) * 1000, 2) ecpm, ");
        stringBuilder.append(" SUM(total_cost) total_cost ");
        stringBuilder.append("FROM dspv2_t_ad_report_daily ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(" `date` >= #{searchStartDate} ");
        stringBuilder.append("AND `date` <= #{searchEndDate} ");
        stringBuilder.append("AND `user_id` = #{userId} ");
        if (adReportDailyModel.getPromotionId() != null){
            stringBuilder.append("AND `promotion_id` = #{promotionId} ");
        }
        if (StringUtils.isNotBlank(adReportDailyModel.getPromotionTitle())){
            stringBuilder.append("AND `promotion_title` LIKE concat('%', #{promotionTitle}, '%') ");
        }
        stringBuilder.append("AND `status` = 1 ");
        stringBuilder.append("GROUP BY date,promotion_id ");
        return stringBuilder.toString();
    }

    public String selectAdData(AdReportDailyModel adReportDailyModel) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(" DATE_FORMAT(date,'%Y-%m-%d') date,user_id,promotion_id,promotion_title,ad_id,ad_title, ");
        stringBuilder.append(" impression,request,pv,click,ctr,ecpc,ecpm,total_cost ");
        stringBuilder.append("FROM dspv2_t_ad_report_daily ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(" `date` >= #{searchStartDate} ");
        stringBuilder.append("AND `date` <= #{searchEndDate} ");
        stringBuilder.append("AND `user_id` = #{userId} ");
        if (adReportDailyModel.getPromotionId() != null){
            stringBuilder.append("AND `promotion_id` = #{promotionId} ");
        }
        if (StringUtils.isNotBlank(adReportDailyModel.getPromotionTitle())){
            stringBuilder.append("AND `promotion_title` LIKE concat('%', #{promotionTitle}, '%') ");
        }
        if (adReportDailyModel.getAdId() != null){
            stringBuilder.append("AND `ad_id` = #{adId} ");
        }
        if (StringUtils.isNotBlank(adReportDailyModel.getAdTitle())){
            stringBuilder.append("AND `ad_title` LIKE concat('%', #{adTitle}, '%') ");
        }
        stringBuilder.append("AND `status` = 1 ");
        stringBuilder.append("GROUP BY date,ad_id ");
        return stringBuilder.toString();
    }
}
