package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.AdReportDailyModel;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;

public interface AdReportDailyDao {

    @SelectProvider(type = AdReportDailyDaoSqlProvider.class, method = "selectPromotionData")
    @Results(
            {
                    @Result(property = "date", column = "date"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "promotionId", column = "promotion_id"),
                    @Result(property = "promotionTitle", column = "promotion_title"),
                    @Result(property = "impression", column = "impression"),
                    @Result(property = "request", column = "request"),
                    @Result(property = "pv", column = "pv"),
                    @Result(property = "click", column = "click"),
                    @Result(property = "ctr", column = "ctr"),
                    @Result(property = "ecpc", column = "ecpc"),
                    @Result(property = "ecpm", column = "ecpm"),
                    @Result(property = "totalCost", column = "total_cost"),
            }
            )
    List<AdReportDailyModel> selectPromotionData(AdReportDailyModel adReportDailyModel);

    @SelectProvider(type = AdReportDailyDaoSqlProvider.class, method = "selectAdData")
    @Results(
            {
                    @Result(property = "date", column = "date"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "promotionId", column = "promotion_id"),
                    @Result(property = "promotionTitle", column = "promotion_title"),
                    @Result(property = "adId", column = "ad_id"),
                    @Result(property = "adTitle", column = "ad_title"),
                    @Result(property = "impression", column = "impression"),
                    @Result(property = "request", column = "request"),
                    @Result(property = "pv", column = "pv"),
                    @Result(property = "click", column = "click"),
                    @Result(property = "ctr", column = "ctr"),
                    @Result(property = "ecpc", column = "ecpc"),
                    @Result(property = "ecpm", column = "ecpm"),
                    @Result(property = "totalCost", column = "total_cost"),
            }
    )
    List<AdReportDailyModel> selectAdData(AdReportDailyModel adReportDailyModel);

    @Select(
            "SELECT " +
            "   DATE_FORMAT(date,'%Y-%m-%d') date,user_id, " +
            "   SUM(impression) impression,SUM(request) request,SUM(pv) pv,SUM(click) click, " +
            "   ROUND((SUM(click)/SUM(pv)) * 100, 2) ctr, " +
            "   ROUND(SUM(total_cost) / SUM(click), 2) ecpc, " +
            "   ROUND(SUM(total_cost) / SUM(pv) * 1000, 2) ecpm, " +
            "   SUM(total_cost) total_cost " +
            "FROM dspv2_t_ad_report_daily " +
            "WHERE " +
            " `date` >= #{searchStartDate} " +
            "AND `date` <= #{searchEndDate} " +
            "AND `user_id` = #{userId} " +
            "AND `status` = 1 " +
            "GROUP BY date,user_id "
    )
    @Results(
            {
                    @Result(property = "date", column = "date"),
                    @Result(property = "userId", column = "user_id"),
                    @Result(property = "impression", column = "impression"),
                    @Result(property = "request", column = "request"),
                    @Result(property = "pv", column = "pv"),
                    @Result(property = "click", column = "click"),
                    @Result(property = "ctr", column = "ctr"),
                    @Result(property = "ecpc", column = "ecpc"),
                    @Result(property = "ecpm", column = "ecpm"),
                    @Result(property = "totalCost", column = "total_cost"),
            }
    )
    List<AdReportDailyModel> selectUserData(AdReportDailyModel adReportDailyModel);
}
