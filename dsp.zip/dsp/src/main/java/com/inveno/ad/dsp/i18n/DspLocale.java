package com.inveno.ad.dsp.i18n;

import java.util.Locale;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public enum DspLocale {

    ZH_CH_LOCALE(new Locale("zh", "CN"));
    private Locale locale;

    DspLocale(Locale locale) {
        this.locale = locale;
    }

    public Locale getLocale() {
        return locale;
    }
}
