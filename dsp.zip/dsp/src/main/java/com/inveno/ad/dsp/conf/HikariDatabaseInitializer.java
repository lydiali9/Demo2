package com.inveno.ad.dsp.conf;

import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

/**
 * @author by sugang on 2018/1/2.
 */
@Configuration
@MapperScan(basePackages = HikariDatabaseInitializer.BASE_PACKAGE, sqlSessionFactoryRef = "hikariSqlSessionFactory")
@EnableConfigurationProperties(HikariDatabaseProperties.class)
public class HikariDatabaseInitializer {


	static final String BASE_PACKAGE = "com.inveno.ad.dsp.dao";

	@Bean
	public HikariDataSource hikariDataSource(HikariDatabaseProperties hikariDatabaseProperties) {
		return new HikariDataSource(hikariDatabaseProperties);
	}

	@Bean
	public DataSourceTransactionManager hikariTransactionManager(HikariDataSource hikariDataSource) {
		return new DataSourceTransactionManager(hikariDataSource);
	}

	@Bean
	public SqlSessionFactory hikariSqlSessionFactory(HikariDataSource hikariDataSource) throws Exception {
		final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setDataSource(hikariDataSource);
		return sessionFactory.getObject();
	}

}
