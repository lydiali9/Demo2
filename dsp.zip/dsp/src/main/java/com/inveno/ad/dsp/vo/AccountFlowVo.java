package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.validate.PageValidatorGroup;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class AccountFlowVo extends PageRequestVo {

    private Integer userId;
    private BigDecimal amount;
    private Integer type;
    private Integer source;
    private BigDecimal balance;
    private String memo;
    private String createTime;

    @NotNull(groups = PageValidatorGroup.class)
    private String searchStartDate;
    @NotNull(groups = PageValidatorGroup.class)
    private String searchEndDate;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getSearchStartDate() {
        return searchStartDate;
    }

    public void setSearchStartDate(String searchStartDate) {
        this.searchStartDate = searchStartDate;
    }

    public String getSearchEndDate() {
        return searchEndDate;
    }

    public void setSearchEndDate(String searchEndDate) {
        this.searchEndDate = searchEndDate;
    }
}
