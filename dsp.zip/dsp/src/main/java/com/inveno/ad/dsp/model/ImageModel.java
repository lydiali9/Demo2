package com.inveno.ad.dsp.model;

import com.inveno.ad.dsp.bean.ImageCropBean;

import java.io.InputStream;
import java.util.Date;

/**
 * <p>Title: {@link ImageModel}</p>
 * <p>Description: 图片MODEL类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/18
 */
public class ImageModel extends BaseModel {

    private Long imageId;
    private String url;
    private Integer userId;
    private Integer width;
    private Integer height;
    private String format;
    private Double ratio;
    private String tag;
    private Date createTime;
    private Date updateTime;
    private Integer status;
    private String name;
    private String folder;
    private String absoluteName;
    private InputStream inputStream;
    private String imgServerUrl;
    private String title;
    private Integer isTemplate;
    private Long templateId;
    private Date startTime;
    private Date endTime;
    private Integer type;
    private Integer bigImageType;
    private ImageCropBean imageCropBean;

    public Long getImageId() {
        return imageId;
    }

    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public Double getRatio() {
        return ratio;
    }

    public void setRatio(Double ratio) {
        this.ratio = ratio;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFolder() {
        return folder;
    }

    public void setFolder(String folder) {
        this.folder = folder;
    }

    public String getAbsoluteName() {
        return absoluteName;
    }

    public void setAbsoluteName(String absoluteName) {
        this.absoluteName = absoluteName;
    }

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public String getImgServerUrl() {
        return imgServerUrl;
    }

    public void setImgServerUrl(String imgServerUrl) {
        this.imgServerUrl = imgServerUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getIsTemplate() {
        return isTemplate;
    }

    public void setIsTemplate(Integer isTemplate) {
        this.isTemplate = isTemplate;
    }

    public Long getTemplateId() {
        return templateId;
    }

    public void setTemplateId(Long templateId) {
        this.templateId = templateId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getBigImageType() {
        return bigImageType;
    }

    public void setBigImageType(Integer bigImageType) {
        this.bigImageType = bigImageType;
    }

    public ImageCropBean getImageCropBean() {
        return imageCropBean;
    }

    public void setImageCropBean(ImageCropBean imageCropBean) {
        this.imageCropBean = imageCropBean;
    }
}
