package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link PlatformEnum} </p>
 * <p>Description: 操作平台 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public enum PlatformEnum {

    /**
     * 不限
     */
    UNLIMITED(0, "unlimited"),
    ANDROID(1, "android"),
    IOS(2, "ios"),
    PC(3, "pc"),
    WINPHONE(4, "winphone");

    private int number;
    private String label;

    PlatformEnum(int number, String label) {
        this.number = number;
        this.label = label;
    }

    public static boolean contains(int number) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getNumber() == number);
    }

    public static PlatformEnum parse(int number) {
        return Arrays.stream(values()).filter(e -> e.getNumber() == number).findFirst().orElse(null);
    }

    public static PlatformEnum parse(String label) {
        return Arrays.stream(values()).filter(e -> e.getLabel().equals(label)).findFirst().orElse(null);
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
