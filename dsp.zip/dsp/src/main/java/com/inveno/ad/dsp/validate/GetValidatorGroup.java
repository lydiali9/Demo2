package com.inveno.ad.dsp.validate;

/**
 * <p>Title: {@link GetValidatorGroup} </p>
 * <p>Description: GET方法校验组 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public interface GetValidatorGroup {
}
