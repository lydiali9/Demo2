package com.inveno.ad.dsp.service.impl.support;

import com.inveno.ad.dsp.model.PromotionModel;

/**
 * <p>Title: {@link PromUpdReduceAmountAndTimeStrategy} </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/30
 * 金额变小，时间减少
 *    a) 更新账户冻结表。
 *    b) 更新推广预算表。
 *    c) 更新推广上线时间表。
 */
public class PromUpdReduceAmountAndTimeStrategy extends AbstractPromUpdStrategy {

    @Override
    public void update(PromotionModel updatePromotionModel, PromotionModel promotionModelInDB) throws Exception {
        // a) 更新账户冻结表。
        updateAccountFrozenAmount(updatePromotionModel);
        // b) 更新推广预算表。
        updatePromotionBudget(updatePromotionModel, promotionModelInDB);
        // c) 更新推广上线时间表。
        updatePromotionOnlineTime(updatePromotionModel);
    }

}
