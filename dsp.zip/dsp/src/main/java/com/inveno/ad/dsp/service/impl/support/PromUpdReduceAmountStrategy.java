package com.inveno.ad.dsp.service.impl.support;

import com.inveno.ad.dsp.model.PromotionModel;

/**
 * <p>Title: {@link PromUpdReduceAmountStrategy}</p>
 * <p>Description: 推广更新策略:金额变小，时间天数未变 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/30
 * 金额变小，时间天数未变
 *    a) 当日金额取最大值，因此不变更，当日之后的冻结记录全部更新至最小值。
 *    b) 更新推广预算表。
 *    c) 更新上线时间表。
 */
public class PromUpdReduceAmountStrategy extends AbstractPromUpdStrategy {

    @Override
    public void update(PromotionModel updatePromotionModel, PromotionModel promotionModelInDB) throws Exception {
        // a) 当日金额取最大值，因此不变更，当日之后的冻结记录全部更新至最小值。
        updateAccountFrozenAmount(updatePromotionModel);
        // b) 更新推广预算表。
        updatePromotionBudget(updatePromotionModel, promotionModelInDB);
        // c) 更新上线时间表
        updatePromotionOnlineTime(updatePromotionModel);
    }

}
