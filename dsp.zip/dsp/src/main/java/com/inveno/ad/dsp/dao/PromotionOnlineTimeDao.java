package com.inveno.ad.dsp.dao;

import com.inveno.ad.dsp.model.PromotionOnlineTimeModel;
import org.apache.ibatis.annotations.*;

import java.util.List;

import static com.inveno.ad.dsp.dao.AbstractSqlProvider.PARAM_BATCH_LIST;

/**
 * <p>Title: {@link PromotionOnlineTimeDao} </p>
 * <p>Description: 推广上线时间表dao类 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
@Mapper
public interface PromotionOnlineTimeDao {

    /**
     * 批量插入时间区间
     * @param promotionOnlineTimeModelList 插入参数
     * @return 影响行数
     */
    @InsertProvider(type = PromotionOnlineTimeDaoSqlProvider.class, method = "batchInsert")
    @Options(useGeneratedKeys = true)
    Integer batchInsert(@Param(PARAM_BATCH_LIST) List<PromotionOnlineTimeModel> promotionOnlineTimeModelList);

    /**
     * 根据推广ID删除记录
     * @param promotionId 推广ID
     * @return 影响记录行数
     */
    @Delete(
            "DELETE FROM dspv2_t_promotion_online_time WHERE promotion_id = #{promotionId}"
    )
    Integer deleteByPromotionId(Long promotionId);

    /**
     * 根据推广ID查询
     * @param promotionId 推广ID
     * @return 推广上线时间记录
     */
    @Select(
            "SELECT id, promotion_id, start_time, end_time, create_time, status " +
                    " FROM dspv2_t_promotion_online_time t" +
                    " WHERE t.promotion_id = #{promotionId}"
    )
    @Results(
            {
                    @Result(property = "id", column = "id"),
                    @Result(property = "promotionId", column = "promotion_id"),
                    @Result(property = "startTime", column = "start_time"),
                    @Result(property = "endTime", column = "end_time"),
                    @Result(property = "createTime", column = "create_time"),
                    @Result(property = "status", column = "status")
            }
    )
    List<PromotionOnlineTimeModel> selectByPromotionId(Long promotionId);

    /**
     * 根据ID批量删除
     * @param idList id
     * @return 影响行数
     */
    @DeleteProvider(type = PromotionOnlineTimeDaoSqlProvider.class, method = "batchDelete")
    Integer batchDelete(List<Integer> idList);

}
