package com.inveno.ad.dsp.common;

import java.util.Arrays;

public enum SendEmailEnum {

    SEND_VERIFICATION_CODE_EMAIL("verificationCode"),
    SEND_FIND_PWD_EMAIL("findPwd");

    private String value;

    SendEmailEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static boolean contains(String value) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getValue().equals(value));
    }
}
