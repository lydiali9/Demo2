package com.inveno.ad.dsp.common;

import java.util.Arrays;

/**
 * <p>Title: {@link NetworkOperatorEnum} </p>
 * <p>Description: 网络运营商 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/26
 */
public enum NetworkOperatorEnum {

    /**
     * 不限
     */
    UNLIMITED(0, ""),
    /**
     * 移动
     */
    CMCC(70120, "CMCC"),
    /**
     * 电信
     */
    CTCC(70121, "CTCC"),
    /**
     * 联通
     */
    CUCC(70123, "CUCC");

    private int number;
    private String label;

    NetworkOperatorEnum(int number, String label) {
        this.number = number;
        this.label = label;
    }

    public static NetworkOperatorEnum parse(int number) {
        return Arrays.stream(values()).filter(e -> e.getNumber() == number).findFirst().orElse(null);
    }

    public static NetworkOperatorEnum parse(String label) {
        return Arrays.stream(values()).filter(e -> e.getLabel().equals(label)).findFirst().orElse(null);
    }

    public static boolean contains(int number) {
        return Arrays.stream(values()).anyMatch(ele -> ele.getNumber() == number);
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
