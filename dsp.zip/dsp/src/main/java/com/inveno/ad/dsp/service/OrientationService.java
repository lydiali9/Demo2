package com.inveno.ad.dsp.service;

import com.inveno.ad.dsp.model.OrientationModel;
import com.inveno.ad.dsp.model.PageModel;

import java.util.List;

/**
 * <p>Title: {@link OrientationService}</p>
 * <p>Description: 定向包service类</p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
public interface OrientationService {

    /**
     * 创建定向包
     * @param orientationModel 定向包元素
     * @return 新生成定向包ID
     * @throws Exception 异常抛出
     */
    Integer create(OrientationModel orientationModel) throws Exception;

    /**
     * 删除定向包
     * @param id 定向包ID
     * @return 是否删除成功
     * @throws Exception 异常处理
     */
    boolean delete(Integer id) throws Exception;

    /**
     * 更新定向包
     * @param orientationModel 新的定向包内容
     * @return 是否成功
     * @throws Exception 异常抛出
     */
    boolean update(OrientationModel orientationModel) throws Exception;

    /**
     * 获取定向包
     * @param id 定向包ID
     * @return 定向包
     * @throws Exception 异常抛出
     */
    OrientationModel get(Integer id) throws Exception;

    /**
     * 分页查询定向包
     * @param pageRequest 请求
     * @return 响应信息
     * @throws Exception 异常抛出
     */
    PageModel<OrientationModel> pageQuery(PageModel<OrientationModel> pageRequest) throws Exception;

    /**
     * 用户定向包列表
     * @param orientationModel 请求参数
     * @return 响应信息
     * @throws Exception 异常抛出
     */
    List<OrientationModel> templateList(OrientationModel orientationModel) throws Exception;

}
