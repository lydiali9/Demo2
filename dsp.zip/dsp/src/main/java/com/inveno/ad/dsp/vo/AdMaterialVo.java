package com.inveno.ad.dsp.vo;

import com.inveno.ad.dsp.validate.PostValidatorGroup;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * <p>Title: {@link AdMaterialVo}</p>
 * <p>Description: 广告素材VO对象 </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public class AdMaterialVo extends PageRequestVo {

    private Long id;
    private Integer type;
    private Integer bigImageType;
    private Integer imageGroupId;
    @NotNull(groups = PostValidatorGroup.class)
    private String title;
    private String source;
    private Integer status;
    private String startTime;
    private String endTime;
    /**
     * 模型更改前
     */
    private List<ImageVo> imageList;
    /**
     * 模型更改后，material与material_image一对一
     */
    private ImageVo image;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getBigImageType() {
        return bigImageType;
    }

    public void setBigImageType(Integer bigImageType) {
        this.bigImageType = bigImageType;
    }

    public Integer getImageGroupId() {
        return imageGroupId;
    }

    public void setImageGroupId(Integer imageGroupId) {
        this.imageGroupId = imageGroupId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public List<ImageVo> getImageList() {
        return imageList;
    }

    public void setImageList(List<ImageVo> imageList) {
        this.imageList = imageList;
    }

    public ImageVo getImage() {
        return image;
    }

    public void setImage(ImageVo image) {
        this.image = image;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
