package redis;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import redis.clients.jedis.JedisCluster;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/27
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class Test {

    @Autowired
    private JedisCluster jedisCluster;

    @org.junit.Test
    public void redisTest() {
        jedisCluster.set("dsp_test", "1234");
        System.out.println(jedisCluster.get("dsp_test"));
        jedisCluster.del("dsp_test");
    }

}
