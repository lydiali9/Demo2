/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/20
 */
public class Test {

    @org.junit.Test
    public void test() {
        System.out.println("111111111");
    }

}
