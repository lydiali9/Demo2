package com.inveno.ad.dsp.orientation;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.inveno.ad.dsp.vo.OrientationVo;
import com.inveno.ad.dsp.vo.VoContainer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/25
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class OrientationTest {

    private RestTemplate restTemplate = new RestTemplate();

    @Test
    public void create() {
        JSONArray ageJsonArray = new JSONArray();
        ageJsonArray.add("<18");
        ageJsonArray.add("18~23");

        JSONArray areaJsonArray = new JSONArray();
        areaJsonArray.add("广东");
        ageJsonArray.add("广西");

        JSONArray phoneBrandJsonArray = new JSONArray();
        phoneBrandJsonArray.add("苹果");
        phoneBrandJsonArray.add("小米");
        phoneBrandJsonArray.add("华为");

        OrientationVo orientationVo = new OrientationVo();
        orientationVo.setUserId(7831);
        orientationVo.setTitle("test");
        orientationVo.setSex(1);
        orientationVo.setAge(ageJsonArray.toJSONString());
        orientationVo.setPlatform("ios");
        orientationVo.setNetwork("wifi");
        orientationVo.setNetworkOperator("CMCC");
        orientationVo.setArea(areaJsonArray.toJSONString());
        orientationVo.setPhoneBrand(phoneBrandJsonArray.toJSONString());
        orientationVo.setIsTemplate(1);
        orientationVo.setOperator(9527);
        ResponseEntity<VoContainer> rsp = restTemplate.postForEntity("http://127.0.0.1:8080/orientation", orientationVo, VoContainer.class);
        System.out.println(JSON.toJSONString(rsp));
    }

    @Test
    public void delete() {
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange("http://127.0.0.1:8080/orientation/23", HttpMethod.DELETE, null, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

    @Test
    public void update() {
        JSONArray ageJsonArray = new JSONArray();
        ageJsonArray.add("31~40");

        JSONArray areaJsonArray = new JSONArray();
        areaJsonArray.add("湖南");
        areaJsonArray.add("湖北");

        JSONArray phoneBrandJsonArray = new JSONArray();
        phoneBrandJsonArray.add("锤子");

        OrientationVo orientationVo = new OrientationVo();
        orientationVo.setId(24);
        orientationVo.setUserId(7831);
        orientationVo.setTitle("test");
        orientationVo.setSex(1);
        orientationVo.setAge(ageJsonArray.toJSONString());
        orientationVo.setPlatform("ios");
        orientationVo.setNetwork("wifi");
        orientationVo.setNetworkOperator("CMCC");
        orientationVo.setArea(areaJsonArray.toJSONString());
        orientationVo.setPhoneBrand(phoneBrandJsonArray.toJSONString());
        orientationVo.setIsTemplate(0);
        orientationVo.setOperator(9527);
        HttpEntity<OrientationVo> httpEntity = new HttpEntity<>(orientationVo);
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange("http://127.0.0.1:8080/orientation", HttpMethod.PUT, httpEntity, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

    @Test
    public void pageQuery() {
        String url = "http://127.0.0.1:8080/orientation?currentPageNo=1&eachPageCapacity=10";
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

}
