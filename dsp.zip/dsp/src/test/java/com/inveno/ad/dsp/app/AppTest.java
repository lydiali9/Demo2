package com.inveno.ad.dsp.app;

import com.alibaba.fastjson.JSON;
import com.inveno.ad.dsp.vo.AppVo;
import com.inveno.ad.dsp.vo.VoContainer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public class AppTest {

    private RestTemplate restTemplate = new RestTemplate();

    @Test
    public void bgUpload() {
        AppVo appVo = new AppVo();
        appVo.setUrl("http://192.168.9.18:8080/files/20180611/rose.jpg");
        appVo.setUserId(20180627);
        HttpEntity<AppVo> httpEntity = new HttpEntity<>(appVo);
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange("http://127.0.0.1:8099/app/bgUpload", HttpMethod.POST, httpEntity, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

}
