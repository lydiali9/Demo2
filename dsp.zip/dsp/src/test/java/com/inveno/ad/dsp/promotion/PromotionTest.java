package com.inveno.ad.dsp.promotion;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.inveno.ad.dsp.common.*;
import com.inveno.ad.dsp.vo.OrientationVo;
import com.inveno.ad.dsp.vo.PromotionOnlineTimeVo;
import com.inveno.ad.dsp.vo.PromotionVo;
import com.inveno.ad.dsp.vo.VoContainer;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/29
 */
public class PromotionTest {

    private RestTemplate restTemplate = new RestTemplate();

    @Test
    public void create() {
        PromotionOnlineTimeVo promotionOnlineTimeVo1 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo1.setStartTime("2018-06-29 10:00:00");
        promotionOnlineTimeVo1.setEndTime("2018-06-29 18:00:00");

        PromotionOnlineTimeVo promotionOnlineTimeVo2 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo2.setStartTime("2018-06-30 08:00:00");
        promotionOnlineTimeVo2.setEndTime("2018-06-30 17:00:00");

        PromotionOnlineTimeVo promotionOnlineTimeVo3 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo3.setStartTime("2018-07-02 08:00:00");
        promotionOnlineTimeVo3.setEndTime("2018-07-02 17:00:00");

        PromotionOnlineTimeVo promotionOnlineTimeVo4 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo4.setStartTime("2018-07-04 08:00:00");
        promotionOnlineTimeVo4.setEndTime("2018-07-04 17:00:00");

        List<PromotionOnlineTimeVo> promotionOnlineTimeVoList = Arrays.asList(promotionOnlineTimeVo1, promotionOnlineTimeVo2, promotionOnlineTimeVo3, promotionOnlineTimeVo4);

        JSONArray ageJsonArray = new JSONArray();
        ageJsonArray.add("0~18");
        ageJsonArray.add("18~23");

        JSONArray areaJsonArray = new JSONArray();
        areaJsonArray.add("湖南");
        ageJsonArray.add("湖北");

        JSONArray phoneBrandJsonArray = new JSONArray();
        phoneBrandJsonArray.add("vivo");
        phoneBrandJsonArray.add("oppo");

        OrientationVo orientationVo = new OrientationVo();
        orientationVo.setUserId(7831);
        orientationVo.setTitle("test");
        orientationVo.setSex(1);
        orientationVo.setAge(ageJsonArray.toJSONString());
        orientationVo.setPlatform("ios");
        orientationVo.setNetwork("wifi");
        orientationVo.setNetworkOperator("CMCC");
        orientationVo.setArea(areaJsonArray.toJSONString());
        orientationVo.setPhoneBrand(phoneBrandJsonArray.toJSONString());
        orientationVo.setIsTemplate(1);
        orientationVo.setOperator(9527);

        PromotionVo promotionVo = new PromotionVo();
        promotionVo.setOrientation(orientationVo);
        promotionVo.setPromotionOnlineTimeList(promotionOnlineTimeVoList);
        promotionVo.setUserId(9527);
        promotionVo.setTitle("First promotion");
        promotionVo.setType(PromotionTypeEnum.LINK.getValue());
        promotionVo.setLinkUrl("www.baidu.com");
        promotionVo.setProduct("传媒");
        promotionVo.setBudgetType(PromotionBudgetTypeEnum.DAILY.getValue());
        promotionVo.setBudgetAmount(BigDecimal.valueOf(100D));
        promotionVo.setDeliverType(PromotionDeliverTypeEnum.SPEED_UP.getValue());
        promotionVo.setBuyType(PromotionBuyTypeEnum.BIDDING.getValue());
        promotionVo.setChargeMode(PromotionChargeModeEnum.CPC.getValue());
        promotionVo.setPayAmountUnit(BigDecimal.valueOf(10D));
        System.out.println(JSON.toJSONString(promotionVo));
        ResponseEntity<VoContainer> rsp = restTemplate.postForEntity("http://127.0.0.1:8099/promotion", promotionVo, VoContainer.class);
        System.out.println(JSON.toJSONString(rsp));
    }

    @Test
    public void update() {
        PromotionOnlineTimeVo promotionOnlineTimeVo1 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo1.setStartTime("2018-06-29 10:00:00");
        promotionOnlineTimeVo1.setEndTime("2018-06-29 18:00:00");

        PromotionOnlineTimeVo promotionOnlineTimeVo2 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo2.setStartTime("2018-06-30 08:00:00");
        promotionOnlineTimeVo2.setEndTime("2018-06-30 17:00:00");

        PromotionOnlineTimeVo promotionOnlineTimeVo3 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo3.setStartTime("2018-07-01 08:00:00");
        promotionOnlineTimeVo3.setEndTime("2018-07-01 17:00:00");


        PromotionOnlineTimeVo promotionOnlineTimeVo6 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo6.setStartTime("2018-07-02 08:00:00");
        promotionOnlineTimeVo6.setEndTime("2018-07-02 17:00:00");

        PromotionOnlineTimeVo promotionOnlineTimeVo4 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo4.setStartTime("2018-07-03 08:00:00");
        promotionOnlineTimeVo4.setEndTime("2018-07-03 17:00:00");

        PromotionOnlineTimeVo promotionOnlineTimeVo5 = new PromotionOnlineTimeVo();
        promotionOnlineTimeVo5.setStartTime("2018-07-04 08:00:00");
        promotionOnlineTimeVo5.setEndTime("2018-07-04 17:00:00");

        List<PromotionOnlineTimeVo> promotionOnlineTimeVoList
                = Arrays.asList(promotionOnlineTimeVo1, promotionOnlineTimeVo2, promotionOnlineTimeVo3, promotionOnlineTimeVo4, promotionOnlineTimeVo6);

        JSONArray ageJsonArray = new JSONArray();
        ageJsonArray.add("0~18");

        JSONArray areaJsonArray = new JSONArray();
        areaJsonArray.add("湖南");

        JSONArray phoneBrandJsonArray = new JSONArray();
        phoneBrandJsonArray.add("vivo");

        OrientationVo orientationVo = new OrientationVo();
        orientationVo.setUserId(7831);
        orientationVo.setTitle("test");
        orientationVo.setSex(1);
        orientationVo.setAge(ageJsonArray.toJSONString());
        orientationVo.setPlatform("ios");
        orientationVo.setNetwork("wifi");
        orientationVo.setNetworkOperator("CMCC");
        orientationVo.setArea(areaJsonArray.toJSONString());
        orientationVo.setPhoneBrand(phoneBrandJsonArray.toJSONString());
        orientationVo.setIsTemplate(1);
        orientationVo.setOperator(9527);

        PromotionVo promotionVo = new PromotionVo();
        promotionVo.setId(30L);
        promotionVo.setOrientation(orientationVo);
        promotionVo.setPromotionOnlineTimeList(promotionOnlineTimeVoList);
        promotionVo.setUserId(9527);
        promotionVo.setTitle("First promotion");
        promotionVo.setType(PromotionTypeEnum.LINK.getValue());
        promotionVo.setLinkUrl("www.baidu.com");
        promotionVo.setProduct("传媒");
        promotionVo.setBudgetType(PromotionBudgetTypeEnum.DAILY.getValue());
        promotionVo.setBudgetAmount(BigDecimal.valueOf(250D));
        promotionVo.setDeliverType(PromotionDeliverTypeEnum.SPEED_UP.getValue());
        promotionVo.setBuyType(PromotionBuyTypeEnum.BIDDING.getValue());
        promotionVo.setChargeMode(PromotionChargeModeEnum.CPC.getValue());
        promotionVo.setPayAmountUnit(BigDecimal.valueOf(10D));
        promotionVo.setOrientationId(50);
        HttpEntity<PromotionVo> httpEntity = new HttpEntity<>(promotionVo);
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange("http://127.0.0.1:8099/promotion", HttpMethod.PUT, httpEntity, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

    @Test
    public void get() {
        String url = "http://127.0.0.1:8099/promotion/33";
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

    @Test
    public void pageQuery() {
        String url = "http://192.168.9.18:8099/promotion?currentPageNo=1&eachPageCapacity=10&deliverStartTime=2018-06-29&deliverEndTime=2018-07-05&operator=9527&name=sugang";
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange(url, HttpMethod.GET, null, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

}
