package com.inveno.ad.dsp.user;

import com.alibaba.fastjson.JSON;
import com.inveno.ad.dsp.vo.LoginVo;
import com.inveno.ad.dsp.vo.VoContainer;
import org.junit.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/3
 */
public class UserTest {

    private RestTemplate restTemplate = new RestTemplate();

    @Test
    public void login() {
        LoginVo loginVo = new LoginVo();
        loginVo.setUsername("admin");
        loginVo.setPassword("123456");
        ResponseEntity<VoContainer> rsp = restTemplate.postForEntity("http://127.0.0.1:8099/login", loginVo, VoContainer.class);
        System.out.println(JSON.toJSONString(rsp));
    }

}
