package com.inveno.ad.dsp.ad;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.inveno.ad.dsp.vo.AdVo;
import com.inveno.ad.dsp.vo.PromotionVo;
import com.inveno.ad.dsp.vo.VoContainer;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/7/5
 */
public class AdTest {

    private RestTemplate restTemplate = new RestTemplate();

    @Test
    public void get() {
        AdVo adVo = new AdVo();
        adVo.setCurrentPageNo(1);
        adVo.setEachPageCapacity(10);

        PromotionVo promotionVo = new PromotionVo();
        promotionVo.setId(34L);
        promotionVo.setDeliverStartTime("2017-06-28");
        promotionVo.setDeliverEndTime("2017-07-08");
        adVo.setPromotion(promotionVo);

        String url = "http://192.168.9.18:8099/ad";
        HttpEntity<AdVo> httpEntity = new HttpEntity<>(adVo);
        httpEntity.getHeaders().add("Content-Type", "application/json");
        restTemplate.setMessageConverters(Collections.singletonList(new FastJsonHttpMessageConverter()));
        ResponseEntity<VoContainer> responseEntity = restTemplate.exchange(url, HttpMethod.GET, httpEntity, VoContainer.class);
        System.out.println(JSON.toJSONString(responseEntity));
    }

}
