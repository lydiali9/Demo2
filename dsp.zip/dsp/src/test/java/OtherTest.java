import org.apache.commons.lang3.time.DateUtils;
import org.junit.Test;
import org.springframework.web.util.UriUtils;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.time.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Company: www.inveno.com</p>
 * @author sugang
 * @date 2018/6/28
 */
public class OtherTest {

    @Test
    public void urlEncode() throws UnsupportedEncodingException {
        String src = "12356 odfj";
        System.out.println(URLEncoder.encode(src, "utf-8"));
        System.out.println(UriUtils.encode(src, Charset.defaultCharset()));
    }

    @Test
    public void test() throws ParseException {
        String[] arr = new String[]{"a", "b", "c", "d"};
        Arrays.stream(arr)
                .peek(System.out::println) //a,b,c,d
                .count();

        LocalDateTime localDateTime = LocalDateTime.of(2018, 7, 9, 0, 0, 0);
        System.out.println(localDateTime);
        System.out.println(localDateTime.plusSeconds(-1L));
        List<BigDecimal> bigDecimalList = new ArrayList<>();
        bigDecimalList.add(BigDecimal.ONE);
        bigDecimalList.add(BigDecimal.TEN);
        bigDecimalList.add(new BigDecimal(2));
        BigDecimal ret = bigDecimalList.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
        System.out.println(ret);

        List<LocalDate> localDates = new ArrayList<>();
        localDates.add(LocalDate.now());
        localDates.add(LocalDate.parse("2018-07-03"));


        List<LocalDate> localDates1 = new ArrayList<>();
//        localDates1.add(LocalDate.now());
        localDates1.add(LocalDate.parse("2018-07-04"));
        System.out.println(localDates.containsAll(localDates1));

        Date date = new Date();
        System.out.println(date);
        System.out.println(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        System.out.println(Math.max(100, 101));
        LocalDate localDate = LocalDate.now();
        System.out.println("---->" + localDate);
        System.out.println(DateUtils.parseDate("2018-06-29 10:00:00", "yyyy-MM-dd HH:mm:ss"));
        LocalDateTime start = LocalDateTime.of(2018, 6, 8, 8, 8);
        LocalDateTime end = LocalDateTime.of(2018, 6, 9, 0, 8);
        System.out.println(Duration.between(start, end).toHours());
        System.out.println(Duration.between(start, end).toDays());
        System.out.println(Duration.between(start.toInstant(ZoneOffset.UTC), end.toInstant(ZoneOffset.UTC)));
    }

}
